#!/bin/sh
set -eu
# Explicit Linux paths bypass this workspace's Windows-forwarding node/npm shims.
if [ "$(uname -s)" != Linux ]; then
  echo 'Render on the Linux server only.' >&2
  exit 1
fi
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH
cd "$(dirname "$0")"
if [ ! -d node_modules/@napi-rs/canvas ]; then
  /usr/bin/node /usr/lib/node_modules/npm/bin/npm-cli.js ci --no-audit --no-fund
fi
PYTHONPATH="$PWD/.audio-deps${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONPATH
if ! /usr/bin/python3 -c 'import numpy' >/dev/null 2>&1; then
  /usr/bin/python3 -m pip install --target "$PWD/.audio-deps" 'numpy==2.5.3'
fi
/usr/bin/python3 audio.py --output output/soundtrack.wav
exec /usr/bin/node render.mjs "$@"
