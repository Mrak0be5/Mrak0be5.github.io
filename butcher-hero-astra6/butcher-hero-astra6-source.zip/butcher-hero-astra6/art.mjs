// Original, entirely procedural art for the Astra reel. Local units: 300 tall.
const INK='#111528', SKIN='#EB9E5B', SHADE='#B86F47', DEEP='#A33B29', LILAC='#8989E5';
const TAU=Math.PI*2;
function shape(c,pts,fill,stroke=INK,w=5){c.beginPath();for(let i=0;i<pts.length;i++){const p=pts[i];if(i===0)c.moveTo(p[0],p[1]);else c.lineTo(p[0],p[1]);}c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.lineJoin='round';c.stroke();}}
function path(c,fn,fill,stroke=INK,w=5){c.beginPath();fn(c);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.lineJoin='round';c.lineCap='round';c.stroke();}}
function ell(c,x,y,rx,ry,fill,stroke=null,w=3,rot=0){c.beginPath();c.ellipse(x,y,rx,ry,rot,0,TAU);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke();}}
function line(c,pts,col=INK,w=4){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.strokeStyle=col;c.lineWidth=w;c.lineCap='round';c.lineJoin='round';c.stroke();}
function rivet(c,x,y,r=3){ell(c,x,y,r,r,'#AFB6C9',INK,1.1);ell(c,x-0.8,y-0.8,r*.32,r*.32,'#E7F0F1');}
function stitch(c,points,w=2.5){line(c,points,'#623F3D',w);for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i];const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),n=Math.max(1,Math.round(len/8));for(let j=0;j<n;j++){const t=(j+.5)/n,x=a[0]+dx*t,y=a[1]+dy*t;line(c,[[x-dy/len*3-dx/len,y+dx/len*3-dy/len],[x+dy/len*3+dx/len,y-dx/len*3+dy/len]],'#402D32',2);}}}
function fist(c,side,sil=false){c.save();c.scale(side,1);path(c,p=>{p.moveTo(98,19);p.bezierCurveTo(117,14,140,35,143,52);p.lineTo(141,78);p.bezierCurveTo(136,94,116,93,105,85);p.lineTo(91,65);p.bezierCurveTo(83,58,90,41,98,40);p.closePath();},sil?INK:SKIN,INK,6);if(!sil){shape(c,[[113,28],[133,41],[141,55],[136,77],[126,84],[112,73],[115,57]],SHADE,null);path(c,p=>{p.moveTo(93,48);p.bezierCurveTo(106,35,115,46,113,59);p.lineTo(110,70);},null,INK,3);line(c,[[120,47],[121,66]],DEEP,3);line(c,[[130,48],[131,65]],DEEP,3);line(c,[[113,76],[124,80],[133,77]],DEEP,3);ell(c,106,30,7,3,'#FFD29B',null,0,-.5);stitch(c,[[101,76],[106,83],[118,87]],1.8);}c.restore();}
function mask(c,mouth=0,angry=false,sil=false,t=0){
  // The mohawk remains visible around the skull-shaped hockey mask.
  shape(c,[[-36,-109],[-31,-128],[-23,-121],[-20,-142],[-11,-132],[-4,-153],[6,-139],[15,-148],[22,-131],[31,-138],[34,-117],[42,-112],[34,-91],[-30,-88]],sil?INK:'#164D55',INK,5);
  if(!sil){shape(c,[[-15,-126],[-5,-143],[-2,-129],[8,-133],[6,-111],[-12,-109]],'#297B78',null);}
  path(c,p=>{p.moveTo(-39,-110);p.bezierCurveTo(-17,-128,22,-125,42,-105);p.lineTo(44,-69);p.bezierCurveTo(40,-43,20,-28,0,-27);p.bezierCurveTo(-24,-31,-44,-47,-45,-68);p.closePath();},sil?INK:'#ECD8AD',INK,6);
  if(sil){ell(c,-18,-84,9,3,'#E52C2A');ell(c,20,-84,9,3,'#E52C2A');return;}
  shape(c,[[22,-117],[40,-104],[43,-71],[34,-48],[16,-32],[3,-30],[12,-48],[20,-69]],'#B9ADAF',null);
  path(c,p=>{p.moveTo(-33,-106);p.bezierCurveTo(-16,-116,6,-117,16,-113);p.lineTo(9,-96);p.lineTo(-31,-91);p.closePath();},'#FFF0C5',null);
  // Chevrons are bold enough to read at thumbnail scale.
  shape(c,[[-19,-109],[0,-103],[21,-110],[11,-96],[0,-91],[-11,-95]],'#8D201C',null);
  shape(c,[[-38,-71],[-23,-61],[-31,-58],[-40,-65]],'#8D201C',null);
  shape(c,[[39,-70],[24,-60],[31,-57],[39,-63]],'#8D201C',null);
  path(c,p=>{p.moveTo(-33,-89);p.quadraticCurveTo(-20,-94,-7,angry?-83:-87);p.lineTo(-9,-76);p.quadraticCurveTo(-24,-71,-34,-77);p.closePath();},'#252137',null);
  path(c,p=>{p.moveTo(7,angry?-83:-87);p.quadraticCurveTo(23,-94,34,-87);p.lineTo(33,-75);p.quadraticCurveTo(18,-72,9,-76);p.closePath();},'#252137',null);
  ell(c,-21,-81,7,3.4,'#FF3338');ell(c,21,-81,7,3.4,'#FF3338');ell(c,-20,-81,2,2,'#FFE8BA');ell(c,20,-81,2,2,'#FFE8BA');
  shape(c,[[-3,-78],[-8,-64],[0,-60],[8,-64],[4,-77]],'#726776',null);
  for(const s of [-1,1])for(let i=0;i<3;i++)ell(c,s*(14+i*7),-53+i*4,1.8,2.5,'#3E3844');
  // A hinged jaw creates a readable bite instead of a generic face scale.
  if(mouth>.01){const open=Math.max(0,Math.min(1,mouth));path(c,p=>{p.moveTo(-29,-51);p.quadraticCurveTo(0,-41,30,-51);p.quadraticCurveTo(29,-15+open*28,0,-12+open*30);p.quadraticCurveTo(-28,-16+open*25,-29,-51);p.closePath();},'#240E23',INK,4);for(let i=0;i<6;i++){let x=-23+i*8;shape(c,[[x,-47],[x+7,-45],[x+5,-36],[x+1,-37]],'#F6DEB6',null);}ell(c,1,-22+open*24,17,7,'#CE3F54');for(let i=0;i<5;i++){let x=-20+i*9;shape(c,[[x,-15+open*26],[x+3,-25+open*26],[x+8,-15+open*26]],'#F6DEB6',null);}path(c,p=>{p.moveTo(-29,-24+open*27);p.quadraticCurveTo(0,-3+open*28,29,-24+open*27);p.lineTo(21,-12+open*27);p.quadraticCurveTo(0,open*28,-21,-12+open*27);p.closePath();},'#C4B193',INK,3);}else{path(c,p=>{p.moveTo(-17,-41);p.quadraticCurveTo(0,-32,18,-42);},null,'#776A64',3);}
  rivet(c,-38,-101,2.5);rivet(c,38,-101,2.5);rivet(c,-33,-53,2.5);rivet(c,32,-52,2.5);
}

export function drawHero(c,x,y,size,opt={}){
  const t=opt.time||0,back=!!opt.back,sil=!!opt.silhouette;
  c.save();c.translate(x,y);c.scale(size/300,size/300);if(opt.flip)c.scale(-1,1);
  if(opt.weapons){const positions=[[-134,-108,'iceaxe'],[128,-112,'greenaxe'],[-130,28,'sword'],[140,23,'hammer']];for(const [wx,wy,wt] of positions){drawChain(c,0,-25,wx,wy,{sag:28,width:5,time:t});drawWeapon(c,wx,wy,112,wt,wx<0?-.5:.5);}}
  // Bare feet, short bowed legs, and torn navy shorts anchor the weight.
  for(const s of [-1,1]){c.save();c.scale(s,1);path(c,p=>{p.moveTo(25,95);p.lineTo(68,91);p.lineTo(72,124);p.lineTo(86,137);p.quadraticCurveTo(88,148,77,148);p.lineTo(27,148);p.quadraticCurveTo(17,144,21,134);p.lineTo(24,118);p.closePath();},sil?INK:SKIN,INK,6);if(!sil){shape(c,[[54,108],[67,108],[71,127],[84,139],[78,146],[47,146],[53,134]],SHADE,null);line(c,[[66,136],[66,145]],DEEP,2);line(c,[[76,139],[76,145]],DEEP,2);line(c,[[31,126],[42,130]],DEEP,3);}c.restore();}
  path(c,p=>{p.moveTo(-83,65);p.lineTo(83,65);p.lineTo(79,111);p.lineTo(68,107);p.lineTo(61,122);p.lineTo(50,115);p.lineTo(38,123);p.lineTo(9,115);p.lineTo(0,95);p.lineTo(-11,116);p.lineTo(-38,123);p.lineTo(-52,113);p.lineTo(-64,122);p.lineTo(-69,108);p.lineTo(-83,114);p.closePath();},sil?INK:'#263452',INK,6);
  if(!sil){shape(c,[[-74,84],[-8,88],[-12,111],[-37,119],[-53,111],[-65,117],[-68,107],[-77,110]],'#3D466B',null);shape(c,[[9,89],[76,85],[73,108],[62,119],[50,112],[38,118],[14,109]],'#1B223C',null);line(c,[[-53,95],[-45,110]],'#687593',2);line(c,[[47,93],[38,109]],'#687593',2);}
  // Upper arms sit behind a single broad pear-shaped torso.
  for(const s of [-1,1]){c.save();c.scale(s,1);path(c,p=>{p.moveTo(61,-61);p.bezierCurveTo(89,-70,113,-55,120,-30);p.lineTo(133,24);p.quadraticCurveTo(123,51,99,45);p.lineTo(74,15);p.lineTo(60,-19);p.closePath();},sil?INK:SKIN,INK,6);if(!sil){path(c,p=>{p.moveTo(99,-52);p.quadraticCurveTo(118,-35,121,-15);p.lineTo(131,24);p.quadraticCurveTo(120,42,109,35);p.lineTo(102,4);p.lineTo(82,-11);p.closePath();},SHADE,null);ell(c,88,-38,17,10,'#F7B971',null,0,-.3);line(c,[[90,-16],[104,-8],[110,7]],DEEP,3);stitch(c,[[85,-42],[99,-29],[111,-23]],2);}c.restore();}
  path(c,p=>{p.moveTo(-54,-65);p.bezierCurveTo(-84,-60,-92,-37,-95,0);p.bezierCurveTo(-117,46,-102,83,-75,91);p.bezierCurveTo(-39,105,37,105,76,91);p.bezierCurveTo(104,78,113,48,96,2);p.bezierCurveTo(94,-36,82,-57,53,-65);p.bezierCurveTo(24,-82,-23,-82,-54,-65);p.closePath();},sil?INK:SKIN,INK,7);
  if(!sil){path(c,p=>{p.moveTo(47,-66);p.bezierCurveTo(90,-59,89,-21,91,6);p.bezierCurveTo(113,55,95,82,74,90);p.bezierCurveTo(34,107,-38,101,-69,90);p.bezierCurveTo(-1,91,42,77,56,57);p.bezierCurveTo(74,22,55,-11,47,-66);p.closePath();},SHADE,null);path(c,p=>{p.moveTo(75,-37);p.bezierCurveTo(86,-12,100,14,97,42);p.bezierCurveTo(87,54,80,61,73,60);p.bezierCurveTo(76,16,65,-5,65,-28);p.closePath();},'#A37069',null);path(c,p=>{p.moveTo(-55,-39);p.bezierCurveTo(-34,-55,18,-49,34,-33);p.bezierCurveTo(13,-35,-6,-17,-16,-2);p.bezierCurveTo(-34,-14,-56,-13,-69,-7);p.quadraticCurveTo(-70,-23,-55,-39);p.closePath();},'#FFC181',null);path(c,p=>{p.moveTo(-53,9);p.bezierCurveTo(-15,-7,26,10,35,43);p.bezierCurveTo(11,29,-26,29,-53,42);p.quadraticCurveTo(-67,33,-53,9);p.closePath();},'#F5AD68',null);}
  if(back){
    if(!sil){
      // Five overlapping riveted plates form the weapon mounting harness.
      shape(c,[[-58,-51],[0,-69],[57,-52],[48,-4],[1,18],[-51,-2]],'#424C68',INK,5);
      shape(c,[[-56,-49],[-10,-60],[-9,-15],[-47,-5]],'#778199',INK,3);
      shape(c,[[8,-60],[53,-49],[47,-5],[8,-15]],'#606C8A',INK,3);
      shape(c,[[-44,2],[0,22],[43,2],[39,38],[0,56],[-40,37]],'#4C5776',INK,5);
      shape(c,[[-32,43],[0,59],[33,43],[26,69],[0,82],[-29,67]],'#626D88',INK,4);
      shape(c,[[-3,-62],[5,-62],[6,72],[-3,75]],'#1F2A43',null);
      for(const s of [-1,1]){rivet(c,s*43,-41,4);rivet(c,s*35,-13,4);rivet(c,s*31,17,4);rivet(c,s*26,34,4);rivet(c,s*20,60,3.5);ell(c,s*57,-28,9,11,'#1E2941',INK,3);ell(c,s*57,-28,4,6,'#A0AEC3');}
      line(c,[[-45,-44],[-18,-51]],'#ABB6C6',3);line(c,[[17,-49],[41,-42]],'#A4ACC3',3);
      stitch(c,[[-78,11],[-64,28],[-65,58]],2.5);stitch(c,[[72,8],[63,29],[72,52]],2.5);
    }
    shape(c,[[-34,-74],[-40,-103],[-29,-116],[-23,-136],[-15,-125],[-5,-151],[3,-134],[16,-142],[23,-125],[33,-130],[36,-105],[31,-76]],sil?INK:'#194F56',INK,5);
    if(!sil){shape(c,[[-27,-105],[-8,-129],[-10,-86],[7,-116],[12,-76],[-9,-71]],'#2F7678',null);line(c,[[-28,-92],[-18,-72],[15,-68],[32,-90]],'#A66D45',5);}
  }else{
    if(!sil){
      // Chest stitches follow a deliberate diagonal incision, with an offset navel.
      stitch(c,[[-62,-31],[-38,-13],[-22,9],[1,26],[25,50],[57,61]],3);
      stitch(c,[[40,-28],[33,-12],[43,4]],2);
      ell(c,0,62,5,4,'#8B4B39');path(c,p=>{p.moveTo(-9,69);p.quadraticCurveTo(0,74,9,69);},null,'#C47B4B',2);
      ell(c,-53,-18,4,3,'#C7744E');ell(c,49,-18,4,3,'#AB6046');
      line(c,[[-55,81],[-36,87],[-14,90]],'#B76C42',3);
    }
    mask(c,opt.mouth||0,!!opt.angry,sil,t);
  }
  fist(c,-1,sil);fist(c,1,sil);
  if(opt.chainsaw&&!back)drawWeapon(c,99,27,146,'chainsaw',-.72);
  c.restore();
}

export function drawChain(c,x1,y1,x2,y2,opt={}){
  const width=opt.width||5,sag=opt.sag??20,time=opt.time||0,dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy),n=Math.max(3,Math.ceil(len/(width*2)));
  const points=[];for(let i=0;i<=n;i++){const q=i/n;points.push([x1+dx*q+Math.sin(q*Math.PI*3-time*7)*Math.sin(q*Math.PI)*sag*.14,y1+dy*q+Math.sin(q*Math.PI)*sag]);}
  line(c,points,INK,width*1.8);
  for(let i=1;i<=n;i++){const a=points[i-1],b=points[i],x=(a[0]+b[0])/2,y=(a[1]+b[1])/2,ang=Math.atan2(b[1]-a[1],b[0]-a[0]);c.save();c.translate(x,y);c.rotate(ang);ell(c,0,0,width*1.15,width*(i%2?.58:.34),opt.color||'#637397',INK,width*.26);if(i%2)ell(c,0,0,width*.65,width*.18,INK);line(c,[[-width*.6,-width*.25],[width*.4,-width*.25]],'#A8B6CC',width*.17);c.restore();}
}

export function drawWeapon(c,x,y,size,type='hammer',angle=0){
 c.save();c.translate(x,y);c.rotate(angle);c.scale(size/300,size/300);c.lineJoin='round';
 if(type==='hook'){
  ell(c,0,129,15,20,'#65758C',INK,5);ell(c,0,129,7,12,INK);
  path(c,p=>{p.moveTo(-11,122);p.lineTo(-12,-34);p.bezierCurveTo(-15,-116,48,-157,93,-120);p.bezierCurveTo(131,-93,120,-39,77,-24);p.lineTo(90,-63);p.lineTo(86,-93);p.bezierCurveTo(70,-118,34,-96,31,-56);p.lineTo(17,119);p.closePath();},'#FFB47E',INK,7);
  path(c,p=>{p.moveTo(-5,109);p.lineTo(-3,-40);p.bezierCurveTo(-4,-99,39,-133,72,-120);},null,'#FFE0AF',8);
  shape(c,[[77,-24],[90,-63],[86,-93],[98,-77],[97,-50]],'#B74322',null);
 }else if(type==='chainsaw'){
  // Thick saw body and mechanically distinct teeth around the complete blade.
  path(c,p=>{p.moveTo(-25,64);p.lineTo(-30,-110);p.quadraticCurveTo(0,-158,31,-110);p.lineTo(29,64);p.closePath();},'#ADB7BA',INK,7);
  for(let k=0;k<12;k++){let yy=-106+k*13;shape(c,[[-29,yy],[-41,yy+7],[-28,yy+11]],'#F2DEB8',INK,2);shape(c,[[29,yy],[41,yy+7],[28,yy+11]],'#F2DEB8',INK,2);}
  shape(c,[[-18,-118],[0,-136],[18,-118],[17,52],[-16,52]],'#525E71',INK,3);line(c,[[0,-118],[0,50]],'#D6E0D5',3);
  path(c,p=>{p.moveTo(-53,72);p.lineTo(-53,107);p.quadraticCurveTo(-51,123,-30,123);p.lineTo(-14,111);p.lineTo(-15,76);p.closePath();},'#293548',INK,6);
  shape(c,[[-41,43],[34,43],[49,60],[46,113],[26,139],[-30,139],[-48,117],[-51,62]],'#F2B622',INK,7);
  shape(c,[[31,52],[45,65],[43,109],[25,132],[4,132],[18,114],[18,55]],'#B45A22',null);
  shape(c,[[-35,58],[9,57],[12,104],[-33,103]],'#D7472A',INK,3);
  for(let j=0;j<4;j++)line(c,[[-28,67+j*8],[3,67+j*8]],'#6A322E',4);
  ell(c,28,81,8,8,'#302D33',INK,2);rivet(c,-35,120,4);rivet(c,28,116,4);
  line(c,[[-45,39],[-51,21],[34,21],[41,42]],INK,8);
 }else{
  // All carried weapons share a leather-wrapped shaft with a chain attachment.
  shape(c,[[-9,-65],[9,-65],[12,127],[0,143],[-12,127]],'#774A41',INK,5);
  shape(c,[[2,-65],[8,-65],[10,127],[0,138],[-2,127]],'#B88B64',null);
  for(let i=0;i<7;i++)line(c,[[-10,54+i*10],[10,47+i*10]],'#27334B',5);
  ell(c,0,137,10,13,'#70849D',INK,4);ell(c,0,138,4,6,INK);
  if(type==='hammer'){
   shape(c,[[-97,-118],[74,-118],[100,-98],[99,-34],[73,-12],[-96,-15],[-119,-35],[-119,-94]],'#8957BF',INK,7);
   shape(c,[[-95,-118],[-74,-93],[-74,-36],[-97,-15],[-119,-35],[-119,-94]],'#5E427B',INK,4);
   shape(c,[[-71,-91],[75,-93],[74,-36],[-70,-36]],'#B98FF0',INK,4);
   shape(c,[[-95,-117],[75,-117],[99,-97],[-73,-93]],'#E2BFFF',INK,4);
   shape(c,[[74,-117],[99,-98],[99,-34],[73,-13],[73,-93]],'#6E4E9B',INK,4);
   shape(c,[[-43,-83],[-23,-106],[1,-89],[21,-108],[46,-81],[35,-51],[9,-44],[-17,-53],[-41,-43]],'#CBACFF',INK,3);
   line(c,[[-21,-99],[-10,-75],[8,-69],[14,-51]],'#F6DCFF',5);
   shape(c,[[-11,-17],[13,-17],[22,-1],[17,14],[-17,14],[-22,-1]],'#D5B573',INK,4);
  }else if(type==='iceaxe'||type==='greenaxe'){
   const ice=type==='iceaxe',base=ice?'#63CBE1':'#58B96C',hi=ice?'#C8F5F2':'#B7EC82',shade=ice?'#4385AA':'#316849';
   for(const side of [-1,1]){c.save();c.scale(side,1);shape(c,[[11,-101],[58,-102],[107,-145],[96,-83],[122,-30],[65,-14],[23,-49]],base,INK,7);shape(c,[[58,-102],[107,-145],[95,-93],[80,-64],[111,-32],[70,-39],[48,-70]],hi,null);shape(c,[[23,-93],[57,-94],[49,-71],[70,-38],[65,-15],[22,-50]],shade,null);line(c,[[63,-91],[74,-74],[62,-58]],ice?'#E8FFFF':'#D6F7B1',3);c.restore();}
   shape(c,[[-15,-110],[15,-110],[22,-83],[14,-48],[-15,-48],[-23,-82]],'#98ADB9',INK,5);ell(c,0,-81,7,10,hi,INK,3);
  }else if(type==='sword'){
   shape(c,[[0,-157],[30,-107],[23,30],[-24,30],[-30,-107]],'#E3BA4D',INK,6);shape(c,[[0,-150],[0,28],[-23,28],[-26,-105]],'#FFE99A',null);shape(c,[[0,-147],[25,-105],[20,27],[8,27]],'#C08432',null);line(c,[[0,-127],[0,20]],'#FFF4BA',3);
   shape(c,[[-68,20],[-56,9],[-25,18],[0,10],[24,18],[56,9],[68,20],[61,39],[30,33],[13,45],[-12,45],[-31,33],[-61,39]],'#E0B65A',INK,5);ell(c,0,28,10,10,'#E3623E',INK,3);
  }
 }
 c.restore();
}

function rock(c,points,col='#605974',light=true){shape(c,points,col,INK,5);if(light&&points.length>=4){const a=points[0],b=points[1],d=points[points.length-1];shape(c,[a,b,[(b[0]+d[0])/2,(b[1]+d[1])/2],d],'#89829A',null);}}
function lavaCrack(c,points,width=4){line(c,points,'#9B220D',width+4);line(c,points,'#FF6621',width);line(c,points,'#FFC057',Math.max(1,width*.3));}
function golem(c,ice=false,opt={}){
 const a=ice?'#579CAE':'#62596F',b=ice?'#8ED9E1':'#776C86',d=ice?'#376F93':'#3F405C',hot=ice?'#C8FFFF':'#FF6821';
 // Stacked leg stones are individually outlined, not a rectangle silhouette.
 for(const s of [-1,1]){c.save();c.scale(s,1);rock(c,[[20,54],[70,48],[84,88],[65,113],[25,108],[12,82]],d,false);rock(c,[[28,109],[70,101],[85,126],[92,145],[73,152],[15,152],[12,135]],a);rock(c,[[82,-67],[123,-77],[148,-44],[143,-5],[112,14],[86,-12]],a);rock(c,[[109,9],[145,-4],[162,26],[157,63],[134,80],[107,63],[99,34]],d,false);rock(c,[[114,53],[152,51],[166,72],[164,104],[146,117],[111,105],[101,83]],b);line(c,[[123,83],[128,102]],INK,3);line(c,[[142,80],[147,102]],INK,3);if(!ice){lavaCrack(c,[[129,-57],[116,-33],[132,-16],[125,3]],3);lavaCrack(c,[[143,12],[126,28],[133,47]],3);lavaCrack(c,[[38,119],[49,127],[43,145]],3);}else{shape(c,[[101,-64],[130,-103],[136,-68],[124,-53]],'#CAF4EF',INK,4);shape(c,[[146,30],[174,9],[166,53],[151,61]],'#85DDE1',INK,4);}c.restore();}
 rock(c,[[-72,-77],[-21,-102],[35,-98],[83,-75],[101,-20],[84,42],[57,75],[9,91],[-47,77],[-83,38],[-98,-18]],a,false);
 rock(c,[[-68,-66],[-16,-88],[-3,-19],[-49,7],[-83,-16]],b);rock(c,[[10,-86],[65,-67],[85,-21],[43,8],[0,-19]],d,false);
 rock(c,[[-50,18],[-7,-11],[42,17],[42,58],[7,79],[-44,59]],b,false);rock(c,[[-82,0],[-53,14],[-45,56],[-73,41],[-89,18]],d,false);
 if(!ice){lavaCrack(c,[[-66,-65],[-42,-46],[-47,-22],[-14,-9],[-23,24],[-1,42],[-7,71]],5);lavaCrack(c,[[40,-74],[27,-47],[44,-22],[23,-3],[45,20]],5);lavaCrack(c,[[-17,-8],[12,-17],[27,-47]],3);lavaCrack(c,[[-22,25],[-49,28],[-64,48]],3);lavaCrack(c,[[45,22],[71,20],[82,37]],4);}else{line(c,[[-60,-62],[-23,-40],[-38,-10],[-8,23],[-13,64]],'#D4FFFF',5);line(c,[[48,-69],[32,-39],[57,-8],[33,28]],'#C9FFFF',4);shape(c,[[-19,-54],[6,-29],[-11,6],[-32,-15]],'#A4EDF2',null);}
 // Inset head framed by two massive shoulder rocks.
 rock(c,[[-46,-139],[-16,-156],[26,-152],[52,-123],[47,-79],[18,-62],[-25,-68],[-48,-94]],d,false);
 rock(c,[[-43,-131],[-18,-146],[8,-142],[-4,-111],[-38,-103]],b);rock(c,[[8,-141],[30,-141],[46,-120],[34,-102],[3,-111]],a,false);
 shape(c,[[-37,-108],[-10,-106],[-7,-94],[-31,-95]],INK,null);shape(c,[[8,-106],[36,-109],[29,-95],[10,-95]],INK,null);
 line(c,[[-30,-101],[-14,-99]],hot,5);line(c,[[14,-99],[29,-102]],hot,5);
 shape(c,[[-28,-87],[-12,-90],[0,-84],[12,-90],[30,-86],[23,-72],[-17,-72]],INK,null);
 for(let j=0;j<4;j++)shape(c,[[-20+j*12,-86],[-15+j*12,-86],[-16+j*12,-77]],hot,null);
 if(!ice)lavaCrack(c,[[2,-146],[-5,-127],[3,-115]],3);else shape(c,[[-5,-157],[8,-178],[17,-150],[4,-138]],'#D1FFFF',INK,3);
}

function warrior(c,opt={}){
 const col=opt.red===false?'#84909D':'#B83749';
 // Long side spikes, tapered helmet and crimson armor convey expendable cult troops.
 line(c,[[-58,-19],[-105,80]],'#66565D',9);shape(c,[[-106,82],[-125,110],[-128,75],[-101,45],[-95,57]],'#ABB5C2',INK,5);
 for(const s of [-1,1]){c.save();c.scale(s,1);shape(c,[[13,66],[44,68],[50,127],[63,141],[58,149],[11,149],[7,136]],'#263149',INK,6);shape(c,[[39,-44],[72,-36],[90,22],[77,44],[53,27],[41,-3]],col,INK,6);shape(c,[[69,26],[87,30],[89,58],[79,68],[60,56],[60,37]],'#AC846F',INK,4);shape(c,[[44,-48],[73,-48],[91,-24],[64,-16],[39,-25]],'#D14F58',INK,5);shape(c,[[48,-49],[65,-69],[69,-48]],'#D8D5C8',INK,3);c.restore();}
 shape(c,[[-40,-52],[39,-52],[51,35],[43,86],[20,93],[0,78],[-24,93],[-47,82],[-53,30]],col,INK,6);
 shape(c,[[0,-49],[39,-44],[47,31],[33,43],[37,78],[17,86],[0,72]],'#792C42',null);
 shape(c,[[-29,-33],[-3,-24],[-8,24],[-36,9]],'#DD6266',null);
 shape(c,[[-52,35],[48,35],[45,51],[-48,51]],'#30314C',INK,3);shape(c,[[-8,35],[9,35],[11,53],[-10,53]],'#C49A66',INK,2);
 shape(c,[[-15,-15],[0,-3],[15,-15],[13,8],[0,22],[-13,8]],'#E4B292',INK,3);
 shape(c,[[-34,-105],[-17,-131],[17,-133],[36,-107],[38,-67],[23,-47],[-20,-48],[-38,-69]],'#5D5268',INK,6);
 shape(c,[[-33,-107],[-14,-124],[0,-125],[0,-55],[-21,-55],[-31,-73]],'#998C9A',null);
 shape(c,[[-38,-107],[-62,-132],[-58,-89],[-36,-78]],'#D8CFC1',INK,5);shape(c,[[37,-108],[61,-133],[59,-89],[37,-77]],'#D8CFC1',INK,5);
 shape(c,[[-31,-91],[-6,-84],[-7,-72],[-31,-79]],INK,null);shape(c,[[6,-84],[31,-91],[30,-78],[7,-72]],INK,null);
 line(c,[[-24,-83],[-12,-79]],'#FF6A5C',3);line(c,[[12,-79],[24,-83]],'#FF6A5C',3);
 shape(c,[[-7,-99],[7,-99],[12,-63],[0,-52],[-12,-63]],'#BCABA5',INK,3);
 shape(c,[[-13,-130],[-8,-151],[4,-160],[14,-138],[9,-122]],'#D84A4D',INK,4);
}

function bear(c,opt={}){
 const brown='#AC7660';
 for(const s of [-1,1]){c.save();c.scale(s,1);ell(c,50,111,31,36,'#765163',INK,6);ell(c,77,27,31,59,brown,INK,6,-.35);for(let i=0;i<3;i++)shape(c,[[74+i*9,74],[82+i*9,73],[79+i*9,90]],'#ECD8AD',INK,2);c.restore();}
 path(c,p=>{p.moveTo(-51,-55);p.bezierCurveTo(-86,-21,-84,82,-52,112);p.quadraticCurveTo(0,135,53,111);p.bezierCurveTo(88,62,76,-15,47,-56);p.closePath();},brown,INK,7);
 ell(c,0,49,45,58,'#D7A586');ell(c,-40,-102,22,25,'#996D69',INK,6);ell(c,40,-102,22,25,'#996D69',INK,6);ell(c,-40,-102,10,12,'#543B51');ell(c,40,-102,10,12,'#543B51');
 path(c,p=>{p.moveTo(-57,-98);p.quadraticCurveTo(0,-139,54,-100);p.lineTo(63,-48);p.quadraticCurveTo(48,-6,0,-10);p.quadraticCurveTo(-51,-12,-64,-46);p.closePath();},brown,INK,6);
 shape(c,[[21,-117],[53,-100],[62,-48],[45,-20],[14,-11],[30,-42]],'#775260',null);
 ell(c,0,-43,35,25,'#D9B493',INK,3);shape(c,[[-15,-54],[14,-54],[10,-41],[0,-35],[-12,-43]],INK,null);
 for(const s of [-1,1]){line(c,[[s*12,-78],[s*34,-84]],'#3C2936',7);ell(c,s*24,-71,4,5,'#FBDF80');shape(c,[[s*21,-24],[s*12,-22],[s*18,-4]],'#F6E4B4',INK,2);}line(c,[[0,-36],[0,-23],[-11,-18]],'#503344',3);
}

function dragon(c,opt={}){
 const flap=Math.sin((opt.time||0)*5)*6;
 for(const s of [-1,1]){c.save();c.scale(s,1);path(c,p=>{p.moveTo(35,-45);p.lineTo(139,-102+flap);p.lineTo(117,-18);p.quadraticCurveTo(95,-42,74,4);p.quadraticCurveTo(53,-15,36,34);p.closePath();},'#3D8890',INK,6);line(c,[[35,-44],[118,-79+flap],[75,2]],'#74C8BD',4);line(c,[[35,-44],[107,-53]],'#74C8BD',3);ell(c,36,116,22,28,'#43828A',INK,5);shape(c,[[23,130],[28,147],[35,132],[42,147],[47,130]],'#E4D9B0',INK,3);c.restore();}
 path(c,p=>{p.moveTo(37,80);p.bezierCurveTo(102,108,97,144,149,108);p.bezierCurveTo(126,153,78,157,24,119);p.closePath();},'#4B9790',INK,5);
 ell(c,0,47,62,83,'#55A79D',INK,6);ell(c,-8,50,35,64,'#BCD5A4');for(let i=0;i<5;i++)line(c,[[-34,16+i*20],[18,22+i*20]],'#87A589',3);
 shape(c,[[-43,-120],[-43,-150],[-20,-125],[4,-151],[18,-119],[47,-141],[48,-99]],'#C6D6AA',INK,5);
 path(c,p=>{p.moveTo(-47,-117);p.quadraticCurveTo(6,-146,48,-112);p.lineTo(52,-70);p.lineTo(73,-43);p.quadraticCurveTo(47,-7,-4,-14);p.quadraticCurveTo(-53,-27,-57,-64);p.closePath();},'#56A69A',INK,6);
 shape(c,[[16,-123],[46,-111],[49,-72],[69,-45],[52,-23],[17,-17],[36,-54]],'#347C86',null);
 ell(c,-24,-83,13,12,'#ECDD78',INK,3);ell(c,24,-83,13,12,'#ECDD78',INK,3);line(c,[[-22,-90],[-22,-76]],INK,4);line(c,[[25,-91],[25,-76]],INK,4);
 line(c,[[-39,-96],[-13,-91]],INK,5);line(c,[[12,-93],[37,-99]],INK,5);
 path(c,p=>{p.moveTo(-31,-42);p.quadraticCurveTo(11,-22,52,-40);},null,INK,4);shape(c,[[-16,-37],[-6,-32],[-10,-18]],'#F4E5AD',INK,2);ell(c,-6,-54,4,3,'#28535B');ell(c,15,-55,4,3,'#28535B');
}

function zombie(c,opt={}){
 for(const s of [-1,1]){c.save();c.scale(s,1);shape(c,[[12,49],[38,50],[37,111],[48,143],[9,145],[4,127]],'#3A4560',INK,5);shape(c,[[31,-51],[58,-37],[81,15],[95,2],[105,10],[98,40],[80,52],[48,15]],'#799C75',INK,5);line(c,[[87,13],[87,32]],'#405A61',3);c.restore();}
 shape(c,[[-32,-58],[35,-57],[43,47],[29,77],[11,63],[-5,82],[-20,68],[-41,71],[-43,2]],'#6E4D72',INK,6);shape(c,[[-20,-50],[-2,-29],[-4,49],[-27,57],[-34,-9]],'#A9828C',null);shape(c,[[4,-35],[31,-47],[31,8],[9,21]],'#8FAA76',INK,2);line(c,[[9,-22],[26,-24]],'#415F5B',3);line(c,[[8,-11],[27,-12]],'#415F5B',3);line(c,[[9,0],[26,-2]],'#415F5B',3);
 path(c,p=>{p.moveTo(-38,-114);p.lineTo(-18,-140);p.lineTo(26,-134);p.lineTo(43,-111);p.lineTo(38,-66);p.lineTo(18,-41);p.lineTo(-27,-52);p.lineTo(-44,-82);p.closePath();},'#91AA7D',INK,6);
 shape(c,[[22,-133],[42,-111],[37,-67],[18,-42],[2,-46],[16,-78]],'#5C7870',null);shape(c,[[-39,-114],[-30,-135],[-9,-141],[3,-129],[18,-138],[28,-124],[11,-116]],'#38485A',INK,3);
 ell(c,-20,-96,12,13,'#37415A');ell(c,22,-94,12,12,'#37415A');ell(c,-18,-94,6,6,'#EAED8C');ell(c,22,-95,4,4,'#EDE692');shape(c,[[0,-87],[-7,-73],[7,-74]],'#465359',null);
 shape(c,[[-24,-67],[21,-62],[14,-48],[-20,-55]],'#2B2B3D',INK,2);for(let i=0;i<4;i++)shape(c,[[-18+i*9,-65],[-12+i*9,-64],[-13+i*9,-58]],'#D4D5A4',null);stitch(c,[[-32,-113],[-10,-119],[5,-114]],2);
}

function vampire(c,opt={}){
 // A wide torn cloak and tall filigree crown make the boss recognizable from far away.
 const wave=Math.sin((opt.time||0)*3)*5;
 path(c,p=>{p.moveTo(-47,-61);p.lineTo(-91,-90);p.lineTo(-77,-21);p.lineTo(-105,132);p.lineTo(-67,117);p.lineTo(-53,145);p.lineTo(-21,125);p.lineTo(0,150);p.lineTo(25,127);p.lineTo(56,145);p.lineTo(71,119);p.lineTo(109+wave,130);p.lineTo(77,-27);p.lineTo(91,-89);p.lineTo(44,-63);p.closePath();},'#492D56',INK,6);
 shape(c,[[-74,-76],[-39,-57],[-27,31],[-61,127],[-83,126],[-67,19]],'#B63E55',null);shape(c,[[75,-76],[40,-57],[27,32],[61,127],[86,128],[68,19]],'#7B2B50',null);
 for(const s of [-1,1]){c.save();c.scale(s,1);shape(c,[[13,64],[35,63],[30,132],[43,147],[7,147],[4,126]],'#232740',INK,5);shape(c,[[29,-43],[48,-48],[82,-1],[91,-19],[104,-12],[93,22],[77,30],[38,6]],'#4F455F',INK,5);shape(c,[[88,-20],[91,-39],[97,-31],[101,-47],[106,-32],[116,-42],[114,-22],[104,-9],[93,-10]],'#C3B9C9',INK,3);c.restore();}
 shape(c,[[-32,-52],[30,-52],[38,30],[28,81],[0,99],[-30,80],[-39,29]],'#303348',INK,5);shape(c,[[-19,-52],[0,-38],[20,-52],[12,36],[0,50],[-15,35]],'#D6C8C4',INK,3);shape(c,[[-12,-49],[0,-35],[13,-49],[9,-21],[-8,-21]],'#BF3355',INK,3);shape(c,[[-3,-18],[4,-18],[12,41],[0,55],[-12,40]],'#AC2C4D',INK,3);for(let j=0;j<3;j++)rivet(c,-20,4+j*18,2.4);
 path(c,p=>{p.moveTo(-34,-117);p.quadraticCurveTo(0,-138,32,-118);p.lineTo(29,-80);p.lineTo(12,-55);p.lineTo(-11,-56);p.lineTo(-29,-78);p.closePath();},'#C6C2D5',INK,5);
 shape(c,[[14,-127],[31,-117],[29,-80],[12,-56],[0,-57],[10,-78]],'#8F88A8',null);shape(c,[[-36,-121],[-25,-138],[0,-144],[25,-138],[36,-117],[31,-98],[21,-113],[2,-109],[-7,-119],[-27,-105],[-31,-87]],'#26293D',INK,4);
 shape(c,[[-25,-90],[-8,-87],[-12,-82],[-24,-82]],'#EB414A',null);shape(c,[[8,-87],[25,-90],[22,-82],[11,-82]],'#EB414A',null);shape(c,[[-4,-87],[-7,-75],[4,-72]],'#777185',null);line(c,[[-16,-69],[14,-69]],'#4E334C',4);shape(c,[[-13,-70],[-7,-70],[-9,-59]],'#FBE5C1',null);shape(c,[[7,-70],[13,-70],[9,-59]],'#FBE5C1',null);
 shape(c,[[-37,-126],[-42,-156],[-24,-146],[-19,-169],[0,-149],[20,-170],[26,-145],[42,-156],[36,-126]],'#BF9554',INK,5);shape(c,[[-34,-131],[33,-131],[31,-120],[-32,-120]],'#EBBD62',INK,3);ell(c,0,-137,7,9,'#D72E47',INK,2);
}

function crab(c,opt={}){
 const twitch=Math.sin((opt.time||0)*5)*4;
 for(const s of [-1,1]){c.save();c.scale(s,1);for(let i=0;i<3;i++)line(c,[[45,40+i*17],[95+i*10,54+i*18],[122+i*7,94+i*14+twitch]],INK,15);for(let i=0;i<3;i++)line(c,[[45,40+i*17],[95+i*10,54+i*18],[122+i*7,94+i*14+twitch]],'#CB6853',8);line(c,[[55,12],[95,-4],[113,-29]],'#5E3B4E',20);line(c,[[55,12],[95,-4],[113,-29]],'#D77F58',12);path(c,p=>{p.moveTo(99,-24);p.lineTo(87,-57);p.lineTo(99,-98);p.lineTo(116,-77);p.lineTo(116,-50);p.lineTo(137,-81);p.lineTo(151,-62);p.lineTo(142,-20);p.lineTo(119,-6);p.closePath();},'#D67F58',INK,6);shape(c,[[99,-92],[109,-78],[109,-52],[100,-65]],'#F7BB76',null);c.restore();}
 path(c,p=>{p.moveTo(-71,4);p.quadraticCurveTo(-64,-35,0,-39);p.quadraticCurveTo(63,-34,75,7);p.lineTo(64,67);p.quadraticCurveTo(0,112,-64,68);p.closePath();},'#B85653',INK,6);shape(c,[[1,-35],[63,-20],[74,6],[65,64],[15,90],[25,43]],'#8A3E50',null);shape(c,[[-61,11],[-33,-12],[1,-23],[18,2],[-8,35],[-51,47]],'#E68E60',null);
 for(const s of [-1,1]){line(c,[[s*25,13],[s*34,-36]],'#793D4A',12);ell(c,s*35,-41,12,15,'#DCC49A',INK,4);ell(c,s*33,-43,5,9,INK);}
 line(c,[[-18,64],[0,72],[18,64]],INK,4);
 // Three strapped explosive sticks, fuse, and little skull warning mark.
 for(let i=0;i<3;i++){c.save();c.translate(-23+i*22,-42);c.rotate((i-1)*.08);path(c,p=>{p.moveTo(-10,9);p.lineTo(-11,-47);p.quadraticCurveTo(0,-59,11,-47);p.lineTo(10,9);p.closePath();},'#D9423E',INK,4);line(c,[[-6,-43],[-6,1]],'#F67E55',3);c.restore();}
 shape(c,[[-39,-62],[39,-63],[39,-49],[-39,-48]],'#3F4052',INK,3);line(c,[[2,-93],[8,-107],[23,-112],[31,-101]],'#C5A779',3);ell(c,32,-100,4,4,'#FFC552');
}

function berserker(c,opt={}){
 const pulse=1+(opt.inflate||0)*.22;c.save();c.scale(pulse,1);
 for(const s of [-1,1]){c.save();c.scale(s,1);shape(c,[[16,66],[57,62],[64,119],[78,140],[69,150],[13,150],[9,129]],'#463147',INK,6);path(c,p=>{p.moveTo(60,-71);p.bezierCurveTo(103,-69,123,-34,132,13);p.lineTo(149,41);p.lineTo(144,80);p.lineTo(122,98);p.lineTo(92,83);p.lineTo(91,43);p.lineTo(66,11);p.closePath();},'#BB594B',INK,7);shape(c,[[103,-35],[129,12],[138,33],[102,49],[87,19]],'#6A4054',INK,4);for(let j=0;j<3;j++)shape(c,[[101+j*10,9+j*4],[113+j*10,-8+j*5],[116+j*10,21+j*4]],'#D6C3B0',INK,2);line(c,[[113,63],[113,79]],'#703242',3);line(c,[[127,60],[128,79]],'#703242',3);c.restore();}
 path(c,p=>{p.moveTo(-52,-81);p.lineTo(48,-80);p.bezierCurveTo(98,-47,90,35,64,72);p.lineTo(28,105);p.lineTo(-34,101);p.lineTo(-69,64);p.bezierCurveTo(-100,17,-90,-53,-52,-81);p.closePath();},'#CB684F',INK,7);shape(c,[[34,-75],[69,-48],[77,-9],[64,45],[44,65],[8,60],[22,34]],'#9B3E43',null);shape(c,[[-66,-26],[-35,-40],[-4,-23],[-13,12],[-59,10]],'#E18B65',null);shape(c,[[1,-23],[37,-42],[63,-26],[58,9],[12,14]],'#DA7C5A',null);line(c,[[-9,23],[1,32],[12,24]],'#733344',4);line(c,[[-5,41],[2,46],[9,40]],'#733344',4);
 shape(c,[[-70,57],[63,57],[56,78],[37,89],[33,117],[9,109],[-7,120],[-30,108],[-43,117],[-47,91],[-63,84]],'#3E354C',INK,5);ell(c,0,72,16,17,'#B9A184',INK,4);ell(c,-6,70,4,5,INK);ell(c,6,70,4,5,INK);shape(c,[[-4,80],[4,80],[3,85],[-3,85]],INK,null);
 path(c,p=>{p.moveTo(-32,-127);p.lineTo(28,-127);p.lineTo(39,-96);p.lineTo(24,-61);p.lineTo(-21,-60);p.lineTo(-41,-95);p.closePath();},'#B96051',INK,5);shape(c,[[-39,-127],[-17,-150],[7,-149],[33,-132],[37,-112],[15,-126],[-3,-118],[-25,-126],[-38,-108]],'#272B40',INK,5);shape(c,[[-35,-136],[-71,-154],[-60,-118],[-37,-114]],'#D3C3AC',INK,4);shape(c,[[33,-134],[68,-152],[58,-116],[36,-110]],'#D3C3AC',INK,4);line(c,[[-25,-103],[-8,-97]],INK,6);line(c,[[9,-98],[26,-104]],INK,6);ell(c,-17,-96,4,3,'#FFE790');ell(c,17,-96,4,3,'#FFE790');shape(c,[[-19,-81],[20,-81],[14,-61],[-13,-62]],'#322335',INK,3);for(let j=0;j<4;j++)shape(c,[[-14+j*8,-80],[-8+j*8,-80],[-10+j*8,-72]],'#F0D6AA',null);c.restore();
}

export function drawEnemy(c,x,y,size,type='warrior',opt={}){
 c.save();c.translate(x,y);c.rotate(opt.angle||0);c.scale(size/300,size/300);if(opt.flip)c.scale(-1,1);if(opt.alpha!==undefined)c.globalAlpha*=opt.alpha;
 if(type==='golem')golem(c,false,opt);else if(type==='ice')golem(c,true,opt);else if(type==='bear')bear(c,opt);else if(type==='dragon')dragon(c,opt);else if(type==='zombie')zombie(c,opt);else if(type==='vampire')vampire(c,opt);else if(type==='crab')crab(c,opt);else if(type==='berserker')berserker(c,opt);else warrior(c,opt);
 c.restore();
}
