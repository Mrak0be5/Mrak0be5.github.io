import { createCanvas, GlobalFonts, Path2D, DOMMatrix } from '@napi-rs/canvas';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { existsSync, mkdirSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { hostname } from 'node:os';

// A bare `node` in this workspace can be a Windows remote shim. Always fail
// before drawing anything if this entry point accidentally reaches that PC.
if (process.platform !== 'linux') throw new Error('Server rendering only: run this on claude-hub-prod using /usr/bin/node.');

const ROOT = dirname(fileURLToPath(import.meta.url));
const OUT = join(ROOT, 'output');
const FPS = 30;
const DURATION = 29.6;
const FRAMES = 888;
const SCENES = [
  ['HOOK & CHEW', 1.4], ['GROW', 4.4], ['UNDERDOG', 7.4],
  ['NEW LANDS', 10.3], ['ARSENAL', 14.2], ['BOSS TOWER', 17.6],
  ['DINNER', 19.45], ['REMATCH', 20.8], ['DEITY', 23.2],
  ['LOGO', 25.9], ['PLAY FREE', 28.6],
];
const args = new Set(process.argv.slice(2));
const draft = args.has('--draft');
const W = draft ? 540 : 1080;
const H = draft ? 960 : 1920;
const name = draft ? 'butcher-hero-astra6_draft.mp4' : 'butcher-hero-astra6_en.mp4';
const file = join(OUT, name);
const FFMPEG = process.env.FFMPEG || resolve(ROOT, '../../.cache/hubrender/bin/ffmpeg');
const FFPROBE = process.env.FFPROBE || resolve(ROOT, '../../.cache/hubrender/bin/ffprobe');
mkdirSync(OUT, { recursive: true });

for (const [font, family] of [
  ['LondrinaSolid-Regular.ttf', 'Londrina Solid'],
  ['LondrinaSolid-Black.ttf', 'Londrina Solid'],
  ['BarlowCondensed-Bold.ttf', 'Barlow Condensed'],
]) {
  if (!GlobalFonts.registerFromPath(join(ROOT, 'assets/fonts', font), family)) {
    throw new Error(`Font registration failed: ${font}`);
  }
}
globalThis.Path2D ??= Path2D;
globalThis.DOMMatrix ??= DOMMatrix;

function run(binary, command, options = {}) {
  const result = spawnSync(binary, command, { encoding: 'utf8', maxBuffer: 16 * 1024 * 1024, ...options });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`${binary} exited ${result.status}\n${result.stderr || result.stdout}`);
  return result;
}

function verifyVideo(path, expectedWidth, expectedHeight, frameChecks = null) {
  const probe = JSON.parse(run(FFPROBE, [
    '-v', 'error', '-count_frames', '-show_streams', '-show_format', '-of', 'json', path,
  ]).stdout);
  const video = probe.streams.find(s => s.codec_type === 'video');
  const audio = probe.streams.find(s => s.codec_type === 'audio');
  const checks = {
    h264: video?.codec_name === 'h264',
    aac: audio?.codec_name === 'aac',
    dimensions: video?.width === expectedWidth && video?.height === expectedHeight,
    frameRate: video?.r_frame_rate === '30/1' && video?.avg_frame_rate === '30/1',
    frameCount: Number(video?.nb_read_frames) === FRAMES,
    duration: Math.abs(Number(probe.format.duration) - DURATION) < 0.02,
    size: statSync(path).size < 60_000_000,
  };
  const inspection = run(FFMPEG, [
    '-hide_banner', '-nostdin', '-threads', '2', '-filter_threads', '1', '-i', path,
    '-vf', 'blackdetect=d=0.05:pix_th=0.02:pic_th=0.995',
    '-af', 'volumedetect', '-threads', '2', '-f', 'null', '-',
  ]).stderr;
  const meanMatch = inspection.match(/mean_volume:\s*([-\w.]+) dB/);
  const peakMatch = inspection.match(/max_volume:\s*([-\w.]+) dB/);
  const meanDb = meanMatch ? Number(meanMatch[1]) : -Infinity;
  checks.audible = Number.isFinite(meanDb) && meanDb > -42;
  const blackIntervals = inspection.split('\n').filter(line => line.includes('black_start:'));
  checks.noBlackIntervals = blackIntervals.length === 0;
  const report = {
    file: path, server: hostname(), fps: video?.avg_frame_rate,
    frames: Number(video?.nb_read_frames), duration: Number(probe.format.duration),
    dimensions: [video?.width, video?.height], bytes: statSync(path).size,
    codecs: [video?.codec_name, audio?.codec_name], audioMeanDb: meanDb,
    audioPeakDb: peakMatch ? Number(peakMatch[1]) : null,
    checks, blackIntervals, frameChecks,
  };
  writeFileSync(join(OUT, draft ? 'verification-draft.json' : 'verification.json'), JSON.stringify(report, null, 2) + '\n');
  const failures = Object.entries(checks).filter(([, value]) => !value).map(([key]) => key);
  console.log(JSON.stringify(report, null, 2));
  if (failures.length) throw new Error(`Video verification failed: ${failures.join(', ')}`);
  return report;
}

if (args.has('--verify-only')) {
  verifyVideo(file, W, H);
  process.exit(0);
}

const { render } = await import('./film.mjs');
if (typeof render !== 'function') throw new Error('film.mjs must export render(ctx,t,width,height).');

function frame(t, width, height, canvas = createCanvas(width, height)) {
  const ctx = canvas.getContext('2d');
  // Reset all Canvas state so arbitrary seeking and sequential rendering agree.
  ctx.reset();
  render(ctx, t, width, height);
  return canvas;
}

function storyboard() {
  const width = 270, height = 480, gap = 18, labelHeight = 36;
  const cols = 4, rows = 3;
  const sheet = createCanvas(cols * (width + gap) + gap, rows * (height + labelHeight + gap) + 70);
  const ctx = sheet.getContext('2d');
  ctx.fillStyle = '#10101A'; ctx.fillRect(0, 0, sheet.width, sheet.height);
  ctx.fillStyle = '#FEE415'; ctx.font = '900 28px "Londrina Solid"';
  ctx.fillText('BUTCHER HERO / ASTRA 6 / STORYBOARD', gap, 39);
  const keyDir = join(OUT, 'keyframes'); mkdirSync(keyDir, { recursive: true });
  SCENES.forEach(([title, t], index) => {
    const x = gap + (index % cols) * (width + gap);
    const y = 60 + Math.floor(index / cols) * (height + labelHeight + gap);
    const canvas = frame(t, 540, 960);
    writeFileSync(join(keyDir, `${String(index + 1).padStart(2, '0')}.png`), canvas.toBuffer('image/png'));
    ctx.drawImage(canvas, x, y, width, height);
    ctx.fillStyle = '#ECEBE7'; ctx.font = '700 19px "Barlow Condensed"';
    ctx.fillText(`${String(index + 1).padStart(2, '0')}  ${title}  /  ${t.toFixed(1)}s`, x, y + height + 25);
  });
  const dest = join(OUT, 'storyboard.png');
  writeFileSync(dest, sheet.toBuffer('image/png'));
  console.log(`Storyboard: ${dest}`);
}

if (args.has('--storyboard')) {
  storyboard();
  process.exit(0);
}

const audioFile = join(OUT, 'soundtrack.wav');
if (!existsSync(audioFile)) throw new Error('Missing soundtrack.wav. Run npm run render (or python3 audio.py first).');
for (const binary of [FFMPEG, FFPROBE]) if (!existsSync(binary)) throw new Error(`Missing tool: ${binary}. Set FFMPEG / FFPROBE environment variables.`);

// Pixel-for-pixel determinism at all 11 scene keyframes, including seek order.
const deterministic = [];
for (const [scene, t] of SCENES) {
  const a = createHash('sha256').update(frame(t, W, H).data()).digest('hex');
  const b = createHash('sha256').update(frame(t, W, H).data()).digest('hex');
  if (a !== b) throw new Error(`Non-deterministic frame at ${t}s / ${scene}.`);
  deterministic.push({ scene, t, sha256: a });
}

const temporary = join(OUT, name.replace('.mp4', '.partial.mp4'));
const ffmpeg = spawn(FFMPEG, [
  '-hide_banner', '-nostdin', '-y', '-threads', '2', '-filter_threads', '1',
  '-f', 'rawvideo', '-pixel_format', 'rgba', '-video_size', `${W}x${H}`,
  '-framerate', String(FPS), '-i', 'pipe:0', '-i', audioFile,
  '-map', '0:v:0', '-map', '1:a:0', '-c:v', 'libx264',
  '-preset', 'medium', '-crf', '19', '-maxrate', '12M', '-bufsize', '24M',
  '-pix_fmt', 'yuv420p', '-r', String(FPS), '-frames:v', String(FRAMES),
  '-threads', '2', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
  '-t', String(DURATION), '-movflags', '+faststart',
  '-metadata', 'title=Butcher Hero — Astra 6',
  '-metadata', 'comment=Fresh deterministic Canvas 2D animation and procedural soundtrack',
  temporary,
], { stdio: ['pipe', 'ignore', 'pipe'] });
let log = '';
ffmpeg.stderr.on('data', chunk => { log = (log + chunk.toString()).slice(-32000); });
let pipeError = null;
ffmpeg.stdin.on('error', error => { pipeError = error; });
const complete = once(ffmpeg, 'close');
const canvas = createCanvas(W, H);
let darkestMean = Infinity;
let maximumDarkFraction = 0;
const start = performance.now();
try {
  for (let i = 0; i < FRAMES; i++) {
    if (pipeError) throw pipeError;
    frame(i / FPS, W, H, canvas);
    const pixels = canvas.data();
    let sum = 0, dark = 0, count = 0;
    // Uniform sample catches accidentally empty frames without retaining frames.
    for (let p = 0; p < pixels.length; p += 4 * 101) {
      const brightness = Math.max(pixels[p], pixels[p + 1], pixels[p + 2]);
      sum += brightness; count++; if (brightness < 5) dark++;
    }
    const mean = sum / count, darkFraction = dark / count;
    darkestMean = Math.min(darkestMean, mean);
    maximumDarkFraction = Math.max(maximumDarkFraction, darkFraction);
    if (darkFraction > 0.995) throw new Error(`Unexpected black frame ${i} at ${(i / FPS).toFixed(3)}s.`);
    if (!ffmpeg.stdin.write(pixels)) await once(ffmpeg.stdin, 'drain');
    if (i % 60 === 0 || i === FRAMES - 1) {
      const elapsed = (performance.now() - start) / 1000;
      console.log(`Frame ${i + 1}/${FRAMES} / ${((i + 1) / FRAMES * 100).toFixed(1)}% / elapsed ${elapsed.toFixed(1)}s`);
    }
  }
  ffmpeg.stdin.end();
  const [status] = await complete;
  if (status !== 0) throw new Error(`FFmpeg exited ${status}:\n${log}`);
} catch (error) {
  ffmpeg.stdin.destroy(); ffmpeg.kill('SIGTERM');
  throw new Error(`${error.message}\n${log}`, { cause: error });
}
renameSync(temporary, file);
verifyVideo(file, W, H, {
  inspected: FRAMES, darkestMean, maximumDarkFraction, deterministic,
  renderSeconds: (performance.now() - start) / 1000,
});
console.log(`Rendered and verified: ${file}`);
