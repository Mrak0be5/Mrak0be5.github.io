# Butcher Hero — Astra 6

A new implementation of the supplied 11-scene brief. All character art, environments, typography animation, chains, combat and transitions are drawn with Canvas 2D. Music and sound effects are synthesized into PCM samples. No prior reel implementation, image, video or sound asset is used.

The film is English, 1080 × 1920, 30 fps, exactly 888 frames / 29.6 seconds, H.264 + AAC. The visual entry point is `render(ctx, t, width = 1080, height = 1920)` in `film.mjs`. It can render any timestamp independently; its logical drawing space is 540 × 960.

## Server render

Run on the Linux hub, never on the user's PC. The workspace's default `node` and `npm` commands can forward to Windows, so the script explicitly uses Linux executables:

```sh
/bin/sh reels/butcher-hero-astra6/render-server.sh
```

From this directory, the equivalent npm command is:

```sh
PATH=/usr/bin:/bin:/usr/sbin:/sbin /usr/bin/npm run render
```

The first command installs the pinned Canvas dependency if needed, synthesizes the soundtrack, renders frames directly into FFmpeg with bounded memory, and verifies the output. Two FFmpeg worker threads are used. `render.mjs` refuses to run on Windows.

FFmpeg and ffprobe default to the existing tools at `../../.cache/hubrender/bin/`. Set `FFMPEG` and `FFPROBE` to absolute paths if rendering on another Linux server. Node 22+ and Python 3 are required; Python uses NumPy for audio synthesis. The script installs NumPy into local `.audio-deps/` if necessary and supplies its path without changing system Python packages.

```sh
# Generate an 11-panel storyboard and individual 540×960 keyframes.
/usr/bin/node render.mjs --storyboard

# Faster 540×960 render, with the same duration and frame rate.
/bin/sh render-server.sh --draft

# Repeat encoded-file verification without rerendering.
/usr/bin/node render.mjs --verify-only
```

Outputs:

- `output/butcher-hero-astra6_en.mp4` — final film.
- `output/soundtrack.wav` — synthesized score and effects.
- `output/storyboard.png` and `output/keyframes/` — composition review.
- `output/verification.json` — codecs, dimensions, frame count, duration, size, audio levels, black-frame detection and deterministic frame hashes.

The renderer checks every source frame for accidental black output, hashes all eleven keyframes twice, then verifies the encoded MP4 with ffprobe and FFmpeg. A final-frame hold is intentional.

## Interactive source preview

Start a static server from this directory with `/usr/bin/python3 -m http.server 8756`, then load `preview.html` in a browser. Controls allow playback and seeking to any frame or scene. The preview uses the same drawing code and embedded fonts as the server renderer.

## Fonts and dependencies

Fonts were downloaded fresh from the [Google Fonts repository](https://github.com/google/fonts): [Londrina Solid](https://github.com/google/fonts/tree/main/ofl/londrinasolid) (Regular and Black) and [Barlow Condensed](https://github.com/google/fonts/tree/main/ofl/barlowcondensed) (Bold). Their SIL Open Font License texts are included beside the font files under `assets/fonts/`.

Rasterization uses the native Skia implementation in [@napi-rs/canvas](https://github.com/Brooooooklyn/canvas), pinned by `package-lock.json`. The source art remains standard Canvas 2D JavaScript and also runs in browser Canvas.
