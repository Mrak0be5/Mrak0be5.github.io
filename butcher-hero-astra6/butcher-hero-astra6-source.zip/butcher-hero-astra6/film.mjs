import {drawHero, drawEnemy, drawWeapon} from './art.mjs';

// Original Astra 6 film. Every visible state is a pure function of time.
export const WIDTH=1080, HEIGHT=1920, FPS=30, DURATION=29.6;
export const scenes=[
  {start:0,end:2.4,name:'HOOK. CHEW.'},
  {start:2.4,end:5.6,name:'EAT AND GET STRONGER'},
  {start:5.6,end:8.8,name:'THE UNDERDOG'},
  {start:8.8,end:12,name:'FIVE NEW WORLDS'},
  {start:12,end:15.2,name:'THE ARSENAL'},
  {start:15.2,end:18.4,name:'BOSS TOWER'},
  {start:18.4,end:20,name:'DINNER IS SERVED'},
  {start:20,end:21.6,name:'THE REMATCH'},
  {start:21.6,end:24.8,name:'DEITY OF DESTRUCTION'},
  {start:24.8,end:26.4,name:'BUTCHER HERO'},
  {start:26.4,end:29.6,name:'PLAY FREE'},
];
const C={ink:'#130F20',paper:'#FFF3D7',yellow:'#FEE415',gold:'#F2B305',red:'#E02B38',navy:'#03113A',ground:'#1E3849',lavender:'#8989E5',green:'#46FF52'};
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const mix=(a,b,t)=>a+(b-a)*t;
const out=t=>1-Math.pow(1-clamp(t),5);
const smooth=t=>{t=clamp(t);return t*t*(3-2*t)};
const back=t=>{t=clamp(t)-1;return 1+2.70158*t*t*t+1.70158*t*t};
const rand=n=>{const q=Math.sin(n*127.1+311.7)*43758.5453;return q-Math.floor(q)};
const pulse=(t,start,d=.22)=>Math.sin(clamp((t-start)/d)*Math.PI);
function poly(g,points,fill,stroke=C.ink,lw=4){g.beginPath();points.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();if(fill){g.fillStyle=fill;g.fill()}if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.lineJoin='round';g.stroke()}}
function ellipse(g,x,y,rx,ry,fill,stroke=null,lw=3){g.beginPath();g.ellipse(x,y,rx,ry,0,0,Math.PI*2);g.fillStyle=fill;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function line(g,points,color,width=3){g.beginPath();points.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.strokeStyle=color;g.lineWidth=width;g.lineCap='round';g.lineJoin='round';g.stroke()}
function rr(g,x,y,w,h,r,fill,stroke=null,lw=3){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=fill;g.fill();if(stroke){g.lineWidth=lw;g.strokeStyle=stroke;g.stroke()}}

function text(g,s,x,y,size,{color=C.paper,align='center',angle=0,max=460,two=false,outline=7}={}){
  g.save();g.translate(x,y);g.rotate(angle);g.font=`900 ${size}px "Londrina Solid"`;g.textAlign=align;g.textBaseline='alphabetic';
  let measured=g.measureText(s).width;if(measured>max)g.scale(max/measured,1);
  g.lineJoin='round';g.strokeStyle=C.ink;g.lineWidth=outline*2;g.strokeText(s,0,0);g.fillStyle=color;g.fillText(s,0,0);
  if(two){g.save();g.beginPath();g.rect(-800,-size*.36,1600,size*.55);g.clip();g.fillStyle=C.gold;g.fillText(s,0,0);g.restore()}
  g.restore();
}
function headline(g,small,big,t,{y=166,bigSize=82,smallSize=38}={}){
  const a=back(t/.35);g.save();g.translate(0,mix(-200,0,a));
  text(g,small,240,y,smallSize,{angle:-.035,max:410,outline:5});
  text(g,big,240,y+bigSize*.91,bigSize,{angle:-.035,max:410,color:C.yellow,two:true,outline:6});g.restore();
}
function tag(g,s,x,y,{fill=C.ink,color=C.paper,size=25}={}){
  g.save();g.font=`900 ${size}px "Londrina Solid"`;const w=g.measureText(s).width+30;
  rr(g,x-w/2,y-size*.8,w,size*1.35,8,fill,C.paper,2);text(g,s,x,y+size*.18,size,{color,outline:0,max:w-14});g.restore();
}
function shardBurst(g,x,y,t,{n=28,color='#FF6621',radius=220,seed=1}={}){
  if(t<0||t>1)return;g.save();g.globalAlpha=1-t*t;
  for(let i=0;i<n;i++){let a=rand(i+seed)*Math.PI*2;let r=radius*out(t)*(.2+.8*rand(i+seed+40));let z=(3+rand(i+8)*10)*(1-t*.7);let px=x+Math.cos(a)*r,py=y+Math.sin(a)*r+t*t*80;g.save();g.translate(px,py);g.rotate(a+t*3);poly(g,[[-z,0],[0,-z*.5],[z*2,0],[0,z*.5]],i%4?color:C.paper,null);g.restore()}g.restore();
}
function star(g,x,y,r,color=C.paper,rotation=0){let p=[];for(let i=0;i<20;i++){let a=i*Math.PI/10+rotation,rad=i%2?r*.4:r;p.push([x+Math.cos(a)*rad,y+Math.sin(a)*rad])}poly(g,p,color,C.ink,4)}
function shock(g,x,y,p,color=C.red){if(p<0||p>1)return;g.save();g.globalAlpha=1-p;g.strokeStyle=color;g.lineWidth=16*(1-p)+2;g.beginPath();g.ellipse(x,y,20+p*300,8+p*100,0,0,Math.PI*2);g.stroke();g.restore()}

function chain(g,x1,y1,x2,y2,{sag=20,time=0,width=6}={}){
  const dx=x2-x1,dy=y2-y1,len=Math.hypot(dx,dy),count=Math.max(2,Math.ceil(len/13));
  const point=t=>[mix(x1,x2,t)+Math.sin(t*Math.PI)*Math.sin(time*10+t*8)*sag*.25,mix(y1,y2,t)+Math.sin(t*Math.PI)*sag];
  const path=[];for(let i=0;i<=count;i++)path.push(point(i/count));line(g,path,C.ink,width+4);line(g,path,'#6E7BA8',width);
  for(let i=0;i<count;i++){const p=point((i+.5)/count),a=point(i/count),b=point((i+1)/count);g.save();g.translate(...p);g.rotate(Math.atan2(b[1]-a[1],b[0]-a[0]));g.strokeStyle=i%2?'#A4B3D3':'#2B3350';g.lineWidth=2;g.beginPath();g.ellipse(0,0,5,width*.55,0,0,Math.PI*2);g.stroke();g.restore()}
}
function lightning(g,a,b,t,color=C.red){let p=[a];for(let i=1;i<9;i++)p.push([mix(a[0],b[0],i/9)+(rand(i+Math.floor(t*18))*2-1)*28,mix(a[1],b[1],i/9)]);p.push(b);line(g,p,C.ink,11);line(g,p,color,6);line(g,p,C.paper,1.6)}

function embers(g,t,count=35,color='#F84504'){
  for(let i=0;i<count;i++){let x=rand(i+31)*540,y=(rand(i+63)*1100-t*(15+rand(i+91)*60)+2200)%1100-70;let s=1+rand(i+13)*4;g.globalAlpha=.35+.55*rand(i);poly(g,[[x,y-s*2],[x+s,y],[x,y+s],[x-s,y]],i%5?color:C.paper,null)}g.globalAlpha=1;
}
function tree(g,x,y,s,color){g.save();g.translate(x,y);g.scale(s,s);poly(g,[[-13,10],[-6,-90],[-48,-131],[-14,-119],[-22,-190],[-3,-139],[13,-170],[7,-106],[45,-143],[23,-97],[8,-75],[20,10]],color,null);g.restore()}
function background(g,t,{theme='night',ground=true}={}){
  const red=theme==='blood'||theme==='lava';let gr=g.createLinearGradient(0,0,0,960);gr.addColorStop(0,red?'#9D0C2C':'#241639');gr.addColorStop(.45,red?'#380D31':'#082344');gr.addColorStop(1,'#04071E');g.fillStyle=gr;g.fillRect(0,0,540,960);
  ellipse(g,405,215,112,112,red?'#DB2736':'#AAA4BE');ellipse(g,378,184,12,6,red?'#A01530':'#8B84A3');ellipse(g,443,235,27,18,red?'#A01530':'#8B84A3');
  for(let layer=0;layer<3;layer++){let pts=[[0,650+layer*40]];for(let i=0;i<15;i++){let x=i*45-35;pts.push([x,440+layer*95-rand(i+layer*31)*150+Math.sin(t*.4+i)*2])}pts.push([570,980],[0,980]);poly(g,pts,['#242341','#15253E','#102339'][layer],null)}
  for(let i=0;i<8;i++)tree(g,i*90-35,710+rand(i)*35,.9+rand(i)*.8,'#070F25');
  if(ground){poly(g,[[0,735],[540,735],[540,960],[0,960]],C.ground,null);for(let i=0;i<30;i++){let x=rand(i+11)*600,y=750+rand(i+72)*210;poly(g,[[x-20,y],[x,y-4],[x+30,y+3],[x,y+7]],i%2?'#17303D':'#284452',null)}}
  embers(g,t,red?45:20,red?'#F84504':'#879BB1');
}
function speed(g,t,amount=1){g.save();g.globalAlpha=.32*amount;for(let i=0;i<22;i++){let x=rand(i+201)*580;let y=((rand(i+301)*1500+t*1100)%1500)-300;line(g,[[x,y],[x,y+50+rand(i+88)*160]],i%3?C.paper:C.red,1+rand(i)*3)}g.restore()}
function vignette(g){let gr=g.createRadialGradient(270,450,260,270,470,680);gr.addColorStop(0,'#02031500');gr.addColorStop(1,'#020315AC');g.fillStyle=gr;g.fillRect(0,0,540,960)}

function killAndEat(g,local,{hx=270,hy=680,mx=hx,my=hy-65,ex=320,ey=420,size=110,type='warrior',weapon='hammer',seed=3}={}){
  // Dead first, hook second. Complete attack, recoil, hook and swallow cycle: 0.8s.
  const hit=local>=0,hook=clamp((local-.4)/.2),pull=clamp((local-.6)/.1)**3;
  if(local<.7){let px=mix(ex,mx,pull),py=mix(ey,my,pull);g.save();g.translate(px,py);g.rotate(local>=0?.52*smooth(local/.4):0);drawEnemy(g,0,0,size*(1-pull*.93),type,{time:local,dead:hit});g.restore()}
  if(local>=0&&local<.24){const a=out(local/.12);drawWeapon(g,mix(ex-80,ex,a),mix(ey-170,ey,a),90*(1+2*pulse(local,0,.16)),weapon,-.5);shardBurst(g,ex,ey,local/.5,{color:'#CCBCBC',radius:120,seed})}
  if(local>=.4&&local<.73){let xx=mix(mx,ex,hook),yy=mix(my,ey,hook);xx=mix(xx,mx,pull);yy=mix(yy,my,pull);chain(g,mx,my,xx,yy,{sag:25*(1-clamp((local-.6)/.1)),time:local});drawWeapon(g,xx,yy,55,'hook',-.5);shardBurst(g,ex,ey,(local-.59)*4,{color:C.red,radius:72,seed})}
  if(local>=.7&&local<1.25){let p=(local-.7)/.55;g.save();g.globalAlpha=1-p;text(g,'+1',hx+50,hy-100-p*100,46,{color:C.green,outline:4});g.restore()}
}

function hookScene(g,u){
  background(g,u,{theme:'blood',ground:false});
  for(let i=0;i<6;i++)chain(g,50+i*90,-80,50+i*90+Math.sin(u+i)*20,330+rand(i)*170,{sag:10,time:u,width:4});
  const breathe=1+.018*Math.sin(u*6);drawHero(g,270,655,breathe*660,{time:u,mouth:pulse(u,1.2,.24)+pulse(u,1.6,.24),angry:true});
  if(u<1.12)killAndEat(g,u-.4,{hx:270,hy:520,mx:270,my:590,ex:320,ey:325,size:137,seed:10});
  if(u>=.8&&u<1.2){const p=out((u-.8)/.28);chain(g,280,470,280,330-130*p,{sag:20*(1-p),time:u,width:8});drawWeapon(g,280,330-130*p,80+230*p,'hook',.1);shardBurst(g,265,330,(u-.82)/.55,{color:C.red,radius:440,n:38})}
  if(u>=.8&&u<1.2){let p=back((u-.8)/.14);g.save();g.translate(240,280);g.scale(p,p);text(g,'HOOK.',0,0,127,{color:C.yellow,two:true,angle:-.06,max:405});g.restore()}
  if(u>=1.2){let p=back((u-1.2)/.13);g.save();g.translate(240,285);g.scale(p,p);text(g,'CHEW.',0,0,126,{color:C.yellow,two:true,angle:-.055,max:405});g.restore()}
  if(u>=1.6){text(g,'+1',420,500-(u-1.6)*90,70,{color:C.green,angle:.12});shardBurst(g,275,470,(u-1.6)/.7,{color:C.red,radius:150,n:16})}
  if(u<.09){g.fillStyle=`rgba(255,226,155,${.25*(1-u/.09)})`;g.fillRect(0,0,540,960)}
}

function growScene(g,u){
  background(g,u+2.4);ellipse(g,270,818,155,37,'#071224');
  const fed=clamp((u-1)/1.7),size=mix(235,370,fed)+pulse(u,.8)*12+pulse(u,1.2)*16+pulse(u,1.6)*18+pulse(u,2)*22;
  const enemies=[[98,468],[207,410],[337,415],[453,475]];
  enemies.forEach(([x,y],i)=>{if(u<.4)drawEnemy(g,x,y,105,'warrior',{time:u});else killAndEat(g,u-(.4+i*.4),{hx:270,hy:680,mx:270,my:685-.08*size,ex:x,ey:y,size:105,seed:24+i})});
  if(u>.35&&u<.85){drawWeapon(g,270,470-80*out((u-.35)/.35),200,'hammer',-.2);for(let i=0;i<4;i++)lightning(g,[270,490],enemies[i],u);shock(g,270,500,(u-.35)*2)}
  drawHero(g,270,685,size,{time:u,mouth:pulse(u,1.1,.2)+pulse(u,1.5,.2)+pulse(u,1.9,.2)+pulse(u,2.3,.2)});
  const chips=[['+DMG',110,560],['+SPD',425,590],['+ARMOR',115,705],['+HP',424,735]];
  chips.forEach(([s,x,y],i)=>{let p=back((u-1.35-i*.2)/.25);if(p>0){g.save();g.translate(x,y);g.scale(p,p);tag(g,s,0,0,{color:C.green,size:24});g.restore()}});
  headline(g,'EAT AND GET','STRONGER',u,{bigSize:86});
  if(u<.35)speed(g,u,1-u/.35);
}

function underdogScene(g,u){
  background(g,u+5.6,{theme:'lava'});let pan=out(u/1.25)*85;
  g.save();g.translate(0,pan-65);drawEnemy(g,324,477,760,'golem',{time:Math.min(u,1.25)});g.restore();
  drawHero(g,115,812,148,{time:Math.min(u,1.25),mouth:pulse(u,2.4,.15)});
  if(u>1.4){let p=clamp((u-1.4)/1.2);ellipse(g,155,748+p*25,5,10,'#9EF4F9',C.ink,2)}
  tag(g,'LVL 100',404,361,{fill:'#B7242A',size:31});tag(g,'LVL 1',107,713,{size:25});
  headline(g,'START AS A','FEEBLE DEMON…',u,{bigSize:65,y:153});
}

function island(g,cx,cy,w,theme,t){
  const palettes={meadow:['#72B74B','#42753B','#51614E'],ice:['#C4F4F7','#65AFC8','#36547A'],candy:['#F4B5C5','#C879A7','#79425F'],fire:['#64384E','#B9452A','#39273D'],grave:['#718265','#3D654D','#293943']};const [top,edge,rock]=palettes[theme];
  poly(g,[[cx-w*.5,cy],[cx-w*.3,cy+110],[cx-w*.1,cy+160],[cx+w*.16,cy+145],[cx+w*.46,cy+50],[cx+w*.5,cy]],rock,C.ink,6);
  for(let i=0;i<7;i++){let x=cx-w*.46+i*w*.14;poly(g,[[x,cy+3],[x+w*.1,cy+9],[x+w*.075,cy+82+rand(i)*50]],i%2?edge:rock,C.ink,2)}
  ellipse(g,cx,cy,w*.5,80,edge,C.ink,6);ellipse(g,cx,cy-13,w*.485,66,top,C.ink,3);
  for(let i=0;i<9;i++){let a=rand(i+19)*Math.PI*2,x=cx+Math.cos(a)*w*.4,y=cy+Math.sin(a)*45-18;
    if(theme==='ice'||theme==='fire'){poly(g,[[x-10,y],[x-9,y-28],[x+3,y-57],[x+16,y-25],[x+12,y]],theme==='ice'?'#D9FCFF':'#22DBC9',C.ink,2);line(g,[[x+3,y-57],[x+3,y]],theme==='ice'?'#60ABC7':'#087F90',3)}
    else if(theme==='grave'){rr(g,x-9,y-27,20,32,7,'#7E8A97',C.ink,2);line(g,[[x+1,y-22],[x+1,y-8]],C.ink,2);line(g,[[x-4,y-17],[x+6,y-17]],C.ink,2)}
    else if(theme==='candy'){line(g,[[x,y],[x,y-35]],'#FFF0CC',5);ellipse(g,x,y-42,14,14,'#F16594',C.ink,2);ellipse(g,x+3,y-44,6,6,'#FFE0B4')}
    else {line(g,[[x-8,y],[x-2,y-12],[x+1,y],[x+8,y-8]],'#2C6B33',3)}
  }
  if(theme==='candy'||theme==='grave'||theme==='fire'){const col=theme==='candy'?'#FF759F':theme==='grave'?'#A2EE37':'#FF6621';line(g,[[cx-w*.32,cy-44],[cx-w*.12,cy-15],[cx+w*.11,cy-12],[cx+w*.3,cy+24]],col,18);line(g,[[cx-w*.32,cy-46],[cx-w*.12,cy-17],[cx+w*.11,cy-14]],'#FFF0B4',3)}
}
function islandsScene(g,u){
  background(g,u+8.8,{theme:'night',ground:false});
  const starts=[0,.8,1.4,1.9,2.3],ends=[.8,1.4,1.9,2.3,3.2],names=['meadow','ice','candy','fire','grave'],types=['warrior','ice','bear','dragon','zombie'],levels=[9,23,47,71,99];
  let k=starts.findIndex((s,i)=>u>=s&&u<ends[i]);if(k<0)k=4;const p=(u-starts[k])/(ends[k]-starts[k]);const offset=-780*(1-out(p/.2));
  if(k>0&&p<.2){g.save();g.translate(0,950*out(p/.2));island(g,270,720,440,names[k-1],u);g.restore()}
  g.save();g.translate(0,offset);island(g,270,708,466,names[k],u);drawHero(g,218,595,230+k*18,{time:u,mouth:pulse(p,.78,.17)});
  killAndEat(g,p*.92-.08,{hx:218,hy:595,mx:218,my:595-.08*(230+k*18),ex:378,ey:513,size:103+k*6,type:types[k],weapon:k%2?'iceaxe':'hammer',seed:100+k});
  tag(g,`LVL ${levels[k]}`,218,779,{fill:C.ink,color:C.yellow,size:34});g.restore();
  headline(g,'EXPLORE NEW','LANDS',u,{bigSize:94});
  const namesLabel=['THE WILDS','FROSTFALL','SUGAR RUSH','EMBER ISLES','THE HOLLOW'];text(g,namesLabel[k],254,338,25,{color:C.paper,outline:3});
  for(let i=0;i<5;i++)rr(g,182+i*30,855,20,5,2,i===k?C.yellow:'#5F697D');
}

function arsenalScene(g,u){
  background(g,u+12,{theme:'blood'});
  for(let row=0;row<3;row++)for(let j=0;j<6;j++){let x=40+j*92+(row%2)*18,y=382+row*54;if(u<2.42)drawEnemy(g,x,y,78+row*10,'warrior',{time:u});else{g.save();g.translate(x,y+out((u-2.4)/.5)*100);g.rotate(.65+row*.3);drawEnemy(g,0,0,80,'warrior',{dead:true,time:u});g.restore()}}
  const poses=[[90,575,'iceaxe'],[164,360,'greenaxe'],[389,375,'sword'],[459,567,'hammer']];
  for(let i=0;i<4;i++){const q=u-(.4+i*.4);if(q<0)continue;let p=back(q/.34);let [x,y,type]=poses[i];let attack=clamp((u-2.25)/.22);let px=mix(x,95+i*115,attack),py=mix(-150,y,p);py=mix(py,410,attack);chain(g,270,667,px,py,{sag:35*(1-attack),time:u,width:7});drawWeapon(g,px,py,140*(1+.5*pulse(u,2.4,.18)),type,(i-1.5)*.26+attack*1.6)}
  drawHero(g,270,751,450,{back:true,time:u});
  if(u>=2.4){for(let i=0;i<4;i++){shardBurst(g,95+i*115,415,(u-2.4)/.7,{seed:i*8,n:13,color:C.red,radius:150});if(u<2.7)lightning(g,[95+i*115,415],[55+i*130,580],u)}shock(g,270,480,(u-2.4)/.7)}
  headline(g,'COLLECT EPIC','WEAPONS',u,{bigSize:88});
}

function towerRoom(g,y,type,u,showBoss=true){
  rr(g,64,y-236,412,499,12,'#302941',C.ink,8);
  for(let i=0;i<9;i++){let yy=y-223+i*53;line(g,[[70,yy],[470,yy]],'#17182B',3);for(let j=0;j<5;j++)line(g,[[80+j*90+(i%2)*40,yy],[80+j*90+(i%2)*40,yy+49]],'#17182B',3)}
  g.beginPath();g.moveTo(139,y+50);g.lineTo(139,y-90);g.bezierCurveTo(139,y-188,215,y-204,270,y-250);g.bezierCurveTo(325,y-204,401,y-188,401,y-90);g.lineTo(401,y+50);g.closePath();g.fillStyle='#0A112C';g.fill();g.strokeStyle='#756D8A';g.lineWidth=14;g.stroke();
  ellipse(g,270,y-82,80,80,type==='vampire'?'#C33143':'#66617D');
  for(const x of [104,436]){rr(g,x-7,y-35,14,91,3,'#5B4E69',C.ink,3);star(g,x,y-46,14+Math.sin(u*19+x)*3,'#FF7939')}
  poly(g,[[77,y+173],[463,y+173],[500,y+233],[40,y+233]],'#555269',C.ink,5);line(g,[[100,y+177],[438,y+177]],'#9390A6',3);
  chain(g,92,y-205,231,y+6,{sag:40,time:u});chain(g,450,y-205,314,y+6,{sag:40,time:u});
  if(type==='vampire'){rr(g,167,y+97,206,71,7,'#68516A',C.ink,5);poly(g,[[150,y+99],[270,y+58],[390,y+99],[270,y+135]],'#962A4B',C.ink,4);if(showBoss)drawEnemy(g,270,y-12,255,'vampire',{time:u});for(const x of [112,429])drawEnemy(g,x,y+127,92,'warrior',{time:u,dead:true});}
  else drawEnemy(g,270,y+20,type==='crab'?230:260,type,{time:u});
  tag(g,type==='crab'?'FLOOR 13':type==='berserker'?'FLOOR 66':'THE BLOOD KING',270,y+226,{size:23,fill:'#241C33'});
}
function towerScene(g,u){
  background(g,u+15.2,{theme:'blood',ground:false});
  let travel=1250*smooth(u/1.8);
  for(let i=0;i<3;i++)towerRoom(g,540-i*625+travel,['crab','berserker','vampire'][i],u);
  for(const x of [25,492]){rr(g,x,0,23,960,0,'#51455D',C.ink,6);for(let i=0;i<12;i++)line(g,[[x,((i*100+travel)%1200)-120],[x+23,((i*100+travel)%1200)-120]],'#171629',5)}
  headline(g,'CLIMB THE','BOSS TOWER',u,{bigSize:74,y:149});
  if(u>1.9){const p=out((u-1.9)/.25);g.save();g.globalAlpha=p;rr(g,32,666,416,92,12,'#100F25',C.paper,2);text(g,"The ritual isn't for summoning",240,700,27,{max:393,outline:0});text(g,"It's for dinner.",240,738,34,{max:393,color:C.yellow,outline:0});g.restore()}
}

function dinnerScene(g,u){
  background(g,u+18.4,{theme:'blood',ground:false});towerRoom(g,540,'vampire',u,u<.14);
  // The victim is covered/replaced by an impact then pulled into the lower mouth.
  if(u>=.14){
    if(u<.7){let p=clamp((u-.5)/.2)**3;g.save();g.translate(270,530+480*p);g.rotate(.5*clamp(u/.4));drawEnemy(g,0,0,255*(1-p*.7),'vampire',{time:u,dead:true});g.restore()}
  }
  if(u<.45){let p=out(u/.16);chain(g,270,1060,270,970-490*p,{sag:0,width:10});drawWeapon(g,270,970-490*p,240,'hammer',-.1);if(u>.13)star(g,270,467,180*(1-clamp((u-.14)/.3)),C.paper)}
  if(u>.4&&u<.75){let p=clamp((u-.4)/.16);chain(g,270,970,270,970-450*p+450*(clamp((u-.58)/.15)**3),{sag:30*(1-p),time:u,width:8});drawWeapon(g,270,970-450*p+450*(clamp((u-.58)/.15)**3),75,'hook')}
  shardBurst(g,270,470,(u-.15)/.7,{color:C.red,radius:230});
  if(u>.78){g.save();const p=back((u-.78)/.2);g.translate(260,423);g.scale(p,p);text(g,'BOSS',0,0,115,{color:C.yellow,two:true,angle:-.055});text(g,'DEFEATED!',0,100,87,{color:C.yellow,two:true,angle:-.055});g.restore();text(g,'+1',270,680-(u-.8)*90,70,{color:C.green})}
  if(u>1.3){let p=(u-1.3)/.3;let edge=960*(1-p);poly(g,[[0,edge],[50,edge-25],[100,edge+8],[150,edge-16],[200,edge+13],[260,edge-19],[320,edge+11],[380,edge-24],[440,edge+18],[540,edge],[540,960],[0,960]],'#130D21',null);line(g,[[0,edge],[60,edge-25],[130,edge+8],[210,edge-18],[290,edge+12],[370,edge-21],[440,edge+18],[540,edge]],'#FF6621',12);shardBurst(g,270,edge,.3,{color:'#FEE415',radius:310,n:35})}
}

function infinity(g,x,y,s,color){g.save();g.translate(x,y);g.scale(s,s);g.beginPath();g.moveTo(0,0);g.bezierCurveTo(-18,-29,-46,-22,-46,0);g.bezierCurveTo(-46,29,-18,29,0,0);g.bezierCurveTo(18,-29,46,-29,46,0);g.bezierCurveTo(46,29,18,29,0,0);g.strokeStyle=C.ink;g.lineWidth=15;g.stroke();g.strokeStyle=color;g.lineWidth=8;g.stroke();g.restore()}
function rematchScene(g,u){
  background(g,u+20,{theme:'lava'});
  drawHero(g,148,575,725,{time:Math.min(u,1.4),back:true});
  drawEnemy(g,430,812,144,'golem',{time:Math.min(u,1.4)});tag(g,'LVL 100',401,717,{fill:'#A72C30',size:25});
  let p=out(u/.95);chain(g,265,546,390,340-80*p,{time:u,sag:23,width:10});drawWeapon(g,390,340-80*p,190,'hammer',-1.5+p*.5);
  if(u>.75&&u<1.4){lightning(g,[260,540],[392,272],u,'#FEE415');lightning(g,[180,560],[107,360],u,'#FEE415')}
  tag(g,'LVL',136,218,{size:38});
  const index=Math.floor(u/.4);if(index<3)text(g,['99','100','999'][index],299,230,95,{color:C.yellow,two:true,outline:6});else infinity(g,320,198,1.2,C.yellow);
  if(u<.15)speed(g,u,1-u/.15);
}

function deityScene(g,u){
  background(g,u+21.6,{theme:'lava'});
  if(u<.10){g.fillStyle=u<.067?'#FFF8D4':C.ink;g.fillRect(0,0,540,960);poly(g,[[380,310],[120,505],[430,575],[290,530]],C.red,null);return}
  const shake=(1-clamp((u-.1)/.55))*14;g.save();g.translate(Math.sin(u*173)*shake,Math.cos(u*137)*shake);
  drawHero(g,206,650,590,{time:u,mouth:pulse(u,.85,.23),angry:true});
  killAndEat(g,u-.17,{hx:255,hy:505,mx:206,my:605,ex:397,ey:407,size:168,type:'golem',seed:500});
  shock(g,342,625,(u-.12)/.65,'#FF6621');shardBurst(g,380,430,(u-.1)/1.1,{n:70,radius:440,color:'#FF6621'});g.restore();
  if(u>.65)headline(g,'…END AS A','DEITY OF',u-.65,{y:152,bigSize:87});
  if(u>.8){let p=back((u-.8)/.25);g.save();g.translate(0,-150*(1-p));text(g,'DESTRUCTION.',240,321,72,{color:C.yellow,two:true,angle:-.035,max:410});g.restore()}
  if(u>1.2&&u<2.5){for(let i=0;i<4;i++){let a=(i/4)*Math.PI*2+u*.35,x=270+Math.cos(a)*213,y=575+Math.sin(a)*200;chain(g,250,590,x,y,{sag:28,time:u,width:5});drawWeapon(g,x,y,95,['iceaxe','greenaxe','sword','hammer'][i],a+.4)}}
  if(u>3){g.fillStyle=`rgba(255,248,229,${clamp((u-3)/.17)})`;g.fillRect(0,0,540,960)}
}

function logoWord(g,word,y,size,u,start,fill,stroke){
  g.font=`900 ${size}px "Londrina Solid"`;const widths=[...word].map(c=>g.measureText(c).width),total=widths.reduce((a,b)=>a+b,0)+2*(word.length-1);let x=270-total/2;
  for(let i=0;i<word.length;i++){let p=back((u-start-i*.045)/.42),yy=mix(-200,y,p),cx=x+widths[i]/2;if(u>=start+i*.045){chain(g,cx,-40,cx,yy-size*.74,{sag:0,width:4,time:u});g.save();g.font=`900 ${size}px "Londrina Solid"`;g.textAlign='center';g.textBaseline='alphabetic';g.lineJoin='round';g.strokeStyle=C.ink;g.lineWidth=20;g.strokeText(word[i],cx,yy);g.strokeStyle=stroke;g.lineWidth=10;g.strokeText(word[i],cx,yy);g.fillStyle=fill;g.fillText(word[i],cx,yy);g.restore()}x+=widths[i]+2}
}
function logoScene(g,u){
  background(g,u+24.8,{theme:'blood',ground:false});
  for(let i=0;i<14;i++){let a=i/14*Math.PI*2;poly(g,[[270+Math.cos(a)*130,490+Math.sin(a)*130],[270+Math.cos(a-.05)*730,490+Math.sin(a-.05)*730],[270+Math.cos(a+.05)*730,490+Math.sin(a+.05)*730]],'#591331',null)}
  drawHero(g,266,772,300,{time:u,chainsaw:true});
  logoWord(g,'BUTCHER',409,101,u,0,'#D2E8F8','#CB5276');logoWord(g,'HERO',559,170,u,.4,'#FF83A9','#FFF2DA');
  if(u>1)text(g,'HOOK. CHEW. REPEAT.',266,635,31,{outline:4,color:C.yellow});
}

function poster(g,t){
  g.fillStyle='#FDD205';g.fillRect(0,0,540,960);
  for(let i=0;i<12;i++){let a=i*Math.PI/6;poly(g,[[270,530],[270+Math.cos(a)*1100,530+Math.sin(a)*1100],[270+Math.cos(a+.07)*1100,530+Math.sin(a+.07)*1100]],'#EDAD09',null)}
  drawHero(g,270,580,650,{time:0,silhouette:true,angry:true});
  g.save();g.strokeStyle=C.ink;g.lineWidth=21;g.beginPath();g.ellipse(270,510,206,276,-.4,3.3,6.1);g.stroke();g.strokeStyle='#ED5524';g.lineWidth=12;g.stroke();g.restore();
  drawWeapon(g,455,430,190,'hook',-.25);drawWeapon(g,130,675,240,'chainsaw',-.4);
  for(let i=0;i<18;i++){let a=rand(i+55)*Math.PI*2,r=130+rand(i+84)*160;ellipse(g,250+Math.cos(a)*r,510+Math.sin(a)*r,4+rand(i)*10,3+rand(i+3)*8,C.red)}
}
function hand(g,x,y,press){
  g.save();g.translate(x,y+press*12);g.rotate(-.25);g.beginPath();g.moveTo(-6,57);g.lineTo(-17,8);g.bezierCurveTo(-24,-13,-5,-20,0,1);g.lineTo(7,22);g.lineTo(7,-27);g.bezierCurveTo(8,-44,28,-44,29,-27);g.lineTo(29,3);g.bezierCurveTo(43,-6,50,1,49,14);g.bezierCurveTo(63,9,70,20,65,35);g.bezierCurveTo(78,39,70,69,57,84);g.lineTo(11,84);g.closePath();g.fillStyle='#FFF4D6';g.fill();g.lineWidth=5;g.strokeStyle=C.ink;g.stroke();rr(g,7,73,53,25,5,'#E7484D',C.ink,5);g.restore();
}
function ctaScene(g,u){
  u=Math.min(u,2.1); // Locked final end card.
  const p=smooth((u-.15)/.58),w=mix(540,236,p),h=mix(960,236,p),x=(540-w)/2,y=mix(0,267,p);
  background(g,u+26.4,{theme:'blood',ground:false});
  if(p>.4){text(g,'BUTCHER HERO',266,198,55,{color:C.paper,outline:5});text(g,'YOUR NEXT POWER TRIP.',265,237,23,{color:C.yellow,outline:2})}
  g.save();g.beginPath();g.roundRect(x,y,w,h,34*p);g.clip();g.translate(x,y);g.scale(w/540,w/540);g.translate(0,-175*p);poster(g,u);g.restore();
  if(p>.8){g.strokeStyle=C.ink;g.lineWidth=8;g.beginPath();g.roundRect(x,y,w,h,34);g.stroke()}
  if(u>.65){let enter=back((u-.65)/.35),press=pulse(u,1.5,.2);g.save();g.translate(265,620);g.scale(enter,enter);rr(g,-179,-47+press*5,358,96,21,'#1D651E',C.ink,6);rr(g,-179,-57+press*9,358,96,21,'#4BE630',C.ink,6);line(g,[[-150,-45],[140,-45]],'#A0FF58',3);text(g,'PLAY FREE',-14,9+press*9,62,{color:'#092815',outline:0,max:300});poly(g,[[132,-23],[151,-10],[132,4]],'#092815',null);g.restore();
    if(u<2.1){const hp=out((u-1)/.3);hand(g,370,780-155*hp,press);if(press>.2)star(g,386,591,25*press,'#FFF3B5')}
    if(u>1){const a=out((u-1)/.3);g.save();g.globalAlpha=a;rr(g,45,689,191,55,12,'#111629','#776F84',2);rr(g,250,689,191,55,12,'#111629','#776F84',2);text(g,'App Store',140,711,22,{outline:0,max:180});star(g,118,728,6,C.yellow);text(g,'4.6',147,734,20,{color:C.yellow,outline:0});text(g,'Google Play',345,711,22,{outline:0,max:190});text(g,'1M+',345,734,20,{color:C.yellow,outline:0});g.restore()}
  }
}

const painters=[hookScene,growScene,underdogScene,islandsScene,arsenalScene,towerScene,dinnerScene,rematchScene,deityScene,logoScene,ctaScene];
export function render(g,t,width=1080,height=1920){
  t=clamp(t,0,DURATION-1/FPS);g.save();g.setTransform(width/540,0,0,height/960,0,0);g.globalAlpha=1;g.globalCompositeOperation='source-over';g.clearRect(0,0,540,960);
  const k=scenes.findIndex(s=>t>=s.start&&t<s.end);const i=k<0?10:k,u=t-scenes[i].start;
  painters[i](g,u);if(i!==10)vignette(g);
  // Up-to-down cut punctuation, always deterministic and only two frames long.
  if(i>0&&i!==8&&i!==10&&u<.0667){g.fillStyle='#F5D7AE';g.globalAlpha=.17*(1-u/.0667);g.fillRect(0,0,540,960);g.globalAlpha=1}
  g.restore();
}
