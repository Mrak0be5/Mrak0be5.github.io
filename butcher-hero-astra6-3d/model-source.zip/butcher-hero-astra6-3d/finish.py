"""Refine, rig and render one still; never creates or submits a video."""
import bpy, sys, json, time, math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
if sys.platform!='linux':raise RuntimeError('Server only')
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
draft='--draft' in args
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'output'/'butcher-hero-astra6.blend'))
from details import build_mouth
from rig import build_rig,parent_bone_keep_world,apply_pose

def tune(name,color=None,roughness=None,metallic=None):
    m=bpy.data.materials.get(name)
    if not m:return
    p=m.node_tree.nodes.get('Principled BSDF')
    if color is not None:p.inputs['Base Color'].default_value=(*color,1);m.diffuse_color=(*color,1)
    if roughness is not None:p.inputs['Roughness'].default_value=roughness
    if metallic is not None:p.inputs['Metallic'].default_value=metallic

tune('Hardware | forged steel',(.075,.10,.15),.35,.72)
for kind,color in [('hammer',(.20,.018,.42)),('iceaxe',(.01,.35,.52)),('greenaxe',(.025,.34,.010)),('sword',(.68,.31,.025))]:
    tune(kind+' | colored metal',color,.31,.18)
tune('AstraDetail_steel',(.12,.17,.23),.32,.75)
tune('AstraDetail_teal',(.009,.065,.070),.49,.02)
tune('AstraDetail_teal_light',(.016,.16,.17),.43,.03)
for name in ['BH basalt slate','BH distant cathedral stone']:
    m=bpy.data.materials.get(name)
    for n in m.node_tree.nodes:
        if n.type=='VALTORGB':
            for elem in n.color_ramp.elements:elem.color=(*[v*.48 for v in elem.color[:3]],1)
moonmat=bpy.data.materials['BH muted blood moon'];moonmat.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=.40

bpy.data.objects['Legendary_Chainsaw'].rotation_euler=(math.radians(8),math.radians(15),math.radians(-8))
bpy.context.scene.camera.data.lens=55
mouth=build_mouth(root=bpy.data.objects['Hero_Head_Details'])
arm=build_rig()
parent_bone_keep_world(bpy.data.objects['Hero_Head_Details'],arm,'head')
parent_bone_keep_world(bpy.data.objects['Hero_Riveted_Back_Armor'],arm,'chest')
parent_bone_keep_world(bpy.data.objects['Legendary_Chainsaw'],arm,'hand.L')

scene=bpy.context.scene
# Keyed skeletal action is part of the editable 3D asset. This script renders
# exactly one PNG, not an animation/video sequence.
scene.render.fps=30;scene.frame_start=1;scene.frame_end=49
for frame in range(1,50):
    apply_pose(arm,(frame-1)/30)
    for bone in arm.pose.bones:
        for channel in ['location','rotation_quaternion','scale']:
            bone.keyframe_insert(data_path=channel,frame=frame,group=bone.name)
if arm.animation_data and arm.animation_data.action:arm.animation_data.action.name='Hook attack | anticipate, strike, settle'
scene.frame_set(25);apply_pose(arm,.8)
scene.cycles.samples=16 if draft else 36
scene.render.resolution_x=540 if draft else 1080
scene.render.resolution_y=675 if draft else 1350
scene.render.resolution_percentage=100
scene.render.threads_mode='FIXED';scene.render.threads=3
scene.render.filepath=str(ROOT/'output'/('hero-action-draft.png' if draft else 'hero-action.png'))
scene['preview_only']='One still frame; 1.6-second editable skeletal action inside the blend file'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'output'/'butcher-hero-astra6-rigged.blend'))
begin=time.time();bpy.ops.render.render(write_still=True)
report={'render_seconds':time.time()-begin,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'samples':scene.cycles.samples,'bones':len(arm.pose.bones),'keyed_frames':49,'objects':len(scene.objects),'image':scene.render.filepath,'engine':'Cycles CPU on claude-hub-prod'}
(ROOT/'output'/'action-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('ACTION_STILL_COMPLETE',json.dumps(report))
