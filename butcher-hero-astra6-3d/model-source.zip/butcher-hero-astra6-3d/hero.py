"""Original sculptural Butcher Hero model; no external mesh or texture assets."""
import bpy
import math
import random
from mathutils import Vector
from math import sin, cos, pi

def material(name, color, roughness=.45, metallic=0, noise=0):
    m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True
    n=m.node_tree.nodes;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=roughness;p.inputs['Metallic'].default_value=metallic
    if noise:
        tex=n.new('ShaderNodeTexNoise');tex.inputs['Scale'].default_value=80;tex.inputs['Detail'].default_value=2
        bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.15;bump.inputs['Distance'].default_value=noise
        m.node_tree.links.new(tex.outputs['Fac'],bump.inputs['Height']);m.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
    return m

def smooth(obj, mat=None):
    if mat:obj.data.materials.append(mat)
    if obj.type=='MESH':
        for p in obj.data.polygons:p.use_smooth=True
    return obj

def ellipsoid(name, loc, scale, mat, segments=48, rings=32):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=loc)
    o=bpy.context.object;o.name=name;o.scale=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    return smooth(o,mat)

def capsule(name,a,b,r,mat,scale2=None):
    a,b=Vector(a),Vector(b);delta=b-a
    o=ellipsoid(name,(a+b)/2,(r,r,delta.length/2+r*.45),mat,40,24)
    o.rotation_euler=delta.to_track_quat('Z','Y').to_euler()
    return o

def curve(name,points,radius,mat,res=3):
    d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.resolution_u=res;d.bevel_depth=radius;d.bevel_resolution=3
    s=d.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
    for p,v in zip(s.bezier_points,points):p.co=v;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
    o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);o.data.materials.append(mat);return o

def bevel_box(name,loc,scale,mat,bevel=.07):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=name;o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(mat)
    mod=o.modifiers.new('Soft manufactured edges','BEVEL');mod.width=bevel;mod.segments=3
    o.modifiers.new('Weighted face normals','WEIGHTED_NORMAL');return o

def ring_body(mat):
    # A continuous asymmetric torso surface, with shaped trapezius and belly.
    profiles=[(1.10,.48,.40,.12),(1.28,.84,.63,.08),(1.55,1.03,.73,.02),(1.90,1.17,.90,-.06),(2.30,1.31,1.04,-.09),(2.66,1.35,.98,-.025),(3.03,1.25,.83,.01),(3.34,1.14,.68,.02),(3.58,1.09,.59,.04),(3.77,.85,.47,.07),(3.91,.44,.34,.03),(4.03,.29,.29,.02)]
    N=80;verts=[];faces=[]
    for z,rx,ry,cy in profiles:
        for j in range(N):
            a=j/N*2*pi;front=max(0,-sin(a));bulge=.022*sin(3*a+z*2)+.008*cos(7*a-z*5)
            verts.append((cos(a)*rx*(1+bulge),cy+sin(a)*ry*(1+bulge),z+.023*cos(a*2)*front))
    for k in range(len(profiles)-1):
        for j in range(N):faces.append((k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j))
    faces.append(tuple(range(N-1,-1,-1)));faces.append(tuple((len(profiles)-1)*N+j for j in range(N)))
    mesh=bpy.data.meshes.new('Sculpted torso topology');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('Hero | continuous torso',mesh);bpy.context.collection.objects.link(o);smooth(o,mat)
    sub=o.modifiers.new('Organic surface subdivision','SUBSURF');sub.levels=2
    bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=sub.name)
    return o

def shorts(mat,seam_mat):
    N=80;verts=[];faces=[]
    for k,z in enumerate([1.08,1.21,1.56,1.78]):
        for j in range(N):
            a=j/N*2*pi;radx=[.97,1.08,1.13,1.13][k];rady=[.66,.77,.80,.83][k]
            zig=(.07 if j%4<2 else -.09) if k==0 else 0
            verts.append((cos(a)*radx,sin(a)*rady+.02,z+zig))
    for k in range(3):
        for j in range(N):faces.append((k*N+j,k*N+(j+1)%N,(k+1)*N+(j+1)%N,(k+1)*N+j))
    mesh=bpy.data.meshes.new('Ragged shorts mesh');mesh.from_pydata(verts,[],faces);o=bpy.data.objects.new('Shorts | navy canvas',mesh);bpy.context.collection.objects.link(o);smooth(o,mat)
    solid=o.modifiers.new('Thick ragged fabric','SOLIDIFY');solid.thickness=.065
    bevel=o.modifiers.new('Worn cloth edges','BEVEL');bevel.width=.025;bevel.segments=2
    curve('Shorts | waistband',[(cos(i/40*2*pi)*1.13,sin(i/40*2*pi)*.83+.02,1.77) for i in range(41)],.06,seam_mat)
    for side in [-1,1]:
        curve('Shorts | pocket seam',[(side*.80,-.59,1.68),(side*.95,-.40,1.46),(side*.94,-.38,1.22)],.018,seam_mat)
    curve('Shorts | fly',[(0,-.84,1.71),(.015,-.81,1.40),(.09,-.78,1.18)],.021,seam_mat)
    return o

def build_hero():
    skin=material('Skin | warm orange clay',(.52,.165,.035),.51,noise=.013)
    skin.node_tree.nodes.get('Principled BSDF').inputs['Subsurface Weight'].default_value=.08
    scar=material('Scar | dark healed stitch line',(.185,.043,.025),.63)
    thread=material('Sutures | warm dark thread',(.11,.055,.032),.72)
    nail=material('Nails | bone ochre',(.39,.29,.15),.5)
    denim=material('Shorts | midnight blue',(.023,.047,.095),.74,noise=.009)
    seam=material('Shorts | worn blue seams',(.072,.13,.21),.8)
    leather=material('Leather | charcoal',(.022,.028,.037),.61,noise=.004)
    steel=material('Hardware | forged steel',(.28,.33,.40),.26,.8)
    pieces=[ring_body(skin)]
    pieces.append(ellipsoid('Neck',(0,.035,3.8),(.50,.46,.51),skin))
    pieces.append(ellipsoid('Head under mask',(0,.015,4.1),(.62,.58,.69),skin))
    for side in [-1,1]:
        # Keep a real armpit opening below z~3.0 before voxel union. The old
        # close-set arms fused along the flank and stretched into a skin web.
        pieces.append(ellipsoid('Shoulder',(side*1.12,.07,3.43),(.55,.55,.50),skin))
        pieces.append(capsule('Upper arm',(side*1.48,.08,3.43),(side*1.97,-.04,2.64),.34,skin))
        pieces.append(ellipsoid('Elbow',(side*1.98,-.075,2.52),(.33,.35,.34),skin))
        pieces.append(capsule('Heavy forearm',(side*1.98,-.075,2.54),(side*2.18,-.38,1.96),.35,skin))
    # Union and smooth the form into one skin, removing intersecting primitive seams.
    bpy.ops.object.select_all(action='DESELECT')
    for o in pieces:o.select_set(True)
    bpy.context.view_layer.objects.active=pieces[0];bpy.ops.object.join();body=bpy.context.object;body.name='Hero | unified sculpted skin'
    rem=body.modifiers.new('Sculpt union','REMESH');rem.mode='VOXEL';rem.voxel_size=.045;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name)
    soft=body.modifiers.new('Relax skin surface','SMOOTH');soft.factor=.65;soft.iterations=4;bpy.ops.object.modifier_apply(modifier=soft.name)
    sub=body.modifiers.new('Final skin smoothness','SUBSURF');sub.levels=1;sub.render_levels=1
    # Thick legs and human-readable feet rather than round toy nubs.
    for side in [-1,1]:
        leg=ellipsoid('Leg',(side*.57,.02,.77),(.43,.45,.63),skin)
        foot=ellipsoid('Broad foot',(side*.61,-.31,.23),(.43,.70,.24),skin);foot.rotation_euler.z=side*.12
        for j in range(4):
            xx=side*.61+(j-1.5)*.175;yy=-.87+.035*abs(j-1.5)
            ellipsoid('Toe',(xx,yy,.22),(.115,.20,.15),skin,24,16)
            ellipsoid('Toenail',(xx,yy-.11,.30),(.070,.082,.022),nail,20,12)
        wrist=Vector((side*2.20,-.40,1.96))
        ellipsoid('Palm',(side*2.20,-.49,1.80),(.38,.29,.40),skin)
        for j in range(4):
            xx=side*2.20+(j-1.5)*.14;zz=1.64+.04*abs(j-1.5)
            capsule('Curled finger',(xx,-.64,1.91),(xx,-.70,zz),.105,skin)
            ellipsoid('Finger knuckle',(xx,-.705,1.88),(.115,.08,.125),skin,24,16)
            ellipsoid('Fingernail',(xx,-.79,zz+.07),(.067,.021,.076),nail,20,12)
        capsule('Thumb',(side*1.93,-.62,1.96),(side*1.93,-.81,1.69),.145,skin)
        # Wrist cuff axis follows the forearm, with visible steel rivets.
        bpy.ops.mesh.primitive_torus_add(major_radius=.32,minor_radius=.075,major_segments=48,minor_segments=12,location=(side*2.14,-.33,2.08))
        cuff=bpy.context.object;cuff.name='Leather wrist cuff';cuff.data.materials.append(leather)
        for j in range(6):
            a=j/6*2*pi;ellipsoid('Cuff rivet',(side*2.14+cos(a)*.33,-.33+sin(a)*.33,2.08),(.055,.055,.055),steel,16,10)
    shorts(denim,seam)
    # Stitched scar follows the front curvature of the belly, clean geometric sutures.
    def front(x,z):
        # Approximated skin surface, increasing depth around the broad belly.
        ry=.78+.285*math.exp(-((z-2.35)/.54)**2)
        rx=1.12+.23*math.exp(-((z-2.6)/.68)**2)
        return -.045-ry*math.sqrt(max(.05,1-(x/rx)**2))-.035
    points=[]
    for i in range(19):
        u=i/18;x=-.78+1.61*u;z=3.35-1.28*u;points.append((x,front(x,z),z))
    curve('Main diagonal scar',points,.030,scar)
    for i in range(14):
        u=(i+.3)/14;x=-.78+1.61*u;z=3.35-1.28*u
        xa,za=x-.072,z-.077;xb,zb=x+.076,z+.08
        curve('Raised cross suture',[(xa,front(xa,za)-.012,za),(x,front(x,z)-.05,z),(xb,front(xb,zb)-.012,zb)],.017,thread)
        for xx,zz in [(xa,za),(xb,zb)]:ellipsoid('Stitch insertion',(xx,front(xx,zz)+.012,zz),(.028,.015,.022),scar,16,10)
    # Belly folds and a tiny inset navel give the body dimensional anatomy.
    curve('Lower belly crease',[(-.70,-.87,1.96),(-.36,-1.025,1.92),(0,-1.07,1.91),(.42,-1.008,1.94),(.77,-.84,2.02)],.015,scar)
    ellipsoid('Navel',(.17,-1.143,2.23),(.075,.018,.045),scar,24,16)
    for side in [-1,1]:
        points=[(side*.93,-.67,3.5),(side*1.17,-.57,3.43),(side*1.38,-.49,3.32)]
        curve('Shoulder scar',points,.024,scar)
        for j in range(4):
            x=side*(.96+j*.115);y=-.66+j*.048;z=3.49-j*.045
            curve('Shoulder suture',[(x-.045,y-.012,z-.060),(x,y-.04,z),(x+.045,y-.012,z+.060)],.018,thread)
    return {'body':body,'skin':skin,'steel':steel,'leather':leather}

def make_chain(name,a,b,sag=.25,links=23):
    mat=bpy.data.materials.get('Hardware | forged steel')
    if not mat:mat=material('Hardware | forged steel',(.28,.33,.40),.27,.82)
    a,b=Vector(a),Vector(b)
    for i in range(links):
        t=(i+.5)/links;p=a.lerp(b,t);p.z-=sin(t*pi)*sag
        tangent=b-a+Vector((0,0,-cos(t*pi)*sag*pi))
        bpy.ops.mesh.primitive_torus_add(major_segments=12,minor_segments=6,location=p,major_radius=.065,minor_radius=.018)
        o=bpy.context.object;o.name=name;o.scale=(1,1.35,1);o.rotation_euler=tangent.to_track_quat('Y','Z').to_euler()
        if i%2:o.rotation_euler.rotate_axis('Y',pi/2)
        smooth(o,mat)

def hero_weapon(kind,location,rotation=(0,0,0)):
    steel=bpy.data.materials.get('Hardware | forged steel');shaft=material(kind+' | leather grip',(.07,.085,.10),.6)
    tint={'hammer':(.35,.10,.63),'iceaxe':(.20,.72,.86),'greenaxe':(.20,.60,.16),'sword':(.87,.48,.065)}[kind]
    accent=material(kind+' | colored metal',tint,.26,.55)
    edge=material(kind+' | sharpened edge',tuple(min(1,c*.65+.35) for c in tint),.19,.65)
    bpy.ops.object.empty_add(location=location);root=bpy.context.object;root.name='Suspended '+kind;root.rotation_euler=rotation
    before=set(bpy.data.objects)
    bpy.ops.mesh.primitive_cylinder_add(vertices=24,radius=.065,depth=1.2,location=(0,0,0));smooth(bpy.context.object,shaft)
    for z in [-.53,-.43,-.33,-.23,-.13]:
        bpy.ops.mesh.primitive_torus_add(major_radius=.070,minor_radius=.017,major_segments=20,minor_segments=6,location=(0,0,z));smooth(bpy.context.object,steel)
    if kind=='hammer':
        bevel_box('Hammer | iron core',(0,0,.7),(.95,.45,.59),steel,.075)
        for s in [-1,1]:bevel_box('Hammer | amethyst face',(s*.48,0,.7),(.19,.49,.64),accent,.08)
        bevel_box('Hammer | crystalline top',(0,0,.99),(.56,.34,.13),accent,.045)
        curve('Hammer | pale fracture',[(-.26,-.245,.93),(-.12,-.26,.77),(.03,-.26,.82),(.20,-.245,.55)],.016,edge)
    elif kind in ['iceaxe','greenaxe']:
        for side in [-1,1]:
            verts=[(side*.10,-.08,.91),(side*.47,-.08,1.03),(side*.65,-.08,.79),(side*.55,-.08,.39),(side*.26,-.08,.58),(side*.10,.08,.91),(side*.47,.08,1.03),(side*.65,.08,.79),(side*.55,.08,.39),(side*.26,.08,.58)]
            faces=[(0,1,2,3,4),(9,8,7,6,5)]+[(i,(i+1)%5,(i+1)%5+5,i+5) for i in range(5)]
            mesh=bpy.data.meshes.new('Forged axe blade');mesh.from_pydata(verts,[],faces);o=bpy.data.objects.new('Double axe blade',mesh);bpy.context.collection.objects.link(o);o.data.materials.append(accent)
            mod=o.modifiers.new('Cutting edge bevel','BEVEL');mod.width=.045;mod.segments=3;o.modifiers.new('Weighted blade normals','WEIGHTED_NORMAL')
        ellipsoid('Axe | boss',(0,-.06,.72),(.15,.15,.15),steel,24,16)
    else:
        verts=[(-.16,0,.38),(.16,0,.38),(.15,0,1.40),(0,0,1.68),(-.15,0,1.40),(0,-.085,.47),(0,-.06,1.38),(0,.085,.47),(0,.06,1.38)]
        faces=[(0,1,5),(1,2,6,5),(2,3,6),(3,4,6),(4,0,5,6),(1,0,7),(2,1,7,8),(3,2,8),(4,3,8),(0,4,8,7)]
        mesh=bpy.data.meshes.new('Gold sword bevel geometry');mesh.from_pydata(verts,[],faces);o=bpy.data.objects.new('Golden sword blade',mesh);bpy.context.collection.objects.link(o);o.data.materials.append(accent)
        bevel_box('Sword | guard',(0,0,.32),(.60,.16,.15),edge,.04);ellipsoid('Sword | pommel',(0,0,-.68),(.14,.10,.15),accent)
    for obj in set(bpy.data.objects)-before:obj.parent=root
    return root
