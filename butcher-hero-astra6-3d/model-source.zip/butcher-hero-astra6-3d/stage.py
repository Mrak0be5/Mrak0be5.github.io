"""Original procedural cathedral arena for the Astra 6 3D art-direction frame.

Blender module; no external assets and no rendering side effects. Hero feet at
Z=0, hero front toward -Y. Designed for camera approximately (7, -12, 6).
Call build_stage(lighting=True). The caller owns camera and render settings.
"""
import math
import random

import bpy
from mathutils import Vector


_COLLECTION = None


def _put(obj):
    for old in tuple(obj.users_collection):
        old.objects.unlink(obj)
    _COLLECTION.objects.link(obj)
    return obj


def _material(name, color, roughness=.7, metallic=0, emission=None):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*color, 1)
    shader.inputs['Roughness'].default_value = roughness
    shader.inputs['Metallic'].default_value = metallic
    if emission:
        shader.inputs['Emission Color'].default_value = (*emission[0], 1)
        shader.inputs['Emission Strength'].default_value = emission[1]
    return mat


def _stone(name, dark, light, scale=3.5):
    mat = _material(name, light, .80)
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    shader = nodes.get('Principled BSDF')
    noise = nodes.new('ShaderNodeTexNoise')
    noise.inputs['Scale'].default_value = scale
    noise.inputs['Detail'].default_value = 2.0
    noise.inputs['Roughness'].default_value = .62
    ramp = nodes.new('ShaderNodeValToRGB')
    ramp.color_ramp.elements[0].position = .18
    ramp.color_ramp.elements[0].color = (*dark, 1)
    ramp.color_ramp.elements[1].position = .82
    ramp.color_ramp.elements[1].color = (*light, 1)
    links.new(noise.outputs['Fac'], ramp.inputs[0])
    links.new(ramp.outputs['Color'], shader.inputs['Base Color'])
    bump = nodes.new('ShaderNodeBump')
    bump.inputs['Strength'].default_value = .17
    bump.inputs['Distance'].default_value = .055
    links.new(noise.outputs['Fac'], bump.inputs['Height'])
    links.new(bump.outputs['Normal'], shader.inputs['Normal'])
    return mat


def _mesh(name, verts, faces, mat, bevel=0):
    data = bpy.data.meshes.new(name + '_Mesh')
    data.from_pydata(verts, [], faces)
    data.update()
    obj = bpy.data.objects.new(name, data)
    _COLLECTION.objects.link(obj)
    obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new('Soft chipped edges', 'BEVEL')
        mod.width = bevel
        mod.segments = 2
        mod.affect = 'EDGES'
        normal = obj.modifiers.new('Face normals', 'WEIGHTED_NORMAL')
        normal.keep_sharp = True
        normal.weight = 40
    return obj


def _box(name, loc, scale, mat, bevel=.04):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    obj = _put(bpy.context.object)
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(mat)
    if bevel:
        m = obj.modifiers.new('Worn arris', 'BEVEL')
        m.width = bevel
        m.segments = 2
        obj.modifiers.new('Architectural normals', 'WEIGHTED_NORMAL')
    return obj


def _prism(name, polygon, bottom, top, mat, bevel=.035):
    n = len(polygon)
    verts = [(x, y, bottom) for x, y in polygon] + [(x, y, top) for x, y in polygon]
    faces = [tuple(reversed(range(n))), tuple(range(n, 2*n))]
    faces += [(i, (i+1) % n, (i+1) % n+n, i+n) for i in range(n)]
    return _mesh(name, verts, faces, mat, bevel)


def _cylinder(name, loc, radius, depth, mat, vertices=48):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    obj = _put(bpy.context.object)
    obj.name = name
    obj.data.materials.append(mat)
    bevel = obj.modifiers.new('Stone edge', 'BEVEL')
    bevel.width = .055
    bevel.segments = 2
    obj.modifiers.new('Cylinder normals', 'WEIGHTED_NORMAL')
    return obj


def _beam(name, start, end, width, depth, mat, bevel=.035):
    a, b = Vector(start), Vector(end)
    obj = _box(name, (a+b)*.5, (width, depth, (b-a).length), mat, bevel)
    obj.rotation_euler = (b-a).to_track_quat('Z', 'Y').to_euler()
    return obj


def _point(name, loc, color, energy, size):
    data = bpy.data.lights.new(name, 'POINT')
    data.color, data.energy, data.shadow_soft_size = color, energy, size
    obj = bpy.data.objects.new(name, data)
    _COLLECTION.objects.link(obj)
    obj.location = loc
    return obj


def _area(name, loc, target, color, energy, size):
    data = bpy.data.lights.new(name, 'AREA')
    data.color, data.energy, data.shape, data.size = color, energy, 'DISK', size
    obj = bpy.data.objects.new(name, data)
    _COLLECTION.objects.link(obj)
    obj.location = loc
    obj.rotation_euler = (Vector(target)-obj.location).to_track_quat('-Z', 'Y').to_euler()
    return obj


def _arena(stone, edge, lava, rng):
    # Lava is recessed under real gaps, not drawn on the surface.
    _cylinder('Arena dark foundation', (0, 0, -.69), 5.28, 1.08, edge)
    lava_floor = _cylinder('Recessed molten fissure bed', (0, 0, -.27), 5.12, .07, lava)
    # Broad center stays visually calm underneath the hero's feet.
    center = [(math.cos(i*math.tau/12)*1.50, math.sin(i*math.tau/12)*1.50) for i in range(12)]
    floor = _prism('Hero standing stone', center, -.25, -.025, stone, .045)
    segments = 18
    for ring, (r0, r1) in enumerate(((1.53, 3.05), (3.09, 4.25), (4.29, 5.10))):
        for j in range(segments):
            a = j*math.tau/segments + ring*.017
            b = (j+1)*math.tau/segments + ring*.017
            da = .007 if ring < 2 else .010
            inner0, inner1 = r0+rng.uniform(0,.025), r0+rng.uniform(0,.025)
            outer0, outer1 = r1-rng.uniform(0,.07), r1-rng.uniform(0,.07)
            poly = [(inner0*math.cos(a+da), inner0*math.sin(a+da)),
                    (outer0*math.cos(a+da), outer0*math.sin(a+da)),
                    (outer1*math.cos(b-da), outer1*math.sin(b-da)),
                    (inner1*math.cos(b-da), inner1*math.sin(b-da))]
            _prism(f'Fractured floor slab {ring}-{j:02}', poly, -.29,
                   -.035+rng.uniform(-.010,.010), stone if j % 6 else edge, .028)
    # The foundation's irregular vertical buttresses give the platform real depth.
    for j in range(18):
        angle = j*math.tau/18
        loc = (math.cos(angle)*5.10, math.sin(angle)*5.10, -.64)
        obj = _box(f'Rim support {j:02}', loc, (.48,.44,.74), edge, .055)
        obj.rotation_euler.z = angle
    return floor, lava_floor


def _arch(name, x, y, height, halfwidth, stone, iron, broken=False):
    spring = height - math.sqrt(3)*halfwidth
    for sign in (-1, 1):
        # Tiered buttress silhouette is intentionally asymmetrical behind the hero.
        px = x+sign*halfwidth
        _box(name+' pier', (px,y,spring/2), (.47,.69,spring), stone, .075)
        _box(name+' foot', (px,y,.23), (.86,1.02,.46), stone, .065)
        _box(name+' collar', (px,y,spring-.07), (.65,.88,.26), iron, .030)
        _box(name+' side buttress', (px+sign*.37,y+.12,spring*.40), (.31,.67,spring*.80), stone, .060)
        # Two pointed arcs made from individual shaped, beveled voussoirs.
        steps = 10
        for i in range(steps):
            if broken and sign == 1 and i > 5:
                continue
            u0, u1 = i/steps, (i+1)/steps
            # Left arc is a circle centered at the opposite spring point.
            lx0 = -halfwidth + halfwidth*u0
            lx1 = -halfwidth + halfwidth*u1
            z0 = spring+math.sqrt(max(0, 4*halfwidth**2-(lx0-halfwidth)**2))
            z1 = spring+math.sqrt(max(0, 4*halfwidth**2-(lx1-halfwidth)**2))
            p0 = (x+(-lx0 if sign == 1 else lx0),y,z0)
            p1 = (x+(-lx1 if sign == 1 else lx1),y,z1)
            _beam(name+f' pointed arch {sign}:{i}', p0, p1, .30, .65, stone, .040)
        # Narrow spire adds the Gothic shape without filling the background.
        bpy.ops.mesh.primitive_cone_add(vertices=4, radius1=.40, radius2=.04,
                                      depth=1.15, location=(px,y,spring+.65))
        obj = _put(bpy.context.object)
        obj.name = name+' spire'
        obj.data.materials.append(iron)
    if not broken:
        _box(name+' apex keystone', (x,y,height+.015), (.43,.84,.54), iron, .045)


def _chain(name, start, end, count, radius, mat):
    # Sparse foreground chain: actual alternating links, never a screen overlay.
    a, b = Vector(start), Vector(end)
    direction = (b-a).normalized()
    axis = direction.to_track_quat('Y', 'Z')
    for j in range(count):
        p = a.lerp(b,j/max(count-1,1))
        p.z -= .17*math.sin(math.pi*j/max(count-1,1))
        bpy.ops.mesh.primitive_torus_add(major_segments=12, minor_segments=5,
            location=p, major_radius=radius, minor_radius=radius*.19)
        obj = _put(bpy.context.object)
        obj.name = name+f' link {j:02}'
        obj.scale = (1,1.35,1)
        obj.rotation_mode = 'QUATERNION'
        from mathutils import Quaternion
        obj.rotation_quaternion = axis @ Quaternion((0,1,0), math.pi/2*(j%2))
        obj.data.materials.append(mat)


def _moon(mat, crater):
    center = Vector((-3.8,9.1,6.5))
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=1.70, location=center)
    obj = _put(bpy.context.object)
    obj.name = 'Blood moon'
    obj.data.materials.append(mat)
    for p in obj.data.polygons:
        p.use_smooth = True
    # Broad crater patches are geometry; their low contrast keeps the hero primary.
    viewer = Vector((7,-12,6))
    normal = (viewer-center).normalized()
    right = normal.cross(Vector((0,0,1))).normalized()
    up = right.cross(normal).normalized()
    for i,(u,v,r) in enumerate(((-.52,.25,.22),(.31,.59,.12),(.43,-.35,.29),(-.15,-.45,.10))):
        vector = normal*math.sqrt(max(.01,1-u*u-v*v)) + right*u + up*v
        pos = center+vector*1.694
        bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=1,location=pos)
        patch = _put(bpy.context.object)
        patch.name = f'Moon basalt crater {i}'
        patch.scale = (r*1.35,r,.018)
        patch.rotation_euler = vector.to_track_quat('Z','Y').to_euler()
        patch.data.materials.append(crater)
    return obj


def build_stage(lighting=True):
    """Build once in a named collection; returns objects needed by the caller.

    Does not clear the scene, create a camera, render, save, or change color
    management. Repeated calls replace only this module's own collection.
    """
    global _COLLECTION
    previous = bpy.data.collections.get('BH_Stage')
    if previous:
        for obj in list(previous.objects):
            bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.collections.remove(previous)
    _COLLECTION = bpy.data.collections.new('BH_Stage')
    bpy.context.scene.collection.children.link(_COLLECTION)
    rng = random.Random(6015055)
    stone = _stone('BH basalt slate', (.035,.045,.060), (.125,.165,.190), 3.1)
    edge = _stone('BH deep foundation', (.016,.021,.027), (.062,.082,.095), 2.7)
    architecture = _stone('BH distant cathedral stone', (.026,.026,.036), (.090,.078,.095), 2.1)
    iron = _material('BH blackened Gothic iron', (.027,.032,.041), .37, .72)
    lava = _material('BH molten orange fissures', (.90,.035,.001), .31, 0,
                     ((1.0,.065,.003),3.2))
    moonmat = _material('BH muted blood moon', (.42,.018,.021), .9, 0,
                        ((.75,.020,.029),.85))
    craters = _material('BH moon crater red', (.12,.012,.020), 1, 0,
                        ((.20,.008,.016),.32))
    floor, lava_floor = _arena(stone,edge,lava,rng)
    # Secondary silhouettes stay behind the action and clear the central hero.
    _arch('Western broken cathedral', -6.4,5.9,8.1,1.23,architecture,iron,True)
    _arch('Eastern cathedral', 4.9,8.7,8.8,1.58,architecture,iron,False)
    _arch('Far transept', -.20,12.3,7.7,1.06,edge,iron,True)
    # Far ground gives real shadowed depth under the raised arena.
    _cylinder('Distant dark ground', (0,2,-1.31), 27,.16,edge,64)
    # Broken stones avoid the hero's contact patch and lower text/weapon zone.
    for j in range(17):
        angle = rng.uniform(0,math.tau)
        radius = rng.uniform(4.45,5.05)
        pos = (radius*math.cos(angle),radius*math.sin(angle),rng.uniform(.04,.12))
        obj = _box(f'Rim rubble {j:02}',pos,
            (rng.uniform(.16,.38),rng.uniform(.13,.29),rng.uniform(.12,.30)),stone,.035)
        obj.rotation_euler = (rng.uniform(-.18,.18),rng.uniform(-.18,.18),rng.uniform(0,math.tau))
    _chain('Foreground left hanging iron',(-5.2,-3.5,3.8),(-5.0,-3.2,.15),15,.16,iron)
    _chain('Foreground right iron', (4.85,-2.8,2.0),(5.3,-2.3,-.25),11,.14,iron)
    moon = _moon(moonmat,craters)
    lights=[]
    if lighting:
        lights += [_area('Hero warm sculpting key',(3.5,-5.5,8.5),(0,0,2.9),(1.0,.73,.52),1550,4.6),
                   _area('Hero cool steel rim',(-4.2,3.2,6.6),(0,0,3.1),(.28,.58,.88),1800,3.5),
                   _area('Soft mask fill',(-2,-6,3.8),(0,0,3.5),(.68,.78,1.0),190,3.8),
                   _area('Blood moon red edge',(-3.8,7.5,6.2),(0,0,3.1),(1,.075,.035),430,3.2),
                   _area('Low lava bounce',(1,-3.7,.32),(0,0,2.1),(1,.13,.015),105,2.5)]
        for j,angle in enumerate((.7,2.3,3.9,5.5)):
            lights.append(_point(f'Local fissure bounce {j}',
                (3.6*math.cos(angle),3.6*math.sin(angle),.12),(1,.085,.006),26,1.0))
    return {'collection':_COLLECTION,'floor':floor,'lava':lava_floor,'moon':moon,'lights':lights}
