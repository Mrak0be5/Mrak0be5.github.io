"""Original dimensional character detail kit. Blender 4.x / 5.x, no assets.

World axes: Z up, hero looks toward -Y. Head details are authored in world
coordinates for a 4.7-unit hero. Every build function returns a named parent.
No rendering, external file access, animation or random state in this module.
"""
import bpy
import math
from mathutils import Vector


def material(name, rgb, metallic=0.0, roughness=0.4, emission=0.0):
    m = bpy.data.materials.get(name)
    if m is None:
        m = bpy.data.materials.new(name)
    m.diffuse_color = (*rgb, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*rgb, 1)
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = roughness
    if 'Coat Weight' in p.inputs:
        p.inputs['Coat Weight'].default_value = 0.16
        p.inputs['Coat Roughness'].default_value = 0.28
    if emission:
        p.inputs['Emission Color'].default_value = (*rgb, 1)
        p.inputs['Emission Strength'].default_value = emission
    return m


def palette(overrides=None):
    # Color values are scene-linear and deliberately restrained under key light.
    specs = {
        'bone': ((0.73, 0.60, 0.38), 0.02, 0.37),
        'bone_edge': ((0.40, 0.29, 0.19), 0.04, 0.50),
        'ivory': ((0.98, 0.86, 0.59), 0.05, 0.31),
        'red_paint': ((0.36, 0.014, 0.019), 0.13, 0.31),
        'cavity': ((0.005, 0.008, 0.018), 0.03, 0.62),
        'eye_red': ((0.95, 0.012, 0.016), 0.0, 0.24, 1.7),
        'eye_core': ((1.0, 0.18, 0.12), 0.0, 0.2, 2.1),
        'teal': ((0.015, 0.135, 0.15), 0.11, 0.40),
        'teal_light': ((0.027, 0.26, 0.27), 0.08, 0.35),
        'steel': ((0.24, 0.31, 0.39), 0.82, 0.29),
        'steel_edge': ((0.55, 0.67, 0.72), 0.87, 0.24),
        'armor': ((0.075, 0.10, 0.155), 0.7, 0.35),
        'armor_side': ((0.025, 0.042, 0.073), 0.7, 0.36),
        'leather': ((0.048, 0.025, 0.025), 0.0, 0.69),
        'rubber': ((0.014, 0.020, 0.024), 0.06, 0.70),
        'saw_yellow': ((0.93, 0.42, 0.025), 0.22, 0.30),
        'saw_high': ((1.0, 0.65, 0.055), 0.14, 0.29),
        'saw_orange': ((0.55, 0.075, 0.017), 0.18, 0.40),
        'saw_warning': ((0.97, 0.77, 0.21), 0.0, 0.43),
    }
    result = {k: material('AstraDetail_' + k, *v) for k, v in specs.items()}
    if overrides:
        for k, v in overrides.items():
            if k in result and isinstance(v, bpy.types.Material):
                result[k] = v
    return result


def parent(name):
    o = bpy.data.objects.new(name, None)
    bpy.context.collection.objects.link(o)
    o.empty_display_type = 'PLAIN_AXES'
    o.empty_display_size = 0.15
    return o


def adopt(o, root, mat=None):
    o.parent = root
    if mat is not None:
        o.data.materials.append(mat)
    return o


def finish(o, bevel=0.015, segments=3, smooth=False):
    if smooth:
        for p in o.data.polygons:
            p.use_smooth = True
    if bevel:
        mod = o.modifiers.new('Machined soft edge', 'BEVEL')
        mod.width = bevel
        mod.segments = segments
        mod.limit_method = 'ANGLE'
    if not smooth:
        mod = o.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
        mod.keep_sharp = True
        mod.weight = 40
    return o


def mesh(name, verts, faces, mat, root=None, bevel=0.012, smooth=False):
    data = bpy.data.meshes.new(name + '_mesh')
    data.from_pydata(verts, [], faces)
    data.update()
    o = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(o)
    if root:
        o.parent = root
    data.materials.append(mat)
    return finish(o, bevel, smooth=smooth)


def cube(name, loc, scale, mat, root=None, bevel=0.025):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.dimensions = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(adopt(o, root, mat), bevel)


def uvball(name, loc, scale, mat, root=None, segments=24):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=12, radius=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.scale = scale
    adopt(o, root, mat)
    for p in o.data.polygons:
        p.use_smooth = True
    return o


def cylinder(name, loc, radius, depth, mat, root=None, axis=(0, -1, 0), vertices=32, bevel=0.008):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    o = bpy.context.object
    o.name = name
    o.rotation_euler = Vector(axis).to_track_quat('Z', 'Y').to_euler()
    adopt(o, root, mat)
    return finish(o, bevel)


def tube(name, pts, radius, mat, root=None, cyclic=False):
    data = bpy.data.curves.new(name + '_curve', 'CURVE')
    data.dimensions = '3D'
    data.resolution_u = 12
    data.bevel_depth = radius
    data.bevel_resolution = 3
    spline = data.splines.new('POLY')
    spline.points.add(len(pts) - 1)
    for p, co in zip(spline.points, pts):
        p.co = (*co, 1)
    spline.use_cyclic_u = cyclic
    o = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(o)
    data.materials.append(mat)
    if root:
        o.parent = root
    return o


def prism_xz(name, points, yfront, yback, mat, root=None, bevel=0.008):
    # Polygon coordinates are (x,z), extrusion axis is Y.
    # Mirrored left/right eye polygons must keep outward volume normals.
    area = sum(points[i][0] * points[(i+1) % len(points)][1] -
               points[(i+1) % len(points)][0] * points[i][1]
               for i in range(len(points)))
    if area > 0:
        points = list(reversed(points))
    n = len(points)
    verts = [(x, yfront, z) for x, z in points] + [(x, yback, z) for x, z in points]
    faces = [tuple(range(n - 1, -1, -1)), tuple(range(n, 2 * n))]
    faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
    return mesh(name, verts, faces, mat, root, bevel)


def bolt(name, x, y, z, mats, root, r=0.027, direction=-1):
    axis = (0, direction, 0)
    cylinder(name + '_washer', (x, y, z), r * 1.3, r * 0.40, mats['armor_side'], root, axis, 24)
    cylinder(name, (x, y + direction * r * 0.28, z), r, r * 0.65, mats['steel_edge'], root, axis, 6)
    # Slot is recessed dark geometry; fixed orientation keeps highlights readable.
    cube(name + '_slot', (x, y + direction * r * 0.64, z), (r * 1.12, 0.004, r * 0.19), mats['cavity'], root, r * 0.04)


def mask_y(x, z):
    # Crown protrudes in front of actual head, cheek/chin surfaces sweep back.
    profile = 0.17 * max(0, 1 - ((z - 4.20) / 0.80) ** 2)
    return -0.77 - profile * math.sqrt(max(0.0, 1 - (x / 0.67) ** 2))


def mask_decal(name, points, mat, root, offset=0.013):
    verts = [(x, mask_y(x, z) - offset, z) for x, z in points]
    o = mesh(name, verts, [tuple(range(len(verts)))], mat, root, bevel=0)
    s = o.modifiers.new('Paint thickness', 'SOLIDIFY')
    s.thickness = 0.008
    b = o.modifiers.new('Paint softened edge', 'BEVEL')
    b.width, b.segments = 0.004, 2
    return o


def boolean_cut(target, cutter):
    # Apply only cutters. Target bevel is appended after all openings.
    bpy.context.view_layer.objects.active = target
    mod = target.modifiers.new('Real recessed mask opening', 'BOOLEAN')
    mod.operation = 'DIFFERENCE'
    mod.solver = 'EXACT'
    mod.object = cutter
    bpy.ops.object.modifier_apply(modifier=mod.name)
    bpy.data.objects.remove(cutter, do_unlink=True)


def build_details(materials=None):
    m = palette(materials)
    root = parent('Hero_Head_Details')
    # Dense gently curved faceplate with real thickness, taper and cheek bulge.
    levels = [
        (3.55, .20), (3.59, .29), (3.67, .39), (3.77, .47),
        (3.89, .54), (4.02, .59), (4.15, .615), (4.28, .61),
        (4.41, .57), (4.54, .49), (4.63, .36), (4.69, .18),
    ]
    cols, rows = 25, len(levels)
    verts = []
    for z, width in levels:
        for j in range(cols):
            x = width * (-1 + 2 * j / (cols - 1))
            verts.append((x, mask_y(x, z), z))
    faces = []
    for i in range(rows - 1):
        for j in range(cols - 1):
            a = i * cols + j
            faces.append((a, a + 1, a + cols + 1, a + cols))
    mask = mesh('Mask_Bone_Convex_Shell', verts, faces, m['bone'], root, bevel=0, smooth=True)
    solid = mask.modifiers.new('Cast shell thickness', 'SOLIDIFY')
    solid.thickness = 0.052
    solid.offset = -1
    bpy.context.view_layer.objects.active = mask
    bpy.ops.object.modifier_apply(modifier=solid.name)
    eye_shapes = [
        [(-.48,4.30),(-.31,4.29),(-.08,4.17),(-.12,4.06),(-.34,4.095),(-.48,4.17)],
        [(.48,4.30),(.31,4.29),(.08,4.17),(.12,4.06),(.34,4.095),(.48,4.17)],
    ]
    eyes = []
    for i, poly in enumerate(eye_shapes):
        cutter = prism_xz('Eye_cut_temporary', poly, -1.25, -.50, m['cavity'], bevel=0)
        # No bevel/weighted normals on boolean operand are required.
        cutter.modifiers.clear()
        boolean_cut(mask, cutter)
        prism_xz('Eye_%d_Deep_Socket' % i, poly, -.825, -.66, m['cavity'], root, .024)
        center = -.27 if i == 0 else .27
        narrow = [(center + (x-center)*.74, 4.17+(z-4.17)*.40) for x,z in poly]
        lens = prism_xz('Eye_%d_Red_Slit' % i, narrow, -.853, -.83, m['eye_red'], root, .012)
        eyes.append(lens)
        core = [(center + (x-center)*.43, 4.17+(z-4.17)*.18) for x,z in poly]
        prism_xz('Eye_%d_Inner_Hotline' % i, core, -.861, -.854, m['eye_core'], root, .006)
    # Seven chin perforations plus upper temple vents: real holes with dark backing.
    vents = [(-.29,3.86,.025),(-.15,3.81,.027),(0,3.79,.028),(.15,3.81,.027),(.29,3.86,.025),
             (-.19,3.67,.023),(.19,3.67,.023),(-.47,4.00,.024),(.47,4.00,.024),
             (-.38,4.47,.022),(.38,4.47,.022)]
    for i,(x,z,r) in enumerate(vents):
        bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=r, depth=.6, location=(x,-.83,z), rotation=(math.pi/2,0,0))
        boolean_cut(mask, bpy.context.object)
        cylinder('Mask_Vent_%02d_Dark_Well' % i,(x,mask_y(x,z)+.06,z),r*.96,.026,m['cavity'],root,vertices=16,bevel=.001)
    finish(mask, bevel=.013, segments=3, smooth=True)
    # Sculptural edge band follows perimeter and reveals cast thickness at profile.
    edge = [(-w,mask_y(-w,z)+.01,z) for z,w in levels]
    edge += [(w,mask_y(w,z)+.01,z) for z,w in reversed(levels)]
    tube('Mask_Bone_Rolled_Rim',edge,.022,m['ivory'],root,cyclic=True)
    # Recognizable three red markings, kept separate from facial openings.
    mask_decal('Mask_Forehead_Red_Chevron',[(-.31,4.56),(0,4.45),(.31,4.56),(.20,4.39),(0,4.31),(-.20,4.39)],m['red_paint'],root)
    mask_decal('Mask_Left_Cheek_Chevron',[(-.55,3.96),(-.35,3.89),(-.39,3.79),(-.51,3.86)],m['red_paint'],root)
    mask_decal('Mask_Right_Cheek_Chevron',[(.55,3.96),(.35,3.89),(.39,3.79),(.51,3.86)],m['red_paint'],root)
    # Snout ridge is a small symmetric bone wedge; it bridges the recessed eyes.
    nose = [(-.075,mask_y(-.075,4.19)-.005,4.19),(.075,mask_y(.075,4.19)-.005,4.19),
            (.105,-.958,3.96),(0,-1.055,3.92),(-.105,-.958,3.96),(0,-1.03,4.17)]
    mesh('Mask_Sculpted_Nose_Ridge',nose,[(0,1,5),(1,2,3,5),(0,5,3,4),(4,3,2)],m['bone'],root,.013,smooth=True)
    for i,(x,z) in enumerate([(-.49,4.38),(.49,4.38),(-.39,3.71),(.39,3.71)]):
        bolt('Mask_Rivet_%02d'%i,x,mask_y(x,z)-.025,z,m,root,.029)
    # Straps wrap around the spherical cranium rather than ending at the mask edge.
    for side in [-1,1]:
        tube('Mask_Temple_Strap_%s'%side,[(side*.55,-.81,4.29),(side*.66,-.55,4.24),(side*.66,-.05,4.21),(side*.43,.30,4.22)],.053,m['leather'],root)
        cube('Mask_Strap_Buckle_%s'%side,(side*.66,-.30,4.23),(.06,.20,.145),m['steel'],root,.016)
    # Six thick swept blades along Y create a true mohawk from every camera view.
    mohawk = []
    for i in range(7):
        yc=-.45+i*.155
        base_z=4.60-abs(yc)*.10
        tip_z=5.20-.10*abs(i-2.6)
        # Central ridge with asymmetric facets yields broad graphic highlights.
        verts=[(-.095,yc-.09,base_z),(.095,yc-.09,base_z),(.083,yc+.12,base_z-.035),(-.083,yc+.12,base_z-.035),
               (-.014,yc+.035,tip_z),(.014,yc+.035,tip_z),(-.005,yc+.13,tip_z-.13),(.005,yc+.13,tip_z-.13)]
        faces=[(0,1,5,4),(1,2,7,5),(2,3,6,7),(3,0,4,6),(4,5,7,6),(3,2,1,0)]
        o=mesh('Mohawk_Swept_Blade_%02d'%i,verts,faces,m['teal'],root,.018)
        o.data.materials.append(m['teal_light'])
        o.data.polygons[0].material_index=1
        mohawk.append(o)
    objects=[o for o in bpy.context.scene.objects if o.parent==root]
    return {'root':root,'mask':mask,'eyes':eyes,'mohawk':mohawk,'objects':objects}


def build_chainsaw(location=(0,0,0),rotation=(0,0,0),materials=None):
    m=palette(materials)
    root=parent('Legendary_Chainsaw')
    # Heavy cast housing, asymmetrical clutch cover, rolled seams and rear bumper.
    cube('Saw_Engine_Main_Housing',(0,0,0),(.57,.36,.48),m['saw_yellow'],root,.085)
    cube('Saw_Engine_Top_Cowling',(-.02,0,.215),(.46,.33,.12),m['saw_high'],root,.048)
    cube('Saw_Engine_Rear_Bumper',(0,.025,-.23),(.58,.34,.09),m['rubber'],root,.031)
    cube('Saw_Engine_Orange_Front',(-.03,-.196,-.005),(.39,.058,.29),m['saw_orange'],root,.032)
    cube('Saw_Engine_Grill_Inset',(-.06,-.231,.018),(.28,.011,.19),m['cavity'],root,.014)
    for i in range(6):
        cube('Saw_Engine_Cooling_Fin_%02d'%i,(-.06,-.245,-.061+i*.031),(.29,.019,.011),m['steel'],root,.004)
    cylinder('Saw_Starter_Pulley',(.191,-.225,-.005),.091,.050,m['armor'],root,vertices=40,bevel=.01)
    cylinder('Saw_Starter_Rim',(.191,-.257,-.005),.067,.016,m['steel'],root,vertices=40,bevel=.007)
    cylinder('Saw_Starter_Axle',(.191,-.272,-.005),.028,.021,m['steel_edge'],root,vertices=6,bevel=.003)
    for j in range(8):
        a=j*math.pi/4
        cube('Saw_Starter_Radial_Slot_%02d'%j,(.191+math.cos(a)*.049,-.269,-.005+math.sin(a)*.049),(.011,.006,.014),m['cavity'],root,.003)
    # Top fuel cap has a ridged knurled edge and debossed central slot.
    cylinder('Saw_Fuel_Cap',(-.17,.03,.30),.075,.050,m['rubber'],root,axis=(0,0,1),vertices=32)
    for i in range(12):
        a=i*math.pi/6
        cube('Saw_Cap_Knurl_%02d'%i,(-.17+.070*math.cos(a),.03+.070*math.sin(a),.3),(.016,.016,.042),m['armor'],root,.003)
    cube('Saw_Fuel_Cap_Slot',(-.17,.03,.33),(.079,.013,.005),m['steel'],root,.003)
    # Actual bar is a long rounded steel extrusion, not a decal or flat plane.
    low,high,r=.22,1.30,.135
    points=[]
    for i in range(13):
        a=math.pi-i*math.pi/12
        points.append((math.cos(a)*r,high+math.sin(a)*r))
    for i in range(13):
        a=-i*math.pi/12
        points.append((math.cos(a)*r,low+math.sin(a)*r))
    prism_xz('Saw_Steel_Guide_Bar',points,-.065,.065,m['steel_edge'],root,.012)
    inner=[(x*.75, .77+(z-.77)*.93) for x,z in points]
    prism_xz('Saw_Recessed_Guide_Plate',inner,-.079,-.065,m['steel'],root,.006)
    cube('Saw_Bar_Center_Channel',(0,-.086,.82),(.017,.010,.82),m['armor_side'],root,.007)
    for z in [.49,.67,.85,1.03,1.19]:
        cylinder('Saw_Bar_Oil_Port_%s'%z,(0,-.094,z),.018,.012,m['cavity'],root,vertices=16,bevel=.002)
    # Complete exposed chain: each link wraps both rounded bar ends.
    perimeter=[]
    for i in range(17):
        perimeter.append((r+.007,low+(high-low)*i/16,0))
    for i in range(1,10):
        a=i*math.pi/10
        perimeter.append((math.cos(a)*(r+.007),high+math.sin(a)*(r+.007),a))
    for i in range(17):
        perimeter.append((-r-.007,high-(high-low)*i/16,math.pi))
    for i in range(1,10):
        a=math.pi+i*math.pi/10
        perimeter.append((math.cos(a)*(r+.007),low+math.sin(a)*(r+.007),a))
    for i,(x,z,a) in enumerate(perimeter):
        link=cube('Saw_Chain_Drive_Link_%02d'%i,(x,-.004,z),(.040,.160,.057),m['armor_side'],root,.006)
        link.rotation_euler[1]=-a
        cylinder('Saw_Chain_Link_Rivet_%02d'%i,(x,-.089,z),.011,.012,m['steel_edge'],root,vertices=12,bevel=.002)
        if i%2==0:
            # Positive local X is outward on first side and around the top cap.
            tooth=prism_xz('Saw_Cutting_Tooth_%02d'%i,[(-.009,-.024),(.055,-.014),(.052,.025),(.015,.032),(-.009,.019)],-.062,.045,m['steel_edge'],root,.004)
            tooth.location=(x,0,z)
            tooth.rotation_euler[1]=-a
    # Thick wraparound upper handle, rear handgrip and brake guard.
    tube('Saw_Wrap_Handle',[(.29,.16,-.08),(.39,.17,.06),(.36,.17,.38),(-.29,.17,.40),(-.37,.17,.18),(-.29,.17,-.04)],.037,m['rubber'],root)
    tube('Saw_Rear_Handle',[(-.18,.04,-.14),(-.30,.08,-.27),(-.27,.08,-.40),(.11,.08,-.40),(.19,.07,-.25),(.17,.04,-.17)],.038,m['rubber'],root)
    tube('Saw_Handle_Reinforcement',[(-.25,.11,-.36),(.10,.11,-.36)],.013,m['steel'],root)
    cube('Saw_Trigger',(-.005,.024,-.339),(.075,.037,.056),m['saw_orange'],root,.013)
    cube('Saw_Brake_Guard',(-.27,-.03,.32),(.07,.28,.27),m['rubber'],root,.022)
    for i in range(3):
        cube('Saw_Brake_Guard_Rib_%02d'%i,(-.311,-.09+i*.078,.33),(.020,.035,.17),m['armor'],root,.008)
    for i,(x,z) in enumerate([(-.21,-.15),(.19,-.16),(-.21,.16),(.23,.17)]):
        bolt('Saw_Case_Bolt_%02d'%i,x,-.21,z,m,root,.019)
    # Tiny hazard chevrons are modeled embossed polygons on rear face.
    for i in range(3):
        x=-.13+i*.092
        prism_xz('Saw_Hazard_Chevron_%02d'%i,[(x,-.16),(x+.04,-.11),(x+.02,-.11),(x-.02,-.16)],.188,.199,m['cavity'],root,.002)
    root.location=location
    root.rotation_euler=rotation
    return root


def build_backarmor(materials=None):
    m=palette(materials)
    root=parent('Hero_Riveted_Back_Armor')
    # Overlapping scalloped plates articulate over the spine and belly silhouette.
    levels=[(3.27,.69,.31),(2.88,.64,.31),(2.50,.57,.30),(2.13,.47,.26)]
    for i,(zc,w,h) in enumerate(levels):
        points=[(-w,zc+h*.60),(-w*.35,zc+h),(.0,zc+h*.85),(w*.35,zc+h),(w,zc+h*.60),
                (w*.90,zc-h*.55),(0,zc-h),( -w*.90,zc-h*.55)]
        y=.77+(0.025 if i==1 else 0)-i*.018
        plate=prism_xz('Armor_Spine_Plate_%02d'%i,points,y,y+.105,m['armor'],root,.037)
        # Embossed central ridge and contrasting rim catch the rim light.
        ridge=[(-.055,zc+h*.77),(.055,zc+h*.77),(.066,zc-h*.63),(0,zc-h*.83),(-.066,zc-h*.63)]
        prism_xz('Armor_Spine_Ridge_%02d'%i,ridge,y+.10,y+.14,m['steel'],root,.012)
        edge=[(-w*.88,y+.112,zc+h*.50),(-w*.30,y+.112,zc+h*.84),(0,y+.112,zc+h*.70),
              (w*.30,y+.112,zc+h*.84),(w*.88,y+.112,zc+h*.50)]
        tube('Armor_Upper_Edge_%02d'%i,edge,.017,m['steel'],root)
        for side in [-1,1]:
            bolt('Armor_Rivet_%02d_%s'%(i,side),side*w*.77,y+.13,zc+.06,m,root,.044,direction=1)
            bolt('Armor_Rivet_Lower_%02d_%s'%(i,side),side*w*.60,y+.13,zc-h*.35,m,root,.034,direction=1)
    for side in [-1,1]:
        for k,z in enumerate([3.38,2.78]):
            x=side*(.65 if k==0 else .60)
            cylinder('Armor_Chain_Mount_Base_%s_%s'%(side,k),(x,.83,z),.12,.13,m['armor_side'],root,axis=(0,1,0),vertices=24,bevel=.013)
            bpy.ops.mesh.primitive_torus_add(major_radius=.086,minor_radius=.027,major_segments=24,minor_segments=10,location=(x,.92,z),rotation=(math.pi/2,0,0))
            ring=bpy.context.object
            ring.name='Armor_Chain_Mount_Ring_%s_%s'%(side,k)
            adopt(ring,root,m['steel_edge'])
            for p in ring.data.polygons:p.use_smooth=True
    return root


def build_mouth(root=None, materials=None):
    """Add a dimensional open bite below an already-built mask.

    This is intentionally NOT called by build_details. It may be called after
    loading the saved model; all pieces are grouped below the existing head root.
    Repeated calls replace only this helper's own named mouth assembly.
    """
    m = palette(materials)
    if root is None:
        root = bpy.data.objects.get('Hero_Head_Details')
        if root is None:
            root = parent('Hero_Head_Details')
    previous = bpy.data.objects.get('Hero_Monster_Mouth')
    if previous is not None:
        for o in list(previous.children_recursive):
            bpy.data.objects.remove(o, do_unlink=True)
        bpy.data.objects.remove(previous, do_unlink=True)
    jaw = parent('Hero_Monster_Mouth')
    jaw.parent = root
    skin = material('AstraDetail_jaw_skin', (.52, .165, .035), .0, .49)
    shadow_skin = material('AstraDetail_jaw_shadow', (.285, .053, .016), .0, .53)
    gum = material('AstraDetail_mouth_gum', (.19, .011, .018), .0, .57)
    tongue_mat = material('AstraDetail_mouth_tongue', (.48, .024, .051), .0, .37)
    enamel = material('AstraDetail_tooth_enamel', (.91, .72, .40), .025, .28)
    # Thick lower flesh hugs an inset bowl. The upper contour slips behind the
    # mask's chin; the large negative space is visible entirely below the mask.
    outline = [(-.40,3.46),(-.32,3.545),(-.19,3.565),(0,3.54),(.19,3.565),(.32,3.545),
               (.40,3.46),(.438,3.345),(.38,3.23),(.23,3.135),(0,3.10),(-.23,3.135),
               (-.38,3.23),(-.438,3.345)]
    # Dark solid has a shallow curved front rather than an infinitely thin plane.
    verts=[(0,-.756,3.355)]
    verts += [(x,-.83+.028*abs(x)/.438,z) for x,z in outline]
    faces=[(0,(i+1)%len(outline)+1,i+1) for i in range(len(outline))]
    bowl=mesh('Mouth_Deep_Recess',verts,faces,m['cavity'],jaw,bevel=0,smooth=True)
    thick=bowl.modifiers.new('Interior bowl thickness','SOLIDIFY')
    thick.thickness=.045
    # Upper rim is lean; the thick bottom jaw carries the character's weight.
    tube('Mouth_Upper_Lip',[(x,-.832,z) for x,z in outline[:7]],.036,shadow_skin,jaw)
    tube('Mouth_Lower_Jaw_Rim',[(x,-.837,z) for x,z in outline[6:]+outline[:1]],.061,skin,jaw)
    tube('Mouth_Inner_Lower_Gum',[(x*.87,-.862,3.355+(z-3.355)*.78) for x,z in outline[7:]],.025,gum,jaw)
    # Front cheeks soften the junction with the mask without concealing the bite.
    for side in [-1,1]:
        uvball('Mouth_Cheek_Hinge_%s'%side,(side*.395,-.796,3.455),(.086,.095,.125),skin,jaw)
    # Separate tapered teeth have chunky enamel facets and rounded cutting edges.
    def tooth(name,x,z,width,height,lower=False,lean=0):
        direction=1 if lower else -1
        tip=z+direction*height
        points=[(x-width*.50,z),(x+width*.50,z),
                (x+width*.28+lean,tip),(x-width*.24+lean,tip+direction*.008)]
        # Teeth sit in front of gums; roots dip beneath their respective lips.
        obj=prism_xz(name,points,-.903,-.812,enamel,jaw,.011)
        return obj
    upper=[(-.285,3.492,.105,.135,-.007),(-.17,3.492,.115,.115,.004),
           (-.055,3.476,.108,.139,-.005),(.063,3.478,.110,.125,.008),
           (.177,3.494,.109,.147,-.008),(.287,3.493,.103,.125,.004)]
    for i,(x,z,w,h,lean) in enumerate(upper):
        tooth('Mouth_Upper_Tooth_%02d'%i,x,z,w,h,False,lean)
    lower=[(-.292,3.227,.093,.084,.004),(-.172,3.173,.104,.101,-.009),
           (-.055,3.155,.102,.106,.004),(.061,3.153,.109,.110,-.005),
           (.180,3.176,.106,.100,.005),(.293,3.226,.088,.078,-.005)]
    for i,(x,z,w,h,lean) in enumerate(lower):
        tooth('Mouth_Lower_Tooth_%02d'%i,x,z,w,h,True,lean)
    # The tongue sits behind the lower teeth in the dark crescent, with a modeled
    # middle cleft. Small wet highlights come from roughness, never image textures.
    uvball('Mouth_Tongue',(0,-.831,3.225),(.198,.058,.053),tongue_mat,jaw)
    tube('Mouth_Tongue_Cleft',[(0,-.883,3.23),(0,-.890,3.259)],.006,gum,jaw)
    uvball('Mouth_Lower_Chin',(0,-.764,3.09),(.26,.12,.073),skin,jaw)
    return jaw
