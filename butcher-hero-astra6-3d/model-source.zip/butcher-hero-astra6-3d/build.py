"""Run with the server Blender executable, --background --python build.py."""
import bpy, sys, os, math, json, time
from pathlib import Path
from mathutils import Vector

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from hero import build_hero,hero_weapon,make_chain
from details import build_details,build_chainsaw,build_backarmor
from stage import build_stage

if sys.platform!='linux':raise RuntimeError('This render is server-only. Do not run on the user PC.')
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
draft='--draft' in args
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for data in bpy.data.materials:bpy.data.materials.remove(data)
scene=bpy.context.scene
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=20 if draft else 64;scene.cycles.use_denoising=True
scene.cycles.max_bounces=6;scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=3;scene.cycles.transparent_max_bounces=4
scene.render.threads_mode='FIXED';scene.render.threads=3
scene.render.resolution_x=540 if draft else 1080;scene.render.resolution_y=800 if draft else 1600;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.view_settings.view_transform='AgX'
try:scene.view_settings.look='AgX - Medium High Contrast'
except Exception:pass
hero=build_hero();details=build_details();build_backarmor()
# The chainsaw is a modeled prop held by the right hand, tilted outside the torso.
saw=build_chainsaw(location=(2.20,-.63,1.77),rotation=(math.radians(8),math.radians(15),math.radians(-8)))
stage=build_stage(lighting=False)
for obj in stage['collection'].objects:
    if obj.name=='Blood moon' or obj.name.startswith('Moon basalt crater'):obj.location.x-=2.3
# Weapons occupy the upper silhouette, in separate planes with real chained depth.
weapons=[('hammer',(-2.05,.60,4.08),(0,-.40,-.18)),('iceaxe',(-1.40,.85,5.05),(.10,-.25,.24)),('greenaxe',(1.38,1.10,4.95),(.1,.31,-.15)),('sword',(2.05,.80,3.91),(-.13,.35,-.23))]
for i,(kind,loc,rot) in enumerate(weapons):
    hero_weapon(kind,loc,rot);make_chain(kind+' | articulated chain',((-1 if i<2 else 1)*.70,.55,3.50),loc,sag=.34,links=22)

world=bpy.data.worlds.new('Dark cathedral ambient');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.022,.030,.052,1);world.node_tree.nodes['Background'].inputs[1].default_value=.35
def area(name,loc,target,color,energy,size):
    d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.color=color;d.shape='DISK';d.size=size;o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();return o
area('Key | warm broad sculpting',(-4,-6,8),(0,0,2.9),(1,.76,.52),1150,3.5)
area('Fill | desaturated cool',(4,-4,4.5),(0,0,2.8),(.53,.71,1),310,3)
area('Rim | hot ember',(-3,3.0,6.5),(0,0,3),(1,.16,.035),1450,2.5)
area('Rim | cool steel',(4,2,6.5),(0,0,3),(.30,.67,.82),850,2.6)
area('Floor | reflected molten amber',(0,-1,.35),(0,0,2),(1,.20,.045),100,2.3)

cam_data=bpy.data.cameras.new('Hero portrait camera');cam=bpy.data.objects.new('Hero portrait camera',cam_data);scene.collection.objects.link(cam)
cam.location=(4.6,-13.0,3.30);target=Vector((0,.10,2.9));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.lens=50;cam.data.sensor_width=36;scene.camera=cam
cam.data.dof.use_dof=True;cam.data.dof.focus_distance=(target-cam.location).length;cam.data.dof.aperture_fstop=7
scene.render.filepath=str(ROOT/'output'/('hero-proof-draft.png' if draft else 'hero-proof.png'))
scene['project']='Original Butcher Hero 3D quality rebuild';scene['source']='Fresh procedural Blender modeling, no external character or texture assets';scene['server_only']=True
ROOT.joinpath('output').mkdir(exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'output'/'butcher-hero-astra6.blend'))
started=time.time();bpy.ops.render.render(write_still=True)
report={'render_seconds':time.time()-started,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'samples':scene.cycles.samples,'objects':len(scene.objects),'engine':'Cycles CPU','threads':3,'image':scene.render.filepath}
(ROOT/'output'/'proof-report.json').write_text(json.dumps(report,indent=2)+'\n')
print('PROOF_RENDER_COMPLETE',json.dumps(report))
