# Butcher Hero — original 3D art study

A fresh, editable Blender character and scene built for the selected **vivid stylized 3D mobile game advertisement** direction. This project contains original procedural meshes, materials, lighting and a skeletal attack action. No previous reel graphics, external character models, photographs, generated images or generated video assets are used.

The scene contains a unified orange character body, stitched scars, modeled hands and feet, ragged shorts, a curved hockey mask with real openings, red eyes, an articulated jaw silhouette and individual teeth, a teal mohawk, back armor, a detailed chainsaw and four suspended weapons. The 17-bone rig includes an editable 1.6-second attack phrase with anticipation, delayed elbow motion, impact hold and recovery.

## Output

- `butcher-hero-astra6-rigged.blend`: complete editable scene, materials, lights, camera and keyed rig.
- `hero-action.png`: the rendered art-direction frame.

The deliverable in this project is a 3D scene and still image. A completed new 29.6-second video is not included.

## Source modules

- `hero.py`: original character body, clothing, stitches and suspended weapons.
- `details.py`: hockey mask, eyes, mohawk, mouth, chainsaw and back armor.
- `stage.py`: fractured stone arena, lava fissures, Gothic silhouettes and blood moon.
- `rig.py`: deterministic skeletal pose function `apply_pose(rig, t)` and bindings.
- `build.py`: fresh scene assembly.
- `finish.py`: material refinement, rigging, keyed action and final still rendering.

## Render on the server

Tested with Blender 4.5.14 LTS, Cycles CPU and three rendering threads. The project deliberately refuses to run through a Windows Python/Blender process. In this workspace the helper also checks the server hostname so that no heavy render reaches the user's PC.

From the workspace root:

```sh
/bin/sh .cache/blender-server/blender --factory-startup --python "$PWD/reels/butcher-hero-astra6-3d/build.py" -- --draft
/bin/sh .cache/blender-server/blender --python "$PWD/reels/butcher-hero-astra6-3d/finish.py"
```

The first command creates the complete source scene; the second creates the refined rigged scene and renders one high resolution PNG. Neither command renders a video sequence or calls an AI generation service.

On another Linux server, use the full Blender executable path in place of the workspace helper and pass the absolute path of the corresponding Python file. NumPy, browser automation and the previous 2D renderer are not required.
