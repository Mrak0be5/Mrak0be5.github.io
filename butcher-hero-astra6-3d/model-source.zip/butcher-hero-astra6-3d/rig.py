"""Original procedural FK rig for the freshly modeled Butcher Hero.

Build after hero.build_hero(), then bone-parent separate prop roots with
parent_bone_keep_world(). apply_pose(rig, None) is the exact undeformed rest
state; apply_pose(rig, t) evaluates a deterministic 1.6-second combat phrase.
This module neither renders nor installs frame handlers.
"""
import math
from collections import defaultdict

import bpy
from mathutils import Euler, Matrix, Vector

RIG_NAME = 'Hero | animation rig'
BODY_NAME = 'Hero | unified sculpted skin'


def _clamp(value, lo=0.0, hi=1.0):
    return max(lo, min(hi, value))


def _smooth(lo, hi, value):
    t = _clamp((value - lo) / (hi - lo))
    return t * t * (3.0 - 2.0 * t)


def _segment_distance(point, a, b):
    delta = b - a
    q = _clamp((point - a).dot(delta) / max(delta.length_squared, 1e-12))
    return (point - (a + delta * q)).length


def parent_bone_keep_world(obj, rig, bone):
    """Rigidly attach an object/empty root while preserving its current world pose.

    Blender bone parents include the tail offset, so assigning an inverse of
    the armature object's matrix alone is insufficient. Let Blender evaluate
    the actual parent transform before reassigning the saved world matrix.
    """
    if isinstance(obj, str):
        obj = bpy.data.objects[obj]
    if bone not in rig.pose.bones:
        raise KeyError(f'Unknown hero bone: {bone}')
    bpy.context.view_layer.update()
    world = obj.matrix_world.copy()
    obj.parent = rig
    obj.parent_type = 'BONE'
    obj.parent_bone = bone
    obj.matrix_parent_inverse = Matrix.Identity(4)
    bpy.context.view_layer.update()
    obj.matrix_world = world
    bpy.context.view_layer.update()
    return obj


def _surface_weights(point, arm_segments):
    """Smooth torso bands plus distance-weighted arm joints; no random binding."""
    x, y, z = point
    weights = defaultdict(float)
    if z < 2.48:
        f = _smooth(1.72, 2.48, z)
        weights['hips'] = 1.0 - f
        weights['spine'] = f
    else:
        f = _smooth(2.48, 3.34, z)
        weights['spine'] = 1.0 - f
        weights['chest'] = f

    # Wide trapezius remains chest-weighted while the neck/head turn naturally.
    head = _smooth(3.52, 4.02, z) * (1.0 - _smooth(.48, .90, abs(x)))
    if z > 4.03:
        head = max(head, _smooth(4.03, 4.28, z))
    for key in list(weights):
        weights[key] *= 1.0 - head
    weights['head'] += head

    side = 'L' if x >= 0 else 'R'
    segments = arm_segments[side]
    distances = {name: _segment_distance(point, a, b) for name, a, b in segments}
    proximity = 1.0 - _smooth(.38, .83, min(distances.values()))
    # Below the shoulder, the widened rest pose has an actual air gap. Keep
    # torso vertices entirely out of arm groups and inner-arm vertices fully
    # attached to the limb: a wide blend across that gap creates a skin web.
    if z < 2.30:
        torso_radius = 1.17 + .14 * _clamp((z - 1.90) / .40)
    elif z < 2.66:
        torso_radius = 1.31 + .04 * _clamp((z - 2.30) / .36)
    else:
        torso_radius = 1.35 - .10 * _clamp((z - 2.66) / .37)
    outside_flank = torso_radius * 1.035 + .015
    limb_gate = _smooth(outside_flank, outside_flank + .055, abs(x))
    shoulder_gate = _smooth(.88, 1.85, abs(x))
    shoulder_blend = _smooth(3.00, 3.42, z)
    gate = (limb_gate * (1.0 - shoulder_blend) + shoulder_gate * shoulder_blend) * proximity
    gate *= 1.0 - _smooth(3.48, 3.97, z)
    gate *= _smooth(1.35, 1.75, z)
    if gate > 1e-5:
        # The short hand segment makes wrist weights transition smoothly into
        # separately modeled hands, while the elbow blends adjacent segments.
        influence = {name: math.exp(-((dist / .38) ** 2))
                     for name, dist in distances.items()}
        total = max(sum(influence.values()), 1e-12)
        for key in list(weights):
            weights[key] *= 1.0 - gate
        for name, value in influence.items():
            weights[name] += gate * value / total

    weights = {name: weight for name, weight in weights.items() if weight > 1e-5}
    total = sum(weights.values())
    return {name: weight / total for name, weight in weights.items()}


def _bind_surface(obj, rig, arm_segments):
    """Bind a mesh in world rest coordinates and deform before subdivision."""
    groups = {name: obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
              for name in ['hips', 'spine', 'chest', 'head',
                           'upper_arm.L', 'forearm.L', 'hand.L',
                           'upper_arm.R', 'forearm.R', 'hand.R']}
    world = obj.matrix_world.copy()
    # Quantized batches avoid one RNA call per weight on the voxel-sculpt mesh.
    # After rounding, each vertex is normalized again; precision is 1e-4.
    batches = defaultdict(list)
    for vertex in obj.data.vertices:
        weights = _surface_weights(world @ vertex.co, arm_segments)
        quantized = {name: max(1, round(value * 10000)) for name, value in weights.items()}
        total = sum(quantized.values())
        for name, value in quantized.items():
            batches[(name, value / total)].append(vertex.index)
    for (name, weight), indices in batches.items():
        groups[name].add(indices, weight, 'REPLACE')

    modifier = obj.modifiers.new('Hero deformation | preserve volume', 'ARMATURE')
    modifier.object = rig
    modifier.use_vertex_groups = True
    modifier.use_bone_envelopes = False
    modifier.use_deform_preserve_volume = True
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.modifier_move_to_index(modifier=modifier.name, index=0)
    obj.parent = rig
    obj.parent_type = 'OBJECT'
    obj.matrix_parent_inverse = rig.matrix_world.inverted()
    obj.matrix_world = world
    obj['hero_surface_binding'] = True
    return obj


def _surface_details():
    prefixes = ('Main diagonal scar', 'Raised cross suture', 'Stitch insertion',
                'Lower belly crease', 'Navel', 'Shoulder scar', 'Shoulder suture')
    return [obj for obj in bpy.context.scene.objects if obj.name.startswith(prefixes)]


def build_rig():
    """Create, bind and return the armature without altering the hero's rest shape.

    Separate details root -> head; back-armor root -> chest; chainsaw root ->
    hand.L (+X side). Those compound roots remain explicit caller decisions.
    """
    existing = bpy.data.objects.get(RIG_NAME)
    if existing is not None:
        if existing.type != 'ARMATURE':
            raise TypeError(f'{RIG_NAME} exists but is not an armature')
        return existing
    body = bpy.data.objects.get(BODY_NAME)
    if body is None or body.type != 'MESH':
        raise RuntimeError(f'Run build_hero() first; missing mesh {BODY_NAME!r}')
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    data = bpy.data.armatures.new('Hero | original FK skeleton')
    rig = bpy.data.objects.new(RIG_NAME, data)
    bpy.context.collection.objects.link(rig)
    rig.show_in_front = True
    rig.display_type = 'WIRE'
    data.display_type = 'OCTAHEDRAL'
    rig['motion_period_seconds'] = 1.6
    rig['motion_bpm'] = 150
    rig['motion_strength'] = 1.0
    rig['motion_phrase'] = 'anticipate 0-.4; strike .4-.8; hold .8-.8667; recover .8667-1.6'
    bpy.ops.object.select_all(action='DESELECT')
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.mode_set(mode='EDIT')

    def bone(name, head, tail, parent=None, deform=True):
        value = data.edit_bones.new(name)
        value.head = head
        value.tail = tail
        value.use_deform = deform
        if parent:
            value.parent = data.edit_bones[parent]
        value.use_connect = False
        return value

    bone('root', (0, 0, 0), (0, 0, 1), deform=False)
    bone('hips', (0, 0, 1.45), (0, 0, 2.12), 'root')
    bone('spine', (0, 0, 2.12), (0, 0, 2.82), 'hips')
    bone('chest', (0, 0, 2.82), (0, 0, 3.55), 'spine')
    bone('head', (0, 0, 3.55), (0, 0, 4.70), 'chest')
    arm_segments = {}
    for side, sign in [('L', 1), ('R', -1)]:
        shoulder = Vector((sign * 1.12, .07, 3.43))
        elbow = Vector((sign * 1.98, -.075, 2.52))
        wrist = Vector((sign * 2.20, -.40, 1.96))
        palm = Vector((sign * 2.20, -.57, 1.62))
        bone('upper_arm.' + side, shoulder, elbow, 'chest')
        bone('forearm.' + side, elbow, wrist, 'upper_arm.' + side)
        bone('hand.' + side, wrist, palm, 'forearm.' + side)
        bone('leg.' + side, (sign * .57, .02, 1.40), (sign * .59, -.01, .70), 'hips')
        bone('shin.' + side, (sign * .59, -.01, .70), (sign * .61, -.10, .28), 'leg.' + side)
        bone('foot.' + side, (sign * .61, -.10, .28), (sign * .61, -.77, .20), 'shin.' + side)
        arm_segments[side] = [('upper_arm.' + side, shoulder, elbow),
                              ('forearm.' + side, elbow, wrist),
                              ('hand.' + side, wrist, palm)]
    bpy.ops.object.mode_set(mode='OBJECT')
    for pose_bone in rig.pose.bones:
        pose_bone.rotation_mode = 'QUATERNION'

    details = _surface_details()
    curves = [obj for obj in details if obj.type == 'CURVE']
    if curves:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in curves:
            obj.select_set(True)
        bpy.context.view_layer.objects.active = curves[0]
        # Beveled sutures must deform with the skin rather than float above it.
        bpy.ops.object.convert(target='MESH')
        details = _surface_details()
    _bind_surface(body, rig, arm_segments)
    for obj in details:
        if obj.type == 'MESH':
            _bind_surface(obj, rig, arm_segments)

    rigid_count = 0
    for obj in list(bpy.context.scene.objects):
        if obj == rig or obj == body or obj.parent is not None:
            continue
        name = obj.name.lower()
        side = 'L' if obj.matrix_world.translation.x >= 0 else 'R'
        target = None
        if name.startswith(('palm', 'curled finger', 'thumb', 'fingernail', 'finger knuckle')):
            target = 'hand.' + side
        elif name.startswith(('leather wrist cuff', 'cuff rivet', 'cuff')):
            target = 'forearm.' + side
        elif name.startswith(('broad foot', 'foot', 'toe', 'toenail')):
            target = 'foot.' + side
        elif name.startswith('leg'):
            target = 'leg.' + side
        elif name.startswith('shorts |'):
            target = 'hips'
        if target:
            parent_bone_keep_world(obj, rig, target)
            rigid_count += 1
    rig['bound_skin_vertices'] = len(body.data.vertices)
    rig['bound_surface_details'] = len(details)
    rig['rigid_attachments'] = rigid_count
    apply_pose(rig, None)
    bpy.ops.object.select_all(action='DESELECT')
    rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    return rig


def _rotate_world_axes(rig, name, x=0.0, y=0.0, z=0.0):
    """Express anatomical rotations in shared world axes despite bone roll."""
    rest = rig.data.bones[name].matrix_local.to_quaternion()
    rotation = Euler((x, y, z), 'XYZ').to_quaternion()
    rig.pose.bones[name].rotation_quaternion = rest.inverted() @ rotation @ rest


def apply_pose(rig, t):
    """Pure timestamp pose: restrained breath, shoulder lead and delayed elbow.

    The free -X hand (hand.R) performs the attack; the +X chainsaw hand guards.
    No accumulated rotation, frame handler, clock or random state is involved.
    """
    for bone in rig.pose.bones:
        bone.matrix_basis = Matrix.Identity(4)
        bone.rotation_mode = 'QUATERNION'
    if t is None:
        rig['evaluated_time'] = -1.0
        bpy.context.view_layer.update()
        return rig
    t = float(t)
    u = t % 1.6
    strength = max(0.0, min(1.0, float(rig.get('motion_strength', 1.0))))
    anticipation = _smooth(0, .36, u) * (1.0 - _smooth(.40, .68, u))
    shoulder = _smooth(.40, .72, u) * (1.0 - _smooth(.88, 1.52, u))
    elbow = _smooth(.50, .80, u) * (1.0 - _smooth(.96, 1.55, u))
    recoil = _smooth(.87, .95, u) * (1.0 - _smooth(.95, 1.24, u))
    breath = math.sin(t * math.tau / 3.2)
    squash = min(.03, .03 * anticipation + .010 * recoil) * strength
    rig.pose.bones['root'].scale = (1 + squash * .30, 1 - squash, 1 + squash * .30)
    r = math.radians
    _rotate_world_axes(rig, 'hips', z=r(2.8 * anticipation - 2.2 * shoulder) * strength)
    _rotate_world_axes(rig, 'spine', x=r(-3.0 * anticipation + 4.0 * shoulder + .35 * breath) * strength,
                       z=r(-3.0 * anticipation + 4.0 * shoulder) * strength)
    _rotate_world_axes(rig, 'chest', x=r(-3.0 * anticipation + 3.5 * shoulder + .25 * breath) * strength,
                       z=r(-5.0 * anticipation + 6.0 * shoulder - 1.5 * recoil) * strength)
    _rotate_world_axes(rig, 'head', x=r(3.2 * anticipation - 4.2 * shoulder) * strength,
                       z=r(4.5 * anticipation - 6.0 * shoulder) * strength)
    _rotate_world_axes(rig, 'upper_arm.R', x=r(12 * anticipation - 58 * shoulder) * strength,
                       y=r(-5 * anticipation + 13 * shoulder) * strength,
                       z=r(5 * anticipation - 5 * shoulder) * strength)
    _rotate_world_axes(rig, 'forearm.R', x=r(-8 * anticipation - 27 * elbow) * strength,
                       z=r(-4 * elbow) * strength)
    _rotate_world_axes(rig, 'hand.R', x=r(-3 * elbow) * strength, z=r(7 * elbow) * strength)
    _rotate_world_axes(rig, 'upper_arm.L', x=r(-5 * anticipation - 8 * shoulder) * strength,
                       y=r(-2 * anticipation - 3 * shoulder) * strength)
    _rotate_world_axes(rig, 'forearm.L', x=r(-7 * anticipation - 5 * shoulder) * strength)
    _rotate_world_axes(rig, 'hand.L', z=r(2 * anticipation - 2 * shoulder) * strength)
    # Feet stay planted in the inherited lower-body pose. Avoid procedural
    # stepping and ankle oscillation that would make the heavy hero feel floaty.
    rig['evaluated_time'] = t
    bpy.context.view_layer.update()
    return rig
