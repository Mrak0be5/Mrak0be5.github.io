# Butcher Hero — Promo Reel (Claude Opus 5.5)

Source of the reel published at https://mrak0be5.github.io/butcher-hero-reel/
English · 29.6 s · 1080×1920 · 30 fps · every frame drawn in code (Canvas 2D + HyperFrames 0.8.87).

## Layout

- `index.html` — master timeline (11 scenes + music track).
- `src/scenes/*.html` — scene sources; each draws its frame with `render(t)`.
- `src/lib/*.js` — shared drawing libs (hero, world, fx, text, golem, gear, bosses, islands, brand).
- `compositions/*.html` — built scenes with the libs inlined (what the renderer loads).
- `assets/fonts/` — Londrina Solid, Rubik, Russo One (woff2); `assets/audio/bh-score.wav` — score.
- `BRIEF.md`, `STORYBOARD.md`, `frame.md`, `storyboard.html` — brief, shot list, palette/typography, sketch sheet.
- `tools/build.py` — inlines `src/lib` into `compositions/`; `tools/score.mjs` — score generator.

## Build & render

```
python tools/build.py          # src/scenes + src/lib -> compositions/
npx --yes hyperframes@0.8.87 check
npx --yes hyperframes@0.8.87 preview
npx --yes hyperframes@0.8.87 render --fps 30 --video-bitrate 16M -o renders/butcher-hero-en.mp4
```

Needs Node.js, Chrome (installed by HyperFrames) and ffmpeg.
