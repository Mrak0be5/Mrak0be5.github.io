#!/usr/bin/env node
// Butcher Hero promo (29.6 s) - fully procedural score + SFX.
// Grid: 150 BPM (beat 0.4 s, bar 1.6 s), music from 2.4 s, key D Phrygian.
// Pure Node built-ins, fully deterministic (mulberry32 seeds), no samples of any kind.
// Usage (from reels/butcher-hero/):  node video/tools/score.mjs [out.wav]
// Default output: video/assets/audio/bh-score.wav - stereo, 48 kHz, 16-bit PCM, exactly 1,420,800 frames.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const T_BEGIN = process.hrtime.bigint();
const SR = 48000, N = 1420800; // 29.6 s
const TAU = Math.PI * 2;
const T0 = 2.4, BEAT = 0.4, BAR = 1.6, SIX = 0.1; // 16th = 0.1 s
const S = (t) => Math.round(t * SR);
const db = (d) => Math.pow(10, d / 20);
const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
const at = (bar, beat = 0, six = 0) => T0 + bar * BAR + beat * BEAT + six * SIX;

// ------------------------------------------------------------------ randomness
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function rng(seed) {
  const r = mulberry32(Math.imul(seed | 0, 0x9e3779b1) ^ 0x5bd1e995);
  r.n = () => r() * 2 - 1;
  r.in = (a, b) => a + (b - a) * r();
  return r;
}

// ------------------------------------------------------------------ buffers / buses
const mono = (dur) => new Float32Array(Math.max(1, Math.ceil(dur * SR)));
const stereo = (dur) => ({ L: mono(dur), R: mono(dur) });
const chans = (v) => (v instanceof Float32Array ? [v] : [v.L, v.R]);
const mkBus = () => ({ L: new Float32Array(N), R: new Float32Array(N) });
const BUS = { drum: mkBus(), bass: mkBus(), syn: mkBus(), sfx: mkBus(), hit: mkBus(), verb: mkBus() };
const panLR = (p) => {
  const a = ((clamp(p, -1, 1) + 1) * Math.PI) / 4;
  return [Math.cos(a) * Math.SQRT2, Math.sin(a) * Math.SQRT2];
};
function peakOf(v) {
  let m = 0;
  for (const x of chans(v)) for (let k = 0; k < x.length; k++) { const a = Math.abs(x[k]); if (a > m) m = a; }
  return m;
}
function scale(v, g) { for (const x of chans(v)) for (let k = 0; k < x.length; k++) x[k] *= g; return v; }
const norm = (v, p = 1) => scale(v, p / (peakOf(v) || 1));
function fadeOut(v, dur) {
  for (const x of chans(v)) {
    const m = Math.min(x.length, Math.ceil(dur * SR));
    for (let k = 0; k < m; k++) x[x.length - 1 - k] *= k / m;
  }
  return v;
}
function fadeIn(v, dur) {
  for (const x of chans(v)) { const m = Math.min(x.length, Math.ceil(dur * SR)); for (let k = 0; k < m; k++) x[k] *= k / m; }
  return v;
}
const reverse = (v) => (v instanceof Float32Array ? v.slice().reverse() : { L: v.L.slice().reverse(), R: v.R.slice().reverse() });
const toSt = (v) => (v instanceof Float32Array ? { L: v, R: v.slice() } : v);

// place a mono (Float32Array, panned) or stereo ({L,R}, balance) voice on a bus at absolute time t
function put(bus, v, t, gain = 1, pan = 0, send = 0) {
  const st = !(v instanceof Float32Array);
  const L = st ? v.L : v, R = st ? v.R : v;
  let gl, gr;
  if (st) { gl = pan > 0 ? 1 - pan : 1; gr = pan < 0 ? 1 + pan : 1; } else [gl, gr] = panLR(pan);
  gl *= gain; gr *= gain;
  const i0 = S(t), n = L.length, V = BUS.verb, F = Math.max(1, Math.min(240, n >> 2)); // 5 ms de-click fade at the voice end
  for (let k = Math.max(0, -i0); k < n; k++) {
    const i = i0 + k;
    if (i >= N) break;
    const w = k >= n - F ? (n - k) / F : 1, l = L[k] * gl * w, r = R[k] * gr * w;
    bus.L[i] += l; bus.R[i] += r;
    if (send) { V.L[i] += l * send; V.R[i] += r * send; }
  }
}
// mix a voice into another stereo voice buffer at relative time t
function mix(dst, src, t = 0, gain = 1, pan = 0) {
  const st = !(src instanceof Float32Array), i0 = S(t);
  const L = st ? src.L : src, R = st ? src.R : src;
  const [gl, gr] = st ? [1, 1] : panLR(pan);
  const n = Math.min(L.length, dst.L.length - i0);
  for (let k = 0; k < n; k++) { dst.L[i0 + k] += L[k] * gl * gain; dst.R[i0 + k] += R[k] * gr * gain; }
  return dst;
}

// ------------------------------------------------------------------ DSP primitives
class BQ { // RBJ cookbook biquad
  constructor(type, f, q = 0.707, g = 0) { this.x1 = this.x2 = this.y1 = this.y2 = 0; if (type) this.set(type, f, q, g); }
  set(type, f, q = 0.707, g = 0) {
    const w = (TAU * clamp(f, 5, SR * 0.49)) / SR, c = Math.cos(w), s = Math.sin(w), al = s / (2 * q), A = Math.pow(10, g / 40);
    let b0, b1, b2, a0, a1, a2;
    if (type === 'lp') { b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; }
    else if (type === 'hp') { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; }
    else if (type === 'bp') { b0 = al; b1 = 0; b2 = -al; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; }
    else if (type === 'pk') { b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A; }
    else { // shelves
      const sq = 2 * Math.sqrt(A) * al, lo = type === 'ls' ? 1 : -1;
      b0 = A * (A + 1 - lo * (A - 1) * c + sq); b1 = lo * 2 * A * (A - 1 - lo * (A + 1) * c); b2 = A * (A + 1 - lo * (A - 1) * c - sq);
      a0 = A + 1 + lo * (A - 1) * c + sq; a1 = -lo * 2 * (A - 1 + lo * (A + 1) * c); a2 = A + 1 + lo * (A - 1) * c - sq;
    }
    this.b0 = b0 / a0; this.b1 = b1 / a0; this.b2 = b2 / a0; this.a1 = a1 / a0; this.a2 = a2 / a0;
    return this;
  }
  p(x) {
    const y = this.b0 * x + this.b1 * this.x1 + this.b2 * this.x2 - this.a1 * this.y1 - this.a2 * this.y2;
    this.x2 = this.x1; this.x1 = x; this.y2 = this.y1; this.y1 = y;
    return y;
  }
}
function filt(v, ...fs) { // apply fresh filter chain per channel: fs are factories () => BQ
  for (const x of chans(v)) { const ch = fs.map((f) => f()); for (let i = 0; i < x.length; i++) { let s = x[i]; for (let k = 0; k < ch.length; k++) s = ch[k].p(s); x[i] = s; } }
  return v;
}
class SVF { // Zavalishin TPT state-variable filter (stable under fast modulation)
  constructor() { this.s1 = 0; this.s2 = 0; this.lp = 0; this.bp = 0; this.hp = 0; this.bn = 0; }
  run(x, f, q) {
    const g = Math.tan((Math.PI * clamp(f, 8, SR * 0.45)) / SR), k = 1 / q;
    const hp = (x - (g + k) * this.s1 - this.s2) / (1 + g * (g + k));
    const bp = g * hp + this.s1; this.s1 = g * hp + bp;
    const lp = g * bp + this.s2; this.s2 = g * bp + lp;
    this.hp = hp; this.bp = bp; this.lp = lp; this.bn = bp * k; // bn: unity-peak band-pass
    return lp;
  }
}
const blep = (t, dt) => {
  if (t < dt) { t /= dt; return t + t - t * t - 1; }
  if (t > 1 - dt) { t = (t - 1) / dt; return t * t + t + t + 1; }
  return 0;
};
class Osc {
  constructor(ph = 0) { this.p = ph; }
  step(f) { const dt = f / SR; this.p += dt; if (this.p >= 1) this.p -= Math.floor(this.p); return dt; }
  saw(f) { const dt = this.step(f); return 2 * this.p - 1 - blep(this.p, dt); }
  sq(f, pw = 0.5) { const dt = this.step(f), p = this.p; return (p < pw ? 1 : -1) + blep(p, dt) - blep((p + 1 - pw) % 1, dt); }
  sin(f) { this.step(f); return Math.sin(TAU * this.p); }
  tri(f) { this.step(f); return 1 - 4 * Math.abs(this.p - 0.5); }
}

// decaying sinusoid (modal partial) into stereo buffer o at relative time t (rotation recurrence, no trig per sample)
function ring(o, t, f, amp, dec, pan = 0) {
  if (f >= SR * 0.45 || amp === 0) return;
  const i0 = S(t), n = Math.min(o.L.length - i0, Math.ceil(dec * 7 * SR));
  const w = (TAU * f) / SR, c = Math.cos(w), s = Math.sin(w), d = Math.exp(-1 / (dec * SR));
  const [gl, gr] = panLR(pan);
  let re = amp, im = 0;
  for (let k = 0; k < n; k++) {
    const nr = (re * c - im * s) * d; im = (re * s + im * c) * d; re = nr;
    const e = k < 16 ? k / 16 : 1;
    o.L[i0 + k] += im * e * gl; o.R[i0 + k] += im * e * gr;
  }
}
// short band-passed noise grain (debris, crunch, link clicks), peak-normalised to amp
function tick(o, t, amp, pan, f, dec, q = 1.2, drive = 0, seed = 1) {
  const r = rng(seed), i0 = S(t), n = Math.min(o.L.length - i0, Math.ceil(dec * 6 * SR));
  if (n <= 0) return;
  const bp = new BQ('bp', f, q), tmp = new Float32Array(n);
  let pk = 0;
  for (let k = 0; k < n; k++) {
    let v = bp.p(r.n()) * Math.exp(-k / (dec * SR)) * Math.min(1, k / 8);
    if (drive) v = Math.tanh(v * drive);
    tmp[k] = v; if (Math.abs(v) > pk) pk = Math.abs(v);
  }
  const [gl, gr] = panLR(pan), g = amp / (pk || 1);
  for (let k = 0; k < n; k++) { o.L[i0 + k] += tmp[k] * g * gl; o.R[i0 + k] += tmp[k] * g * gr; }
}
// pitch-swept saturated sine thump (kick-like body), peak = amp
function thump(o, t, { amp = 0.8, f0 = 150, f1 = 55, sw = 0.03, dec = 0.08, drive = 2, pan = 0, len = 0 } = {}) {
  const i0 = S(t), n = Math.min(o.L.length - i0, Math.ceil((len || dec * 6) * SR)), [gl, gr] = panLR(pan);
  const nd = Math.tanh(drive);
  let ph = 0;
  for (let k = 0; k < n; k++) {
    const tt = k / SR;
    ph += (f1 + (f0 - f1) * Math.exp(-tt / sw)) / SR;
    const v = (Math.tanh(Math.sin(TAU * ph) * Math.exp(-tt / dec) * Math.min(1, tt / 0.0008) * drive) / nd) * amp;
    o.L[i0 + k] += v * gl; o.R[i0 + k] += v * gr;
  }
}
// filtered-noise layer with moving filter, envelope, stereo motion; peak-normalised to amp
function hiss(o, t, { amp = 0.5, dur = 0.2, f0 = 2000, f1 = null, q = 0.8, type = 'bp', atk = 0.002, shape = 1, env = null,
  pan0 = 0, pan1 = null, width = 0.4, seed = 7, am = 0, amf = 0 } = {}) {
  const r = rng(seed), i0 = S(t), n = Math.min(o.L.length - i0, Math.ceil(dur * SR));
  if (n <= 0) return;
  const a = new SVF(), b = new SVF(), L = new Float32Array(n), R = new Float32Array(n);
  const fe = f1 == null ? f0 : f1, p1 = pan1 == null ? pan0 : pan1;
  let pk = 0;
  for (let k = 0; k < n; k++) {
    const u = k / n, tt = k / SR;
    const fc = f0 * Math.pow(fe / f0, u);
    const e = env ? env(u, tt) : Math.min(1, tt / atk) * Math.pow(1 - u, shape);
    const m = am ? 1 - am + am * (0.5 + 0.5 * Math.sin(TAU * amf * tt)) : 1;
    const n1 = r.n(), n2 = r.n() * width + n1 * (1 - width);
    a.run(n1, fc, q); b.run(n2, fc, q);
    const va = type === 'bp' ? a.bn : type === 'lp' ? a.lp : a.hp, vb = type === 'bp' ? b.bn : type === 'lp' ? b.lp : b.hp;
    const [gl, gr] = panLR(p0lerp(pan0, p1, u));
    L[k] = va * e * m * gl; R[k] = vb * e * m * gr;
    pk = Math.max(pk, Math.abs(L[k]), Math.abs(R[k]));
  }
  const g = amp / (pk || 1);
  for (let k = 0; k < n; k++) { o.L[i0 + k] += L[k] * g; o.R[i0 + k] += R[k] * g; }
}
const p0lerp = (a, b, u) => a + (b - a) * u;
// wet resonant squelch: noise / glottal buzz through a sweeping resonant band-pass (+2nd formant); peak = amp
function squelch(o, t, { amp = 0.5, dur = 0.12, f0 = 900, f1 = 300, f2 = 0, f3 = 0, q = 6, buzz = 0.5, bf = 100, bf1 = 0,
  pan = 0, seed = 5, atk = 0.003, shape = 1.5, curve = 0.7 } = {}) {
  const r = rng(seed), i0 = S(t), n = Math.min(o.L.length - i0, Math.ceil(dur * SR));
  if (n <= 0) return;
  const a = new SVF(), b = new SVF(), [gl, gr] = panLR(pan), tmp = new Float32Array(n);
  let ph = 0, pk = 0;
  for (let k = 0; k < n; k++) {
    const tt = k / SR, u = k / n, w = Math.pow(u, curve);
    ph += (bf1 ? bf * Math.pow(bf1 / bf, u) : bf) / SR; if (ph >= 1) ph -= 1;
    const ex = r.n() * (1 - buzz) + (ph < 0.1 ? 1.4 : -0.155) * buzz;
    a.run(ex, f0 * Math.pow(f1 / f0, w), q);
    let y = a.bn;
    if (f2) { b.run(ex, f2 * Math.pow((f3 || f2) / f2, w), q); y += b.bn * 0.6; }
    y *= Math.min(1, tt / atk) * Math.pow(1 - u, shape);
    tmp[k] = y; if (Math.abs(y) > pk) pk = Math.abs(y);
  }
  const g = amp / (pk || 1);
  for (let k = 0; k < n; k++) { o.L[i0 + k] += tmp[k] * g * gl; o.R[i0 + k] += tmp[k] * g * gr; }
}

// ------------------------------------------------------------------ reverb (Freeverb topology, stereo)
function freeverb(inL, inR, { room = 0.84, damp = 0.3, width = 1, predelay = 0.02 } = {}) {
  const sc = SR / 44100, n = inL.length, pd = S(predelay);
  const combT = [1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617], apT = [556, 441, 341, 225];
  const mk = (off) => ({
    cb: combT.map((l) => new Float64Array(Math.round((l + off) * sc))), ci: new Int32Array(8), cf: new Float64Array(8),
    ab: apT.map((l) => new Float64Array(Math.round((l + off) * sc))), ai: new Int32Array(4),
  });
  const C = [mk(0), mk(23)], out = { L: new Float32Array(n), R: new Float32Array(n) };
  const w1 = width / 2 + 0.5, w2 = (1 - width) / 2, o = [0, 0];
  for (let i = 0; i < n; i++) {
    const j = i - pd, x = j >= 0 ? (inL[j] + inR[j]) * 0.015 : 0;
    for (let ch = 0; ch < 2; ch++) {
      const c = C[ch];
      let acc = 0;
      for (let k = 0; k < 8; k++) {
        const b = c.cb[k], y = b[c.ci[k]];
        c.cf[k] = y * (1 - damp) + c.cf[k] * damp;
        b[c.ci[k]] = x + c.cf[k] * room;
        if (++c.ci[k] >= b.length) c.ci[k] = 0;
        acc += y;
      }
      for (let k = 0; k < 4; k++) {
        const b = c.ab[k], bo = b[c.ai[k]], y = bo - acc;
        b[c.ai[k]] = acc + bo * 0.5;
        if (++c.ai[k] >= b.length) c.ai[k] = 0;
        acc = y;
      }
      o[ch] = acc;
    }
    out.L[i] = o[0] * w1 + o[1] * w2; out.R[i] = o[1] * w1 + o[0] * w2;
  }
  return out;
}

// ================================================================== MUSIC INSTRUMENTS
function kick({ f0 = 185, f1 = 45, sw = 0.035, hold = 0.035, dec = 0.3, click = 0.6, drive = 2.2, len = 0.65, seed = 11 } = {}) {
  const r = rng(seed), x = mono(len), hp = new BQ('hp', 2200, 0.7), lp = new BQ('lp', 9000), nd = Math.tanh(drive);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (f1 + (f0 - f1) * Math.exp(-t / sw)) / SR;
    const a = (t < hold ? 1 : Math.exp(-(t - hold) / dec)) * Math.min(1, t / 0.0005);
    const body = Math.tanh(Math.sin(TAU * ph) * a * drive) / nd;
    const ck = t < 0.015 ? lp.p(hp.p(r.n())) * Math.exp(-t / 0.002) * click : 0;
    x[i] = body + ck;
  }
  return norm(fadeOut(x, 0.03));
}
function snare({ seed = 21, tone = 190, dec = 0.16, len = 0.5, drive = 1.6, snap = 1 } = {}) {
  const r = rng(seed), x = mono(len), nd = Math.tanh(drive);
  const bp = new BQ('bp', 4200, 0.6), hp = new BQ('hp', 1100, 0.7), lp = new BQ('lp', 12000), pk = new BQ('pk', 250, 1, 3);
  let p1 = r(), p2 = r();
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, nz = r.n(), f = tone * (1 + 0.6 * Math.exp(-t / 0.008));
    p1 += f / SR; p2 += (f * 1.83) / SR;
    const body = (Math.sin(TAU * p1) + 0.45 * Math.sin(TAU * p2)) * Math.exp(-t / 0.05);
    const nzv = lp.p(hp.p(bp.p(nz) * 1.4 + nz * 0.35)) * Math.exp(-t / dec) * Math.min(1, t / 0.0008);
    const tr = t < 0.005 ? nz * Math.exp(-t / 0.0007) * snap : 0;
    x[i] = Math.tanh((pk.p(body) * 0.7 + nzv * 1.3 + tr * 0.5) * drive) / nd;
  }
  return norm(fadeOut(x, 0.05));
}
function clap({ seed = 31, len = 0.4 } = {}) {
  const r = rng(seed), x = mono(len), bp = new BQ('bp', 1400, 1.1), hp = new BQ('hp', 700, 0.7), offs = [0, 0.009, 0.019, 0.031];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let e = 0;
    for (const o of offs) if (t >= o) e = Math.max(e, Math.exp(-(t - o) / 0.0045));
    if (t >= 0.031) e = Math.max(e, 0.55 * Math.exp(-(t - 0.031) / 0.1));
    x[i] = hp.p(bp.p(r.n())) * e;
  }
  return norm(fadeOut(x, 0.05));
}
const METAL = [205.3, 304.4, 369.6, 522.7, 540.0, 800.0]; // 808-style square cluster
function hat({ seed = 41, dec = 0.04, len = 0.15, base = 1 } = {}) {
  const r = rng(seed), x = mono(len), fr = METAL.map((f) => f * 2.2 * base), ph = fr.map(() => r());
  const bp = new BQ('bp', 10000, 0.8), hp = new BQ('hp', 7200, 0.7), hp2 = new BQ('hp', 5500, 0.7);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let m = 0;
    for (let k = 0; k < 6; k++) { ph[k] += fr[k] / SR; if (ph[k] >= 1) ph[k] -= 1; m += ph[k] < 0.5 ? 1 : -1; }
    x[i] = hp2.p(hp.p(bp.p(m * 0.16 + r.n() * 0.55))) * Math.exp(-t / dec) * Math.min(1, t / 0.0003);
  }
  return norm(fadeOut(x, 0.01));
}
function crash({ seed = 51, dec = 1.2, len = 2.5, bright = 1 } = {}) {
  const r = rng(seed), o = stereo(len);
  for (const x of [o.L, o.R]) {
    const fr = METAL.map((f) => f * (3.1 + r() * 0.3)), ph = fr.map(() => r());
    const hp = new BQ('hp', 3000 * bright, 0.7), pk = new BQ('pk', 6500, 0.8, 5), lp = new BQ('lp', 14000, 0.7), bite = new BQ('bp', 4500, 0.8);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR, nz = r.n();
      let m = 0;
      for (let k = 0; k < 6; k++) { ph[k] += fr[k] / SR; if (ph[k] >= 1) ph[k] -= 1; m += ph[k] < 0.5 ? 1 : -1; }
      const wash = lp.p(pk.p(hp.p(m * 0.12 + nz * 0.7))) * (Math.exp(-t / dec) * 0.85 + 0.15 * Math.exp(-t / (dec * 2.2)));
      const b = t < 0.1 ? bite.p(nz) * Math.exp(-t / 0.02) * 1.5 : 0;
      x[i] = (wash + b) * Math.min(1, t / 0.0008);
    }
  }
  return norm(fadeOut(o, 0.3));
}
// 808 / sub bass with exponential glide from `from` (midi) to `midi`
function b808(midi, len, { from = null, glide = 0.05, drive = 2.4, dec = 1.3, rel = 0.035, cut = 900 } = {}) {
  const f = mtof(midi), fr = from == null ? f : mtof(from), x = mono(len + rel), lp = new BQ('lp', cut, 0.7), nd = Math.tanh(drive);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (f * Math.pow(fr / f, Math.exp(-t / glide))) / SR;
    let a = Math.min(1, t / 0.004) * Math.exp(-t / dec);
    if (t > len) a *= Math.max(0, 1 - (t - len) / rel);
    x[i] = lp.p(Math.tanh(Math.sin(TAU * ph) * a * drive) / nd);
  }
  return x;
}
// palm-muted distorted power chord (double-tracked L/R)
function chug(midi, len, { seed = 61, open = 0, accent = 1, fifth = 1, oct = 1 } = {}) {
  const r = rng(seed), o = stereo(len + 0.05), notes = [midi, midi + 7, midi + 12], amps = [1, 0.8 * fifth, 0.5 * oct];
  const dec = open ? 0.5 : 0.09;
  for (let ch = 0; ch < 2; ch++) {
    const y = ch ? o.R : o.L, osc = notes.map(() => new Osc(r())), fq = notes.map((m) => mtof(m) * (1 + (r() - 0.5) * 0.008));
    const f1 = new SVF(), hp = new BQ('hp', 110, 0.7), scoop = new BQ('pk', 420, 0.9, -6), pres = new BQ('pk', 2100, 1.1, 4);
    const cab = new BQ('lp', 4600, 0.8), cab2 = new BQ('lp', 7000, 0.7);
    for (let i = 0; i < y.length; i++) {
      const t = i / SR;
      let s = 0;
      for (let k = 0; k < 3; k++) if (amps[k]) s += osc[k].saw(fq[k]) * amps[k];
      const cut = (open ? 1800 : 520) + 4200 * accent * Math.exp(-t / (open ? 0.12 : 0.022));
      const v = cab2.p(cab.p(pres.p(scoop.p(hp.p(Math.tanh(f1.run(s * 0.6, cut, 0.9) * 9))))));
      let a = Math.min(1, t / 0.0015) * Math.exp(-t / dec);
      if (t > len) a *= Math.max(0, 1 - (t - len) / 0.04);
      y[i] = v * a;
    }
  }
  return o;
}
// detuned saw stack through a resonant filter with envelope (+ optional formants): leads, stabs, brass, pads, choir
function synth(midis, len, o = {}) {
  const { seed = 71, voices = 5, det = 0.18, cut0 = 250, cut1 = 3500, fa = 0.008, fd = 0.22, fs = 0.3, q = 1.3, drive = 1.8,
    atk = 0.004, rel = 0.1, vib = 0, vibD = 0.004, vibDelay = 0.2, scoop = 0, width = 0.8, formant = null, sub = 0, lfo = 0, lfoD = 0,
    glide = null, glideT = 0.04 } = o;
  const r = rng(seed), out = stereo(len + rel + 0.02), n = out.L.length, vs = [];
  for (const m of midis) for (let v = 0; v < voices; v++) {
    const d = voices > 1 ? (v / (voices - 1) - 0.5) * 2 : 0;
    vs.push({ f: mtof(m) * Math.pow(2, (d * det) / 12), osc: new Osc(r()), g: panLR(d * width) });
  }
  const fl = new SVF(), fr = new SVF(), subO = new Osc(0), subF = mtof(midis[0] - 12), nd = Math.tanh(drive), g1 = 1 / Math.sqrt(vs.length);
  const fm = formant ? formant.map(([f, q2, g]) => [new BQ('bp', f, q2), new BQ('bp', f, q2), g]) : null;
  const gl = glide == null ? 1 : mtof(glide) / mtof(midis[0]);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    let pm = 1;
    if (scoop) pm *= Math.pow(2, (-scoop * Math.exp(-t / 0.035)) / 12);
    if (vib) pm *= 1 + vibD * Math.sin(TAU * vib * t) * clamp((t - vibDelay) / 0.2, 0, 1);
    if (gl !== 1) pm *= Math.pow(gl, Math.exp(-t / glideT));
    let l = 0, rr = 0;
    for (let k = 0; k < vs.length; k++) { const s = vs[k].osc.saw(vs[k].f * pm); l += s * vs[k].g[0]; rr += s * vs[k].g[1]; }
    l *= g1; rr *= g1;
    if (sub) { const s = subO.sin(subF * pm) * sub; l += s; rr += s; }
    const fe = t < fa ? t / fa : fs + (1 - fs) * Math.exp(-(t - fa) / fd);
    let cut = cut0 + (cut1 - cut0) * fe;
    if (lfo) cut *= 1 + lfoD * Math.sin(TAU * lfo * t);
    l = fl.run(l, cut, q); rr = fr.run(rr, cut, q);
    if (fm) { let a = 0, b = 0; for (const [x, y, g] of fm) { a += x.p(l) * g; b += y.p(rr) * g; } l = l * 0.2 + a; rr = rr * 0.2 + b; }
    let e = Math.min(1, t / atk);
    if (t > len) e *= Math.max(0, 1 - (t - len) / rel);
    out.L[i] = (Math.tanh(l * drive) / nd) * e; out.R[i] = (Math.tanh(rr * drive) / nd) * e;
  }
  return out;
}
// cheesy drawbar organ with leslie wobble, percussion and key click
function organ(midis, len, { leslie = 6.5, perc = 0.6, click = 0.25, drive = 1.5, rel = 0.06, seed = 81 } = {}) {
  const r = rng(seed), o = stereo(len + rel), n = o.L.length, nd = Math.tanh(drive);
  const bars = [[0.5, 0.7], [1, 1], [1.5, 0.55], [2, 0.6], [3, 0.3], [4, 0.28], [6, 0.12]], parts = [];
  for (const m of midis) for (const [mul, a] of bars) parts.push({ f: mtof(m) * mul, a, ph: r() });
  const g = 1 / Math.sqrt(parts.length), cl = new BQ('bp', 2500, 0.8), pf = mtof(midis[midis.length - 1]) * 3;
  let pp = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR, vib = 1 + 0.0035 * Math.sin(TAU * leslie * t);
    let s = 0;
    for (const p of parts) { p.ph += (p.f * vib) / SR; if (p.ph >= 1) p.ph -= 1; s += Math.sin(TAU * p.ph) * p.a; }
    pp += (pf * vib) / SR; if (pp >= 1) pp -= 1;
    s = s * g + Math.sin(TAU * pp) * perc * Math.exp(-t / 0.18) * 0.5;
    if (t < 0.006) s += cl.p(r.n()) * click * (1 - t / 0.006);
    let e = Math.min(1, t / 0.003);
    if (t > len) e *= Math.max(0, 1 - (t - len) / rel);
    const v = (Math.tanh(s * drive) / nd) * e, am = 0.22 * Math.sin(TAU * leslie * t);
    o.L[i] = v * (1 + am); o.R[i] = v * (1 - am);
  }
  return o;
}
// Karplus-Strong pizzicato
function pluck(midi, { seed = 91, len = 0.8, loop = 0.992, bright = 0.45, env = 0.35 } = {}) {
  const r = rng(seed), P = SR / mtof(midi) - 0.5, n0 = Math.floor(P), fr = P - n0, x = mono(len);
  const exc = new Float64Array(n0 + 2), y = new Float64Array(x.length);
  let s = 0;
  for (let k = 0; k < exc.length; k++) { s += (r.n() - s) * bright; exc[k] = s; }
  for (let i = 0; i < x.length; i++) {
    const a = i - n0 >= 0 ? y[i - n0] : 0, b = i - n0 - 1 >= 0 ? y[i - n0 - 1] : 0, c = i - n0 - 2 >= 0 ? y[i - n0 - 2] : 0;
    y[i] = (i < exc.length ? exc[i] : 0) + loop * 0.5 * ((1 - fr) * a + fr * b + (1 - fr) * b + fr * c);
  }
  const b1 = new BQ('pk', 280, 1.2, 5), b2 = new BQ('pk', 950, 1.5, 3), hp = new BQ('hp', 120, 0.7);
  for (let i = 0; i < x.length; i++) x[i] = hp.p(b2.p(b1.p(y[i]))) * Math.exp(-i / SR / env);
  return norm(fadeOut(x, 0.05));
}
// comic tuba "oom"
function tuba(midi, len) {
  const f = mtof(midi), x = mono(len + 0.08), o1 = new Osc(0), o2 = new Osc(0.3), sv = new SVF(), nd = Math.tanh(1.6);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, pf = f * Math.pow(2, (-0.45 * Math.exp(-t / 0.03)) / 12);
    const s = o1.saw(pf) * 0.7 + o2.sq(pf) * 0.3;
    const cut = 450 + 900 * Math.min(1, t / 0.02) * Math.exp(-t / 0.12);
    let a = Math.min(1, t / 0.012) * (0.55 + 0.45 * Math.exp(-t / 0.08));
    if (t > len) a *= Math.max(0, 1 - (t - len) / 0.08);
    x[i] = (Math.tanh(sv.run(s, cut, 1.1) * 1.6) / nd) * a;
  }
  return norm(x);
}
// FM bell / chime
function bell(midi, { len = 1.6, ratio = 3.5, index = 2.2, dec = 0.7 } = {}) {
  const f = mtof(midi), x = mono(len);
  let pc = 0, pm = 0, p2 = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    pc += f / SR; pm += (f * ratio) / SR; p2 += (f * 2.01) / SR;
    const I = index * Math.exp(-t / 0.18);
    x[i] = (Math.sin(TAU * pc + I * Math.sin(TAU * pm)) * Math.exp(-t / dec) + 0.3 * Math.sin(TAU * p2) * Math.exp(-t / (dec * 0.4))) * Math.min(1, t / 0.001);
  }
  return norm(fadeOut(x, 0.1));
}
// pitch + noise riser (ends at buffer end)
function riser(dur, { seed = 121, f0 = 110, f1 = 880, n0 = 300, n1 = 9000, tone = 0.6, noise = 0.8, curve = 2.2 } = {}) {
  const r = rng(seed), o = stereo(dur), n = o.L.length, os = [new Osc(r()), new Osc(r()), new Osc(r())], dt = [1, 1.012, 0.989];
  const sl = new SVF(), sr2 = new SVF(), tl = new SVF();
  for (let i = 0; i < n; i++) {
    const u = i / n, e = Math.pow(u, curve), f = f0 * Math.pow(f1 / f0, u), fc = n0 * Math.pow(n1 / n0, u);
    let s = 0;
    for (let k = 0; k < 3; k++) s += os[k].saw(f * dt[k]);
    tl.run(s / 3, 400 + 5000 * u, 1.5);
    sl.run(r.n(), fc, 1.2); sr2.run(r.n(), fc * 1.05, 1.2);
    const w = 0.3 + 0.7 * u;
    o.L[i] = (tl.lp * tone + sl.bn * noise * 2) * e;
    o.R[i] = (tl.lp * tone + (sl.bn * (1 - w) + sr2.bn * w) * noise * 2) * e;
  }
  return norm(o);
}

// ================================================================== SFX DESIGN
const smooth = (t, a, b, floor, ramp = 0.004) => // gain dip to `floor` inside [a,b] with short ramps (hit-stop)
  t < a - ramp || t > b + ramp ? 1 : t < a ? 1 - ((1 - floor) * (t - (a - ramp))) / ramp : t <= b ? floor : floor + ((1 - floor) * (t - b)) / ramp;
// cinematic impact: transient crack + pitch-dropping body + sub boom + falling noise tail + debris grains (layers peak-normalised)
function impact(opt = {}) {
  const { seed = 1001, size = 1, len = 2.8, bodyF0 = 150, bodyF1 = 40, subF = 36, subDec = 0.9, drop = 0, tailDec = 0.6,
    debrisDelay = 0, bright = 1, style = 'crystal', stop = null, w = {} } = opt;
  const W = { crack: 0.55, body: 0.9, sub: 0.9, tail: 0.45, debris: 0.35, ...w };
  const r = rng(seed), n = Math.ceil(len * SR), nd = Math.tanh(2.2);
  const crk = new Float32Array(n), bod = new Float32Array(n), sbv = new Float32Array(n), tail = stereo(len), deb = stereo(len);
  const hpC = new BQ('hp', 2500, 0.7), bpC = new BQ('bp', 1800 * bright, 0.9), tl = new SVF(), tr = new SVF();
  let pb = 0, ps = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    if (t < 0.15) { const nz = r.n(); crk[i] = Math.tanh((hpC.p(nz) * Math.exp(-t / 0.0012) * 1.2 + bpC.p(nz) * Math.exp(-t / (0.02 * size)) * 1.6) * 2); }
    pb += (bodyF1 + (bodyF0 - bodyF1) * Math.exp(-t / (0.05 * size))) / SR;
    bod[i] = (Math.tanh(Math.sin(TAU * pb) * 2.2) / nd) * Math.exp(-t / (0.22 * size)) * Math.min(1, t / 0.001);
    ps += (drop ? subF + (drop - subF) * Math.exp(-t / (0.3 * size)) : subF * (1 + 0.35 * Math.exp(-t / 0.12))) / SR;
    sbv[i] = Math.sin(TAU * ps) * Math.min(1, t / 0.004) * Math.exp(-t / (subDec * size));
    const cut = 160 + 5500 * bright * Math.exp(-t / (0.12 * size)), te = Math.exp(-t / (tailDec * size)) * Math.min(1, t / 0.006);
    tail.L[i] = tl.run(r.n(), cut, 0.6) * te; tail.R[i] = tr.run(r.n(), cut, 0.6) * te;
  }
  const G = Math.round((style === 'rock' ? 90 : 60) * size);
  for (let g = 0; g < G; g++) {
    const u = r(), tg = debrisDelay + 0.015 + 1.1 * size * u * u, a = Math.pow(1 - u, 1.5) * (0.35 + 0.65 * r()), pan = r.n() * 0.85;
    if (tg > len - 0.1) continue;
    if (style === 'rock') tick(deb, tg, a, pan, 350 + r() * 2200 * bright, 0.004 + r() * 0.018, 1.5, 2, seed * 7 + g);
    else {
      const f = (style === 'metal' ? 900 : 1400) + r() * 5200 * bright, dec = 0.004 + r() * 0.03;
      ring(deb, tg, f, a * 0.8, dec, pan);
      if (r() < 0.6) ring(deb, tg + 0.0007, f * (1.37 + r() * 0.9), a * 0.5, dec * 0.7, pan);
      tick(deb, tg, a * 0.7, pan, f * 0.7, 0.003 + r() * 0.006, 1.4, 0, seed * 7 + g);
    }
  }
  norm(crk); norm(bod); norm(sbv); norm(tail); norm(deb);
  const out = stereo(len);
  for (let i = 0; i < n; i++) {
    const t = i / SR, hs = stop ? smooth(t, stop[0], stop[1], 0.18) : 1;
    const m = crk[i] * W.crack + bod[i] * W.body + sbv[i] * W.sub;
    out.L[i] = m + (tail.L[i] * W.tail + deb.L[i] * W.debris) * hs;
    out.R[i] = m + (tail.R[i] * W.tail + deb.R[i] * W.debris) * hs;
  }
  return norm(fadeOut(out, 0.08));
}
function shing(o, t, { base = 1400, amp = 0.3, dec = 0.8, ratios = [1, 1.52, 2.34, 2.98, 3.81, 5.13, 6.42], spread = 0.6, detune = 0.004 } = {}) {
  ratios.forEach((m, k) => {
    const a = amp / (1 + k * 0.35), d = dec / (1 + k * 0.4);
    ring(o, t, base * m, a, d, -spread); ring(o, t, base * m * (1 + detune), a, d, spread);
  });
}
function hammerSmash(seed, big = 1) { // huge meaty crystal hammer: crack + thump + sub + debris rattle, hit-stop gap
  const o = impact({ seed, size: 1.2 * big, len: 3, bodyF0: 175, bodyF1: 68, subF: 34, subDec: 0.8, bright: 1.1, style: 'crystal',
    debrisDelay: 0.07, stop: [0.035, 0.085], w: { crack: 0.6, body: 1, sub: 0.95, tail: 0.5, debris: 0.45 } });
  const r = rng(seed + 3), c = stereo(3), m = stereo(0.4);
  shing(c, 0.003, { base: 1350 + r() * 150, amp: 1, dec: 0.9 * big });
  mix(o, norm(c), 0, 0.28);
  squelch(m, 0.004, { amp: 1, dur: 0.16, f0: 700, f1: 220, q: 2.5, buzz: 0.25, bf: 70, seed: seed + 5, shape: 2 });
  thump(m, 0, { amp: 0.8, f0: 260, f1: 90, sw: 0.02, dec: 0.05, drive: 3 });
  mix(o, norm(m), 0, 0.45);
  return norm(o);
}
function stoneImpact(seed) { // deep boom + crumble + dust
  const o = impact({ seed, size: 1.1, len: 3, bodyF0: 120, bodyF1: 60, subF: 30, subDec: 1.1, tailDec: 1.0, bright: 0.45, style: 'rock',
    w: { crack: 0.35, body: 0.9, sub: 1, tail: 0.55, debris: 0.55 } });
  const d = stereo(3), r = rng(seed + 9);
  for (let g = 0; g < 70; g++) { const u = r(); tick(d, 0.08 + 1.6 * u, (1 - u) * (0.3 + 0.7 * r()), r.n() * 0.7, 250 + r() * 900, 0.01 + r() * 0.03, 1.2, 2.5, seed + 100 + g); }
  hiss(d, 0.02, { amp: 0.5, dur: 2.2, f0: 900, f1: 250, q: 0.7, type: 'lp', env: (u, t) => Math.min(1, t / 0.15) * Math.pow(1 - u, 2.2), width: 0.8, seed: seed + 7 });
  mix(o, norm(d), 0, 0.35);
  return norm(o);
}
function megaImpact(seed) { // the biggest hit: stacked impacts + sub-drop + crackle
  const o = impact({ seed, size: 1.6, len: 4, bodyF0: 190, bodyF1: 56, subF: 28, drop: 95, subDec: 1.4, tailDec: 0.9, bright: 1.1,
    style: 'crystal', w: { crack: 0.6, body: 1, sub: 1.1, tail: 0.55, debris: 0.35 } });
  mix(o, impact({ seed: seed + 1, size: 1.3, len: 4, bodyF0: 110, bodyF1: 84, subF: 28, subDec: 1.2, bright: 0.6, style: 'rock',
    w: { crack: 0.2, body: 1, sub: 0, tail: 0.5, debris: 0.4 } }), 0, 0.55);
  mix(o, crackle(0.45, { seed: seed + 2, rate: 260, buzz: 0.5, env: (u) => 1 - u }), 0.005, 0.28);
  shing(o, 0.004, { base: 1100, amp: 0.05, dec: 1.2 });
  return norm(o);
}
function massImpact(seed) {
  const o = impact({ seed, size: 1.35, len: 3, bodyF0: 180, bodyF1: 64, subF: 32, subDec: 1.0, style: 'metal', w: { crack: 0.6, body: 1, sub: 1, tail: 0.5, debris: 0.5 } });
  mix(o, norm(chainRattle(0.5, { seed: seed + 3, rate: 90, amp: 1, env: (u) => Math.pow(1 - u, 1.5) })), 0.01, 0.22);
  return norm(o);
}
function posterSlam(seed) {
  const o = impact({ seed, size: 1.15, len: 3, bodyF0: 160, bodyF1: 72, subF: 36, subDec: 0.9, bright: 1.25, style: 'metal', w: { crack: 0.75, body: 1, sub: 0.9, tail: 0.45, debris: 0.25 } });
  const s = stereo(0.3);
  hiss(s, 0, { amp: 1, dur: 0.07, f0: 1900, f1: 900, q: 1.1, atk: 0.0005, shape: 3, width: 0.5, seed: seed + 4 }); // board slap
  thump(s, 0, { amp: 0.6, f0: 520, f1: 260, sw: 0.01, dec: 0.03, drive: 2 }); // wooden knock
  mix(o, norm(s), 0, 0.5);
  return norm(o);
}
const dropBoom = (seed) => impact({ seed, size: 1.05, len: 2.6, bodyF0: 140, bodyF1: 74, subF: 37, subDec: 0.9, bright: 0.8, style: 'rock', w: { crack: 0.35, body: 1, sub: 1, tail: 0.35, debris: 0.12 } });

function whoosh(dur, { seed = 2001, f0 = 400, f1 = 2400, q = 1.1, pan0 = -0.7, pan1 = 0.7, peak = 0.6, c1 = 2, c2 = 1.6, byEnv = false, tone = 0, tf0 = 200, tf1 = 600, air = 0.35 } = {}) {
  const r = rng(seed), o = stereo(dur + 0.03), n = S(dur), a = new SVF(), b = new SVF(), la = new SVF(), lb = new SVF(), to = new Osc(0);
  for (let i = 0; i < n; i++) {
    const u = i / n, e = u < peak ? Math.pow(u / peak, c1) : Math.pow(1 - (u - peak) / (1 - peak), c2);
    const fc = f0 * Math.pow(f1 / f0, byEnv ? e : u), n1 = r.n(), n2 = r.n();
    a.run(n1, fc, q); b.run(n2 * 0.6 + n1 * 0.4, fc * 1.06, q); la.run(n1, fc * 0.45, 0.7); lb.run(n2, fc * 0.45, 0.7);
    let vl = a.bn + la.lp * air, vr = b.bn + lb.lp * air;
    if (tone) { const s = to.sin(tf0 * Math.pow(tf1 / tf0, u)) * tone; vl += s; vr += s; }
    const [gl, gr] = panLR(pan0 + (pan1 - pan0) * u);
    o.L[i] = vl * e * gl; o.R[i] = vr * e * gr;
  }
  return norm(o);
}
function chainRattle(dur, { seed = 3001, rate = 70, f0 = 1600, f1 = 7000, d0 = 0.008, d1 = 0.035, amp = 0.3, whirr = 0, pan0 = 0, pan1 = 0, spread = 0.5, env = null, tail = 0.25 } = {}) {
  const r = rng(seed), o = stereo(dur + tail);
  let t = r() * 0.004, g = 0;
  while (t < dur) {
    const u = t / dur, e = env ? env(u) : 1, wh = whirr ? 0.5 + 0.5 * Math.sin(TAU * whirr * t) : 1;
    const a = amp * e * (0.25 + 0.75 * wh) * (0.35 + 0.65 * r()), pan = clamp(pan0 + (pan1 - pan0) * u + r.n() * spread, -1, 1);
    const np = 2 + Math.floor(r() * 3);
    for (let k = 0; k < np; k++) ring(o, t + r() * 0.0015, f0 * Math.pow(f1 / f0, r()), (a / np) * 1.6, d0 + (d1 - d0) * r(), pan);
    tick(o, t, a * 0.6, pan, 3000 + r() * 4000, 0.0015, 0.9, 0, seed * 31 + g++);
    t += (1 / rate) * (0.4 + 1.2 * r());
  }
  return o;
}
function clank(seed, { heavy = 1, pitch = 1 } = {}) { // heavy chain links slamming (flam of 2-3 link hits)
  const r = rng(seed), o = stereo(1.8), ratios = [1, 1.47, 2.09, 2.56, 3.39, 4.18, 5.43, 6.8, 8.9];
  const hits = heavy > 0.7 ? [0, 0.011 + r() * 0.008, 0.028 + r() * 0.012] : [0, 0.014];
  hits.forEach((ht, h) => {
    const a = h === 0 ? 1 : 0.45, base = (330 + r() * 120) * pitch;
    ratios.forEach((m, k) => ring(o, ht, base * m * (1 + r.n() * 0.02), (a * (0.7 + 0.5 * r())) / (1 + k * 0.3), ((0.55 * heavy) / (1 + k * 0.3)) * (0.7 + 0.6 * r()), r.n() * 0.3));
    tick(o, ht, a * 1.4, r.n() * 0.2, 3200, 0.003, 0.8, 1.5, seed + h);
  });
  thump(o, 0, { amp: 0.9 * heavy, f0: 160, f1: 70, sw: 0.015, dec: 0.06, drive: 2.5 });
  mix(o, norm(chainRattle(0.2, { seed: seed + 1, rate: 55, amp: 1, env: (u) => 1 - u })), 0.025, 0.25);
  return norm(o);
}
function yank(seed, { dur = 0.1 } = {}) { // taut clank + zip
  const r = rng(seed), o = stereo(dur + 0.5);
  [1, 1.51, 2.24, 3.07, 4.3].forEach((m, k) => ring(o, 0, 620 * m * (1 + r.n() * 0.01), 0.5 / (1 + k * 0.4), 0.16 / (1 + k * 0.3), r.n() * 0.2));
  tick(o, 0, 0.9, 0, 2800, 0.003, 0.8, 1.5, seed + 1);
  thump(o, 0, { amp: 0.4, f0: 300, f1: 140, sw: 0.01, dec: 0.03 });
  let t = 0.012, k = 0;
  while (t < dur) {
    const u = t / dur;
    ring(o, t, 2300 + 3800 * u + r() * 700, 0.16, 0.005, r.n() * 0.4);
    tick(o, t, 0.2, r.n() * 0.4, 4000 + 2000 * u, 0.0012, 0.8, 0, seed + 10 + k++);
    t += 0.012 * (1 - 0.55 * u);
  }
  hiss(o, 0.005, { amp: 0.55, dur, f0: 1100, f1: 6500, q: 2.2, env: (u, tt) => Math.min(1, tt / 0.01) * (0.4 + 0.6 * u), pan0: -0.3, pan1: 0.3, seed: seed + 3 });
  return norm(o);
}
function needle(seed, p = 1) { // signature sharp wet piercing "shlk"
  const o = stereo(0.35);
  tick(o, 0, 0.9, 0, 7500 * p, 0.0012, 0.7, 0, seed + 1);
  ring(o, 0.0005, 7400 * p, 0.28, 0.02, -0.2); ring(o, 0.0005, 10900 * p, 0.2, 0.014, 0.2);
  hiss(o, 0.001, { amp: 0.55, dur: 0.05, f0: 7500 * p, f1: 2600 * p, q: 1.6, atk: 0.001, shape: 2, seed: seed + 2 });
  squelch(o, 0.012, { amp: 0.8, dur: 0.075, f0: 1500 * p, f1: 330 * p, f2: 2600 * p, f3: 900 * p, q: 7, buzz: 0.35, bf: 140, seed: seed + 3, shape: 1.3 });
  thump(o, 0.016, { amp: 0.5, f0: 240 * p, f1: 110 * p, sw: 0.012, dec: 0.025, drive: 2 });
  tick(o, 0.07, 0.35, 0.1, 2200 * p, 0.004, 1.5, 2, seed + 4);
  return norm(o);
}
function chomp(seed, p = 1) { // low wet thump + crunchy bursts + formant squelch
  const r = rng(seed), o = stereo(0.4);
  thump(o, 0, { amp: 0.85, f0: 155 * p, f1: 58 * p, sw: 0.022, dec: 0.075, drive: 2.6 });
  const nb = 4 + Math.floor(r() * 3);
  for (let k = 0; k < nb; k++) { const tk = 0.003 + r() * 0.07; tick(o, tk, 0.55 * (1 - tk * 7), r.n() * 0.3, (1400 + r() * 3200) * p, 0.003 + r() * 0.008, 2.5, 4, seed + 10 + k); }
  squelch(o, 0.008, { amp: 0.55, dur: 0.17, f0: 950 * p, f1: 290 * p, f2: 1700 * p, f3: 820 * p, q: 5, buzz: 0.55, bf: 95 * p, bf1: 70 * p, seed: seed + 2, shape: 1.2 });
  squelch(o, 0, { amp: 0.3, dur: 0.03, f0: 2400 * p, f1: 1200 * p, q: 3, buzz: 0, seed: seed + 3, shape: 2 });
  return norm(o);
}
function gulp(seed, { big = 0, p = 1 } = {}) { // "glk"
  const s = 1 + big * 0.8, o = stereo(0.7 * s);
  squelch(o, 0, { amp: 0.9, dur: 0.09 * s, f0: (900 * p) / (1 + big * 0.3), f1: 240 * p, f2: 1700 * p, f3: 700 * p, q: 7, buzz: 0.85, bf: 115 * p, bf1: 80 * p, seed: seed + 1, shape: 1 });
  thump(o, 0.015, { amp: 0.55 + big * 0.35, f0: 330 * p, f1: 105 * p, sw: 0.025 * s, dec: 0.05 * s, drive: 1.8 });
  tick(o, 0.085 * s, 0.6, 0, 1900 * p, 0.004, 1.2, 2, seed + 2);
  thump(o, 0.085 * s, { amp: 0.4, f0: 900 * p, f1: 400 * p, sw: 0.008, dec: 0.012 });
  if (big) {
    thump(o, 0.11 * s, { amp: 0.8, f0: 140, f1: 42, sw: 0.08, dec: 0.18, drive: 2.2 });
    squelch(o, 0.16 * s, { amp: 0.45, dur: 0.14, f0: 500, f1: 180, q: 6, buzz: 0.8, bf: 70, seed: seed + 5 });
  }
  return norm(o);
}
function slurp(seed) { // wet slurp + lip-lick
  const o = stereo(0.55);
  hiss(o, 0, { amp: 0.9, dur: 0.36, f0: 380, f1: 2200, q: 5, am: 0.7, amf: 26, env: (u, t) => Math.min(1, t / 0.03) * Math.pow(Math.sin(Math.PI * Math.min(1, u * 1.05)), 0.7), pan0: -0.25, pan1: 0.25, seed: seed + 1 });
  squelch(o, 0.05, { amp: 0.5, dur: 0.25, f0: 500, f1: 1400, f2: 1200, f3: 2600, q: 8, buzz: 0.4, bf: 60, seed: seed + 2, shape: 0.7 });
  tick(o, 0.37, 0.7, 0.2, 2800, 0.005, 1.4, 1.5, seed + 3);
  thump(o, 0.37, { amp: 0.35, f0: 600, f1: 300, sw: 0.006, dec: 0.012 });
  return norm(o);
}
// growl / roar: jittery saw voices + subharmonic + breath noise through moving vowel formants, distorted
function growl(seed, { dur = 0.6, f = 72, f1 = null, vowel = [[700, 1100, 2500], [520, 850, 2400]], rough = 28, drive = 3, voices = 2, noise = 0.35 } = {}) {
  const r = rng(seed), o = stereo(dur + 0.1), n = S(dur + 0.1), nd = Math.tanh(drive * 2);
  const vs = Array.from({ length: voices }, (_, k) => ({ osc: new Osc(r()), det: 1 + (k - (voices - 1) / 2) * 0.012, g: panLR(voices > 1 ? (k / (voices - 1) - 0.5) * 1.2 : 0) }));
  const F = [0, 1, 2].map(() => [new SVF(), new SVF()]), sub = new Osc(0), fg = [1, 0.7, 0.35];
  let jit = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR, u = Math.min(1, t / dur);
    jit += (r.n() * 0.5 - jit) * 0.002;
    const fr = (f1 ? f * Math.pow(f1 / f, u) : f) * (1 + jit * 0.16) * (1 + 0.06 * Math.sin(TAU * rough * t));
    let l = 0, rr = 0;
    for (const v of vs) { const s = v.osc.saw(fr * v.det); l += s * v.g[0]; rr += s * v.g[1]; }
    const sb = sub.sq(fr * 0.5) * 0.35, nz = r.n() * noise, am = 0.75 + 0.25 * Math.sin(TAU * rough * t);
    l = (l / voices + sb + nz) * am; rr = (rr / voices + sb + nz) * am;
    let ol = 0, or = 0;
    for (let k = 0; k < 3; k++) {
      const fk = vowel[0][k] + (vowel[1][k] - vowel[0][k]) * u;
      F[k][0].run(l, fk, 6); F[k][1].run(rr, fk, 6); ol += F[k][0].bn * fg[k]; or += F[k][1].bn * fg[k];
    }
    const e = Math.min(1, t / 0.06) * (t < dur ? 1 : Math.max(0, 1 - (t - dur) / 0.1)) * (1 - 0.3 * u);
    o.L[i] = (Math.tanh(ol * drive * 2) / nd) * e; o.R[i] = (Math.tanh(or * drive * 2) / nd) * e;
  }
  return norm(filt(o, () => new BQ('lp', 6000, 0.7), () => new BQ('hp', 60, 0.7)));
}
// sparse random clicks through resonances (+ optional gated electric buzz and zaps)
function crackle(dur, { seed = 4001, rate = 180, fLo = 1500, fHi = 7500, buzz = 0, buzzF = 100, zap = 0, env = null, fire = false } = {}) {
  const r = rng(seed), o = stereo(dur + 0.05);
  let t = 0, k = 0;
  while (t < dur) {
    const u = t / dur, a = (env ? env(u) : 1) * Math.pow(r(), 1.8), pan = r.n() * 0.9;
    ring(o, t, fLo * Math.pow(fHi / fLo, r()), a * 0.8, 0.0008 + r() * 0.003, pan);
    tick(o, t, a * 0.6, pan, fire ? 1200 + r() * 2500 : 5000 + r() * 4000, 0.0008, 0.7, 0, seed + k++);
    t += -Math.log(1 - r() * 0.999) / rate;
  }
  norm(o);
  if (buzz) {
    const b = stereo(dur), os = new Osc(0), bp = new BQ('bp', 1800, 1.2), bp2 = new BQ('bp', 3600, 2);
    let gate = 0, gt = 0;
    for (let i = 0; i < b.L.length; i++) {
      if (i >= gt) { gate = r() < 0.55 ? 0.4 + 0.6 * r() : 0; gt = i + S(0.01 + r() * 0.035); }
      const s = os.saw(buzzF * (1 + 0.03 * r.n())), v = (bp.p(s) + bp2.p(s) * 0.5) * gate * (env ? env(i / b.L.length) : 1);
      b.L[i] = v; b.R[i] = v * 0.8;
    }
    mix(o, norm(b), 0, buzz);
  }
  for (let z = 0; z < Math.round(zap * dur * 12); z++)
    hiss(o, r() * dur, { amp: 0.9, dur: 0.008 + r() * 0.012, f0: 2500, f1: 6000, q: 0.8, atk: 0.0005, shape: 0.5, pan0: r.n() * 0.7, seed: seed + 500 + z });
  return norm(o);
}
function fuse(dur, seed) {
  const o = stereo(dur + 0.05);
  hiss(o, 0, { amp: 0.8, dur, f0: 3800, f1: 6200, q: 0.9, env: (u, t) => Math.min(1, t / 0.02) * (0.7 + 0.3 * Math.sin(TAU * 17 * t) * Math.sin(TAU * 5.3 * t)) * (u > 0.9 ? (1 - u) * 10 : 1), width: 0.6, seed: seed + 1 });
  mix(o, crackle(dur, { seed: seed + 2, rate: 90, fLo: 2500, fHi: 8000, fire: true }), 0, 0.35);
  return norm(o);
}
function eyeIgnite(seed) { // metallic shing + hot flare
  const o = stereo(1.6);
  shing(o, 0, { base: 2150, amp: 0.35, dec: 0.7, ratios: [1, 1.34, 1.93, 2.41, 3.07, 3.9, 4.73], spread: 0.7, detune: 0.006 });
  hiss(o, 0, { amp: 0.6, dur: 0.12, f0: 9000, f1: 5000, q: 0.9, atk: 0.001, shape: 2, width: 0.7, seed: seed + 1 });
  hiss(o, 0.01, { amp: 0.8, dur: 0.55, f0: 350, f1: 2800, q: 0.8, env: (u, t) => Math.min(1, t / 0.05) * Math.pow(1 - u, 1.8), pan0: -0.4, pan1: 0.4, width: 0.6, seed: seed + 2 });
  thump(o, 0, { amp: 0.45, f0: 120, f1: 60, sw: 0.05, dec: 0.15, drive: 1.5 });
  mix(o, crackle(0.5, { seed: seed + 3, rate: 60, fLo: 1500, fHi: 5000, fire: true, env: (u) => 1 - u }), 0.03, 0.12);
  return norm(o);
}
function heartbeat(seed) { // lub-dub, saturated so it survives phone speakers
  const o = stereo(0.6);
  thump(o, 0, { amp: 0.95, f0: 70, f1: 42, sw: 0.03, dec: 0.07, drive: 3 });
  thump(o, 0.17, { amp: 0.7, f0: 78, f1: 46, sw: 0.025, dec: 0.055, drive: 3 });
  hiss(o, 0, { amp: 0.25, dur: 0.1, f0: 220, type: 'lp', q: 0.7, seed, shape: 3 });
  hiss(o, 0.17, { amp: 0.18, dur: 0.08, f0: 240, type: 'lp', q: 0.7, seed: seed + 1, shape: 3 });
  return norm(o);
}
function breath(dur, { inhale = true, seed = 5001 } = {}) { // lava-golem breathing swell
  const o = stereo(dur + 0.05);
  hiss(o, 0, { amp: 1, dur, f0: inhale ? 180 : 520, f1: inhale ? 520 : 170, q: 1.4, env: (u) => Math.pow(Math.sin(Math.PI * u), inhale ? 1.4 : 0.9), am: inhale ? 0 : 0.35, amf: 17, width: 0.5, seed });
  hiss(o, 0, { amp: 0.35, dur, f0: 1200, f1: inhale ? 1800 : 900, q: 2.5, env: (u) => Math.pow(Math.sin(Math.PI * u), 2), width: 0.6, seed: seed + 1 });
  return norm(o);
}
function weaponPop(seed, kind) { // springy metallic pop/ting + chain rattle, per-weapon character
  const r = rng(seed), o = stereo(0.9), K = { ice: [2600, 1.25], poison: [1500, 0.85], gold: [1750, 1], crystal: [2200, 1.12] }[kind];
  squelch(o, 0, { amp: 0.25, dur: 0.02, f0: 3000, f1: 1500, q: 2, buzz: 0, seed: seed + 1, shape: 2 });
  const b = mono(0.25);
  let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, f = 330 * K[1] * (1 + 1.6 * Math.exp(-t / 0.012)) * (1 + 0.18 * Math.exp(-t / 0.08) * Math.sin(TAU * 24 * t));
    ph += f / SR; b[i] = Math.sin(TAU * ph) * Math.exp(-t / 0.07) * Math.min(1, t / 0.001);
  }
  mix(o, b, 0, 0.8);
  const ratios = kind === 'gold' ? [1, 2.76, 5.4, 8.93] : [1, 1.59, 2.14, 2.92, 3.87], dd = kind === 'crystal' ? 0.55 : 0.35;
  ratios.forEach((m, k) => { ring(o, 0.002, K[0] * m, 0.32 / (1 + k * 0.5), dd / (1 + k * 0.4), -0.3); ring(o, 0.002, K[0] * m * 1.003, 0.32 / (1 + k * 0.5), dd / (1 + k * 0.4), 0.3); });
  if (kind === 'ice') for (let k = 0; k < 8; k++) ring(o, 0.02 + k * 0.025 + r() * 0.01, 4000 + r() * 5000, 0.08, 0.05, r.n() * 0.8);
  if (kind === 'poison') for (let k = 0; k < 6; k++) squelch(o, 0.03 + k * 0.045 + r() * 0.02, { amp: 0.25, dur: 0.035, f0: 500 + r() * 400, f1: 1200 + r() * 600, q: 9, buzz: 0.2, seed: seed + 20 + k, shape: 1 });
  if (kind === 'gold') ring(o, 0.07, K[0] * 1.5, 0.15, 0.4, 0.5);
  if (kind === 'crystal') [1, 1.26, 1.5].forEach((m, k) => ring(o, 0.01 + k * 0.03, 1760 * m, 0.12, 0.6, (k - 1) * 0.6));
  mix(o, norm(chainRattle(0.18, { seed: seed + 50, rate: 70, amp: 1, env: (u) => 1 - u })), 0.01, 0.22);
  return norm(o);
}
function bouncyPop(seed, { p = 1, big = 1 } = {}) { // "bwoop" button pop
  const o = stereo(0.35), b = mono(0.3);
  let ph = 0;
  for (let i = 0; i < b.length; i++) {
    const t = i / SR, f = 520 * p * (1 + 0.9 * (1 - Math.exp(-t / 0.01)) * Math.exp(-t / 0.05)) * (1 + 0.12 * Math.exp(-t / 0.06) * Math.sin(TAU * 30 * t));
    ph += f / SR; b[i] = Math.sin(TAU * ph) * Math.exp(-t / (0.06 * big)) * Math.min(1, t / 0.0015);
  }
  mix(o, b, 0, 0.9);
  tick(o, 0, 0.5, 0, 3500 * p, 0.0015, 0.8, 0, seed);
  thump(o, 0, { amp: 0.4 * big, f0: 200 * p, f1: 120 * p, sw: 0.01, dec: 0.03 });
  return norm(o);
}
function tap(seed) {
  const o = stereo(0.12);
  tick(o, 0, 0.8, 0, 4200, 0.0012, 0.8, 0, seed);
  ring(o, 0, 2100, 0.35, 0.012, 0); ring(o, 0, 3350, 0.2, 0.008, 0);
  thump(o, 0, { amp: 0.4, f0: 380, f1: 220, sw: 0.005, dec: 0.012 });
  return norm(o);
}
function blip(midi, { len = 0.09, two = true, bright = 1 } = {}) { // coin-style reward blip / counter tick
  const x = mono(len * (two ? 2.2 : 1.2)), o1 = new Osc(0), o2 = new Osc(0), lp = new BQ('lp', 7000 * bright, 0.7), f1 = mtof(midi), f2 = mtof(midi + 5);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR, f = two && t > len * 0.45 ? f2 : f1;
    x[i] = lp.p(o1.sq(f, 0.3) * 0.6 + o2.sin(f) * 0.4) * Math.exp(-t / (len * 0.9)) * Math.min(1, t / 0.001);
  }
  return norm(fadeOut(x, 0.01));
}
function settle(seed) {
  const o = stereo(1.0), r = rng(seed);
  thump(o, 0, { amp: 0.8, f0: 110, f1: 48, sw: 0.04, dec: 0.12, drive: 1.6 });
  hiss(o, 0.01, { amp: 0.45, dur: 0.7, f0: 1200, f1: 300, type: 'lp', q: 0.7, env: (u, t) => Math.min(1, t / 0.02) * Math.pow(1 - u, 2.5), width: 0.8, seed });
  for (let k = 0; k < 14; k++) tick(o, 0.03 + r() * 0.5, 0.15 * r(), r.n() * 0.7, 600 + r() * 1800, 0.006, 1.5, 1.5, seed + k);
  return norm(o);
}
function clack(seed) { // final heavy CLACK: chain + locking bolt + body
  const o = clank(seed, { heavy: 1.3, pitch: 0.8 }), b = stereo(1.5);
  thump(b, 0, { amp: 1, f0: 190, f1: 48, sw: 0.03, dec: 0.16, drive: 3 });
  tick(b, 0, 1, 0, 2600, 0.004, 0.9, 2, seed + 5);
  ring(b, 0, 1180, 0.4, 0.25, 0); ring(b, 0, 1770, 0.3, 0.2, 0);
  mix(o, norm(b), 0, 0.8);
  return norm(o);
}
function chime(seed) { // bright success chime: A5 D6 E6 A6 FM bells + sparkle
  const o = stereo(1.8), r = rng(seed);
  [81, 86, 88, 93].forEach((m, k) => mix(o, bell(m, { len: 1.5, ratio: 4, index: 1.6, dec: 0.55 + k * 0.1 }), k * 0.045, 0.6 / (1 + k * 0.15), (k / 3 - 0.5) * 1.2));
  for (let k = 0; k < 10; k++) ring(o, 0.15 + r() * 0.5, 5000 + r() * 6000, 0.05, 0.08, r.n());
  return norm(o);
}
const BRASS = { voices: 3, det: 0.08, cut0: 300, cut1: 3800, fa: 0.035, fd: 0.18, fs: 0.55, q: 0.9, drive: 2.2, atk: 0.012, rel: 0.09, scoop: 0.6, width: 0.7, vib: 5.5, vibD: 0.006, vibDelay: 0.18 };
function victory() { // "ta-DAAA": C major grace -> D major brass stab (main hit at +0.08 s)
  const o = stereo(0.9);
  mix(o, synth([60, 64, 67, 72], 0.06, { ...BRASS, seed: 901 }), 0, 0.7);
  mix(o, synth([50, 62, 66, 69, 74], 0.42, { ...BRASS, seed: 902 }), 0.08, 1);
  return norm(o);
}

// ================================================================== ARRANGEMENT: MUSIC (150 BPM grid from 2.4 s)
const kickTimes = [], duckEv = []; // -> synth pump + sidechain ducking of the music bed
const KICK = kick(), KICK_BIG = kick({ f0: 210, dec: 0.42, drive: 2.8, click: 0.8, len: 0.9, seed: 12 }), KICK_LT = kick({ f0: 160, dec: 0.2, click: 0.35, seed: 13 });
const SNR = snare(), SNR_R = snare({ seed: 23, tone: 210, dec: 0.08, drive: 1.2 }), CLP = clap();
const HATS = [hat({ seed: 41 }), hat({ seed: 42, dec: 0.032 }), hat({ seed: 43, dec: 0.05, base: 1.04 })], OHAT = hat({ seed: 44, dec: 0.2, len: 0.5 });
const CRASH = crash(), CRASH2 = crash({ seed: 52, dec: 1.8, len: 3.2 });
const endAt = (t, v) => t - (v instanceof Float32Array ? v : v.L).length / SR; // start time so the buffer ends at t
function revCym(dur, v = CRASH) { const n = S(dur); return fadeIn({ L: v.L.slice(0, n).reverse(), R: v.R.slice(0, n).reverse() }, dur * 0.6); }

function K(t, g = 0, v = KICK) { put(BUS.drum, v, t, db(-4 + g), 0, 0.03); if (v !== KICK_LT) kickTimes.push(t); }
function SN(t, g = 0, v = SNR) { put(BUS.drum, v, t, db(-7 + g), 0.05, 0.16); if (v === SNR) put(BUS.drum, CLP, t, db(-15 + g), -0.1, 0.2); }
function HH(t, g = 0, k = 0, pan = 0.3) { put(BUS.drum, HATS[k % 3], t, db(-19 + g), pan, 0.02); }
function OH(t, g = 0) { put(BUS.drum, OHAT, t, db(-21 + g), -0.35, 0.06); }
function CR(t, g = 0, v = CRASH) { put(BUS.drum, v, t, db(-13 + g), 0, 0.18); }
function B8(t, midi, len, o = {}, g = 0) { put(BUS.bass, b808(midi, len, o), t, db(-8 + g)); }
function CHG(t, midi, len, o = {}, g = 0) { put(BUS.syn, chug(midi, len, { seed: S(t) % 9973, ...o }), t, db(-13.5 + g), 0, 0.02); }
function SY(t, v, g = 0, send = 0.2, pan = 0) { put(BUS.syn, v, t, db(g), pan, send); }
function echo(t, v, g, send, n = 2, dt = 0.3, fb = -8) { SY(t, v, g, send); for (let k = 1; k <= n; k++) SY(t + dt * k, v, g + fb * k, send * 1.5, k % 2 ? -0.6 : 0.6); }

// main trap-metal groove: [step, midi, len16, accent] riffs, 808 line [step, midi, len16, glideFrom], kick steps, lead hook
const RIFF = [
  [[0, 38, 2, 1], [2, 38, 1, 0.5], [3, 38, 1, 1], [5, 38, 1, 0.5], [6, 38, 2, 1], [8, 41, 2, 1], [10, 39, 2, 1], [12, 38, 1, 0.6], [13, 38, 1, 0.5], [14, 38, 1, 0.8], [15, 39, 1, 0.9]],
  [[0, 38, 2, 1], [2, 38, 1, 0.5], [3, 38, 1, 1], [5, 38, 1, 0.5], [6, 38, 2, 1], [8, 34, 2, 1], [10, 36, 3, 1], [13, 38, 1, 0.6], [14, 39, 1, 0.8], [15, 41, 1, 0.9]],
];
const BASS = [
  [[0, 38, 6], [6, 38, 2], [8, 41, 2, 38], [10, 39, 4, 41], [14, 38, 2, 39]],
  [[0, 38, 6], [6, 38, 2], [8, 34, 2, 38], [10, 36, 4, 34], [14, 38, 2, 36]],
];
const KPAT = [[0, 3, 6, 8, 10, 14], [0, 3, 6, 8, 11, 14]];
const LEAD = [[[0, 74, 3], [3, 77, 3], [6, 75, 4]], [[0, 74, 2], [2, 72, 2], [4, 70, 2], [6, 69, 6]]];
const LEADSYN = { voices: 5, det: 0.22, cut0: 600, cut1: 5200, fa: 0.006, fd: 0.16, fs: 0.45, q: 1.6, drive: 2.6, atk: 0.003, rel: 0.06, width: 0.9, vib: 6, vibD: 0.005, vibDelay: 0.15 };
const STAB = { voices: 4, det: 0.2, cut0: 400, cut1: 6000, fa: 0.003, fd: 0.09, fs: 0.25, q: 1.2, drive: 3, atk: 0.002, rel: 0.12, width: 1 };
const CHOIR = { voices: 3, det: 0.15, cut0: 2400, cut1: 2400, fa: 0.2, fd: 1, fs: 1, q: 0.7, drive: 1.3, atk: 0.3, rel: 0.4, width: 1, vib: 5, vibD: 0.004,
  formant: [[730, 7, 1], [1090, 8, 0.6], [2440, 9, 0.3]] };

function grooveBar(b, { v = 0, lead = true, chugs = true, fillEnd = false, skip = null, big = [] } = {}) {
  const t0 = at(b), ok = (s) => !skip || s < skip[0] || s >= skip[1];
  const lim = (s, l) => (skip && s < skip[0] ? Math.min(l, skip[0] - s) : l);
  for (const s of KPAT[v]) if (ok(s)) { const bg = big.includes(s); K(t0 + s * SIX, bg ? 1.5 : s === 0 ? 0 : -1.5, bg ? KICK_BIG : KICK); if (bg) CR(t0 + s * SIX, 0, CRASH2); }
  for (const s of [4, 12]) if (ok(s) && !(fillEnd && s === 12)) SN(t0 + s * SIX);
  for (let s = 0; s < 16; s++) if (ok(s)) HH(t0 + s * SIX, s % 2 ? -5 : 0, s, s % 2 ? 0.45 : 0.25);
  if (ok(7)) OH(t0 + 7 * SIX, -2);
  if (ok(15) && !fillEnd) OH(t0 + 15 * SIX, -3);
  for (const [s, m, l, f] of BASS[v]) if (ok(s)) B8(t0 + s * SIX, m, lim(s, l) * SIX - 0.01, f ? { from: f, glide: 0.04 } : {});
  if (chugs) for (const [s, m, l, a] of RIFF[v]) if (ok(s)) CHG(t0 + s * SIX, m, lim(s, l) * SIX - 0.015, { accent: a }, a < 0.7 ? -3 : 0);
  if (lead) for (const [s, m, l] of LEAD[v]) if (ok(s)) echo(t0 + s * SIX, synth([m], lim(s, l) * SIX - 0.02, { ...LEADSYN, seed: 700 + b * 16 + s }), -13, 0.25);
  if (fillEnd) for (let s = 12; s < 16; s++) SN(t0 + s * SIX, -6 + (s - 12) * 1.5, SNR_R);
}

// ---- 0.0-2.4 HOOK & CHEW: no music, only a low dark hum bed + short build into the drop
SY(0, fadeIn(synth([26, 38, 45], 2.36, { voices: 3, det: 0.08, cut0: 160, cut1: 260, fa: 0.8, fd: 1, fs: 1, q: 1.2, drive: 1.4, atk: 0.12, rel: 0.02, lfo: 0.4, lfoD: 0.25, width: 0.6, sub: 0.4, seed: 131 }), 0.1), -13, 0.1);
SY(2.0, riser(0.39, { seed: 122, f0: 70, f1: 300, n0: 400, n1: 7000, tone: 0.4, noise: 0.9, curve: 1.8 }), -13, 0.1);
SY(endAt(2.39, revCym(0.39)), revCym(0.39), -12, 0.1);
// ---- 2.4-5.6 GROW: beat drop, driving groove
grooveBar(0, { v: 0, big: [0] });
grooveBar(1, { v: 1, fillEnd: true });
// ---- 5.6-8.8 UNDERDOG: ominous drone + tense cluster (heartbeat / breathing are SFX)
B8(5.6, 26, 1.4, { dec: 1.2, drive: 1.8 }, 0);
SY(5.6, synth([26, 33, 38], 3.2, { voices: 3, det: 0.1, cut0: 140, cut1: 420, fa: 1.5, fd: 1, fs: 1, q: 2, drive: 1.6, atk: 0.3, rel: 0.25, lfo: 0.3, lfoD: 0.35, sub: 0.5, seed: 132 }), -13, 0.15);
SY(5.8, synth([74, 75], 3.0, { voices: 2, det: 0.06, cut0: 900, cut1: 1400, fa: 2, fd: 1, fs: 1, q: 0.8, drive: 1, atk: 1.2, rel: 0.2, vib: 4.5, vibD: 0.006, width: 1, seed: 133 }), -28, 0.4);
// ---- 8.8-12.0 ISLANDS: rebuild, kick on beats, hats 8ths -> 16ths -> 32nds, riser into 12.0
for (let k = 0; k < 8; k++) { const t = 8.8 + k * BEAT; K(t, -1.5); B8(t, k % 4 === 3 ? 41 : 38, 0.3, { dec: 0.3 }, -2); }
for (let k = 0; k < 6; k++) HH(8.8 + k * 0.2, -1, k);
for (let k = 0; k < 12; k++) HH(10.0 + k * 0.1, k % 2 ? -4 : 0, k, k % 2 ? 0.45 : 0.2);
for (let k = 0; k < 16; k++) HH(11.2 + k * 0.05, -4 + k * 0.3, k, k % 2 ? 0.5 : 0.15);
SN(10.8, -2); SN(11.6, -2);
for (let k = 0; k < 8; k++) CHG(10.4 + k * 0.2, 38, 0.18, { accent: 0.5 + k * 0.06 }, -6 + k * 0.6);
for (let k = 0; k < 8; k++) SN(11.2 + k * 0.1, -14 + k * 1.2, SNR_R);
SY(8.8, synth([50, 53, 57, 62], 3.2, { voices: 3, det: 0.15, cut0: 300, cut1: 2600, fa: 3.2, fd: 1, fs: 1, q: 1.4, drive: 1.6, atk: 1.2, rel: 0.02, width: 1, seed: 134 }), -16, 0.3);
SY(10.4, riser(1.6, { seed: 123, f0: 110, f1: 880, curve: 2.4 }), -11, 0.15);
// ---- 12.0-15.2 ARSENAL: full groove, drop-out 14.0-14.4 for the wind-up, slam back at 14.4
grooveBar(6, { v: 0, big: [0] });
grooveBar(7, { v: 1, skip: [4, 8], big: [8] });
SY(endAt(14.4, revCym(0.4)), revCym(0.4), -9, 0.1);
// ---- 15.2-18.4 BOSS TOWER: comic half-time, oom-pah tuba, organ "pah", pizzicato, spooky
{
  const OOM = [38, 33, 31, 33], PAH = [[50, 53, 57], [50, 53, 57], [55, 58, 62], [57, 61, 64, 67]];
  for (let h = 0; h < 4; h++) {
    const t = 15.2 + h * 0.8, tp = t + 0.4;
    put(BUS.bass, tuba(OOM[h], 0.3), t, db(-7));
    K(t, -6, KICK_LT);
    if (Math.abs(tp - 17.2) > 0.01) SY(tp, organ(PAH[h], 0.14, { leslie: 6.8, perc: 0.3, seed: 84 + h }), -17, 0.12);
    SN(tp, -9, SNR_R);
    HH(t + 0.2, -6, h); HH(tp + 0.2, -6, h + 1);
  }
  const PIZZ = [57, 62, 65, 64, 62, 61, 62, 57, 58, 62, 67, 65, 64, 67, 73, 76];
  PIZZ.forEach((m, k) => SY(15.2 + k * 0.2, pluck(m, { seed: 300 + k, len: 0.5, env: 0.22 }), -12.5 - (k % 2) * 2, 0.18, k % 2 ? 0.25 : -0.25));
  SY(17.2, organ([55, 58, 62, 63], 0.55, { leslie: 7.2, perc: 0.8, seed: 83 }), -10, 0.25); // cheesy spooky organ sting (Gm b6)
}
// ---- 18.4-20.0 DINNER: smash, then victory sting at 19.2
K(18.4, 1.5, KICK_BIG); CR(18.4, 0, CRASH2); B8(18.4, 38, 0.75, { dec: 0.9 });
CHG(18.4, 38, 0.7, { open: 1 }, -1);
K(18.9, -3); K(19.2, 0); SN(19.2, -2); B8(19.2, 38, 0.35, {}, -1); K(19.6, -2); B8(19.6, 41, 0.3, { from: 38 }, -2);
for (let k = 0; k < 7; k++) HH(18.6 + k * 0.2, -5, k);
SY(19.12, victory(), -10, 0.25); // main stab lands at 19.20
// ---- 20.0-21.6 REMATCH: tension, snare roll + riser 20.4-21.4, then TRUE silence 21.40-21.60 (enforced at master)
for (const t of [20.0, 20.4, 20.8, 21.0, 21.2]) K(t, t < 20.8 ? -1 : -2.5);
B8(20.0, 38, 0.35, {}, -2); B8(20.4, 39, 0.3, {}, -3); B8(20.8, 38, 0.55, { from: 39 }, -3);
SY(20.0, synth([62, 63, 74, 75], 1.4, { voices: 3, det: 0.1, cut0: 500, cut1: 4000, fa: 1.3, fd: 1, fs: 1, q: 2.5, drive: 2, atk: 0.8, rel: 0.005, lfo: 9, lfoD: 0.1, width: 1, seed: 135 }), -17, 0.2);
{
  let k = 0;
  for (let i = 0; i < 4; i++) SN(20.4 + i * 0.1, -16 + (k++) * 0.5, SNR_R);
  for (let i = 0; i < 8; i++) SN(20.8 + i * 0.05, -14 + (k++) * 0.45, SNR_R);
  for (let i = 0; i < 8; i++) SN(21.2 + i * 0.025, -9 + (k++) * 0.3, SNR_R);
}
SY(20.4, riser(1.0, { seed: 124, f0: 150, f1: 1400, curve: 2 }), -9, 0.1);
// ---- 21.6-24.8 DEITY: mega impact, full groove at peak energy + choir
grooveBar(12, { v: 0, big: [0] });
grooveBar(13, { v: 1, skip: [14, 16], big: [0] });
SY(21.6, synth([50, 57, 62, 65], 2.95, { ...CHOIR, seed: 136 }), -11, 0.35);
// ---- 24.8-26.4 LOGO: sparse stabs synced to the chain hits, final clack at 26.0
for (const [t, ch] of [[24.8, [50, 57, 62, 65]], [25.2, [50, 57, 62, 65]], [25.6, [51, 58, 63, 67]], [26.0, [38, 50, 57, 62, 69]]]) {
  const bg = t === 26.0, root = ch[0] < 45 ? ch[0] : ch[0] - 12;
  K(t, bg ? 1.5 : -1, bg ? KICK_BIG : KICK);
  B8(t, root, bg ? 0.38 : 0.3, { dec: 0.4 }, bg ? 0 : -2);
  SY(t, synth(ch, bg ? 0.3 : 0.16, { ...STAB, seed: S(t) % 997 }), bg ? -12 : -14, 0.3);
  CHG(t, root, bg ? 0.3 : 0.15, { open: 1 }, -3);
}
CR(24.8, -1);
SY(endAt(26.4, revCym(0.35)), revCym(0.35), -12, 0.1);
// ---- 26.4-29.6 CTA: slam, light groove, final Dsus2 chord fading out
K(26.4, 1.5, KICK_BIG); CR(26.4, 0, CRASH2); B8(26.4, 38, 0.75, { dec: 0.8 });
K(27.2, -3); B8(27.2, 38, 0.35, {}, -4); SN(26.8, -9, SNR_R);
for (let k = 0; k < 7; k++) HH(26.6 + k * 0.2, -7, k);
SY(26.4, synth([50, 57, 64], 1.6, { voices: 3, det: 0.15, cut0: 400, cut1: 1800, fa: 1.4, fd: 1, fs: 1, q: 1, drive: 1.3, atk: 0.5, rel: 0.05, width: 1, seed: 137 }), -18, 0.3);
{
  const fin = synth([38, 45, 50, 57, 64, 69], 1.3, { voices: 4, det: 0.2, cut0: 500, cut1: 3200, fa: 0.02, fd: 0.7, fs: 0.4, q: 1, drive: 1.6, atk: 0.008, rel: 0.02, width: 1, vib: 4.5, vibD: 0.003, seed: 138 });
  for (const x of [fin.L, fin.R]) for (let i = 0; i < x.length; i++) x[i] *= 0.35 + 0.65 * Math.exp(-i / SR / 0.35);
  SY(28.0, fin, -10.5, 0.4);
  K(28.0, -3); CR(28.0, -5); B8(28.0, 26, 1.2, { dec: 0.8, drive: 1.6 }, -1);
}

// ================================================================== ARRANGEMENT: SFX (story beats; the six big hits live on their own bus)
const FX = (t, v, g = 0, pan = 0, send = 0.1, dk = null) => { put(BUS.sfx, v, t, db(g), pan, send); if (dk) duckEv.push([t, dk[0], dk[1]]); };
const HIT = (t, v, g = 0, send = 0.2) => { put(BUS.hit, v, t, db(g), 0, send); duckEv.push([t, -10, 0.35, 0.004, 0.05]); };
const MED = [-4, 0.15], BIGD = [-6, 0.3];

function thud(seed, p = 1) { // island landing: heavy thud + grit + dust
  const o = stereo(0.9), r = rng(seed);
  thump(o, 0, { amp: 1, f0: 135 * p, f1: 48 * p, sw: 0.03, dec: 0.11, drive: 2.6 });
  for (let k = 0; k < 10; k++) tick(o, 0.008 + r() * 0.2, 0.32 * (1 - k / 11), r.n() * 0.6, 400 + r() * 1500, 0.008 + r() * 0.015, 1.3, 2, seed + k);
  hiss(o, 0.004, { amp: 0.3, dur: 0.55, f0: 1600, f1: 300, type: 'lp', q: 0.7, env: (u, t) => Math.min(1, t / 0.01) * Math.pow(1 - u, 2.5), width: 0.8, seed: seed + 50 });
  return norm(o);
}
function hookThrow(seed, { dur = 0.2, pan0 = -0.5, pan1 = 0.5 } = {}) { // chain hook launch: whoosh + rattle whirr
  const o = stereo(dur + 0.16);
  mix(o, whoosh(dur, { seed, f0: 700, f1: 4200, q: 1.3, pan0, pan1, peak: 0.45, c1: 1.6, c2: 1.2, air: 0.2 }), 0, 1);
  mix(o, norm(chainRattle(dur, { seed: seed + 1, rate: 120, amp: 1, whirr: 22, pan0, pan1, spread: 0.3, env: (u) => 0.4 + 0.6 * Math.sin(Math.PI * u), tail: 0.12 })), 0, 0.55);
  return norm(o);
}
function counterTick(midi, big = 0) { // score counter increment
  const o = stereo(0.45);
  mix(o, blip(midi, { len: big ? 0.13 : 0.08, two: !!big, bright: 1.2 }), 0, 0.8);
  tick(o, 0, 0.6, 0, 5000, 0.0015, 0.9, 0, midi * 7 + big);
  if (big) ring(o, 0.002, mtof(midi + 12), 0.25, 0.12, 0);
  return norm(o);
}
function chainsOut(seed) { // chains fan out
  const o = stereo(0.9);
  mix(o, norm(chainRattle(0.36, { seed, rate: 150, amp: 1, f0: 1300, f1: 6500, pan0: -0.1, pan1: 0.1, spread: 0.9, env: (u) => Math.pow(1 - u, 0.8), tail: 0.3 })), 0, 0.8);
  mix(o, clank(seed + 1, { heavy: 0.9, pitch: 1.1 }), 0, 0.6);
  mix(o, whoosh(0.3, { seed: seed + 2, f0: 900, f1: 3500, pan0: -0.6, pan1: 0.6, peak: 0.25, c1: 1, c2: 1.5 }), 0, 0.45);
  return norm(o);
}
function revHit(v, dur) { // reversed impact head -> suck-in swell that ends exactly at the hit
  const n = S(dur), o = { L: v.L.slice(0, n).reverse(), R: v.R.slice(0, n).reverse() };
  return norm(fadeIn(o, dur * 0.35));
}
function flashSwell(seed, dur = 0.2) { // white flash: rising air + reversed sparkle
  const o = stereo(dur + 0.03), s = stereo(dur);
  hiss(o, 0, { amp: 1, dur, f0: 2200, f1: 12000, q: 0.8, env: (u) => Math.pow(u, 2.4), width: 0.9, pan0: -0.3, pan1: 0.3, seed });
  shing(s, 0.004, { base: 2600, amp: 1, dec: 0.1, spread: 0.8 });
  mix(o, norm(reverse(s)), 0, 0.5);
  return norm(o);
}
function burnWhoosh(seed, dur) { // fiery whoosh with crackle
  const o = stereo(dur + 0.1);
  mix(o, whoosh(dur, { seed, f0: 450, f1: 1800, q: 0.8, pan0: 0.6, pan1: -0.6, peak: 0.45, c1: 1.4, c2: 1.4, air: 0.7 }), 0, 1);
  mix(o, crackle(dur, { seed: seed + 1, rate: 130, fire: true, fLo: 900, fHi: 4000, env: (u) => Math.sin(Math.PI * u) }), 0, 0.35);
  return norm(o);
}

// ---- 0.0-2.4 HOOK & CHEW
FX(0.0, eyeIgnite(6001), -5, 0, 0.25);
FX(0.1, whoosh(0.3, { seed: 2002, f0: 500, f1: 3200, pan0: -0.5, pan1: 0.3, peak: 0.85, c1: 2.2, c2: 1 }), -10, 0, 0.1);
HIT(0.40, hammerSmash(7001, 1), 0.5);
FX(0.8, hookThrow(2101, { dur: 0.2, pan0: -0.6, pan1: 0.6 }), -6, 0, 0.08);
FX(1.0, needle(8001), -3, 0.15, 0.08, MED);
FX(1.1, yank(8101, { dur: 0.1 }), -5, 0.3, 0.06);
FX(1.2, chomp(8201, 1), -3, 0, 0.08, MED);
FX(1.6, chomp(8202, 1.08), -3, 0, 0.08, MED);
FX(1.6, counterTick(86), -12, 0.35, 0.15);
FX(2.0, breath(0.38, { inhale: true, seed: 5002 }), -7, 0, 0.1);
// ---- 2.4-5.6 GROW
HIT(2.40, dropBoom(7101), -1.5);
FX(3.6, hammerSmash(7002, 0.8), -3, 0, 0.15, [-6, 0.25]);
FX(3.6, crackle(0.4, { seed: 4101, rate: 230, buzz: 0.6, buzzF: 110, zap: 1.5, env: (u) => 1 - 0.6 * u }), -9, 0, 0.1);
[4.0, 4.03, 4.07, 4.1].forEach((t, k) => FX(t, needle(8002 + k, 1 + k * 0.06), -3, [-0.35, 0.1, -0.1, 0.35][k], 0.06, MED));
FX(4.2, yank(8102, { dur: 0.1 }), -2.5, 0, 0.06, MED);
[4.4, 4.44, 4.48, 4.52].forEach((t, k) => FX(t, chomp(8203 + k, [1, 1.1, 0.94, 1.2][k]), -4, [-0.2, 0.2, -0.1, 0.1][k], 0.06, MED));
[4.4, 4.43, 4.47, 4.5].forEach((t, k) => FX(t, counterTick([79, 81, 84, 86][k]), -11, 0.4, 0.15));
// ---- 5.6-8.8 UNDERDOG
FX(5.6, stoneImpact(7201), -2, 0, 0.25, [-8, 0.4]);
[6.02, 6.8, 7.63, 8.39].forEach((t, k) => FX(t, heartbeat(5101 + k), k === 2 ? -6 : -5, 0, 0.03));
FX(6.15, breath(0.9, { inhale: true, seed: 5003 }), -6, -0.15, 0.3);
FX(7.1, breath(0.8, { inhale: false, seed: 5004 }), -4, 0.15, 0.3);
FX(8.0, gulp(8301, { p: 1.15 }), -3, 0, 0.1, MED);
// ---- 8.8-12.0 ISLANDS: thud, hook throw, chomp + counter per island
[8.8, 9.6, 10.2, 10.7, 11.1].forEach((T, k) => {
  const side = k % 2 ? 1 : -1;
  FX(T + 0.1, thud(5201 + k * 20, 1 + k * 0.04), -3.5, side * 0.3, 0.12, MED);
  FX(T + 0.1, hookThrow(2110 + k * 3, { dur: 0.2, pan0: side * 0.6, pan1: -side * 0.2 }), -6, 0, 0.06);
  FX(T + 0.3, chomp(8210 + k, [1, 1.12, 0.9, 1.25, 1.06][k]), -3, 0, 0.06, MED);
  FX(T + 0.3, counterTick([79, 81, 84, 86, 88][k]), -12, -side * 0.35, 0.15);
});
// ---- 12.0-15.2 ARSENAL
FX(12.0, chainsOut(3101), -2, 0, 0.15, MED);
[[12.4, 'ice', -0.4], [12.8, 'poison', 0.4], [13.2, 'gold', -0.25], [13.6, 'crystal', 0.25]].forEach(([t, kind, pan], k) => FX(t, weaponPop(6101 + k * 10, kind), -1, pan, 0.18, [-5, 0.18]));
FX(14.0, revHit(impact({ seed: 7302, size: 1, len: 0.8, bodyF1: 72, style: 'metal' }), 0.4), -6, 0, 0.1);
FX(14.0, whoosh(0.4, { seed: 2003, f0: 220, f1: 3200, pan0: 0.5, pan1: -0.1, peak: 0.96, c1: 2.4, c2: 1 }), -10, 0, 0.05);
HIT(14.40, massImpact(7401), -1);
FX(14.4, crackle(0.4, { seed: 4201, rate: 240, buzz: 0.5, buzzF: 90, zap: 1.2, env: (u) => 1 - 0.7 * u }), -5, 0, 0.1);
// ---- 15.2-18.4 BOSS TOWER
FX(15.2, whoosh(1.0, { seed: 2004, f0: 180, f1: 3200, q: 1, pan0: -0.25, pan1: 0.25, peak: 0.75, c1: 1.5, c2: 1.3, tone: 0.25, tf0: 90, tf1: 520, air: 0.5 }), -5, 0, 0.25);
FX(15.2, fuse(0.4, 9101), -7, 0.4, 0.05);
FX(15.6, growl(9201, { dur: 0.55, f: 68, f1: 56, vowel: [[650, 1080, 2450], [430, 800, 2350]], rough: 30 }), -4, 0, 0.2, BIGD);
FX(16.2, settle(9301), -6, 0, 0.15);
FX(17.3, slurp(9401), -2, 0.1, 0.1, MED);
// ---- 18.4-20.0 DINNER
FX(18.1, revHit(impact({ seed: 7303, size: 1.1, len: 0.8, bodyF1: 70, style: 'crystal' }), 0.3), -8, 0, 0.1); // suck-in to the smash
FX(18.1, whoosh(0.3, { seed: 2006, f0: 260, f1: 3600, pan0: -0.4, pan1: 0.1, peak: 0.96, c1: 2.4, c2: 1 }), -11, 0, 0.05);
HIT(18.40, hammerSmash(7003, 1.25), -0.5);
FX(19.0, needle(8020, 0.95), -3, -0.15, 0.08, MED);
FX(19.1, yank(8120, { dur: 0.1 }), -5, 0.2, 0.06);
FX(19.2, gulp(8320, { big: 1 }), -2, 0, 0.12, BIGD);
FX(19.75, burnWhoosh(2201, 0.45), -6, 0, 0.15);
// ---- 20.0-21.6 REMATCH (silence 21.40-21.60 is enforced at the master)
[[20.2, 79, 0], [20.55, 82, 0], [20.8, 86, 0], [21.0, 91, 1]].forEach(([t, m, big], k) => FX(t, counterTick(m, big), big ? -3.5 : -5, [0.3, -0.3, 0.2, 0][k], 0.15, big ? MED : [-2.5, 0.1]));
FX(20.4, crackle(0.8, { seed: 4301, rate: 200, buzz: 0.7, buzzF: 95, zap: 1.5, env: (u) => 0.3 + 0.7 * u }), -5, 0, 0.08);
// ---- 21.6-24.8 DEITY
HIT(21.60, megaImpact(7501), 0, 0.25);
FX(21.6, crackle(0.4, { seed: 4401, rate: 260, buzz: 0.6, buzzF: 80, zap: 1.2, env: (u) => 1 - 0.6 * u }), -5, 0, 0.1);
FX(22.3, needle(8030, 1.05), -1.5, 0.1, 0.08, MED);
FX(22.4, yank(8130, { dur: 0.1 }), -2, -0.2, 0.06, MED);
FX(22.6, gulp(8330, { big: 1, p: 0.9 }), -2, 0, 0.12, BIGD);
FX(22.6, growl(9202, { dur: 0.4, f: 84, f1: 70, vowel: [[760, 1220, 2600], [600, 950, 2450]], rough: 34, drive: 3.5, voices: 3, noise: 0.45 }), -3, 0, 0.3, BIGD);
FX(24.6, flashSwell(6201, 0.2), -5, 0, 0.3);
// ---- 24.8-26.4 LOGO
[24.8, 25.2, 25.6].forEach((t, k) => FX(t, clank(6301 + k, { heavy: 1.2, pitch: 1 - k * 0.06 }), -1, [-0.3, 0.3, 0][k], 0.2, [-5, 0.15]));
FX(26.0, clack(6401), 0, 0, 0.25, [-6, 0.2]);
// ---- 26.4-29.6 CTA
HIT(26.40, posterSlam(7601), -1);
FX(26.8, whoosh(0.8, { seed: 2005, f0: 5200, f1: 450, q: 1.3, pan0: -0.8, pan1: 0, peak: 0.8, c1: 1.5, c2: 1.2, tone: 0.2, tf0: 900, tf1: 160 }), -4.5, 0, 0.12);
FX(27.6, bouncyPop(6501, { p: 1, big: 1.2 }), -4, 0, 0.12, MED);
FX(28.15, tap(6601), -1, 0.1, 0.05);
FX(28.3, chime(6701), -6, 0, 0.35);
FX(28.4, bouncyPop(6502, { p: 1.5, big: 0.6 }), -11, -0.35, 0.12);
FX(28.47, bouncyPop(6503, { p: 1.8, big: 0.5 }), -12, 0.35, 0.12);

// ================================================================== MIX + MASTER
function dipEnv(evts) { // ducking envelope in dB (deepest event wins): [t, depthDb, release, attack, hold]
  const e = new Float32Array(N);
  for (const [t, d, rel, atk = 0.004, hold = 0.02] of evts) {
    const i0 = Math.max(0, S(t - atk)), i1 = Math.min(N, S(t + hold + rel * 5));
    for (let i = i0; i < i1; i++) {
      const tt = i / SR - t, v = tt < 0 ? d * (1 + tt / atk) : tt < hold ? d : d * Math.exp(-(tt - hold) / rel);
      if (v < e[i]) e[i] = v;
    }
  }
  return e;
}
function glue(bus, { ratio = 2.5, atk = 0.012, rel = 0.16, knee = 6, below = 5 } = {}) { // RMS bus compressor, threshold from the loud part of the programme
  const aM = Math.exp(-1 / (0.006 * SR)), lv = new Float32Array(N);
  let ms = 0;
  for (let i = 0; i < N; i++) { ms = aM * ms + (1 - aM) * 0.5 * (bus.L[i] * bus.L[i] + bus.R[i] * bus.R[i]); lv[i] = ms; }
  const smp = [];
  for (let i = 0; i < N; i += 48) if (lv[i] > 1e-8) smp.push(lv[i]);
  smp.sort((a, b) => a - b);
  const thr = 10 * Math.log10(smp[Math.floor(smp.length * 0.9)] || 1) - below;
  const aA = Math.exp(-1 / (atk * SR)), aR = Math.exp(-1 / (rel * SR)), sl = 1 - 1 / ratio;
  let env = 0, grMax = 0;
  for (let i = 0; i < N; i++) {
    const o = 10 * Math.log10(lv[i] + 1e-12) - thr;
    const gr = o <= -knee / 2 ? 0 : o >= knee / 2 ? o * sl : (sl * (o + knee / 2) ** 2) / (2 * knee);
    env = gr > env ? aA * env + (1 - aA) * gr : aR * env + (1 - aR) * gr;
    if (env > 1e-3) { const g = db(-env); bus.L[i] *= g; bus.R[i] *= g; }
    if (env > grMax) grMax = env;
  }
  return { thr, grMax };
}
// inter-sample peak estimate (4x windowed-sinc interpolation, 32 taps/phase): level between sample i and i+1
const TPH = [0.25, 0.5, 0.75].map((f) => Float64Array.from({ length: 32 }, (_, k) => { const x = k - 15 - f; return (Math.sin(Math.PI * x) / (Math.PI * x)) * (0.5 + 0.5 * Math.cos((Math.PI * x) / 16.5)); }));
function ispLevel(L, R) {
  const d = new Float32Array(N), [h0, h1, h2] = TPH;
  for (let c = 0; c < 2; c++) {
    const X = c ? R : L;
    for (let i = 15; i < N - 17; i++) {
      let s0 = 0, s1 = 0, s2 = 0;
      for (let k = 0; k < 32; k++) { const x = X[i + k - 15]; s0 += x * h0[k]; s1 += x * h1[k]; s2 += x * h2[k]; }
      const m = Math.max(Math.abs(s0), Math.abs(s1), Math.abs(s2));
      if (m > d[i]) d[i] = m;
    }
  }
  return d;
}
// look-ahead brickwall: forward-min gain (look-ahead window) -> exponential release -> backward box average (never exceeds ceiling)
function limit(L, R, ceil, { look = 0.003, rel = 0.08, tp = false } = {}) {
  const W = Math.max(1, S(look)), req = new Float32Array(N), m = new Float32Array(N), dq = new Int32Array(N), isp = tp ? ispLevel(L, R) : null;
  let minG = 1;
  for (let i = 0; i < N; i++) {
    let p = Math.max(Math.abs(L[i]), Math.abs(R[i]));
    if (isp) p = Math.max(p, isp[i], i ? isp[i - 1] : 0);
    req[i] = p > ceil ? ceil / p : 1;
  }
  let h = 0, t = 0;
  for (let i = N - 1; i >= 0; i--) {
    while (t > h && req[dq[t - 1]] >= req[i]) t--;
    dq[t++] = i;
    while (dq[h] > i + W - 1) h++;
    m[i] = req[dq[h]];
  }
  const aR = Math.exp(-1 / (rel * SR));
  let gp = 1;
  for (let i = 0; i < N; i++) { gp = Math.min(m[i], 1 - (1 - gp) * aR); m[i] = gp; }
  let acc = 0;
  for (let i = 0; i < N; i++) {
    acc += m[i]; if (i >= W) acc -= m[i - W];
    const g = Math.min(1, acc / Math.min(i + 1, W));
    L[i] *= g; R[i] *= g; if (g < minG) minG = g;
  }
  return minG;
}
const softclip = (x, c) => { // linear below 0.55c, tanh knee towards 1.15c
  const a = 0.55 * c, b = 1.15 * c - a, ax = Math.abs(x);
  return ax <= a ? x : Math.sign(x) * (a + b * Math.tanh((ax - a) / b));
};
function kweight(x) { // ITU-R BS.1770 K-weighting @ 48 kHz
  const y = new Float64Array(x.length);
  let a1 = 0, a2 = 0, b1 = 0, b2 = 0, c1 = 0, c2 = 0, d1 = 0, d2 = 0;
  for (let i = 0; i < x.length; i++) {
    const u = 1.53512485958697 * x[i] - 2.69169618940638 * a1 + 1.19839281085285 * a2 + 1.69065929318241 * b1 - 0.73248077421585 * b2;
    a2 = a1; a1 = x[i]; b2 = b1; b1 = u;
    const v = u - 2 * c1 + c2 + 1.99004745483398 * d1 - 0.99007225036621 * d2;
    c2 = c1; c1 = u; d2 = d1; d1 = v;
    y[i] = v;
  }
  return y;
}
function lufs(L, R) { // integrated loudness, 400 ms blocks / 100 ms hop, -70 LUFS absolute + -10 LU relative gate
  const kl = kweight(L), kr = kweight(R), B = S(0.4), H = S(0.1), z = [], ld = (p) => -0.691 + 10 * Math.log10(p);
  for (let s = 0; s + B <= L.length; s += H) { let a = 0; for (let i = s; i < s + B; i++) a += kl[i] * kl[i] + kr[i] * kr[i]; z.push(a / B); }
  let g = z.filter((p) => p > 0 && ld(p) > -70);
  const gate = ld(g.reduce((a, b) => a + b, 0) / g.length) - 10;
  g = g.filter((p) => ld(p) > gate);
  return ld(g.reduce((a, b) => a + b, 0) / g.length);
}

// ---- music bus: kick pump on synths / 808, SFX sidechain ducking, glue compression
const duckE = dipEnv(duckEv);
const pumpS = dipEnv(kickTimes.map((t) => [t, -3.5, 0.08, 0.002, 0.012]));
const pumpB = dipEnv(kickTimes.map((t) => [t, -6, 0.045, 0.002, 0.01]));
const music = mkBus();
for (let i = 0; i < N; i++) {
  const d = duckE[i], eb = d + pumpB[i], es = d + pumpS[i];
  const gd = d ? db(d * 0.5) : 1, gb = eb ? db(eb) : 1, gs = es ? db(es) : 1;
  music.L[i] = BUS.drum.L[i] * gd + BUS.bass.L[i] * gb + BUS.syn.L[i] * gs;
  music.R[i] = BUS.drum.R[i] * gd + BUS.bass.R[i] * gb + BUS.syn.R[i] * gs;
}
const GLUE = glue(music);
// ---- reverb return (level-matched to the send bus, band-limited)
const RV = filt(freeverb(BUS.verb.L, BUS.verb.R, { room: 0.83, damp: 0.32, width: 1, predelay: 0.018 }), () => new BQ('hp', 180, 0.7), () => new BQ('lp', 9000, 0.7));
const rmsOf = (v) => { let s = 0; for (const x of chans(v)) for (let i = 0; i < x.length; i++) s += x[i] * x[i]; return Math.sqrt(s / (chans(v).length * chans(v)[0].length)); };
const WET = (0.9 * rmsOf(BUS.verb)) / (rmsOf(RV) || 1);
const body = mkBus();
for (let i = 0; i < N; i++) {
  body.L[i] = music.L[i] + BUS.sfx.L[i] + RV.L[i] * WET;
  body.R[i] = music.R[i] + BUS.sfx.R[i] + RV.R[i] * WET;
}
filt(body, () => new BQ('ls', 55, 0.7, -3)); // tame the sub under the groove (phones can't use it; frees headroom for mids)
// ---- big-hit bus: saturated for density, fixed absolute scale (mega impact peaks right at the output ceiling)
const HITSAT = 1.6, HS = 0.97, hitB = mkBus();
for (let i = 0; i < N; i++) {
  hitB.L[i] = (HS * Math.tanh(HITSAT * BUS.hit.L[i])) / Math.tanh(HITSAT);
  hitB.R[i] = (HS * Math.tanh(HITSAT * BUS.hit.R[i])) / Math.tanh(HITSAT);
}
const C_BODY = db(-3.5), C_OUT = db(-1.08), SIL0 = S(21.4), SIL1 = S(21.6), SILF = S(21.395), END0 = S(28.55), END1 = S(29.3);
function render(g) {
  const L = new Float32Array(N), R = new Float32Array(N);
  for (let i = 0; i < N; i++) { L[i] = softclip(body.L[i] * g, C_BODY); R[i] = softclip(body.R[i] * g, C_BODY); }
  const grBody = limit(L, R, C_BODY, { look: 0.003, rel: 0.09 });
  for (let i = 0; i < N; i++) { L[i] += hitB.L[i]; R[i] += hitB.R[i]; }
  filt({ L, R }, () => new BQ('hp', 20, 0.707)); // DC / infrasonic cleanup
  const grOut = limit(L, R, C_OUT, { look: 0.002, rel: 0.06, tp: true });
  for (let i = SILF; i < SIL0; i++) { const w = 0.5 + 0.5 * Math.cos((Math.PI * (i - SILF)) / (SIL0 - SILF)); L[i] *= w; R[i] *= w; }
  for (let i = SIL0; i < SIL1; i++) L[i] = R[i] = 0; // TRUE digital silence 21.40-21.60
  for (let i = END0; i < N; i++) { const w = i >= END1 ? 0 : Math.pow(0.5 + 0.5 * Math.cos((Math.PI * (i - END0)) / (END1 - END0)), 1.3); L[i] *= w; R[i] *= w; }
  return { L, R, grBody, grOut };
}
// ---- loudness loop: body gain -> about -14 LUFS integrated (secant steps; limiting makes the curve sub-linear)
let gdb = 0, prev = null, OUT_BUF = null, LOUD = 0;
for (let it = 0; it < 7; it++) {
  OUT_BUF = render(db(gdb)); LOUD = lufs(OUT_BUF.L, OUT_BUF.R);
  if (Math.abs(LOUD + 14) < 0.05) break;
  const slope = prev ? clamp((LOUD - prev.L) / (gdb - prev.g || 1e-9), 0.15, 1.2) : 1;
  prev = { g: gdb, L: LOUD };
  gdb += clamp((-14 - LOUD) / slope, -18, 18);
}

// ---- write 16-bit PCM WAV
const q16 = (x) => Math.max(-32768, Math.min(32767, Math.round(x * 32767)));
function writeWav(file, L, R) {
  const buf = Buffer.alloc(44 + N * 4);
  buf.write('RIFF', 0, 'ascii'); buf.writeUInt32LE(36 + N * 4, 4); buf.write('WAVE', 8, 'ascii'); buf.write('fmt ', 12, 'ascii');
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22); buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36, 'ascii'); buf.writeUInt32LE(N * 4, 40);
  for (let i = 0; i < N; i++) { buf.writeInt16LE(q16(L[i]), 44 + i * 4); buf.writeInt16LE(q16(R[i]), 46 + i * 4); }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, buf);
  return buf.length;
}
const HERE = path.dirname(fileURLToPath(import.meta.url)), ROOT = path.resolve(HERE, '..', '..');
const OUT = process.argv[2] ? path.resolve(process.argv[2]) : path.join(ROOT, 'video', 'assets', 'audio', 'bh-score.wav');
const bytes = writeWav(OUT, OUT_BUF.L, OUT_BUF.R);
{
  let pk = 0, sil = 0;
  for (let i = 0; i < N; i++) pk = Math.max(pk, Math.abs(OUT_BUF.L[i]), Math.abs(OUT_BUF.R[i]));
  for (let i = SIL0; i < SIL1; i++) if (q16(OUT_BUF.L[i]) || q16(OUT_BUF.R[i])) sil++;
  const secs = Number(process.hrtime.bigint() - T_BEGIN) / 1e9;
  console.log(`bh-score: ${OUT} (${bytes} bytes, ${N} frames)`);
  console.log(`  loudness ${LOUD.toFixed(2)} LUFS | peak ${(20 * Math.log10(pk)).toFixed(2)} dBFS | body gain ${gdb.toFixed(2)} dB | body GR ${(-20 * Math.log10(OUT_BUF.grBody)).toFixed(1)} dB | out GR ${(-20 * Math.log10(OUT_BUF.grOut)).toFixed(1)} dB`);
  console.log(`  glue thr ${GLUE.thr.toFixed(1)} dB, max GR ${GLUE.grMax.toFixed(1)} dB | reverb wet x${WET.toFixed(2)} | nonzero samples in 21.40-21.60: ${sil} | ${secs.toFixed(1)} s`);
  if (process.env.BH_STATS) for (const k of ['drum', 'bass', 'syn', 'sfx', 'hit']) console.log(`  bus ${k}: ${lufs(BUS[k].L, BUS[k].R).toFixed(1)} LUFS, peak ${(20 * Math.log10(peakOf(BUS[k]))).toFixed(1)} dBFS`);
}
