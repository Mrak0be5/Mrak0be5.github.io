#!/usr/bin/env python3
"""Zoomed crop of a reference image (hub has no PIL): crop.py <img> x y w h [--out name] [--width 1000]
Coordinates are in source pixels. Output: reels/butcher-hero/.cache/crops/<name>.png"""
import argparse, base64, functools, http.server, json, os, pathlib, shutil, socketserver, sys, threading

ROOT = pathlib.Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, '/mnt/claude-data/krivsunov-bluegin2/multicode-test/chest-treasury/tools')
from cdp import Chrome  # noqa: E402


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('img')
    ap.add_argument('x', type=float); ap.add_argument('y', type=float)
    ap.add_argument('w', type=float); ap.add_argument('h', type=float)
    ap.add_argument('--out')
    ap.add_argument('--width', type=int, default=1000)
    a = ap.parse_args()
    img = pathlib.Path(a.img).resolve()
    rel = img.relative_to(ROOT).as_posix()
    srv = socketserver.ThreadingTCPServer(('127.0.0.1', 0), functools.partial(Quiet, directory=str(ROOT)))
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    ow = a.width
    oh = round(ow * a.h / a.w)
    prof = f'bh-crop-{os.getpid()}'   # private throwaway profile: parallel crops never share a lock
    c = Chrome(1200, 1200, prof)
    try:
        c.goto(f'http://127.0.0.1:{port}/')
        c.wait('document.readyState === "complete"')
        js = f'''(async () => {{
          const im = new Image(); im.src = {json.dumps('/' + rel)};
          await im.decode();
          const cv = document.createElement('canvas'); cv.width = {ow}; cv.height = {oh};
          const g = cv.getContext('2d'); g.imageSmoothingQuality = 'high';
          g.drawImage(im, {a.x}, {a.y}, {a.w}, {a.h}, 0, 0, {ow}, {oh});
          return cv.toDataURL('image/png');
        }})()'''
        url = c.eval(js)
        out = ROOT / '.cache' / 'crops' / f'{a.out or img.stem}.png'
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(url.split(',', 1)[1]))
        print(out)
    finally:
        c.close()
        srv.shutdown()
        shutil.rmtree(f'/mnt/claude-data/krivsunov-bluegin2/multicode-test/chest-treasury/.cache/{prof}', ignore_errors=True)


if __name__ == '__main__':
    main()
