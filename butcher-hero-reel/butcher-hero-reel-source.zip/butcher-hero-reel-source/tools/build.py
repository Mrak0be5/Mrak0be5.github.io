#!/usr/bin/env python3
"""Inline the shared libs (src/lib/*.js) into each scene (src/scenes/<id>.html) -> compositions/<id>.html.

Usage: build.py [scene-id ...] [--src DIR] [--out DIR]
The scene source carries a `<!-- @LIBS -->` marker inside its <template>; it is replaced by one
<script> holding every lib in LIBS order. Scene-specific libs are appended with `<!-- @LIBS +gear +golem -->`
(src/lib/gear.js, src/lib/golem.js). Every lib is guarded on its own window.BH flag, so the copies
that end up in the mounted document run only once.
"""
import argparse, base64, pathlib, re, sys

VIDEO = pathlib.Path(__file__).resolve().parent.parent
LIBS = ['fonts', 'core', 'fx', 'text', 'world', 'chars']
FONTS = {
    '__LONDRINA_900__': 'londrina-solid-latin-900.woff2',
    '__LONDRINA_400__': 'londrina-solid-latin-400.woff2',
}
MARK = re.compile(r'<!-- @LIBS((?: \+[a-z0-9-]+)*) -->')


def bundle(extra=()):
    parts = []
    for name in LIBS + [e for e in extra if e not in LIBS]:
        p = VIDEO / 'src' / 'lib' / f'{name}.js'
        if not p.exists():
            if name in extra:
                sys.exit(f'lib/{name}.js not found')
            continue
        s = p.read_text(encoding='utf-8')
        if name == 'fonts':
            for key, fn in FONTS.items():
                s = s.replace(key, base64.b64encode((VIDEO / 'assets' / 'fonts' / fn).read_bytes()).decode())
        if '</script' in s:
            sys.exit(f'lib/{name}.js contains "</script" - would break inlining')
        parts.append(f'/* ---- lib/{name}.js ---- */\n{s}')
    return '<script>\n' + '\n'.join(parts) + '\n</script>'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('ids', nargs='*')
    ap.add_argument('--src', default=str(VIDEO / 'src' / 'scenes'))
    ap.add_argument('--out', default=str(VIDEO / 'compositions'))
    a = ap.parse_args()
    src, out = pathlib.Path(a.src), pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    files = sorted(src.glob('*.html'))
    if a.ids:
        files = [f for f in files if f.stem in a.ids or any(f.stem.startswith(i) for i in a.ids)]
    if not files:
        sys.exit('no scenes matched')
    for f in files:
        s = f.read_text(encoding='utf-8')
        marks = MARK.findall(s)
        if len(marks) != 1:
            sys.exit(f'{f.name}: expected exactly one <!-- @LIBS --> marker')
        libs = bundle(marks[0].replace('+', ' ').split())
        dst = out / f.name
        tmp = dst.with_suffix('.tmp')
        tmp.write_text(MARK.sub(lambda m: libs, s), encoding='utf-8')
        tmp.replace(dst)
        print(f'{dst.relative_to(VIDEO.parent) if dst.is_relative_to(VIDEO.parent) else dst}  {dst.stat().st_size // 1024} KB')


if __name__ == '__main__':
    main()
