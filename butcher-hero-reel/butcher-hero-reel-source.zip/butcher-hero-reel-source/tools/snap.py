#!/usr/bin/env python3
"""Hub-side preview: build scenes, mount them in tools/harness.html (headless Chrome), dump frames/sheets.

Usage:
  snap.py 01 --at 0,0.4,1.2         full-res PNGs  -> .cache/snap/<id>/<t>.png
  snap.py 01 --sheet 0:2.4:0.2      contact sheet  -> .cache/snap/<id>/sheet.jpg
  snap.py 01 --bench                ms per frame over the whole scene
  --no-build skips build.py
"""
import argparse, base64, functools, http.server, json, pathlib, socketserver, subprocess, sys, threading

VIDEO = pathlib.Path(__file__).resolve().parent.parent
OUT = VIDEO.parent / '.cache' / 'snap'
sys.path.insert(0, '/mnt/claude-data/krivsunov-bluegin2/multicode-test/chest-treasury/tools')
from cdp import Chrome  # noqa: E402

DUR = {'01': 2.4, '02': 3.2, '03': 3.2, '04': 3.2, '05': 3.2, '06': 3.2, '07': 1.6, '08': 1.85, '09': 3.2, '10': 1.6, '11': 3.2}


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a):
        pass


def serve():
    h = functools.partial(Quiet, directory=str(VIDEO))
    srv = socketserver.ThreadingTCPServer(('127.0.0.1', 0), h)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv.server_address[1]


def save(data_url, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(base64.b64decode(data_url.split(',', 1)[1]))
    return path


def rng(spec, dur):
    a, b, s = (spec.split(':') + [None, None])[:3]
    a = float(a); b = float(b) if b else dur; s = float(s) if s else 0.2
    out, t = [], a
    while t <= b + 1e-6:
        out.append(round(t, 4)); t += s
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('ids', nargs='+')
    ap.add_argument('--at')
    ap.add_argument('--sheet')
    ap.add_argument('--cols', type=int, default=6)
    ap.add_argument('--scale', type=float, default=0.25)
    ap.add_argument('--bench', action='store_true')
    ap.add_argument('--no-build', action='store_true')
    a = ap.parse_args()
    names = []
    for i in a.ids:
        m = sorted(p.stem for p in (VIDEO / 'src' / 'scenes').glob(f'{i}*.html'))
        if not m:
            sys.exit(f'no scene {i}')
        names.append(m[0])
    if not a.no_build:
        subprocess.run([sys.executable, str(VIDEO / 'tools' / 'build.py')] + names, check=True, stdout=subprocess.DEVNULL)
    port = serve()
    c = Chrome(1080, 1920, 'bh-snap-' + names[0][:2])   # one profile per scene: parallel snaps don't share a lock
    try:
        c.goto(f'http://127.0.0.1:{port}/tools/harness.html')
        c.wait('!!(window.H && window.gsap)')
        for n in names:
            key = n[:2]
            c.eval(f'H.load({json.dumps(n)})', timeout=120)
            if a.at:
                for t in [float(x) for x in a.at.split(',')]:
                    p = save(c.eval(f'H.grab({json.dumps(n)}, {t})'), OUT / n / f'{t:05.2f}.png')
                    print(p)
            if a.sheet:
                ts = rng(a.sheet, DUR.get(key, 3.2))
                p = save(c.eval(f'H.sheet({json.dumps(n)}, {json.dumps(ts)}, {a.cols}, {a.scale})'), OUT / n / 'sheet.jpg')
                ms = c.eval('H.lastMs')
                print(p, 'ms/frame max %.0f avg %.0f' % (max(ms), sum(ms) / len(ms)))
            if a.bench:
                print(n, 'bench', c.eval(f'H.bench({json.dumps(n)}, {DUR.get(key, 3.2)})', timeout=600))
        for line in c.console:
            print('console:', line[:400])
    finally:
        c.close()


if __name__ == '__main__':
    main()
