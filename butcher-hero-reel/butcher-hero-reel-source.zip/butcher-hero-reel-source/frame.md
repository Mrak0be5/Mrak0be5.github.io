---
version: 1
name: Butcher Hero — Frame (vertical promo reel, final EN)
description: >
  Code-drawn cartoon key art in motion. Chunky cel-shaded characters with thick dark outlines,
  a blood-red sky over dark teal-blue low-poly pines, glowing lava and weapon arcs, embers,
  red lightning and meaty impacts. Everything is painted in Canvas 2D by the scene's render(t);
  only words live in the DOM. Titles are Londrina Solid 900 caps in hard two-tone yellow with a
  near-black outline and a brown extrusion; small words are white with the same outline.
unit: the frame — 1080×1920 (9:16), 30 fps
principle: key art that moves · every hit lands on the grid · words punch, never float

colors:
  # sky (top → horizon)
  sky-hot: "#DB0C21"
  sky-red: "#971126"
  sky-wine: "#69031B"
  sky-plum: "#340221"
  sky-night: "#04071E"
  # forest / ground
  pine-far: "#102048"
  pine-near: "#03113A"
  ground: "#1E3849"
  ground-lit: "#2B4556"
  # butcher skin
  skin-light: "#EB9E5B"
  skin-mid: "#B86F47"
  skin-dark: "#A33B29"
  skin-line: "#842D2F"
  rim-cold: "#8989E5"
  # mask
  mask-light: "#ECD8AD"
  mask-mid: "#E2CE9A"
  mask-dark: "#CEB075"
  mask-shadow: "#A1845D"
  mask-mark: "#8D201C"
  mask-socket: "#0B0D0A"
  # hair / cloth / metal
  mohawk: "#2F7F6B"
  mohawk-dark: "#28515F"
  shorts: "#3A4A6B"
  chain: "#2B3350"
  chain-lit: "#6E7BA8"
  chain-line: "#030407"
  hook-lit: "#FFB47E"
  hook: "#B74322"
  hook-shade: "#5158BC"
  # fx
  blood: "#E02B38"
  hit-flash: "#CCBCBC"
  reward: "#46FF52"
  legendary: "#FFDF2B"
  bolt: "#FF1401"
  bolt-core: "#FFCB01"
  ember: "#F84504"
  lava: "#F51F00"
  lava-foam: "#FF6621"
  lava-glow: "#772300"
  golem-stone: "#4A3F6B"
  golem-stone-lit: "#6D5F99"
  golem-stone-dark: "#2A2244"
  # UI pills (text chips only)
  pill-orange: "#FFAE00"
  pill-green: "#4BE630"
  pill-pink: "#ED1355"
  # app icon
  icon-yellow: "#FDD205"
  icon-black: "#010000"
  icon-red: "#D60301"
  icon-red-hot: "#E60301"
  icon-red-deep: "#B30201"
  flame: "#F83302"
  flame-hot: "#EE8F03"
  # type
  title-top: "#FEE415"
  title-bottom: "#F2B305"
  word-white: "#FEFEFE"
  stroke: "#130300"
  extrude: "#47291C"
  # logo
  logo-ice: "#D2E8F8"
  logo-ice-stroke: "#E23A5C"
  logo-hero: "#FF83A9"
  # islands (scene 04)
  meadow-deep: "#31783B"
  meadow-lit: "#9EE761"
  road-deep: "#542812"
  road-lit: "#F1C363"
  tundra-deep: "#20A1D0"
  tundra-lit: "#F3FBFF"
  tundra-prop: "#D6F8FF"
  tundra-prop-shade: "#6E8FC2"
  candy-deep: "#41A569"
  candy-lit: "#C1F3FF"
  candy-river: "#FF86A3"
  ember-deep: "#1F1450"
  ember-lit: "#B994F1"
  ember-crystal: "#5CFFC4"
  graves-deep: "#361E53"
  graves-lit: "#EACBFF"
  graves-acid: "#54FF00"
  graves-lantern: "#90FF63"
  graves-candle: "#FFFF28"
  # weapons (scene 05)
  ice-axe: "#7FE3FF"
  green-axe: "#43F06A"
  gold-sword: "#FFD34A"
  crystal-purple: "#C23BFF"
  crystal-purple-dark: "#6A1CA8"

typography:
  slam:        { fontFamily: "Londrina Solid", weight: 900, px: "230–260", upper: true, tracking: "-0.03em", lineHeight: 0.9 }
  caption-big: { fontFamily: "Londrina Solid", weight: 900, px: "140–170", upper: true, tracking: "-0.03em", lineHeight: 0.92, rotate: "-4°" }
  caption-small: { fontFamily: "Londrina Solid", weight: 900, px: "70–80", upper: true, tracking: "-0.02em", color: "{colors.word-white}" }
  lvl-label:   { fontFamily: "Londrina Solid", weight: 900, px: "72–120", upper: true, color: "{colors.word-white}", rotate: "-5°" }
  quote:       { fontFamily: "Londrina Solid", weight: 400, px: "56–72", color: "{colors.word-white}" }
  chip:        { fontFamily: "Londrina Solid", weight: 900, px: "44–56", upper: true }

strokes:
  title: "outer stroke 0.09em {colors.stroke}, extrusion 0.06em {colors.extrude} straight down"
  word:  "outer stroke 0.1em {colors.stroke}"

spacing:
  safe-x: "60–900px"
  safe-y: "200–1500px"
  title-top-third: "y 230–640"

components:
  title-two-tone:
    fill: "{colors.title-top} above 52% of cap height, {colors.title-bottom} below — a hard split, never a gradient"
    stroke: "{strokes.title}"
    description: "Every yellow payoff word (CHEW., STRONGER, LANDS, WEAPONS, DEITY OF DESTRUCTION.)."
  title-white:
    fill: "{colors.word-white}"
    stroke: "{strokes.word}"
    description: "Set-up words (EAT AND GET, EXPLORE NEW, COLLECT EPIC, START AS A, END AS A)."
  lvl-label:
    fill: "{colors.word-white}"
    stroke: "{strokes.word}"
    description: "The only game-UI element allowed — Steam-screenshot style 'LVL N', tilted −5°."
  stat-chip:
    backgroundColor: "{colors.reward}"
    textColor: "{colors.stroke}"
    border: "6px solid {colors.stroke}"
    rounded: "9999px"
    description: "+DMG / +SPD / +ARMOR / +HP growth chips (scene 02)."
  cta-button:
    backgroundColor: "{colors.pill-green}"
    border: "10px solid {colors.stroke}"
    textColor: "{colors.word-white} with {strokes.word}"
    rounded: "56px"
    description: "PLAY FREE. Bottom lip in a darker green, glossy top band."
  store-chip:
    backgroundColor: "{colors.stroke}"
    textColor: "{colors.word-white}"
    rounded: "9999px"
    description: "Text-only store chips (App Store ★ 4.6, Google Play 1M+). No official badges."
  cel-shape:
    description: "Base fill, far-side shadow crescent, lit-edge highlight crescent, cold rim ({colors.rim-cold}), outline stroke behind the fill."
---

# Butcher Hero — Frame

## Overview

The reel is the game's key art brought to life. The world is dark and cold — night-blue ground,
teal-blue pines, a sky that burns from `sky-hot` red down to `sky-night` — and everything the
player cares about is hot: the orange butcher, lava, embers, red lightning, and the glowing arcs
of the weapons. The warm/cold split is the whole palette logic: warm means power, cold means
world.

Characters are chunky and readable at phone size: thick dark outlines, three-tone cel shading,
a cold rim light on the side away from the key light, and bold hand-placed details (X-stitched
scars, rivets, chain links). Motion is cartoon-physical — anticipation, overshoot, hit-stop,
camera shake — and every impact lands on the 150 BPM grid.

## The Frame

- 1080×1920, safe zone x 60–900, y 200–1500 (right edge and bottom band are UI in the feeds).
- Three depth layers per scene: world canvas (sky, set, characters, lightning) → DOM words →
  FX canvas (lens blood, flashes, embers in front, vignette, film grain).
- Titles live in the top third. The subject owns the middle and lower thirds.
- Glows are allowed and wanted on lava, eyes, embers, lightning and weapon arcs — additive,
  saturated, never milky.

## Composition Rules

1. One focal hit per beat. The eye goes: subject → impact → word.
2. Titles slam (scale down from ~2.4× with a 3-frame overshoot) and then hold still; the world
   keeps moving under them.
3. The two-tone yellow is a hard split, never a gradient. White set-up words come first, the
   yellow payoff word lands on the next beat.
4. Big hits get the full stack: 2–3 frames of hit-stop, `hit-flash`, a shockwave ring, debris,
   shake that decays in ~0.3 s.
5. The hook always takes a dead enemy: weapon hit first, then hook.
6. Dark backgrounds get radial light, never full-screen linear gradients (banding). Grain at
   6–8% hides what banding is left.

## Do's and Don'ts

Do:
- Keep outlines on everything solid — characters, weapons, props, islands, logo letters.
- Tint shadows cold (`rim-cold`, `hook-shade`) and lights warm.
- Show growth with a pulse (scale overshoot + green reward flash).

Don't:
- No fake game HUD except the white "LVL N" labels. No coins, no health bars, no joystick.
- No official store badges — text chips only.
- Never draw the face under the mask. Chewing reads through the chin, cheeks and jowls.
- Never name other games or characters; no other IP.
- The butcher is not shown in scene 06 and appears only as hammer and hook from below in 07.
