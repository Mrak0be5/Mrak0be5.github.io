@echo off
"%~dp0python\python.exe" "%~dp0app\run_leased.py" %*
