# -*- coding: utf-8 -*-
"""Клиент аренды GpuQ: with lease(...) as gpu: — карта и память забронированы, пока выполняется блок.

    from gpuq_client import lease
    with lease(owner="train", vram_mb=20000, ram_mb=40000) as gpu:
        os.environ["CUDA_VISIBLE_DEVICES"] = gpu.card      # UUID карты
        ...                                                # длинная работа; в цикле вызывайте gpu.check()

Адрес демона: переменная GPUQ_URL (по умолчанию http://127.0.0.1:8189). Подробности — РУКОВОДСТВО.md."""
import json
import os
import sys
import threading
import time
import uuid
import warnings
from contextlib import contextmanager
import urllib.error
import urllib.request



def _default_base():
    """Адрес демона: GPUQ_URL, иначе порт из %LOCALAPPDATA%\GpuQ\config.json, иначе 8189."""
    url = os.environ.get("GPUQ_URL")
    if url:
        return url.rstrip("/")
    try:
        with open(os.path.join(os.environ.get("LOCALAPPDATA", ""), "GpuQ", "config.json"), encoding="utf-8-sig") as f:
            port = json.load(f).get("port")
        if isinstance(port, int) and 1024 <= port <= 65535:
            return "http://127.0.0.1:%d" % port
    except (OSError, ValueError, AttributeError):
        pass
    return "http://127.0.0.1:8189"


BASE = _default_base()
_CLIENT_ID = uuid.uuid4().hex
RETRY_PAUSE = 5        # перезапуск демона занимает до ~20 с
RESTART_WAIT = 60      # столько ждём очередь при запросе аренды, дольше — прежняя ошибка


def metadata():
    """Один источник на запуск, с привязкой к чату при наличии окружения."""
    result = {"client_id": os.environ.get("GPUQ_CALL_ID") or _CLIENT_ID}
    for key in ("chat_id", "chat_title"):
        value = os.environ.get("GPUQ_" + key.upper())
        if value:
            result[key] = value
    return result


class LeaseLostError(RuntimeError):
    pass


class _Lease:
    def __init__(self, response, handback=None):
        self.token = response["token"]
        self.card = response["card"]
        self.name = response.get("name", self.card)
        self.error = None
        self.handback = handback

    def check(self):
        """Вызывать в цикле работы; contextmanager также проверяет аренду при выходе.
        Аренда потеряна, только если очередь прямо так ответила: пока процесс жив, она аренду не снимает
        (однажды ПК ушёл в подкачку, очередь молчала, и клиент остановил идущее обучение)."""
        if self.handback and os.path.exists(self.handback):
            return  # аренду вернул сам раннер: его работа идёт через очередь
        if self.error:
            raise LeaseLostError("Аренда GPU потеряна: %s" % self.error)


@contextmanager
def lease(owner=None, card=None, timeout=6 * 3600, poll=2, vram_mb=None, exclusive=False, handback=None, ram_mb=None):
    """Аренда карты через gpuq; внутри длительной работы вызывайте handle.check().
    Обычная аренда делит карту с другими, пока хватает видеопамяти (vram_mb, по умолчанию default_vram_mb из config.json);
    exclusive=True — карта целиком, для замеров FPS и бенчмарков.
    ram_mb — сколько оперативной памяти ПК возьмёт задача: аренда ждёт, пока её хватит (обучению ~60000).
    handback — путь файла-метки: если он есть, аренду уже вернул сам дочерний процесс (раннер ушёл в очередь),
    и её отсутствие на сервере — не потеря."""
    # since — когда начали ждать: очередь пишет ожидание аренды в журнал и отчёт.
    body = {"owner": owner or metadata().get("chat_title") or metadata()["client_id"], "ttl": 120,
            "pid": os.getpid(), "since": time.time()}
    if card:
        body["card"] = card
    if vram_mb:
        body["vram_mb"] = int(vram_mb)
    if exclusive:
        body["exclusive"] = True
    if ram_mb:
        body["ram_mb"] = int(ram_mb)
    deadline = time.monotonic() + timeout
    while True:
        started = time.monotonic()
        response = _lease_call(body, min(deadline, started + RESTART_WAIT))
        if not isinstance(response, dict) or response.get("error"):
            raise RuntimeError("Не удалось получить аренду GPU: %r" % response)
        if not response.get("waiting"):
            break
        if time.monotonic() >= deadline:
            raise TimeoutError("Истекло время ожидания аренды GPU")
        time.sleep(min(poll, max(0, deadline - time.monotonic())))
    if not response.get("token") or not str(response.get("card", "")).startswith("GPU-"):
        raise RuntimeError("Некорректный ответ аренды GPU: %r" % response)
    ttl = float(response.get("ttl", 120))
    handle = _Lease(response, handback)
    stop = threading.Event()

    def heartbeat():
        while not stop.wait(min(30, ttl / 3)):
            if handback and os.path.exists(handback):
                return  # отдана раннером — продлевать нечего
            try:
                reply = _lease_call({"token": handle.token, "ttl": 120}, time.monotonic() + 30, stop.wait)
            except Exception:
                continue  # очередь молчит (перезапуск, ПК в подкачке) — аренда за живым процессом, спросим снова
            if isinstance(reply, dict) and (reply.get("error") or reply.get("released")
                                            or reply.get("token") != handle.token or reply.get("card") != handle.card):
                if not stop.is_set() and not (handback and os.path.exists(handback)):
                    handle.error = "Сервер отклонил продление: %r" % reply
                return

    worker = threading.Thread(target=heartbeat, name="gpuq-lease", daemon=True)
    failed = False
    try:
        handle.check()
        worker.start()
        yield handle
        handle.check()
    except BaseException:
        failed = True
        raise
    finally:
        stop.set()
        if worker.ident is not None:
            worker.join()
        try:
            if handback and os.path.exists(handback):
                reply = {"released": True}  # уже вернул дочерний процесс
            else:
                reply = _lease_call({"token": handle.token, "release": True}, time.monotonic() + (0 if failed else 30))
            if not isinstance(reply, dict) or not reply.get("released"):
                raise RuntimeError("Сервер не подтвердил возврат аренды GPU: %r" % reply)
        except Exception as error:
            if not failed:
                raise
            warnings.warn("Не удалось вернуть аренду GPU: %s" % error)
        if not failed:
            # Продление могло завершиться ошибкой уже во время выхода из блока.
            handle.check()


def _lease_call(body, until, wait=None):
    """Запрос к /gpuq/lease. Пока очередь перезапускается (соединение отвергнуто или оборвано),
    повтор раз в RETRY_PAUSE с до until; ответ с HTTP-ошибкой и сигнал wait — сразу прежняя ошибка."""
    while True:
        try:
            return _api(BASE, "/gpuq/lease", body, timeout=10)
        except urllib.error.HTTPError:
            raise
        except OSError:
            if time.monotonic() + RETRY_PAUSE >= until:
                raise
            if wait is None:
                time.sleep(RETRY_PAUSE)
            elif wait(RETRY_PAUSE):
                raise


def _api(base, route, body=None, timeout=30):
    req = urllib.request.Request(
        base + route,
        data=None if body is None else json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    return json.loads(raw) if raw else None
