"""Штатная выгрузка моделей простаивающих ComfyUI, без управления процессами."""
import hashlib
import json
import time
import urllib.request

IDLE_SECONDS = 600
CHECK_SECONDS = 30
MIN_VRAM_MB = 4096
MAX_UTIL = 5
RETRY_SECONDS = 600
FAIL_SECONDS = 3600
VERIFY_SECONDS = 15
MIN_RELEASE_MB = 256


def busy_or_gone(error):
    """Сервер не ответил за 3 с (занят тяжёлым расчётом) или порт уже закрыт (сервер завершился) — не ошибка выгрузки."""
    reason = getattr(error, 'reason', error)
    return isinstance(reason, (TimeoutError, ConnectionRefusedError, ConnectionResetError)) or 'timed out' in str(error)


def may_free(state, now, idle, util, used_mb, shared=False):
    """shared — на карте есть и другие процессы: загрузку дают они (рядом считают, рабочий стол), а простой
    самого сервера и так виден по пустой /queue и неизменной /history 10 минут."""
    return (idle and (shared or util is not None and util < MAX_UTIL) and used_mb >= MIN_VRAM_MB
            and now - state.get('idle_since', now) >= IDLE_SECONDS
            and now >= state.get('retry_at', 0) and not state.get('unloaded', False))


class IdleMonitor:
    def __init__(self, manager):
        self.manager = manager
        self.states = {}
        self.checked = 0
        self.running = False

    @staticmethod
    def request(port, path, body=None):
        req = urllib.request.Request('http://127.0.0.1:%d%s' % (port, path),
                                     data=None if body is None else json.dumps(body).encode(),
                                     headers={'Content-Type': 'application/json'})
        with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=3) as r:
            raw = r.read()
        return json.loads(raw) if raw else {}

    def check(self):
        m = self.manager
        now = time.time()
        servers = {}
        cards = {c['uuid']: c for c in m._gpu_cache}
        for u, pids in m._observed.items():
            for pid in pids:
                info = (m._labels.get(pid) or (0, {}))[1]
                if info.get('engine') == 'ComfyUI' and info.get('port'):
                    servers[info['port']] = (u, pid)
        own = set()
        for b in list(m.backends):
            if not b.remote and b.ready and b.proc:
                servers[b.port] = (b.uuid, m._owned_servers.get(b.port, b.proc.pid))
                own.add(b.port)
        for port, (u, pid) in servers.items():
            c = cards.get(u)
            if not c:
                continue
            # Загрузка карты при соседях (чужие расчёты, приложения рабочего стола, наши задания) — не довод против выгрузки.
            shared = bool((m._observed.get(u) or set()) - {pid}) or any(
                b.uuid == u and not b.remote and b.port != port and m.inflight(b) for b in list(m.backends))
            if port not in self.states:
                self.states[port] = m.load_idle_state(port)
            state = self.states[port]
            if state.get('pid') != pid:
                state.clear()
                state['pid'] = pid
            if now < state.get('retry_at', 0):
                continue
            try:
                if now - state.get('last_seen', now) > CHECK_SECONDS * 3:
                    state['idle_since'] = now
                state.update(last_seen=now, card=m.card_name(u))
                queue = self.request(port, '/queue')
                if not isinstance(queue, dict) or not all(k in queue for k in ('queue_running', 'queue_pending')):
                    raise ValueError('неполный /queue')
                hist = self.request(port, '/history?max_items=1')
                if not isinstance(hist, dict):
                    raise ValueError('неполный /history')
                signature = hashlib.sha256(json.dumps(hist, sort_keys=True).encode()).hexdigest()
                # Пустая очередь сервера отдельно от загрузки карты: по ней очередь решает, нужен ли рядом запас 6 ГБ.
                state['queue_empty'] = not queue['queue_running'] and not queue['queue_pending']
                idle = state['queue_empty'] and (shared or c.get('util', 100) < MAX_UTIL)
                if not idle or state.get('history') != signature:
                    state['idle_since'] = now
                    state['unloaded'] = False
                state['history'] = signature
                state.setdefault('idle_since', now)
                stats = self.request(port, '/system_stats')
                devices = stats.get('devices') or []
                # torch_vram_total в ComfyUI — reserved данного процесса, не память всей карты.
                reserved = sum(float(d.get('torch_vram_total') or 0) for d in devices) / 1048576
                used = m._process_mb.get((u, pid))
                if used is None:
                    used = reserved
                state.update(used_mb=round(used), memory_source='process' if (u, pid) in m._process_mb else 'torch_reserved',
                             util=c.get('util'), reason='')
                if state.get('unloaded') and used >= MIN_VRAM_MB and used > state.get('after_mb', used) + MIN_RELEASE_MB:
                    state.update(unloaded=False, idle_since=now)
                if port in own:
                    # Свою модель очередь выгружает сама: через полчаса простоя или сразу, когда память нужна другим.
                    # Раньше её выгружали и здесь через 10 минут — следующий кадр снова грузил модель 20–30 с.
                    state['reason'] = 'Модель держит очередь gpuq: выгрузит сама после простоя или при нехватке памяти'
                    continue
                if not may_free(state, now, idle, c.get('util'), used, shared):
                    state['reason'] = (('Есть работа' if not state['queue_empty'] else 'Загрузка карты >=5%') if not idle else
                                       'Подтверждённая память процесса меньше 4096 МиБ' if used < MIN_VRAM_MB else
                                       'Модели уже выгружены' if state.get('unloaded') else 'Наблюдаем 10 минут простоя')
                    continue
                # Повторная проверка непосредственно перед /free: между запросами могли прислать работу.
                queue = self.request(port, '/queue')
                if 'queue_running' not in queue or 'queue_pending' not in queue:
                    raise ValueError('неполный /queue перед /free')
                if queue['queue_running'] or queue['queue_pending']:
                    state['idle_since'] = now
                    continue
                before_card = next((v for v in m.read_gpus() if v['uuid'] == u), None)
                if not before_card or (before_card.get('util', 100) >= MAX_UTIL and not shared):
                    state['idle_since'] = now
                    continue
                before = before_card['used']
                state['retry_at'] = now + RETRY_SECONDS
                self.request(port, '/free', {'unload_models': True, 'free_memory': True})
                released = 0
                # /free обрабатывается циклом ComfyUI; ожидание только в этом фоновом потоке.
                for _ in range(VERIFY_SECONDS):
                    time.sleep(1)
                    fresh = next((v for v in m.read_gpus() if v['uuid'] == u), None)
                    if fresh:
                        released = max(0, before - fresh['used'])
                    if released >= MIN_RELEASE_MB:
                        break
                if released < MIN_RELEASE_MB:
                    raise ValueError('/free принят, память карты не снизилась')
                state.update(unloaded=True, after_mb=max(0, used - released))
                state.update(reason='Модели выгружены', freed_mb=released)
                text = 'Освобождено %.1f ГБ на %s: ComfyUI :%d простаивал %d мин' % (
                    released / 1024, m.card_name(u), port, (now - state['idle_since']) // 60)
                m.resource_notice('free', text, m.card_name(u), port=port, freed_mb=released)
                for b in list(m.backends):
                    if not b.remote and b.port == port:
                        b.freed = True
            except (OSError, ValueError, TypeError, AttributeError) as e:
                if busy_or_gone(e):
                    # Занят или уже закрыт: проверим в следующий обход, без уведомления и часовой паузы.
                    state.update(idle_since=time.time(), queue_empty=False, reason='Сервер занят или закрыт: ' + str(e)[:100])
                    continue
                state.update(retry_at=time.time() + FAIL_SECONDS, idle_since=time.time(), reason=str(e)[:140],
                             queue_empty=False)
                m.resource_notice('free_error', 'ComfyUI :%d: %s; повтор не раньше чем через час' % (port, str(e)[:140]),
                                  m.card_name(u), port=port)
        m.save_idle_states(self.states)
        self.checked = time.time()
