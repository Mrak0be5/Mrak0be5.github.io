# -*- coding: utf-8 -*-
"""Состояние карт в терминале: python gpuq_status.py (или gpuq-status.cmd). Только чтение."""
import json
import sys
import urllib.request

from gpuq_client import BASE

for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8")
    except Exception:
        pass


def main():
    try:
        with urllib.request.urlopen(BASE + "/gpuq/dashboard?limit=5", timeout=10) as r:
            d = json.loads(r.read())
    except OSError as error:
        print("GpuQ не отвечает на %s: %s" % (BASE, error))
        return 1
    for w in d.get("workers", []):
        if w.get("kind") not in (None, "ПК"):
            continue
        used, total = w.get("used_mb"), w.get("total_mb")
        mem = "%.1f/%.0f ГБ" % (used / 1024, total / 1024) if used is not None and total else "—"
        temp = "%d °C" % w["temp"] if w.get("temp") is not None else "—"
        util = "%d %%" % w["util"] if w.get("util") is not None else "—"
        print("%-28s %6s %6s  %-14s %s — %s" % (w["name"][:28], temp, util, mem, w.get("state", ""), (w.get("reason") or "")[:90]))
    pc = d.get("pc") or {}
    if pc.get("ram_total_gb"):
        print("ПК: процессор %s %%, RAM свободно %.1f из %.0f ГБ" % (round(pc.get("cpu") or 0), pc.get("ram_free_gb", 0), pc["ram_total_gb"]))
    for a in d.get("alerts", [])[:5]:
        print("! " + a.get("message", ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
