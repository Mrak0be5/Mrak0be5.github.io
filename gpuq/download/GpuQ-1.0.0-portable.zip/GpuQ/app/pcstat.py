"""Состояние ПК для панели: процессор, память, commit, идущие Unity и Blender.

Только чтение, раз в 10 с из фонового потока очереди. Unity — без воркеров импорта (AssetImportWorker),
как считают ворота проектов; проект — по -projectPath."""
import ctypes
import os
import re
import shutil
import time
from pathlib import PureWindowsPath

try:
    import psutil
except ImportError:  # без psutil ряд «ПК» просто пустой
    psutil = None

UNITY_LIMIT = 4       # Unity стартует сразу, пока их меньше 4
HEAVY_LIMIT = 2       # остальное тяжёлое (Blender и т. п.) — не больше двух
GENERIC = {'unity', 'client', 'project', 'game', 'src', 'app'}


class _Perf(ctypes.Structure):
    _fields_ = [('cb', ctypes.c_ulong), ('CommitTotal', ctypes.c_size_t), ('CommitLimit', ctypes.c_size_t),
                ('CommitPeak', ctypes.c_size_t), ('PhysicalTotal', ctypes.c_size_t), ('PhysicalAvailable', ctypes.c_size_t),
                ('SystemCache', ctypes.c_size_t), ('KernelTotal', ctypes.c_size_t), ('KernelPaged', ctypes.c_size_t),
                ('KernelNonpaged', ctypes.c_size_t), ('PageSize', ctypes.c_size_t), ('HandleCount', ctypes.c_ulong),
                ('ProcessCount', ctypes.c_ulong), ('ThreadCount', ctypes.c_ulong)]


def memory():
    """(RAM свободно, RAM всего, commit свободно, commit предел) в ГБ через GetPerformanceInfo."""
    perf = _Perf()
    perf.cb = ctypes.sizeof(perf)
    if not ctypes.windll.psapi.GetPerformanceInfo(ctypes.byref(perf), perf.cb):
        raise OSError('GetPerformanceInfo')
    gb = perf.PageSize / 2 ** 30
    return (perf.PhysicalAvailable * gb, perf.PhysicalTotal * gb,
            (perf.CommitLimit - perf.CommitTotal) * gb, perf.CommitLimit * gb)


def commit_growth(ram_total, commit_limit):
    """На сколько ГБ commit ещё вырастет сам: файл подкачки «по выбору системы» (PagingFiles = ?:\\pagefile.sys)
    растёт до 3×RAM, пока на C: есть место ."""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management') as k:
            files = winreg.QueryValueEx(k, 'PagingFiles')[0]
        disk = shutil.disk_usage('C:\\').free / 2 ** 30
    except OSError:
        return 0.0
    if not any(f.strip().startswith('?:') for f in files):
        return 0.0
    return max(0.0, min(3 * ram_total - (commit_limit - ram_total), disk - 20))


def project(cmdline):
    """Имя проекта Unity по -projectPath; папка «unity» и т. п. — по папке выше."""
    text = ' '.join(cmdline)
    m = re.search(r'-projectpath\s+"?([^"]+?)"?(\s+-|$)', text, re.I)
    if not m:
        return ''
    path = PureWindowsPath(m.group(1).strip())
    return path.parent.name if path.name.lower() in GENERIC and path.parent.name else path.name


def sample():
    if psutil is None or os.name != 'nt':
        return {}
    unity, blender = [], []
    for p in psutil.process_iter(['name', 'pid', 'create_time']):
        name = (p.info.get('name') or '').lower()
        if name not in ('unity.exe', 'blender.exe'):
            continue
        try:
            cmd = p.cmdline()
        except (psutil.Error, OSError):
            continue
        if name == 'unity.exe':
            if any('assetimportworker' in a.lower() for a in cmd):
                continue
            unity.append({'pid': p.info['pid'], 'project': project(cmd) or 'Unity', 'batch': '-batchmode' in cmd,
                          'since': p.info.get('create_time')})
        else:
            blender.append({'pid': p.info['pid'], 'since': p.info.get('create_time')})
    ram_free, ram_total, commit_free, commit_limit = memory()
    return {'ts': time.time(), 'cpu': psutil.cpu_percent(interval=None), 'cores': psutil.cpu_count(),
            'ram_free_gb': round(ram_free, 1), 'ram_total_gb': round(ram_total, 1),
            'commit_free_gb': round(commit_free, 1), 'commit_limit_gb': round(commit_limit, 1),
            'commit_room_gb': round(commit_free + commit_growth(ram_total, commit_limit), 1),
            'unity': sorted(unity, key=lambda u: u['since'] or 0), 'blender': blender,
            'unity_limit': UNITY_LIMIT, 'heavy_limit': HEAVY_LIMIT}
