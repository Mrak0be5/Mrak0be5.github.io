"""Минутная история нагрузки: одна SQLite-транзакция на четыре устройства."""
from collections import defaultdict

INTERVAL = 60
RETENTION = 30 * 86400
ACTIVE = {'генерация', 'аренда', 'unity'}


def init(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS gpu_history(card TEXT, ts REAL, util REAL, used_mb INTEGER, '
                 'temp REAL, power REAL, state TEXT)')
    conn.execute('CREATE INDEX IF NOT EXISTS gpu_history_ts ON gpu_history(ts)')
    conn.execute('CREATE INDEX IF NOT EXISTS gpu_history_card_ts ON gpu_history(card,ts)')
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='index' AND name='gpu_history_minute'").fetchone():
        conn.execute('DELETE FROM gpu_history WHERE rowid NOT IN '
                     '(SELECT MAX(rowid) FROM gpu_history GROUP BY card,CAST(ts/60 AS INTEGER))')
        conn.execute('CREATE UNIQUE INDEX gpu_history_minute ON gpu_history(card,CAST(ts/60 AS INTEGER))')
    # частота SM и причины её снижения — видно, когда карта упирается в предел мощности или нагрев.
    have = {row[1] for row in conn.execute('PRAGMA table_info(gpu_history)')}
    for column, kind in (('sm_mhz', 'INTEGER'), ('reasons', 'TEXT')):
        if column not in have:
            conn.execute('ALTER TABLE gpu_history ADD COLUMN %s %s' % (column, kind))


def save(conn, points, now):
    def number(value):
        return value if isinstance(value, (int, float)) and not isinstance(value, bool) else None
    with conn:
        conn.executemany('INSERT OR REPLACE INTO gpu_history(card,ts,util,used_mb,temp,power,state,sm_mhz,reasons)'
                         ' VALUES(?,?,?,?,?,?,?,?,?)',
                         [(name, now, *(number(p.get(k)) for k in ('util','used_mb','temp','power')), p['state'],
                           number(p.get('sm_mhz')), p.get('reasons') if isinstance(p.get('reasons'), str) else None)
                          for name, p in points.items()])
        conn.execute('DELETE FROM gpu_history WHERE ts<?', (now - RETENTION,))


def read(conn, now, hours=24, card=None):
    hours = max(1 / 60, min(720, float(hours)))
    since = now - hours * 3600
    where, args = (' AND card=?', (card,)) if card else ('', ())
    rows = conn.execute('SELECT card,ts,util,used_mb,temp,power,state FROM gpu_history '
                        'WHERE ts>=? AND ts<=?' + where + ' ORDER BY card,ts', (since - INTERVAL, now) + args).fetchall()
    groups = defaultdict(list)
    for name, *p in rows:
        groups[name].append(dict(zip(('ts', 'util', 'used_mb', 'temp', 'power', 'state'), p)))
    cards = {}
    for name, points in groups.items():
        totals = dict(busy_seconds=0., idle_seconds=0., offline_seconds=0.)
        for i, p in enumerate(points):
            end = min(now, p['ts'] + INTERVAL, points[i + 1]['ts'] if i + 1 < len(points) else now)
            seconds = max(0, end - max(since, p['ts']))
            key = ('offline_seconds' if p['state'] == 'офлайн' else 'busy_seconds'
                   if (p['util'] or 0) >= 20 or p['state'] in ACTIVE else 'idle_seconds')
            totals[key] += seconds
        observed = sum(totals.values())
        summary = {k: round(v, 1) for k, v in totals.items()}
        summary.update({k + '_pct': round(100 * totals[k + '_seconds'] / observed, 1) if observed else None
                        for k in ('busy', 'idle', 'offline')})
        summary.update(observed_seconds=round(observed, 1), window_seconds=round(hours * 3600),
                       unknown_seconds=round(max(0, hours * 3600 - observed), 1))
        cards[name] = {'points': [p for p in points if p['ts'] >= since], 'summary': summary}
    return {'cards': cards, 'hours': hours, 'ts': now}
