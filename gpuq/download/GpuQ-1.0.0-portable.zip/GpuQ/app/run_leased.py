"""Запуск одной команды под арендой GPU: python run_leased.py -- python script.py."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gpuq_client import lease


if os.name == "nt":
    import ctypes
    from ctypes import wintypes
    import _winapi

    class _Limits(ctypes.Structure):
        _fields_ = [("ProcessTime", ctypes.c_int64), ("JobTime", ctypes.c_int64),
                    ("Flags", wintypes.DWORD), ("MinWorkingSet", ctypes.c_size_t),
                    ("MaxWorkingSet", ctypes.c_size_t), ("ActiveLimit", wintypes.DWORD),
                    ("Affinity", ctypes.c_size_t), ("Priority", wintypes.DWORD),
                    ("Scheduling", wintypes.DWORD)]

    class _ExtendedLimits(ctypes.Structure):
        _fields_ = [("Basic", _Limits), ("Io", ctypes.c_uint64 * 6),
                    ("ProcessMemory", ctypes.c_size_t), ("JobMemory", ctypes.c_size_t),
                    ("PeakProcessMemory", ctypes.c_size_t), ("PeakJobMemory", ctypes.c_size_t)]

    class _Accounting(ctypes.Structure):
        _fields_ = [("Times", ctypes.c_int64 * 4), ("PageFaults", wintypes.DWORD),
                    ("Total", wintypes.DWORD), ("Active", wintypes.DWORD),
                    ("Terminated", wintypes.DWORD)]

    _kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    for _name, _args, _result in (
        ("CreateJobObjectW", [ctypes.c_void_p, wintypes.LPCWSTR], wintypes.HANDLE),
        ("SetInformationJobObject", [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                     wintypes.DWORD], wintypes.BOOL),
        ("QueryInformationJobObject", [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                       wintypes.DWORD, ctypes.c_void_p], wintypes.BOOL),
        ("AssignProcessToJobObject", [wintypes.HANDLE, wintypes.HANDLE], wintypes.BOOL),
        ("TerminateJobObject", [wintypes.HANDLE, wintypes.UINT], wintypes.BOOL),
        ("ResumeThread", [wintypes.HANDLE], wintypes.DWORD),
        ("OpenProcess", [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
        ("IsProcessInJob", [wintypes.HANDLE, wintypes.HANDLE,
                            ctypes.POINTER(wintypes.BOOL)], wintypes.BOOL),
    ):
        _function = getattr(_kernel, _name)
        _function.argtypes, _function.restype = _args, _result

    def _checked(result):
        if not result:
            raise ctypes.WinError(ctypes.get_last_error())
        return result

    class _WindowsTree:
        def __init__(self, command, env):
            self.process = None
            self.job = _checked(_kernel.CreateJobObjectW(None, None))
            thread = None
            assigned = False
            inherited = []
            try:
                limits = _ExtendedLimits()
                limits.Basic.Flags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, без breakaway.
                _checked(_kernel.SetInformationJobObject(
                    self.job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
                commandline = command if isinstance(command, str) else subprocess.list2cmdline(command)
                # Ребёнок пишет в stdout/stderr обёртки (например, `> log 2>&1` раннера) и наследует
                # только эти handles; его код не выполняется до назначения в Job.
                startup = subprocess.STARTUPINFO()
                current = _winapi.GetCurrentProcess()
                for field, std in (("hStdInput", _winapi.STD_INPUT_HANDLE),
                                   ("hStdOutput", _winapi.STD_OUTPUT_HANDLE),
                                   ("hStdError", _winapi.STD_ERROR_HANDLE)):
                    try:
                        source = _winapi.GetStdHandle(std)
                        if source:
                            inherited.append(_winapi.DuplicateHandle(
                                current, source, current, 0, True, _winapi.DUPLICATE_SAME_ACCESS))
                            setattr(startup, field, inherited[-1])
                    except OSError:
                        pass  # Нет такого потока (pythonw): ребёнок получит пустой.
                if inherited:
                    startup.dwFlags |= subprocess.STARTF_USESTDHANDLES
                    startup.lpAttributeList = {"handle_list": list(inherited)}
                self.process, thread, _, _ = _winapi.CreateProcess(
                    None, commandline, None, None, bool(inherited),
                    subprocess.CREATE_NO_WINDOW | 0x4, env, None, startup)
                _checked(_kernel.AssignProcessToJobObject(self.job, self.process))
                assigned = True
                if _kernel.ResumeThread(thread) == 0xFFFFFFFF:
                    raise ctypes.WinError(ctypes.get_last_error())
            except BaseException:
                if self.process is not None and not assigned:
                    _winapi.TerminateProcess(self.process, 1)
                    _winapi.WaitForSingleObject(self.process, _winapi.INFINITE)
                self.close()
                raise
            finally:
                if thread is not None:
                    _winapi.CloseHandle(thread)
                for handle in inherited:
                    _winapi.CloseHandle(handle)

        def wait(self, timeout):
            if _winapi.WaitForSingleObject(self.process, int(timeout * 1000)) == _winapi.WAIT_TIMEOUT:
                raise subprocess.TimeoutExpired("leased process", timeout)
            return _winapi.GetExitCodeProcess(self.process)

        def close(self):
            processes = []
            try:
                if self.job is not None:
                    # При >=1 живом процессе новые потомки превысят лимит и не запустят код.
                    limits = _ExtendedLimits()
                    limits.Basic.Flags = 0x2000 | 0x8
                    limits.Basic.ActiveLimit = 1
                    _checked(_kernel.SetInformationJobObject(
                        self.job, 9, ctypes.byref(limits), ctypes.sizeof(limits)))
                    capacity = 16
                    while True:
                        class _ProcessList(ctypes.Structure):
                            _fields_ = [("Assigned", wintypes.DWORD), ("Count", wintypes.DWORD),
                                        ("Ids", ctypes.c_size_t * capacity)]
                        members = _ProcessList()
                        if _kernel.QueryInformationJobObject(
                                self.job, 3, ctypes.byref(members), ctypes.sizeof(members), None):
                            break
                        if ctypes.get_last_error() != 234:  # ERROR_MORE_DATA
                            raise ctypes.WinError(ctypes.get_last_error())
                        capacity = max(capacity * 2, members.Assigned)
                    for pid in members.Ids[:members.Count]:
                        process = _kernel.OpenProcess(0x100000 | 0x1000, False, pid)
                        if not process:
                            if ctypes.get_last_error() == 87:  # Уже вышел, handle больше нет.
                                continue
                            raise ctypes.WinError(ctypes.get_last_error())
                        try:
                            belongs = wintypes.BOOL()
                            _checked(_kernel.IsProcessInJob(process, self.job, ctypes.byref(belongs)))
                            if belongs.value:
                                processes.append(process)
                                process = None
                        finally:
                            if process is not None:
                                _winapi.CloseHandle(process)
                    _checked(_kernel.TerminateJobObject(self.job, 1))
                    # Закрытие Job само асинхронно: аренду возвращаем только после выхода всех.
                    info = _Accounting()
                    while True:
                        _checked(_kernel.QueryInformationJobObject(
                            self.job, 1, ctypes.byref(info), ctypes.sizeof(info), None))
                        if not info.Active:
                            break
                        time.sleep(0.01)
                    for process in processes:
                        _winapi.WaitForSingleObject(process, _winapi.INFINITE)
            finally:
                if self.job is not None:
                    _winapi.CloseHandle(self.job)
                    self.job = None
                if self.process is not None:
                    _winapi.CloseHandle(self.process)
                    self.process = None
                for process in processes:
                    _winapi.CloseHandle(process)


def run(command, owner=None, card=None, timeout=6 * 3600, vram_mb=None, exclusive=False, ram_mb=None):
    extra = {k: v for k, v in (("vram_mb", vram_mb), ("exclusive", exclusive), ("ram_mb", ram_mb)) if v}
    # Метка возврата: раннер, которому карта не нужна (кадры уходят в очередь), отдаёт аренду сам (launcher.handback).
    mark = os.path.join(os.environ.get("TEMP") or os.getcwd(), "gpuq-handback-%d.flag" % os.getpid())
    if os.path.exists(mark):
        os.remove(mark)
    try:
        return _run(command, owner, card, timeout, mark, extra)
    finally:
        if os.path.exists(mark):
            os.remove(mark)


def _run(command, owner, card, timeout, mark, extra):
    with lease(owner=owner, card=card, timeout=timeout, handback=mark, **extra) as handle:
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=handle.card, CUDA_DEVICE_ORDER="PCI_BUS_ID", GPUQ_LEASED="1")
        if getattr(handle, "token", None):  # раннер может вернуть аренду сам (launcher.handback)
            env.update(GPUQ_LEASE_TOKEN=handle.token, GPUQ_LEASE_HANDBACK=mark)
        handle.check()
        child = (_WindowsTree(command, env) if os.name == "nt" else
                 subprocess.Popen(command, env=env, creationflags=0))
        try:
            while True:
                handle.check()
                try:
                    return child.wait(timeout=0.25)
                except subprocess.TimeoutExpired:
                    pass
        finally:
            if os.name == "nt":
                child.close()
            elif child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Запустить команду на карте, арендованной у gpuq")
    parser.add_argument("--owner")
    parser.add_argument("--card", help="GPU-UUID или имя карты в gpuq")
    parser.add_argument("--timeout", type=float, default=6 * 3600, help="Ожидание карты, секунды")
    parser.add_argument("--vram-mb", type=int, help="Сколько видеопамяти нужно, МиБ; по умолчанию default_vram_mb из config.json")
    parser.add_argument("--exclusive", action="store_true", help="Вся карта целиком: замеры FPS, бенчмарки")
    parser.add_argument("--ram-mb", type=int, help="Сколько оперативной памяти ПК возьмёт задача, МиБ: ждать, пока хватит")
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command
    if command[:1] == ["--"]:
        command = command[1:]
    if not command:
        parser.error("Укажите команду после --")
    try:
        return run(command, args.owner, args.card, args.timeout, vram_mb=args.vram_mb, exclusive=args.exclusive,
                   ram_mb=args.ram_mb)
    except (RuntimeError, OSError, ValueError) as error:
        print("Ошибка запуска под арендой GPU: %s" % error, file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Запуск остановлен пользователем", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
