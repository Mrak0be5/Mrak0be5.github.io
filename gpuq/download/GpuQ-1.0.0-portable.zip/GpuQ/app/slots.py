"""Места на ПК для тяжёлых задач: Unity в приоритете.

Unity — до 4 сразу и всегда первым: пока Unity ждёт места, Blender и прочее тяжёлое новых мест не получают.
Тяжёлое без Unity — до 2. Unity нужно свободно 6 ГБ RAM и 8 ГБ commit (с ростом файла подкачки), тяжёлому — 10 ГБ RAM,
чтобы Unity осталось. Место держит процесс (PID и время его создания): процесс завершился — место свободно,
продлевать не нужно. Ждущие спрашивают раз в несколько секунд; кто не спрашивал 30 с — ушёл из очереди.
Unity и Blender, запущенные без места (чужие скрипты, редактор), тоже занимают место — их видно по процессам."""
import threading
import time
import uuid

try:
    import psutil
except ImportError:  # без psutil места не считаются: выдаём сразу
    psutil = None

UNITY_MAX, HEAVY_MAX = 4, 2
UNITY_RAM_GB, HEAVY_RAM_GB = 6, 10   # Unity нужно 6 ГБ свободной RAM; остальное оставляет Unity запас
UNITY_COMMIT_GB = 8                  # и 8 ГБ commit
SEEN_S = 30


def _ctime(pid):
    try:
        return psutil.Process(pid).create_time()
    except (psutil.Error, OSError, ValueError):
        return None


class Slots:
    def __init__(self, db, lock, pc, promised=lambda: 0):
        self.db, self.lock, self.pc = db, lock, pc      # pc() — последний замер pcstat.sample()
        self.promised = promised                         # МиБ RAM, которую аренды с ram_mb ещё возьмут (обучение)
        self.waiting = {}                                # (вид, pid) -> {'owner', 'since', 'seen', 'why'}
        self.mutex = threading.Lock()
        self._chains = {}                                # (pid, время создания) -> PID родителей процесса

    def _granted(self):
        with self.lock:
            return self.db().execute("SELECT token, kind, owner, pid, ctime, since, granted FROM slots").fetchall()

    def _sweep(self, now):
        """Места умерших держателей освобождаются; ждущие без нового запроса уходят."""
        dead = [r[0] for r in self._granted() if psutil and _ctime(r[3]) != r[4]]
        if dead:
            with self.lock:
                self.db().executemany("DELETE FROM slots WHERE token=?", [(t,) for t in dead])
                self.db().commit()
        for key in [k for k, v in self.waiting.items() if now - v['seen'] > SEEN_S]:
            del self.waiting[key]

    def _parents(self, proc):
        """PID родителей процесса из замера pcstat; цепочка не меняется — помним, пока процесс жив. None — процесса нет."""
        key = (proc['pid'], proc.get('since'))
        if key not in self._chains:
            if len(self._chains) > 512:
                self._chains.clear()
            try:
                self._chains[key] = {p.pid for p in psutil.Process(proc['pid']).parents()} if psutil else set()
            except (psutil.Error, OSError):
                return None
        return self._chains[key]

    def _unmanaged(self, field, holders):
        """Процессы Unity ('unity') или Blender ('blender') на ПК, не запущенные держателями мест (их место тоже занято)."""
        count = 0
        for u in (self.pc() or {}).get(field) or []:
            chain = self._parents(u)
            if chain is not None and not chain & holders:
                count += 1
        return count

    def _first(self, kind):
        queue = sorted((v['since'], k) for k, v in self.waiting.items() if k[0] == kind)
        return queue[0][1] if queue else None

    def _can(self, kind, key, rows):
        pc = self.pc() or {}
        fresh = pc.get('ts') and time.time() - pc['ts'] < 60
        ram_free = pc.get('ram_free_gb', 99) - (self.promised() / 1024 if fresh else 0)
        if kind == 'unity':
            mine = [r for r in rows if r[1] == 'unity']
            busy = len(mine) + self._unmanaged('unity', {r[3] for r in mine})
            if busy >= UNITY_MAX:
                return 'Unity на ПК %d из %d' % (busy, UNITY_MAX)
            if fresh and ram_free < UNITY_RAM_GB:
                return 'свободно RAM %.1f ГБ, Unity нужно %d' % (ram_free, UNITY_RAM_GB)
            if fresh and pc.get('commit_room_gb', 99) < UNITY_COMMIT_GB:
                return 'свободно commit %.1f ГБ, Unity нужно %d' % (pc['commit_room_gb'], UNITY_COMMIT_GB)
        else:
            waiting_unity = sum(1 for k in self.waiting if k[0] == 'unity')
            if waiting_unity:
                return 'Unity в приоритете: ждёт %d' % waiting_unity
            mine = [r for r in rows if r[1] == 'heavy']
            busy = len(mine) + self._unmanaged('blender', {r[3] for r in mine})
            if busy >= HEAVY_MAX:
                return 'тяжёлых задач %d из %d' % (busy, HEAVY_MAX)
            if fresh and ram_free < HEAVY_RAM_GB:
                return 'свободно RAM %.1f ГБ, нужно %d (запас для Unity)' % (ram_free, HEAVY_RAM_GB)
        first = self._first(kind)
        if first is not None and first != key:
            return 'очередь: впереди %s' % self.waiting[first]['owner']
        return ''

    def request(self, body):
        """{kind, owner, pid[, since]} -> {granted, token} | {waiting, why, position}; {token, release} -> {released}."""
        if body.get('release'):
            with self.lock:
                self.db().execute("DELETE FROM slots WHERE token=?", (str(body.get('token') or ''),))
                self.db().commit()
            return {'released': True}
        kind = body.get('kind')
        if kind not in ('unity', 'heavy'):
            return {'error': 'kind: unity или heavy'}
        pid = int(body.get('pid') or 0)
        owner = str(body.get('owner') or pid)[:80]
        now = time.time()
        with self.mutex:
            self._sweep(now)
            rows = self._granted()
            for r in rows:
                if r[1] == kind and r[3] == pid:
                    return {'granted': True, 'token': r[0]}
            ctime = _ctime(pid) if psutil else None
            if psutil and ctime is None:
                return {'error': 'процесс %d не найден' % pid}
            key = (kind, pid)
            entry = self.waiting.setdefault(key, {'owner': owner, 'since': float(body.get('since') or now)})
            entry['seen'] = now
            why = self._can(kind, key, rows)
            if why:
                entry['why'] = why
                order = sorted((v['since'], k) for k, v in self.waiting.items() if k[0] == kind)
                return {'waiting': True, 'why': why, 'position': [k for _, k in order].index(key) + 1}
            token = uuid.uuid4().hex
            with self.lock:
                self.db().execute("INSERT INTO slots(token, kind, owner, pid, ctime, since, granted) VALUES(?,?,?,?,?,?,?)",
                                  (token, kind, owner, pid, ctime, entry['since'], now))
                self.db().commit()
            del self.waiting[key]
            return {'granted': True, 'token': token}

    def view(self):
        """Для панели: кто держит места и кто ждёт."""
        rows = self._granted()
        held = [{'kind': r[1], 'owner': r[2], 'pid': r[3], 'since': r[5], 'granted': r[6]} for r in rows]
        holders = {r[3]: r[2] for r in rows}
        with self.mutex:
            waiting = [{'kind': k[0], 'owner': v['owner'], 'since': v['since'], 'why': v.get('why', '')}
                       for k, v in sorted(self.waiting.items(), key=lambda kv: (kv[0][0] != 'unity', kv[1]['since']))]
            bound = {}                                    # PID Unity -> чьё место он занимает
            for u in (self.pc() or {}).get('unity') or []:
                owner = next((holders[h] for h in self._parents(u) or () if h in holders), None)
                if owner:
                    bound[str(u['pid'])] = owner
        return {'held': held, 'waiting': waiting, 'bound': bound, 'unity_max': UNITY_MAX, 'heavy_max': HEAVY_MAX}
