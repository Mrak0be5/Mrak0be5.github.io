"""JSON-отчёт очереди; интервалы обрезаются границами окна наблюдения."""
from collections import defaultdict
import load_history


def _spread(values):
    """Сколько ждали: число, медиана, 90-й перцентиль, максимум и сколько дольше минуты, с."""
    values = sorted(values)
    if not values:
        return dict(count=0)
    pick = lambda p: round(values[min(len(values) - 1, int(len(values) * p))], 1)
    return dict(count=len(values), p50=pick(.5), p90=pick(.9), max=round(values[-1], 1),
                over_minute=sum(v > 60 for v in values))


def read(conn, now, days=7, card_names=None):
    days = max(1, min(30, int(days)))
    since = now - days * 86400
    card_names = card_names or {}
    history = load_history.read(conn, now, days * 24)
    devices = {}
    for card, item in history['cards'].items():
        s = item['summary']
        devices[card] = dict(busy_hours=round(s['busy_seconds'] / 3600, 4),
                             idle_hours=round(s['idle_seconds'] / 3600, 4),
                             offline_hours=round(s['offline_seconds'] / 3600, 4),
                             busy_pct=s['busy_pct'], observed_seconds=s['observed_seconds'])
    pools, chats, scripts = defaultdict(lambda: dict(jobs=0, gpu_seconds=0)), defaultdict(list), defaultdict(list)
    script_labels = {}
    def seconds(start, end):
        return max(0, min(end if end is not None else now, now) - max(start or now, since))
    def add(title, task, card, start, end):
        a, b = max(start or now, since), min(end if end is not None else now, now)
        if b <= a:
            return
        # Без известной карты интервалы разных исполнений нельзя безопасно объединить.
        card = card_names.get(card, card) if card else object()
        if title:
            chats[(title, card)].append((a, b))
        if task:
            label = task.split(' → ')[0].replace('\\', '/').rsplit('/', 1)[-1].strip()
            if label:
                key = (label[:-3] if label.lower().endswith('.py') else label).casefold()
                if key not in script_labels or label.lower().endswith('.py'):
                    script_labels[key] = label
                scripts[(key, card)].append((a, b))
    for pool, title, task, card, start, end, submitted in conn.execute(
            'SELECT pool,chat_title,task,card,start_ts,done_ts,submit_ts FROM jobs WHERE '
            '(done_ts IS NULL OR done_ts>=?) AND submit_ts<=?', (since, now)):
        duration = seconds(start, end)
        pools[pool]['jobs'] += int(submitted >= since)
        pools[pool]['gpu_seconds'] += duration
        add(title, task, card, start, end)
    for pool, title, task, card, start, end in conn.execute(
            'SELECT j.pool,j.chat_title,j.task,s.card,s.start_ts,s.end_ts FROM job_spans s '
            'JOIN jobs j ON j.id=s.job_id WHERE s.end_ts>=? AND s.start_ts<=?', (since, now)):
        duration = seconds(start, end)
        pools[pool]['gpu_seconds'] += duration
        add(title, task, card, start, end)
    bypass, unity, bypass_seconds = 0, 0, 0
    for title, task, via, card, start, end in conn.execute(
            'SELECT chat_title,task,via,card,start_ts,done_ts FROM foreign_jobs WHERE '
            '(done_ts IS NULL OR done_ts>=?) AND start_ts<=?', (since, now)):
        duration = seconds(start, end)
        unity += int(via == 'unity' and start >= since)
        is_bypass = via in (None, 'foreign')
        bypass += int(is_bypass and start >= since)
        bypass_seconds += duration if is_bypass else 0
        add(title, task, card, start, end)
    # Пересечения аренды и наблюдения того же раннера объединяются по физической карте.
    for owner, card, start, end in conn.execute('SELECT owner,card,start_ts,end_ts FROM lease_log WHERE '
                                         '(end_ts IS NULL OR end_ts>=?) AND start_ts<=?', (since, now)):
        add(None, owner, card, start, end)
    counts = dict(conn.execute("SELECT kind,COUNT(*) FROM resource_notices WHERE ts>=? AND ts<=? "
                               "AND kind IN ('model_hit','model_swap') GROUP BY kind", (since, now)))
    def top(values, key):
        totals = defaultdict(float)
        for (name, card), intervals in values.items():
            end = float('-inf')
            for a, b in sorted(intervals):
                totals[name] += max(0, b - max(a, end))
                end = max(end, b)
        return [{key: script_labels[name] if key == 'script' else name, 'gpu_seconds': round(duration, 1)}
                for name, duration in sorted(totals.items(), key=lambda item: (-item[1], item[0]))[:10]]
    # Ожидание: задание очереди — от постановки до первого старта (фон priority<0 ждёт по замыслу),
    # аренда — от первого запроса раннера до выдачи (у старых клиентов не известно).
    queue_waits = [min(start, first or start) - submitted for submitted, start, first in conn.execute(
        'SELECT submit_ts,start_ts,(SELECT MIN(s.start_ts) FROM job_spans s WHERE s.job_id=j.id) FROM jobs j '
        'WHERE start_ts>=? AND start_ts<=? AND prio_q>=0 AND submit_ts IS NOT NULL', (since, now))]
    lease_waits = conn.execute('SELECT owner,start_ts-req_ts FROM lease_log WHERE start_ts>=? AND start_ts<=? '
                               'AND req_ts IS NOT NULL', (since, now)).fetchall()
    by_owner = defaultdict(float)
    for owner, wait in lease_waits:
        by_owner[owner] += wait
    queued, oldest = conn.execute("SELECT COUNT(*),MIN(submit_ts) FROM jobs WHERE state='queued' AND prio_q>=0").fetchone()
    waits = dict(queue=_spread(queue_waits), lease=_spread([w for _owner, w in lease_waits]),
                 lease_top=[{'owner': o, 'wait_seconds': round(w, 1)}
                            for o, w in sorted(by_owner.items(), key=lambda item: -item[1])[:5] if w >= 1],
                 queued_now=dict(jobs=queued, oldest_seconds=round(now - oldest, 1) if oldest else 0))
    return dict(days=days, since=since, ts=now, devices=devices, waits=waits,
                observed_seconds=max((s['observed_seconds'] for s in devices.values()), default=0),
                pools={p: dict(jobs=s['jobs'], gpu_seconds=round(s['gpu_seconds'], 1)) for p,s in pools.items()},
                top_chats=top(chats, 'chat_title'), top_scripts=top(scripts, 'script'),
                bypass=dict(jobs=bypass, gpu_seconds=round(bypass_seconds, 1)), unity_runs=unity,
                model_hits=counts.get('model_hit', 0), model_swaps=counts.get('model_swap', 0))
