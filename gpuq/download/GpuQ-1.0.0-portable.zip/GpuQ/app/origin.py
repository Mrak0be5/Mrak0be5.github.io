"""API для gpuq: resolve(body, client_port, server_port), mappings()."""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import threading
import time

MAP_PATH = Path(__file__).with_name("origin-map.json")
CALL_RE = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\Z")
_lock = threading.RLock()
_map_cache = {}
_map_checked = 0.0
_pid_cache = {}


def mappings():
    """Копия call_id → {thread_id, title}; перечитывание не чаще раза в секунду."""
    global _map_cache, _map_checked
    with _lock:
        now = time.monotonic()
        if now - _map_checked >= 1:
            _map_checked = now
            try:
                data = json.loads(MAP_PATH.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    _map_cache = {k: {"thread_id": v["thread_id"], "title": v["title"]}
                                  for k, v in list(data.items())[-4096:]
                                  if isinstance(k, str) and isinstance(v, dict)
                                  and isinstance(v.get("thread_id"), str)
                                  and isinstance(v.get("title"), str)}
            except (OSError, ValueError):
                pass  # Синхронизация может временно убрать файл; сохраняем прошлую карту.
        return {k: dict(v) for k, v in _map_cache.items()}


def _tcp_owner(client_port, server_port):
    """PID клиентского конца установленного TCP-соединения (IPv4 и IPv6)."""
    if os.name != "nt":
        return None
    dword = wintypes.DWORD

    class Row4(ctypes.Structure):
        _fields_ = [(key, dword) for key in
                    ("state", "local_addr", "local_port", "remote_addr", "remote_port", "pid")]

    class Row6(ctypes.Structure):
        _fields_ = [("local_addr", ctypes.c_ubyte * 16), ("local_scope", dword),
                    ("local_port", dword), ("remote_addr", ctypes.c_ubyte * 16),
                    ("remote_scope", dword), ("remote_port", dword),
                    ("state", dword), ("pid", dword)]

    api = ctypes.WinDLL("iphlpapi", use_last_error=True).GetExtendedTcpTable
    api.argtypes = [ctypes.c_void_p, ctypes.POINTER(dword), wintypes.BOOL,
                    wintypes.ULONG, ctypes.c_int, wintypes.ULONG]
    api.restype = dword
    owners = set()
    for family, row_type in ((socket.AF_INET, Row4), (socket.AF_INET6, Row6)):
        size = dword(0)
        if api(None, ctypes.byref(size), False, family, 5, 0) not in (0, 122):
            continue
        for _ in range(3):
            buf = ctypes.create_string_buffer(size.value)
            result = api(buf, ctypes.byref(size), False, family, 5, 0)
            if result != 122:
                break
        if result:
            continue
        count = dword.from_buffer_copy(buf).value
        for index in range(count):
            row = row_type.from_buffer_copy(buf, ctypes.sizeof(dword) + index * ctypes.sizeof(row_type))
            if (row.state == 5 and socket.ntohs(row.local_port & 65535) == client_port
                    and socket.ntohs(row.remote_port & 65535) == server_port):
                owners.add(row.pid)
    # При совпадении портов у нескольких процессов ничего не предполагаем.
    return owners.pop() if len(owners) == 1 else None


def _process_stamp(pid):
    """Время создания защищает кэш от переиспользования PID."""
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    api.OpenProcess.restype = wintypes.HANDLE
    api.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
    api.GetProcessTimes.restype = wintypes.BOOL
    api.CloseHandle.argtypes = [wintypes.HANDLE]
    handle = api.OpenProcess(0x1000, False, pid)
    if not handle:
        return None
    try:
        times = [wintypes.FILETIME() for _ in range(4)]
        if api.GetProcessTimes(handle, *(ctypes.byref(t) for t in times)):
            return times[0].dwLowDateTime | times[0].dwHighDateTime << 32
    finally:
        api.CloseHandle(handle)
    return None


def _call_for_pid(pid):
    if os.name != "nt" or not isinstance(pid, int) or pid <= 0:
        return None
    stamp = _process_stamp(pid)
    if stamp is None:
        return None
    now = time.monotonic()
    with _lock:
        for key in list(_pid_cache):
            if now - _pid_cache[key][0] >= 60:
                del _pid_cache[key]
        if pid in _pid_cache and _pid_cache[pid][1] == stamp:
            return _pid_cache[pid][2]
    # PowerShell идёт без замка: mappings() в цикле очереди не ждёт его до 8 с.
    # На stdout только UUID. Полные командные строки остаются внутри CIM-запроса.
    script = r"""$ErrorActionPreference='Stop'; $p=PID_VALUE; $seen=@{};
while ($p -gt 0 -and !$seen.ContainsKey($p)) {
 $seen[$p]=$true;
 $r=Get-CimInstance Win32_Process -Filter ('ProcessId='+$p);
 if (!$r) { break };
 if ($r.Name -ieq 'cmd.exe' -and $r.CommandLine -match '(?i)\bGPUQ_CALL_ID=([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12})(?![\w-])') {
  [Console]::Write($Matches[1].ToLowerInvariant()); break
 };
 $p=[int]$r.ParentProcessId
}""".replace("PID_VALUE", str(pid))
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, encoding="ascii",
            errors="replace", timeout=8, creationflags=subprocess.CREATE_NO_WINDOW)
        call_id = result.stdout.strip().lower()
        if result.returncode or not CALL_RE.fullmatch(call_id):
            return None
    except (OSError, subprocess.SubprocessError):
        return None
    if _process_stamp(pid) != stamp:
        return None
    with _lock:
        if len(_pid_cache) >= 4096:
            _pid_cache.pop(next(iter(_pid_cache)))
        _pid_cache[pid] = (now, stamp, call_id)
    return call_id


def resolve(body, client_port=None, server_port=8189):
    """Возвращает (client_id, origin, chat_title), без сетевых запросов к T3."""
    body = body if isinstance(body, dict) else {}
    client = str(body.get("client_id") or "Источник не указан")[:200]
    explicit_id = str(body.get("chat_id") or "")[:200]
    explicit_title = str(body.get("chat_title") or "")[:200]
    call_id = client.lower() if CALL_RE.fullmatch(client) else None
    known = mappings()
    found = known.get(call_id)
    if not found and not (explicit_id and explicit_title) and client_port is not None:
        try:
            port, server = int(client_port), int(server_port)
            if 0 < port < 65536 and 0 < server < 65536:
                pid = _tcp_owner(port, server)
                detected = _call_for_pid(pid) if pid else None
                if detected:
                    call_id = detected
                    found = known.get(call_id)
                elif pid:
                    # Обычный Comfy-клиент тоже может прислать UUID как client_id.
                    call_id = None
        except (OSError, ValueError, TypeError):
            pass
    if call_id:
        client = call_id
    origin = explicit_id or (found["thread_id"] if found else call_id or client)
    title = explicit_title or (found["title"] if found else
                              "Чат " + call_id[:8] + " (сопоставление)" if call_id else
                              "Источник не указан")
    return client, origin, title
