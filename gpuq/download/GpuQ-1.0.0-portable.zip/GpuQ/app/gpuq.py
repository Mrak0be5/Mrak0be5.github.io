# -*- coding: utf-8 -*-
"""GpuQ — диспетчер видеокарт NVIDIA для Windows.

Задачи берут карту в аренду (видеопамять и оперативная память считаются заранее), поэтому две программы не
садятся на одну карту так, что драйвер уносит видеопамять в RAM и всё замедляется в 3–5 раз. Демон слушает
127.0.0.1:8189: аренды (/gpuq/lease), места для тяжёлых задач (/gpuq/slot), панель (/gpuq/ui/) и данные для неё.
Если указан каталог ComfyUI (config.json), тот же порт принимает задания в формате ComfyUI и раздаёт их по картам.

Запуск скрытый (pythonw). Состояние — SQLite и журналы в %LOCALAPPDATA%\\GpuQ. Настройки — config.json там же.
"""
import ctypes
import json
import mimetypes
import os
import re
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
import uuid
import hashlib
import shutil
from collections import defaultdict, deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlencode
import origin as chat_origin
from jobinfo import graph_summary, graph_meta, meta_text, describe_process, describe_foreign, chat_for, program_for
from telemetry import compute_pids, process_info
from idle import IdleMonitor, CHECK_SECONDS, MIN_VRAM_MB
import load_history
import report as queue_report
from preview import Live
import pcstat
import slots as pc_slots

STICKY_WAIT_S = 20

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # только чтение /queue чужих серверов
HERE = Path(__file__).resolve().parent
UI_DIR = HERE / 'ui'  # панель трея (WebView2): статика, данные — API ниже
UI_TYPES = {'.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8'}
UI_CSP = ("default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'self' 'unsafe-inline'; "
          "script-src 'self'; connect-src 'self'; frame-ancestors 'none'")

# --- расположение установок ComfyUI на этом ПК (переопределяется config.json) ---
KREA_PKG = ""   # каталог ComfyUI (где main.py); пусто — очередь ComfyUI выключена, остаются аренды и панель
KREA_PY = ""    # python.exe этого ComfyUI
KREA_OUT = ""   # куда ComfyUI складывает результаты
H3_COMFY = ""
H3_PY = ""

STATE_DIR = Path(os.environ.get("LOCALAPPDATA") or (HERE / "_state")) / "GpuQ"
DB_PATH = STATE_DIR / "gpuq.sqlite"
LOG_PATH = STATE_DIR / "gpuq.log"

TICK = 1.5            # период диспетчера, с
MAXDEPTH = 1          # свободный слот остаётся общей очереди, а не резервируется пачкой
DEPTH_SAME = 2        # кадр с той же моделью ждёт прямо в ComfyUI карты, которая вот-вот закончит: без паузы между кадрами
IDLE_FREE = 1800      # через столько секунд простоя выгружаем модели бэкенда (/free); раньше при нехватке памяти
JOB_TIMEOUT = 1800
START_TIMEOUT = 180   # ждём готовности нового бэкенда
MAX_ATTEMPTS = 2      # сколько раз переотправить задание после смерти бэкенда
FOREIGN_NEED_MB = 14000  # карта «свободна», если под задание осталось не меньше
FOREIGN_FREE_MB = 8000   # если nvidia-smi не дал объём памяти: занято не больше
FOREIGN_FREE_UTIL = 20
FREE_WINDOW = 60       # те же два замера с интервалом около минуты
MARGIN_MB = 2048         # запас памяти, когда карту делят задания
MARGIN_COMFY_MB = 6144   # рядом чужой ComfyUI: его пик при загрузке модели больше
BIG_LEASE_MB = 51200     # аренда от 50 ГБ (обучение): рядом с ней запас больше
BIG_MARGIN_MB = 8192     # обучение 64 ГБ + видео 29 ГБ на карте с 96 ГБ переполнили её: больше двух часов почти без шагов
STUCK_MB = 4096          # аренда держит столько памяти карты, а карта простаивает —
STUCK_UTIL = 5           # (загрузка не выше, %)
STUCK_S = 900            # дольше этого — уведомление: задача, похоже, зависла (однажды обучение провисело около 3 ч)
OVERFLOW_S = 300         # переполнение видеопамяти держится столько — уведомление
OVERFLOW_REPEAT_S = 1800 # о той же карте — не чаще
QUIET_FRESH = CHECK_SECONDS * 3  # сведения монитора простоя о чужом ComfyUI не старше, с
RAMP = 180               # столько секунд новая аренда или модель ещё набирают память
LOW_FREE_MB = 4096       # чужим заданиям осталось меньше — выгружаем свою простаивающую модель
LEASE_GPU_MB = 1024      # процессы аренды уже брали столько памяти карты: вернутся за всей заявкой
RAM_MARGIN_MB = 8192     # после аренды с ram_mb в RAM ПК остаётся столько: Unity (6 ГБ) и система
CONTEND_UTIL = 40        # загрузка карты без наших заданий: рядом считает чужая задача, %
CONTEND_HOLD = 30        # видео и обучение между стадиями ненадолго отпускают карту, с
WAIT_LOG_S = 300         # раз в столько секунд журнал объясняет, почему задания ждут
MEASURE_RE = re.compile(r'fps|bench|perf|profil|record|capture', re.I)  # замеры FPS, бенчмарки и запись экрана: карту целиком

# Имена карт для приоритета и проверки привязки (подстроки из nvidia-smi name).
CARD_PRIORITY = []   # подстроки названий карт по убыванию приоритета; задаётся в config.json (card_priority)
# Во сколько раз карта медленнее самой быстрой; нужно, пока своих замеров для карты нет.
CARD_SPEED = {}   # во сколько раз карта медленнее самой быстрой; задаётся в config.json (card_speed)
COLD_START = 60       # оценка запуска ComfyUI на свободной карте, с


def card_prio(name):
    for i, want in enumerate(CARD_PRIORITY):
        if want in name:
            return i
    return len(CARD_PRIORITY)


def card_label(name):
    tail = name[name.rfind(" #"):] if " #" in name else ""   # одинаковые карты различаем по номеру
    for want in CARD_PRIORITY:
        if want in name:
            return want + tail
    return re.sub(r"^NVIDIA\s+(GeForce\s+)?", "", name)


def _median(values):
    values = sorted(values)
    mid = len(values) // 2
    return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2


_CFG = {}


def _load_config():
    """Конфиг (env GPUQ_CONFIG или %LOCALAPPDATA%\\GpuQueue\\config.json) переопределяет пути и пулы.

    Ключи: KREA_PKG/KREA_PY/KREA_OUT/H3_COMFY/H3_PY — пути установок; state_dir или
    state_subdir — куда класть БД и журналы; pools — поэлементная правка POOLS()
    (facade_port, ports, python, entry, root, base_args, disabled и т.д.). Нужен для
    self-test на отдельных портах, не трогая боевые 8189/8190."""
    global STATE_DIR, DB_PATH, LOG_PATH, _CFG
    cfg = Path(os.environ.get("GPUQ_CONFIG") or (STATE_DIR / "config.json"))
    if cfg.is_file():
        try:
            _CFG = json.loads(cfg.read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            _CFG = {}
    g = globals()
    for key in ("KREA_PKG", "KREA_PY", "KREA_OUT", "H3_COMFY", "H3_PY"):
        if key in _CFG:
            g[key] = _CFG[key]
    for alias, key in (("comfy_root", "KREA_PKG"), ("comfy_python", "KREA_PY"), ("comfy_output", "KREA_OUT")):
        if _CFG.get(alias):
            g[key] = _CFG[alias]
    if g["KREA_PKG"] and not g["KREA_OUT"]:
        g["KREA_OUT"] = str(Path(g["KREA_PKG"]) / "output")
    if isinstance(_CFG.get("card_priority"), list):
        g["CARD_PRIORITY"] = [str(x) for x in _CFG["card_priority"]]
    if isinstance(_CFG.get("card_speed"), dict):
        g["CARD_SPEED"] = {str(k): float(v) for k, v in _CFG["card_speed"].items()}
    if isinstance(_CFG.get("default_vram_mb"), int) and _CFG["default_vram_mb"] >= 1024:
        g["FOREIGN_NEED_MB"] = _CFG["default_vram_mb"]
    if isinstance(_CFG.get("port"), int) and 1024 <= _CFG["port"] <= 65535:
        _CFG.setdefault("pools", {}).setdefault("krea", {})["facade_port"] = _CFG["port"]
    if os.environ.get("GPUQ_STATE_DIR") or _CFG.get("state_dir"):
        STATE_DIR = Path(os.environ.get("GPUQ_STATE_DIR") or _CFG["state_dir"])
    sub = os.environ.get("GPUQ_STATE_SUBDIR") or _CFG.get("state_subdir")
    if sub:
        STATE_DIR = STATE_DIR / sub
    DB_PATH = STATE_DIR / "gpuq.sqlite"
    LOG_PATH = STATE_DIR / "gpuq.log"


def _krea_args():
    """Аргументы ComfyUI очереди: каталоги и extra_model_paths.yaml добавляются, только если они заданы и существуют."""
    args = ["--disable-auto-launch", "--preview-method", "latent2rgb", "--reserve-vram", "0.5", "--use-pytorch-cross-attention"]
    if KREA_OUT:
        args += ["--output-directory", KREA_OUT]
    if KREA_PKG:
        args += ["--input-directory", str(Path(KREA_PKG) / "input")]
        extra = Path(KREA_PKG) / "extra_model_paths.yaml"
        if extra.is_file():
            args += ["--extra-model-paths-config", str(extra)]
    return args


def POOLS():
    pools = {
        "krea": {
            "facade_port": 8189,
            "python": KREA_PY,
            "entry": "boot",            # boot.py: даёт int8/cu130, как боевой 8189
            "root": KREA_PKG,
            "ports": [8181, 8182],      # до двух бэкендов — по одному на карту
            "warm": True,               # держим процессы тёплыми, только выгружаем модели
            "output_dir": KREA_OUT,
            "input_dir": str(Path(KREA_PKG) / "input"),
            "base_args": _krea_args(),
            "highvram_on_6000": False,  # рецепт Krea2 настроен без highvram
            "card_affinity": None,      # картинки берут любую (порядок 6000→4090);
                                        # уступают 6000 активному видеопулу — см. _card_order_key
        },
        "h3": {
            "facade_port": 8190,
            "python": H3_PY,
            "entry": "main",            # портативный ComfyUI: прямой main.py -s
            "root": H3_COMFY,
            "ports": [8183, 8184],
            "warm": False,              # видео редкое: освобождаем карту после простоя
            "output_dir": str(Path(H3_COMFY) / "output"),
            "input_dir": str(Path(H3_COMFY) / "input"),
            "base_args": [
                "--disable-auto-launch", "--disable-dynamic-vram",
            ],
            "highvram_on_6000": True,   # как _h3_run_6000.py
            "card_affinity": ["RTX PRO 6000", "RTX 4090"],  # видео любит 96 ГБ: сначала 6000
        },
    }
    if not H3_COMFY:
        pools.pop("h3", None)   # второй пул нужен только тем, кто указал для него свой ComfyUI
    # Поэлементная правка из конфига: pools.<имя> дописывает/переопределяет поля,
    # pools.<имя>.disabled=true убирает пул. Нужно для self-test на отдельных портах.
    over = _CFG.get("pools")
    if isinstance(over, dict):
        for name, patch in over.items():
            if not isinstance(patch, dict):
                continue
            if patch.get("disabled"):
                pools.pop(name, None)
                continue
            base = pools.get(name, {})
            base.update({k: v for k, v in patch.items() if k != "disabled"})
            pools[name] = base
    return pools


def glog(msg):
    line = time.strftime("%H:%M:%S ") + msg
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as h:
            h.write(line + "\n")
    except OSError:
        pass


# ------------------------------- GPU-инвентарь -------------------------------

_GPU_FIELDS = "uuid,name,memory.used,utilization.gpu,temperature.gpu,memory.total,power.draw"
_GPU_EXTRA = ",clocks.sm,clocks_event_reasons.active,power.limit"   # частота SM, причины её снижения, предел мощности


def gpus():
    """Список карт: uuid, name, занятая и вся память МиБ, загрузка %, температура °C, частота SM и причины снижения."""
    global _GPU_EXTRA
    if _CFG.get("test_mode") and _CFG.get("test_gpus"):
        return _CFG["test_gpus"]
    try:
        text = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=" + _GPU_FIELDS + _GPU_EXTRA, "--format=csv,noheader,nounits"],
            text=True, timeout=30, creationflags=NO_WINDOW)
    except subprocess.CalledProcessError:
        if not _GPU_EXTRA:
            return []
        _GPU_EXTRA = ""   # драйвер не знает новых полей — карты важнее частоты
        return gpus()
    except (OSError, subprocess.SubprocessError):
        return []
    out = []
    for line in text.splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) not in (6, 7, 9, 10):
            continue
        uuid_, name, used, util, temp, total = parts[:6]
        try:
            power = float(parts[6]) if len(parts) > 6 else None
        except ValueError:
            power = None
        try:
            power_limit = float(parts[9]) if len(parts) > 9 else None
        except ValueError:
            power_limit = None
        try:
            out.append({"uuid": uuid_, "name": name, "used": int(used), "util": int(util),
                        "temp": int(temp) if temp.isdigit() else None,
                        "power": power, "power_limit": power_limit,
                        "total": int(total) if total.isdigit() else None,
                        "sm_mhz": int(parts[7]) if len(parts) > 8 and parts[7].isdigit() else None,
                        "reasons": parts[8] if len(parts) > 8 and parts[8].startswith("0x") else None,
                        "prio": card_prio(name)})
        except ValueError:
            continue
    out.sort(key=lambda c: c["prio"])
    names = [c["name"] for c in out]
    for dup in sorted({n for n in names if names.count(n) > 1}):
        for i, c in enumerate([c for c in out if c["name"] == dup], 1):
            c["name"] = "%s #%d" % (dup, i)   # две одинаковые карты: без номера их не отличить в панели и аренде
    return out


def card_busy(card):
    """Почему карту нельзя занять новым заданием; пустая строка — свободна."""
    if card.get("total"):
        free = card["total"] - card["used"]
        if free < FOREIGN_NEED_MB:
            return ("Свободно %.1f ГБ, нужно %.1f ГБ" % (free / 1024, FOREIGN_NEED_MB / 1024)).replace(".", ",")
    elif card["used"] > FOREIGN_FREE_MB:
        return ("Занято %.1f ГБ при пороге %.1f ГБ" % (card["used"] / 1024, FOREIGN_FREE_MB / 1024)).replace(".", ",")
    if card["util"] >= FOREIGN_FREE_UTIL:
        return "Загрузка %d %% (порог %d %%)" % (card["util"], FOREIGN_FREE_UTIL)
    return ""


def card_free(card):
    return not card_busy(card)


# ------------------------------- SQLite-очередь ------------------------------

_LK = threading.RLock()
_DB = None


def db():
    global _DB
    if _DB is None:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        _DB = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=30)
        _DB.execute("PRAGMA journal_mode=WAL")
        _DB.execute("PRAGMA synchronous=NORMAL")
        _DB.execute("""CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY,
            n INTEGER,
            pool TEXT,
            client_id TEXT,
            graph TEXT,
            state TEXT,               -- queued/running/done/error/cancelled
            backend_port INTEGER,
            bpid TEXT,
            attempts INTEGER DEFAULT 0,
            prio_q INTEGER DEFAULT 0,  -- приоритет в очереди: выше = раньше (интерактив поверх пачки)
            card TEXT,                 -- на какой карте считался (для метрик, переживает смену бэкенда)
            submit_ts REAL,
            start_ts REAL,
            done_ts REAL,
            result TEXT,
            error TEXT)""")
        # миграция старой БД без prio_q/card
        for ddl in ("prio_q INTEGER DEFAULT 0", "card TEXT", "chat_title TEXT",
                    "origin TEXT", "signature TEXT", "avoid TEXT DEFAULT '[]'", "retry_stop INTEGER DEFAULT 0",
                    "bg_preempt INTEGER DEFAULT 0", "model_event TEXT", "dispatch_ts REAL", "media TEXT DEFAULT '[]'", "token TEXT",
                    "task TEXT", "what TEXT", "prompt_text TEXT", "meta TEXT"):
            try:
                _DB.execute("ALTER TABLE jobs ADD COLUMN %s" % ddl)
            except sqlite3.OperationalError:
                pass
        _DB.execute("CREATE INDEX IF NOT EXISTS jobs_state ON jobs(pool,state,prio_q,n)")
        _DB.execute("CREATE TABLE IF NOT EXISTS events(ts REAL, job_id TEXT, message TEXT)")
        _DB.execute("CREATE TABLE IF NOT EXISTS leases(token TEXT PRIMARY KEY, card TEXT, owner TEXT, expires REAL)")
        # Совместные аренды: сколько памяти просили, целиком ли карта, когда выдана.
        # ram — сколько RAM ПК заявлено (МиБ); ctime — время создания процесса-клиента: пока он жив, аренду не снимаем.
        for ddl in ("need INTEGER DEFAULT 14000", "exclusive INTEGER DEFAULT 0", "ts REAL DEFAULT 0", "pid INTEGER",
                    "ram INTEGER DEFAULT 0", "ctime REAL"):
            try:
                _DB.execute("ALTER TABLE leases ADD COLUMN %s" % ddl)
            except sqlite3.OperationalError:
                pass
        # Задания в обход очереди — для истории по картам.
        _DB.execute("CREATE TABLE IF NOT EXISTS foreign_jobs(id TEXT PRIMARY KEY, card TEXT, task TEXT, what TEXT,"
                    " chat_title TEXT, ref TEXT, port INTEGER, start_ts REAL, seen_ts REAL, done_ts REAL)")
        for ddl in ("meta TEXT", "via TEXT", "media TEXT DEFAULT '[]'", "err INTEGER DEFAULT 0", "exact INTEGER DEFAULT 0", "prompt_text TEXT"):
            try:
                _DB.execute("ALTER TABLE foreign_jobs ADD COLUMN %s" % ddl)
            except sqlite3.OperationalError:
                pass
        # Аренды для статистики: сколько каждая карта была отдана раннерам.
        _DB.execute("CREATE TABLE IF NOT EXISTS lease_log(token TEXT PRIMARY KEY, card TEXT, owner TEXT, need INTEGER,"
                    " exclusive INTEGER, pid INTEGER, start_ts REAL, end_ts REAL)")
        try:  # с какого момента раннер ждал карту
            _DB.execute("ALTER TABLE lease_log ADD COLUMN req_ts REAL")
        except sqlite3.OperationalError:
            pass
        _DB.execute("CREATE TABLE IF NOT EXISTS resource_notices(ts REAL, kind TEXT, message TEXT, card TEXT, details TEXT)")
        _DB.execute("CREATE INDEX IF NOT EXISTS resource_notices_ts ON resource_notices(ts)")
        _DB.execute('CREATE TABLE IF NOT EXISTS idle_servers(port INTEGER PRIMARY KEY, state TEXT)')
        # Места на ПК для тяжёлых задач (slots.py): Unity первым, держатель — процесс (PID + время создания).
        _DB.execute("CREATE TABLE IF NOT EXISTS slots(token TEXT PRIMARY KEY, kind TEXT, owner TEXT, pid INTEGER,"
                    " ctime REAL, since REAL, granted REAL)")
        _DB.execute("UPDATE foreign_jobs SET via='unity' WHERE (via='foreign' OR via IS NULL) AND what LIKE 'Unity%'"
                    " AND (task LIKE '%unity_run%' OR (task NOT LIKE '%fps%' AND task NOT LIKE '%bench%'"
                    " AND task NOT LIKE '%perf%' AND task NOT LIKE '%record%' AND task NOT LIKE '%capture%'))")
        _DB.execute('CREATE TABLE IF NOT EXISTS job_spans(job_id TEXT, start_ts REAL, end_ts REAL, card TEXT, PRIMARY KEY(job_id,start_ts))')
        load_history.init(_DB)
        _DB.commit()
    return _DB


def job_add(pool, graph, client_id, priority=0, origin="", chat_title="", task="", app="", avoid=()):
    """avoid — устройства, куда задание не отправлять (клиент просит, например, только карты ПК)."""
    if not valid_graph(graph):
        raise ValueError('Некорректный граф')
    jid = str(uuid.uuid4())
    what, prompt = graph_summary(graph)
    with _LK:
        c = db()
        n = (c.execute("SELECT COALESCE(MAX(n),0)+1 FROM jobs").fetchone()[0])
        c.execute("INSERT INTO jobs(id,n,pool,client_id,graph,state,attempts,prio_q,submit_ts,avoid)"
                  " VALUES(?,?,?,?,?, 'queued', 0, ?, ?, ?)",
                  (jid, n, pool, client_id, json.dumps(graph), int(priority), time.time(), json.dumps(list(avoid))))
        c.commit()
        # Не учитываем seed и текст в оценке длительности, но учитываем модель/размер/шаги.
        sig = graph_signature(graph)
        meta = graph_meta(graph)
        if app:
            meta['app'] = app  # программа-клиент, если чат не определён
        job_set(jid, origin=origin or client_id, chat_title=chat_title or client_id,
                signature=sig, task=task or None, what=what, prompt_text=prompt, meta=json.dumps(meta))
    return jid, n


def graph_signature(graph):
    shape = [(v.get('class_type'), {k: x for k, x in v.get('inputs', {}).items()
              if k not in ('seed', 'noise_seed', 'text', 'prompt', 'filename_prefix', 'image')})
             for v in graph.values() if isinstance(v, dict)]
    return hashlib.sha256(json.dumps(shape, sort_keys=True).encode()).hexdigest()[:20]


def model_key(graph):
    """Имена весов и полный набор LoRA с весами, без seed и текста."""
    models, loras = [], []
    for node in graph.values():
        inputs = node.get('inputs', {}) if isinstance(node, dict) else {}
        models.extend((k, v) for k, v in inputs.items()
                      if k in ('unet_name', 'ckpt_name') and isinstance(v, str))
        if any('lora' in k.lower() for k in inputs):
            loras.append(json.dumps({k: v for k, v in inputs.items() if 'lora' in k.lower() or k.startswith('strength')}, sort_keys=True))
    return json.dumps([sorted(models), sorted(loras)]) if models else None


def exec_start(entry):
    """Когда ComfyUI начал исполнять граф, по сообщениям /history, с; None — не видно."""
    for msg in ((entry or {}).get('status') or {}).get('messages') or []:
        if isinstance(msg, list) and len(msg) > 1 and msg[0] == 'execution_start' and isinstance(msg[1], dict):
            ts = msg[1].get('timestamp')
            if isinstance(ts, (int, float)) and not isinstance(ts, bool):
                return ts / 1000.0
    return None


def weights_of(key):
    """Только веса из model_key, без LoRA: смена одних LoRA стоит 1–2 с, смена весов — 20–30 с."""
    try:
        return json.loads(key)[0] if key else None
    except (TypeError, ValueError, IndexError):
        return None


def _lease_alive(pid, ctime):
    """Процесс-клиент аренды ещё жив (по PID и времени создания, если оно известно)."""
    if not pid or pc_slots.psutil is None:
        return False
    if ctime:
        return pc_slots._ctime(pid) == ctime
    return pc_slots.psutil.pid_exists(pid)


def _tree_ram_mb(pid):
    """Сколько RAM уже взяли процесс и все его потомки, МиБ; 0 — процесса нет. Берём выделенную память (private),
    если она больше рабочего набора: например, обучение выделило 67 ГБ, а в RAM лежало 4 ГБ — заявка уже взята."""
    psutil = pc_slots.psutil
    if not psutil or not pid:
        return 0
    try:
        root = psutil.Process(pid)
        procs = [root] + root.children(recursive=True)
    except (psutil.Error, OSError):
        return 0
    total = 0
    for p in procs:
        try:
            mi = p.memory_info()
            total += max(mi.rss, getattr(mi, 'private', 0))
        except (psutil.Error, OSError):
            pass
    return total // 2 ** 20


def gb(mb):
    """МиБ → «7,7» ГБ для журнала."""
    return ('%.1f' % ((mb or 0) / 1024)).replace('.', ',')


def backend_model_key(backend, graph):
    effective = backend._prefer_int8(graph) if backend.remote and hasattr(backend, '_prefer_int8') else graph
    return model_key(effective)


def valid_graph(graph):
    return isinstance(graph, dict) and bool(graph) and all(
        (_CFG.get('test_mode') and k == '_ctl') or
        (isinstance(k, str) and isinstance(v, dict) and isinstance(v.get('class_type'), str)
         and isinstance(v.get('inputs'), dict)) for k,v in graph.items())


def job_row(jid):
    with _LK:
        r = db().execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
        cols = [d[0] for d in db().execute("SELECT * FROM jobs LIMIT 0").description]
    return dict(zip(cols, r)) if r else None


def media_of(qs):
    """Файлы результата: задание очереди (?job=) или задание вне очереди (?foreign=)."""
    fid = qs.get('foreign', [''])[0]
    if fid:
        with _LK:
            row = db().execute("SELECT media FROM foreign_jobs WHERE id=?", (fid,)).fetchone()
        media = row[0] if row else None
    else:
        row = job_row(qs.get('job', [''])[0])
        media = row['media'] if row else None
    return _loads(media, [])


def _loads(text, default):
    """JSON из базы; битое или другого типа — значение по умолчанию."""
    try:
        value = json.loads(text) if text else default
    except (ValueError, TypeError):
        return default
    return value if isinstance(value, type(default)) else default


def _span(intervals):
    """Сколько секунд покрывают отрезки; пересечения считаются один раз."""
    total, end = 0.0, None
    for a, b in sorted(intervals):
        if end is None or a > end:
            total, end = total + b - a, b
        elif b > end:
            total, end = total + b - end, b
    return round(total)


def _empty_stats():
    return {'today': {'done': 0, 'errors': 0, 'images': 0, 'videos': 0, 'gen_seconds': 0, 'lease_seconds': 0, 'other': 0,
                      'unity_runs': 0, 'model_hits': 0, 'model_swaps': 0, 'busy_pct_24h': None},
            'week': {'done': 0, 'avg_seconds': None}, 'last_done_ts': None}


def remaining_after(samples, elapsed):
    """Остаток, когда обычное время уже вышло: медиана (длительность − прошло) у прошлых, что шли дольше.
    Дольше всех похожих — примерно 15 % прошедшего, не меньше 5 с. Возвращает (остаток, примерно ли)."""
    longer = [d - elapsed for d in samples if d > elapsed]
    return (_median(longer), False) if longer else (max(5.0, 0.15 * elapsed), True)


def work_units(meta):
    """Объём работы графа: шаги × пиксели × кадры × пачка (в мегапикселях) — для пересчёта с похожих."""
    meta = meta if isinstance(meta, dict) else {}
    if not (meta.get('steps') and meta.get('w') and meta.get('h')):
        return None
    return meta['steps'] * meta['w'] * meta['h'] * max(1, meta.get('frames') or 1) * max(1, meta.get('batch') or 1) / 1e6


def foreign_signature(task, what, meta):
    """Форма задания вне очереди для оценки длительности: параметры графа ComfyUI, иначе скрипт и движок."""
    meta = meta if isinstance(meta, dict) else {}
    if meta.get('model') or meta.get('w'):
        return json.dumps([meta.get(k) for k in ('kind', 'model', 'w', 'h', 'steps', 'frames', 'batch')]
                          + [len(meta.get('loras') or [])])
    first = (task or '').split(' → ')[0].strip().lower()
    engine = (what or '').split(' :')[0].split(' · ')[0].strip()[:40]
    return 'script:%s|%s' % (first, engine) if first else None


def collapse_unity(items):
    """Короткие прогоны одного скрипта на одной карте, без потери исходных строк в БД."""
    result, chains = [], {}
    for item in sorted(items, key=lambda row: row.get('start_ts') or 0):
        key = (item['card'], item['task'], item['chat_title'])
        duration = ((item['done_ts'] - item['start_ts']) if item.get('done_ts') and item.get('start_ts') else None)
        if item['via'] != 'unity' or duration is None or duration >= 60:
            result.append(item)
            chains.pop(key, None)
            continue
        prev = chains.get(key)
        if prev and 0 <= item['start_ts'] - prev['done_ts'] < 120:
            prev['count'] += item['count']
            prev['done_ts'] = item['done_ts']
            prev['duration_seconds'] += item['duration_seconds'] or 0
            prev['what'] = 'Unity-тесты × %d, суммарно %.1f мин' % (prev['count'], prev['duration_seconds'] / 60)
        else:
            result.append(item)
            chains[key] = item
    return sorted(result, key=lambda row: row.get('start_ts') or 0, reverse=True)


def jobs_where(pool, states):
    q = "SELECT * FROM jobs WHERE pool=? AND state IN (%s) ORDER BY n" % ",".join("?" * len(states))
    with _LK:
        cur = db().execute(q, (pool, *states))
        cols = [d[0] for d in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]


def queued_sorted(pool):
    """Очередь на раздачу: сначала высокий приоритет (интерактив), внутри — по порядку подачи.
    Пачка скриптов идёт с prio_q=0, одиночный запрос пользователя с prio_q>0 встаёт перед ней."""
    q = "SELECT * FROM jobs WHERE pool=? AND state='queued' ORDER BY prio_q DESC, n"
    with _LK:
        cur = db().execute(q, (pool,))
        cols = [d[0] for d in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        served = dict(db().execute("SELECT COALESCE(origin,client_id), MAX(dispatch_ts) FROM jobs"
                                   " WHERE pool=? GROUP BY COALESCE(origin,client_id)", (pool,)))
    result = []
    for priority in sorted({r["prio_q"] for r in rows}, reverse=True):
        groups = {}
        for r in rows:
            if r["prio_q"] == priority:
                groups.setdefault(r["origin"] or r["client_id"], deque()).append(r)
        order = sorted(groups, key=lambda k: (served.get(k) or 0, groups[k][0]["n"]))
        while any(groups.values()):
            for key in order:
                if groups[key]:
                    result.append(groups[key].popleft())
    return result


def event(jid, message):
    now = time.time()
    with _LK:
        # Повторы проб ноутбуков не засоряют журнал: то же сообщение по заданию — раз в 10 минут.
        if db().execute("SELECT 1 FROM events WHERE job_id=? AND message=? AND ts>?",
                        (jid, message, now - 600)).fetchone():
            return
        db().execute("INSERT INTO events VALUES(?,?,?)", (now, jid, message))
        db().execute("DELETE FROM events WHERE ts < ?", (now - 30 * 86400,))
        db().commit()
    glog(message)


def job_set(jid, **kw):
    if not kw:
        return
    sets = ", ".join("%s=?" % k for k in kw)
    with _LK:
        db().execute("UPDATE jobs SET %s WHERE id=?" % sets, (*kw.values(), jid))
        db().commit()


def _safe_getcwd():
    try:
        return os.getcwd()
    except OSError:
        return "<недоступен>"


# --------------------------------- Бэкенд -----------------------------------

class Backend:
    def __init__(self, pool, port, card):
        self.pool = pool
        self.port = port
        self.uuid = card["uuid"]
        self.card = card_label(card["name"])
        self.proc = None
        self.ready = False
        self.starting = False
        self.remote = False
        self.blocked = False
        self.last_used = time.time()
        self.freed = False
        self.ramp_ts = 0          # когда модель начала грузиться
        self.base = "http://127.0.0.1:%d" % port
        self.user_dir = STATE_DIR / ("%s-%d" % (pool, port)) / "user"
        self.temp_dir = STATE_DIR / ("%s-%d" % (pool, port)) / "temp"
        self.log = STATE_DIR / ("%s-%d" % (pool, port)) / "backend.log"

    # --- жизненный цикл ---
    def _spawn(self, cmd, cwds, env, stdout):
        """Создаёт процесс бэкенда, пробуя рабочие каталоги из cwds по порядку.
        OSError (в т.ч. WinError 267 из-за на миг отвалившегося junction/диска) не
        роняет диспетчер: логируем и возвращаем False. Тик переживёт сбой и повторит
        старт на следующем круге, когда путь восстановится, — карта не застрянет в
        простое с невыполненным заданием."""
        last = None
        for cwd in cwds:
            try:
                self.proc = subprocess.Popen(
                    cmd, cwd=cwd, env=env, stdout=stdout,
                    stderr=subprocess.STDOUT, creationflags=NO_WINDOW)
                if last is not None:
                    glog("spawn %s:%d удался запасным заходом cwd=%r" % (self.pool, self.port, cwd))
                return True
            except OSError as e:
                last = e
                glog("spawn %s:%d сбой cwd=%r: %r (getcwd=%r)"
                     % (self.pool, self.port, cwd, e, _safe_getcwd()))
        return False

    def start(self):
        spec = POOLS()[self.pool]
        self.user_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)
        self.log.parent.mkdir(parents=True, exist_ok=True)
        args = list(spec["base_args"]) + [
            "--listen", "127.0.0.1", "--port", str(self.port),
            "--user-directory", str(self.user_dir),
            "--temp-directory", str(self.temp_dir),
        ]
        if spec["highvram_on_6000"] and "6000" in self.card:
            args.append("--highvram")
        env = os.environ.copy()
        inherited_cvd = os.environ.get("CUDA_VISIBLE_DEVICES")
        env["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
        env["CUDA_VISIBLE_DEVICES"] = self.uuid
        env["PYTHONIOENCODING"] = "utf-8"
        env["PYTHONUTF8"] = "1"
        glog("env %s:%d CVD=%r (унаследован CVD=%r)" % (self.pool, self.port, self.uuid, inherited_cvd))
        if spec["entry"] == "boot":
            env["GPUQ_COMFY_ROOT"] = spec["root"]
            env["GPUQ_BACKEND_LOG"] = str(self.log)
            cmd = [spec["python"], str(HERE / "boot.py")] + args
            stdout = subprocess.DEVNULL
            # boot.py сам делает os.chdir(Path(GPUQ_COMFY_ROOT).resolve()), поэтому
            # навязывать рабочий каталог процессу не нужно: если диск с ComfyUI на миг отвалится,
            # CreateProcess с cwd=root падает с WinError 267; cwd=None убирает проверку каталога.
            cwds = [None]
        else:
            cmd = [spec["python"], "-s", "main.py"] + args
            stdout = open(self.log, "a", encoding="utf-8", errors="replace")
            # main.py требует запуска из своего дерева; junction резолвим в реальную
            # цель (диск D:), а на крайний случай оставляем заход без cwd.
            cwds = [os.path.realpath(spec["root"]), None]
        glog("start %s:%d on %s" % (self.pool, self.port, self.card))
        if not self._spawn(cmd, cwds, env, stdout):
            return False
        deadline = time.monotonic() + START_TIMEOUT
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                glog("backend %s:%d died at boot rc=%s" % (self.pool, self.port, self.proc.returncode))
                return False
            st = self.get("/system_stats", timeout=5)
            if st:
                devs = st.get("devices") or []
                name = devs[0]["name"] if devs else ""
                if self.card.split(" #")[0] in name or not devs:
                    self.ready = True
                    self.last_used = time.time()
                    glog("ready %s:%d (%s)" % (self.pool, self.port, name or "?"))
                    return True
                glog("backend %s:%d wrong card %s, expected %s" % (self.pool, self.port, name, self.card))
                self.stop(boot=True)
                return False
            time.sleep(2)
        glog("backend %s:%d boot timeout" % (self.pool, self.port))
        self.stop(boot=True)
        return False

    def alive(self):
        return self.starting or (self.proc is not None and self.proc.poll() is None)

    def start_async(self):
        self.starting = True
        def boot():
            try:
                self.start()
            except Exception:
                glog(traceback.format_exc())
            finally:
                self.starting = False
        threading.Thread(target=boot, daemon=True).start()

    def stop(self, boot=False):
        if self.starting and not boot:
            return False
        if self.proc and self.proc.poll() is None:
            try:
                result = subprocess.run(["taskkill", "/T", "/F", "/PID", str(self.proc.pid)],
                               capture_output=True, creationflags=NO_WINDOW, timeout=15)
                self.proc.wait(timeout=5)
                if result.returncode and _port_busy(self.port):
                    return False
            except (OSError, subprocess.SubprocessError):
                return False
        if _port_busy(self.port):
            if not stop_owned_processes(self.user_dir) or _port_busy(self.port):
                return False
        elif self.proc and not stop_owned_processes(self.user_dir):
            return False
        self.ready = False
        return True

    # --- HTTP к бэкенду ---
    def _req(self, path, body=None, method=None, timeout=60):
        data = None if body is None else json.dumps(body).encode()
        req = urllib.request.Request(self.base + path, data=data, method=method,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
        return json.loads(raw) if raw else None

    def get(self, path, timeout=30):
        try:
            return self._req(path, timeout=timeout)
        except (OSError, ValueError):
            return None

    def submit(self, graph, client_id):
        """Подаёт граф, возвращает (bpid, node_errors) или (None, errtext)."""
        try:
            res = self._req("/prompt", {"prompt": graph, "client_id": client_id}, timeout=120)
        except urllib.error.HTTPError as e:
            return None, "reject: " + e.read().decode("utf-8", errors="replace")[:1500]
        except (OSError, ValueError) as e:
            return None, "submit: %r" % e
        if not res or "prompt_id" not in res:
            return None, json.dumps(res)[:1500]
        return res["prompt_id"], res.get("node_errors") or {}

    def free(self):
        try:
            self._req("/free", {"unload_models": True, "free_memory": True}, timeout=30)
            self.freed = True
            self.ramp_ts = 0    # модели нет: резерв RAMP на её загрузку держал следующий кадр по 3 мин
            glog("freed %s:%d" % (self.pool, self.port))
        except OSError:
            pass


# -------------------------------- Диспетчер ---------------------------------

BYPASS_LONG_SECONDS = 10 * 60


class Manager:
    def __init__(self):
        self.backends = []          # все живые Backend
        self.stats_cache = {}       # pool -> последний system_stats бэкенда
        self._stop = False
        self._gpu_cache = []
        self._foreign = {}
        self._inventory_ts = 0
        self.scheduling = threading.RLock()
        self.cooldown = {}
        self._sticky_since = {}
        self._fits = {}             # (ноутбук, форма графа) -> подходит ли; для прикидки ETA
        self._light = {}            # карта -> допущенные простаивающие приложения с графикой
        self._seen = {}             # карта -> {pid приложения с графикой: с какого момента видим без нашей модели}
        self._noisy = {}            # карта -> когда последний раз видели чужую нагрузку
        self._ours = {}             # карта -> когда последний раз на ней была наша модель
        self._procs = {}            # pid -> (тип, имя) из последней телеметрии
        self._labels = {}           # pid -> (когда подписан, подпись чужого процесса)
        self._foreign_now = {}      # карта -> что сейчас считают в обход очереди
        self._measuring = {}        # карта -> замер в обход очереди: карта целиком
        self._wanted = {}           # карта -> когда совместная аренда ждала памяти
        self._wanted_excl = {}      # карта -> когда ждали аренду целиком
        self._contend = {}          # карта -> (когда видели чужой расчёт при нашем простое, его процессы)
        self._lease_peak = {}       # токен аренды -> сколько памяти карты её процессы уже брали, МиБ
        self._wait_log_ts = 0       # когда журнал последний раз объяснял ожидание заданий
        self._lease_waits = {}      # (владелец, pid) ждущей аренды -> с какого времени, сколько просит и почему ждёт
        self._interrupted = {}      # id отменяемого кадра -> когда его начали прерывать адресно
        self._cf_open = {}          # id задания чужого ComfyUI -> (порт, prompt_id, папка результатов)
        self._stats_cache = (0, {}) # (когда, сводка по картам) для панели
        self._fdur = (0, {})        # (когда, медианы длительности заданий вне очереди) для оценки остатка
        self._lease_src = {}        # токен аренды -> чат, программа и раннер (по PID клиента аренды)
        self._labeling = False
        self._observed = {}
        self._pc, self._pc_ts, self._pc_busy = {}, 0.0, False   # ряд «ПК» панели: pcstat.sample() раз в 10 с
        self.slots = pc_slots.Slots(db, _LK, lambda: self._pc, self._ram_promised)   # места на ПК: Unity первым (/gpuq/slot)
        self._kept = set()          # токены аренд, которые держим без продления: клиент жив, очередь до него не достучалась
        self._stuck, self._stuck_said = {}, set()   # токен аренды -> с какого времени простаивает; о каких уже сказали
        self._overflow, self._overflow_said = {}, {}  # карта -> с какого времени переполнена; когда сказали
        self._process_mb = {}
        self._owned_servers = {}
        self._history_ts = 0
        self._bypass_warned = {}
        self._long_bypass_warned = set()
        self.idle_monitor = IdleMonitor(self)

    read_gpus = staticmethod(gpus)

    def card_name(self, u):
        return next((card_label(c['name']) for c in self._gpu_cache if c['uuid'] == u), u)

    def load_idle_state(self, port):
        with _LK:
            row = db().execute('SELECT state FROM idle_servers WHERE port=?', (port,)).fetchone()
        return _loads(row[0], {}) if row else {}

    def save_idle_states(self, states):
        with _LK:
            db().executemany('INSERT OR REPLACE INTO idle_servers VALUES(?,?)',
                             [(port, json.dumps(state)) for port, state in states.items()])
            db().commit()

    def notice_long_bypass(self, pid, info, card, title, since, now):
        """Один тихий сигнал на PID и время создания; наблюдаем время именно на GPU."""
        if now - since <= BYPASS_LONG_SECONDS:
            return
        key = '%s:%s' % (pid, info.get('start') or since)
        if key in self._long_bypass_warned:
            return
        with _LK:
            previous = db().execute("SELECT 1 FROM resource_notices WHERE kind='bypass_long' "
                                    "AND json_extract(details,'$.process_key')=? LIMIT 1", (key,)).fetchone()
            if not previous:
                script = (info.get('task') or info.get('engine') or str(pid)).split(' → ')[0]
                minutes = int((now - since) / 60)
                self.resource_notice('bypass_long', 'Долгий обход очереди: %s · чат «%s» · %s · %d мин' %
                                     (script, (title or 'не определён')[:60], card, minutes), card,
                                     process_key=key, pid=pid, script=script, chat_title=title or '', minutes=minutes)
            self._long_bypass_warned.add(key)

    def resource_notice(self, kind, message, card='', **details):
        glog(message)
        with _LK:
            db().execute('INSERT INTO resource_notices VALUES(?,?,?,?,?)',
                         (time.time(), kind, message, card, json.dumps(details)))
            db().execute('DELETE FROM resource_notices WHERE ts<?', (time.time() - 30 * 86400,))
            db().commit()

    def sample_history(self):
        now = time.time()
        if now - self._history_ts < load_history.INTERVAL:
            return
        active = {}
        with _LK:
            for card, in db().execute("SELECT DISTINCT card FROM jobs WHERE state IN ('running','submitting','uncertain','cancelling')"):
                active[card] = True
        leased = {r[0] for r in self._lease_rows()}
        points = {name: {'state': 'офлайн'} for name in CARD_PRIORITY}
        for c in self._gpu_cache:
            name = card_label(c['name'])
            labels = self._foreign_now.get(name) or []
            state = ('генерация' if active.get(name) or any(l.get('via') == 'foreign' and not l.get('what', '').endswith('ждёт задание') for l in labels)
                     else 'аренда' if c['uuid'] in leased else 'unity' if any(l.get('via') == 'unity' for l in labels) else 'простой')
            points[name] = dict(util=c.get('util'), used_mb=c.get('used'), temp=c.get('temp'), power=c.get('power'), state=state,
                                sm_mhz=c.get('sm_mhz'), reasons=c.get('reasons'))
        for b in list(self.backends):
            if not b.remote:
                continue
            tel = getattr(b, 'telemetry', None) or {}
            fresh = now - tel.get('ts', 0) < 120
            points[b.card] = dict(util=tel.get('util') if fresh else None, used_mb=tel.get('used') if fresh else None,
                                 temp=tel.get('temp') if fresh else None, power=tel.get('power') if fresh else None,
                                 state='офлайн' if not b.ready or not fresh else 'генерация'
                                 if active.get(b.card) or getattr(b, 'current', None) else 'простой')
        with _LK:
            load_history.save(db(), points, now)
        self._history_ts = now

    def history(self, hours=24, card=None):
        with _LK:
            return load_history.read(db(), time.time(), hours, card)

    def refresh_inventory(self):
        if time.time() - self._inventory_ts < 5:
            return
        self._inventory_ts = time.time()
        self._gpu_cache = gpus()
        if _CFG.get("test_mode"):
            self._foreign = {}
            return
        try:
            out = subprocess.check_output(["nvidia-smi", "-q", "-x"], timeout=10, creationflags=NO_WINDOW)
            # venv запускает дочерний python: одного Popen.pid недостаточно.
            ps = ("$p=@(Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | Select-Object ProcessId,CommandLine); "
                  "$m=@(Get-CimInstance Win32_PerfRawData_GPUPerformanceCounters_GPUProcessMemory -ErrorAction SilentlyContinue "
                  "| Select-Object Name,DedicatedUsage); @{processes=$p;memory=$m}|ConvertTo-Json -Compress")
            raw = subprocess.check_output(["powershell", "-NoProfile", "-Command", ps],
                    text=True, timeout=10, creationflags=NO_WINDOW)
            processes = json.loads(raw or "[]")
            memory = (processes.get('memory') or []) if isinstance(processes, dict) and 'processes' in processes else []
            if isinstance(processes, dict) and 'processes' in processes:
                processes = processes['processes']
            if isinstance(processes, dict):
                processes = [processes]
            owned = {int(p["ProcessId"]) for p in processes
                     if any(str(b.user_dir).lower() in (p.get("CommandLine") or "").lower()
                            for b in self.backends if not b.remote)}
            info = process_info(out)
            foreign = defaultdict(set)
            observed = compute_pids(out)
            self._owned_servers = {}
            for b in list(self.backends):
                if b.remote:
                    continue
                matches = [int(p['ProcessId']) for p in processes
                           if int(p['ProcessId']) in observed.get(b.uuid, ())
                           and str(b.user_dir).lower() in (p.get('CommandLine') or '').lower()]
                if matches:
                    self._owned_servers[b.port] = matches[0]
            self._observed = {u: pids - owned for u, pids in observed.items()}
            from telemetry import process_memory
            self._process_mb = process_memory(out)
            by_pid = defaultdict(float)
            for item in memory:
                match = re.search(r'pid_(\d+)_', item.get('Name') or '')
                if match:
                    by_pid[int(match[1])] += float(item.get('DedicatedUsage') or 0) / 1048576
            for u, pids in observed.items():
                for pid in pids:
                    if pid in by_pid and sum(pid in ids for ids in observed.values()) == 1:
                        self._process_mb.setdefault((u, pid), round(by_pid[pid]))
            for gpu_uuid, pids in observed.items():
                foreign[gpu_uuid] = self._settle(gpu_uuid, pids, owned, info)
            self._procs = info
            self._foreign = foreign
            if not self._labeling:
                self._labeling = True
                threading.Thread(target=self._label_run, args=(dict(self._observed),), daemon=True).start()
        except (OSError, ValueError, subprocess.SubprocessError):
            self._foreign = {c["uuid"]: {"не удалось проверить процессы"} for c in self._gpu_cache}

    def _label_run(self, foreign):
        """Подписи заданий вне очереди: раннеры под арендой, чужой ComfyUI, Unity, очереди ноутбуков.
        Выгрузку простаивающих моделей отдельно проверяет IdleMonitor.
        via: lease, farm, unity — учтённый Unity-тест, foreign — обход очереди."""
        try:
            now = time.time()
            names = {c['uuid']: card_label(c['name']) for c in self._gpu_cache}
            with _LK:
                live_leases = db().execute("SELECT token,pid,owner FROM leases WHERE expires>=?", (now,)).fetchall()
            lease_pids = {r[1] for r in live_leases if r[1]}
            # Кто взял аренду: чат по GPUQ_CALL_ID или по имени раннера, иначе программа — один раз на аренду.
            for token, lpid, owner in live_leases:
                if token in self._lease_src or not lpid:
                    continue
                stem = re.sub(r'(?i)\.(py|cmd|bat|ps1)$', '', (owner or '').strip()).lower()
                title = chat_for(chat_origin._call_for_pid(lpid)) or next(
                    (chat_for('job:' + stem + ext) for ext in ('', '.cmd', '.py', '.ps1', '.bat') if chat_for('job:' + stem + ext)), '')
                self._lease_src[token] = {'chat_title': title, 'app': program_for(lpid), 'owner': owner or ''}
            for token in set(self._lease_src) - {r[0] for r in live_leases}:
                self._lease_src.pop(token, None)
            rows, current, extra, alive, procs, measuring, open_now = [], defaultdict(list), defaultdict(dict), set(), {}, {}, {}
            prompts, apps, paths, farm_now = {}, {}, {}, {}
            for uuid_, pids in foreign.items():
                card = names.get(uuid_)
                if not card:
                    continue
                for pid in pids:
                    if not isinstance(pid, int):
                        continue
                    alive.add(pid)
                    seen = self._labels.get(pid)
                    if seen is None or (seen[1]['engine'] == 'ComfyUI' and not seen[1]['port'] and now - seen[0] > 30):
                        seen = (now, describe_foreign(pid))
                        self._labels[pid] = seen
                    info = seen[1]
                    engine = info['engine'] or ''
                    title = chat_for(info['ref']) or chat_for('job:' + (info.get('task') or '').split(' → ')[0].lower())
                    via = 'lease' if info.get('leased') or set(info.get('chain') or ()) & lease_pids else 'foreign'
                    if via == 'foreign' and engine.lower().startswith('unity') and (
                            'unity_run' in (info.get('task') or '').lower() or not MEASURE_RE.search(info.get('task') or '')):
                        via = 'unity'
                    if via != 'unity' and MEASURE_RE.search(info.get('task') or ''):
                        measuring.setdefault(uuid_, info['task'])
                    if via in ('foreign', 'unity') and (engine == 'ComfyUI' or engine.startswith('Unity') or
                            re.search(r'(?i)\.(?:py|pyw|cmd|bat|ps1|js)\b', info.get('task') or '')):
                        self.notice_long_bypass(pid, info, card, title, seen[0], now)
                    if engine == 'ComfyUI':
                        port = info['port']
                        if not port:  # сервер ещё запускается: в историю не пишем
                            extra[card]['ComfyUI · запускается'] = {'what': 'ComfyUI · запускается', 'task': info['task'],
                                                                     'chat_title': title, 'via': via, 'meta': {}}
                            continue
                        if info.get('out') is None and not info.get('out_checked'):
                            info['out_checked'] = True
                            info['out'] = self._comfy_out(port)
                        try:
                            with _NOPROXY.open('http://127.0.0.1:%d/queue' % port, timeout=2) as r:
                                queue = json.load(r)
                            running = queue.get('queue_running') or []
                            pending = queue.get('queue_pending') or []
                        except (OSError, ValueError, AttributeError):
                            running, pending = [], []
                        # Пачка раннера: сколько ещё ждёт в его ComfyUI и сколько это займёт по прошлым таким же.
                        left = [self._foreign_eta(card, info['task'], '', graph_meta(p[2]), 0)[0]
                                for p in pending[:200] if isinstance(p, (list, tuple)) and len(p) > 2 and isinstance(p[2], dict)]
                        for k, item in enumerate(running[:4]):
                            try:
                                meta = graph_meta(item[2]) if isinstance(item[2], dict) else {}
                                if info.get('app'):
                                    meta['app'] = info['app']
                                if info.get('path'):
                                    meta['path'] = info['path']
                                if k == 0 and pending:
                                    meta['pending'] = len(pending)
                                    if left and None not in left:
                                        meta['pending_eta'] = round(sum(left))
                                client = str((item[3] or {}).get('client_id') or '')
                                ref = client.lower() if chat_origin.CALL_RE.fullmatch(client) else info['ref']
                                fid = '%s:%d:%s' % (card, port, item[1])
                                prompts[fid] = graph_summary(item[2])[1] if isinstance(item[2], dict) else ''
                                rows.append((fid, card, info['task'], 'ComfyUI :%d · %s' % (port, meta_text(meta)),
                                             chat_for(ref) or title, ref, port, now, meta, via))
                                open_now[fid] = (port, str(item[1]), info.get('out'))
                            except (TypeError, IndexError, KeyError, AttributeError):
                                continue
                        if not running:
                            w = 'ComfyUI :%d · ждёт задание' % port
                            extra[card][w] = {'what': w, 'task': info['task'], 'chat_title': title, 'via': via, 'meta': {}}
                        continue
                    # Игры и плееры с графикой без скриптов в цепочке — не задания: только подпись карты
                    if self._procs.get(pid, ('', ''))[0] == 'C+G' and not engine.startswith('Unity') \
                            and not re.search(r'(?i)\.(?:py|pyw|cmd|bat|ps1|js)\b', info.get('task') or ''):
                        w = 'Приложение ' + (engine or str(pid))
                        extra[card][w] = {'what': w, 'task': '', 'chat_title': '', 'via': 'app', 'meta': {}}
                        continue
                    # Порт полезен у серверов; у Unity это служебный порт редактора — в подписи не нужен.
                    what = (engine or 'Процесс %d' % pid) + (' :%d' % info['port'] if info['port'] and not engine.startswith('Unity') else '')
                    # Unity держит на карте ещё и свои AssetImportWorker: одна строка на запуск, по самому раннему процессу
                    key = (card, info['task'], what, title, info['ref'], info['port'], via)
                    mark = (info['start'] or 0, pid)
                    if key not in procs or mark < procs[key]:
                        procs[key] = mark
                        apps[key] = info.get('app') or ''
                        paths[key] = info.get('path') or ''
            for key, (start, pid) in procs.items():
                card, task, what, title, ref, port, via = key
                meta = {'vram_mb': self._process_mb.get((next((u for u, n in names.items() if n == card), ''), pid))} if via == 'unity' else {}
                if apps.get(key):
                    meta['app'] = apps[key]
                if paths.get(key):
                    meta['path'] = paths[key]
                rows.append(('%s:%d:%d' % (card, pid, int(start)), card, task, what, title, ref, port, start or now, meta, via))
            for b in list(self.backends):
                cur = getattr(b, 'current', None) if b.remote else None
                if b.remote and b.ready and isinstance(getattr(b, 'queue', None), dict):
                    farm_now[b.card] = '%s:%s' % (b.card, cur['prompt_id']) if cur else None
                if cur:
                    fid = '%s:%s' % (b.card, cur['prompt_id'])
                    prompts[fid] = cur.get('prompt') or ''
                    rows.append((fid, b.card, cur['task'], cur['what'],
                                 cur['chat_title'], None, None, now, cur.get('meta') or {}, 'farm'))
            for row in rows:
                current[row[1]].append({'what': row[3], 'task': row[2], 'chat_title': row[4], 'via': row[9], 'meta': row[8]})
            for card, items in extra.items():  # простой, запуск и приложения — после настоящих заданий
                current[card].extend(items.values())
            for pid in list(self._labels):
                if pid not in alive:
                    del self._labels[pid]
            with _LK:
                c = db()
                for fid, card, task, what, title, ref, port, start, meta, via in rows:
                    m = json.dumps(meta)
                    prompt = prompts.get(fid) or None
                    if c.execute("SELECT 1 FROM foreign_jobs WHERE id=?", (fid,)).fetchone():
                        c.execute("UPDATE foreign_jobs SET seen_ts=?, done_ts=NULL, task=?, what=?, meta=?, via=?,"
                                  " chat_title=COALESCE(NULLIF(?,''),chat_title), prompt_text=COALESCE(?,prompt_text) WHERE id=?",
                                  (now, task, what, m, via, title, prompt, fid))
                    else:
                        c.execute("INSERT INTO foreign_jobs(id,card,task,what,chat_title,ref,port,start_ts,seen_ts,done_ts,meta,via,prompt_text)"
                                  " VALUES(?,?,?,?,?,?,?,?,?,NULL,?,?,?)", (fid, card, task, what, title, ref, port, start, now, m, via, prompt))
                    if via == 'foreign':
                        script = (task or what).split(' → ')[0]
                        key = script.lower()
                        if now - self._bypass_warned.get(key, 0) >= 3600:
                            previous = c.execute("SELECT MAX(ts) FROM resource_notices WHERE kind='bypass' AND json_extract(details,'$.script')=? COLLATE NOCASE", (script,)).fetchone()[0]
                            self._bypass_warned[key] = previous or 0
                            if now - (previous or 0) >= 3600:
                                self.resource_notice('bypass', 'Мимо очереди: %s (чат «%s») на %s' %
                                                     (script, (title or 'не определён')[:60], card), card, script=script)
                                self._bypass_warned[key] = now
                c.execute("UPDATE foreign_jobs SET done_ts=seen_ts WHERE done_ts IS NULL AND seen_ts<?", (now - 60,))
                for card_, fid in farm_now.items():  # ноутбук взял следующий кадр или освободился — прошлый закончен
                    c.execute("UPDATE foreign_jobs SET done_ts=seen_ts WHERE via='farm' AND card=? AND done_ts IS NULL AND id<>?",
                              (card_, fid or ''))
                c.execute("DELETE FROM foreign_jobs WHERE seen_ts<?", (now - 30 * 86400,))
                c.commit()
            # Законченные задания чужого ComfyUI: точное время и файлы из /history (сеть — вне блокировки)
            finished = {fid: v for fid, v in self._cf_open.items() if fid not in open_now}
            self._cf_open = open_now
            for fid, (port, prompt_id, out) in finished.items():
                got = self._comfy_history(port, prompt_id, out)
                if got:
                    start, done, err, media = got
                    with _LK:
                        db().execute("UPDATE foreign_jobs SET start_ts=COALESCE(?,start_ts), done_ts=COALESCE(?,done_ts),"
                                     " exact=?, err=?, media=? WHERE id=?",
                                     (start, done, int(bool(start and done)), err, json.dumps(media), fid))
                        db().commit()
            self._foreign_now = dict(current)
            self._measuring = measuring
        except Exception:
            glog('label: ' + traceback.format_exc()[-600:])
        finally:
            self._labeling = False

    def _comfy_out(self, port):
        """Папка результатов чужого ComfyUI по его /system_stats, если её не видно в командной строке."""
        try:
            with _NOPROXY.open('http://127.0.0.1:%d/system_stats' % port, timeout=2) as r:
                argv = [str(a) for a in json.load(r).get('system', {}).get('argv') or []]
        except (OSError, ValueError, AttributeError, TypeError):
            return None
        path = None
        for i, a in enumerate(argv):
            if a.startswith('--output-directory='):
                path = a.split('=', 1)[1]
            elif a == '--output-directory' and i + 1 < len(argv):
                path = argv[i + 1]
        if path is None and argv:
            path = os.path.join(os.path.dirname(argv[0]), 'output')
        return path if path and os.path.isabs(path) else None

    def _comfy_history(self, port, prompt_id, out):
        """(начало, конец, ошибка, файлы) законченного задания чужого ComfyUI по его /history; только чтение."""
        try:
            with _NOPROXY.open('http://127.0.0.1:%d/history/%s' % (port, quote(prompt_id, safe='')), timeout=2) as r:
                entry = json.load(r).get(prompt_id)
            messages = (entry.get('status') or {}).get('messages') or []
            outputs = entry.get('outputs') or {}
        except (OSError, ValueError, AttributeError):
            return None
        start = done = None
        err = 0
        for msg in messages:
            if not (isinstance(msg, list) and len(msg) > 1 and isinstance(msg[1], dict)):
                continue
            ts = msg[1].get('timestamp')
            ts = ts / 1000.0 if isinstance(ts, (int, float)) and not isinstance(ts, bool) else None
            if msg[0] == 'execution_start':
                start = ts
            elif msg[0] in ('execution_success', 'execution_error', 'execution_interrupted'):
                done, err = ts, int(msg[0] != 'execution_success')
        media = []
        root = os.path.normcase(os.path.realpath(out)) if out else None
        for node in (outputs.values() if isinstance(outputs, dict) else ()):
            for kind in ('images', 'gifs', 'videos'):
                for im in (node.get(kind) if isinstance(node, dict) else None) or []:
                    if not root or not isinstance(im, dict) or im.get('type', 'output') != 'output':
                        continue
                    name = str(im.get('filename') or '')
                    path = os.path.realpath(os.path.join(out, str(im.get('subfolder') or ''), name))
                    if name and os.path.normcase(path).startswith(root + os.sep) and os.path.isfile(path):
                        media.append({'path': path, 'filename': os.path.basename(path),
                                      'type': mimetypes.guess_type(path)[0] or 'application/octet-stream'})
        return start, done, err, media

    def _settle(self, u, pids, owned, info):
        """Чужие процессы карты без простаивающих приложений с графикой (Unity, IDE).
        Карта свободна, если два замера через минуту: под задание хватает памяти и загрузка ниже 20 %.
        Чистый расчёт (C) блокирует всегда. Незнакомое приложение с графикой (C+G) допускаем,
        когда минуту видели его без нашей модели и без чужой нагрузки. Пока на карте наша модель,
        её вклад от чужого не отличить, поэтому новых приложений не допускаем."""
        now = time.time()
        mine = bool(pids & owned) or any(b.uuid == u and not b.remote for b in self.backends)
        if mine:
            self._ours[u] = now
        pids = pids - owned
        cand = {p for p in pids if info.get(p, ("",))[0] == "C+G"}
        card = next((c for c in self._gpu_cache if c["uuid"] == u), None)
        # 10 с после ухода нашей модели память ещё может освобождаться
        if pids - cand or (cand and not (card and card_free(card)) and now - self._ours.get(u, 0) > 10):
            self._noisy[u] = now
        seen = {p: now if mine else self._seen.get(u, {}).get(p, now) for p in cand}
        self._seen[u] = seen
        old = self._light.get(u, set()) & cand
        if mine:
            light = old
        elif self.calm_left(u):
            light = set()
        else:
            light = old | {p for p in cand if now - seen[p] >= FREE_WINDOW}
        self._light[u] = light
        return pids - light

    def calm_left(self, u):
        """Сколько ещё ждать минуту тишины после чужой нагрузки на карте."""
        return max(0.0, self._noisy.get(u, 0) + FREE_WINDOW - time.time())

    def leased_cards(self):
        with _LK:
            now = time.time()
            # ПК ушёл в подкачку, продления не доходили, и аренды снимались под идущим обучением.
            for token, owner, pid, ctime in db().execute("SELECT token, owner, pid, ctime FROM leases"
                                                         " WHERE expires < ? AND pid IS NOT NULL", (now,)).fetchall():
                if _lease_alive(pid, ctime):
                    db().execute("UPDATE leases SET expires=? WHERE token=?", (now + 120, token))
                    if token not in self._kept:
                        self._kept.add(token)
                        glog('аренда «%s» без продления: процесс %d жив, держим' % (owner, pid))
            db().execute("UPDATE lease_log SET end_ts=(SELECT expires FROM leases WHERE leases.token=lease_log.token)"
                         " WHERE end_ts IS NULL AND token IN (SELECT token FROM leases WHERE expires < ?)", (now,))
            db().execute("DELETE FROM leases WHERE expires < ?", (now,))
            self._kept &= {r[0] for r in db().execute("SELECT token FROM leases")}
            db().execute("UPDATE lease_log SET end_ts=? WHERE end_ts IS NULL AND token NOT IN (SELECT token FROM leases)", (now,))
            db().execute("DELETE FROM lease_log WHERE start_ts < ?", (now - 30 * 86400,))
            db().commit()
            return {r[0] for r in db().execute("SELECT card FROM leases")}

    def _lease_rows(self):
        """Живые аренды: (карта, владелец, нужно МиБ, целиком ли, когда выдана, PID клиента, токен)."""
        with _LK:
            return db().execute("SELECT card, owner, need, exclusive, ts, pid, token FROM leases WHERE expires >= ?",
                                (time.time(),)).fetchall()

    def _exclusive(self, u, rows):
        return any(r[0] == u and r[3] for r in rows)

    def _comfy_on(self, u):
        """Чужой ComfyUI, которому нужен запас 6 ГБ; простаивающему с выгруженной моделью хватает обычного."""
        return any(isinstance(p, int) and (self._labels.get(p) or (0, {}))[1].get('engine') == 'ComfyUI'
                   and not self._comfy_quiet(p) for p in self._foreign.get(u) or ())

    def _comfy_quiet(self, pid):
        """Монитор простоя недавно видел у сервера пустую очередь и меньше 4 ГБ памяти: модель не загружена."""
        state = self.idle_monitor.states.get((self._labels.get(pid) or (0, {}))[1].get('port')) or {}
        used = state.get('used_mb')
        return (state.get('pid') == pid and state.get('queue_empty') is True and isinstance(used, (int, float))
                and used < MIN_VRAM_MB and time.time() - (state.get('last_seen') or 0) <= QUIET_FRESH)

    def _lease_used(self, u, pid):
        """Сколько памяти карты сейчас держат процессы аренды (клиент и всё под ним), МиБ; None — не видно."""
        if not pid:
            return None
        total, seen = 0, False
        for p in self._observed.get(u) or ():
            if p == pid or pid in ((self._labels.get(p) or (0, {}))[1].get('chain') or ()):
                mb = self._process_mb.get((u, p))
                if mb is not None:
                    total, seen = total + mb, True
        return total if seen else None

    def _pending(self, u, now, rows):
        """Память, которую аренды и наши загружающиеся модели ещё могут занять сверх уже занятого.
        Свежая аренда — вся заявка за вычетом того, что её процессы уже держат. После RAMP заявка остаётся
        за арендой, чьи процессы уже брали память этой карты: видео между стадиями и раннер со своим ComfyUI
        вернутся за ней, и новая аренда в эту память не сядет (иначе драйвер молча уносит память в RAM и всё
        на карте идёт в 3–5 раз медленнее). Раннер, который шлёт кадры в очередь, памяти карты не держит."""
        mb = 0
        for r in rows:
            if r[0] != u:
                continue
            pid, token = (r[5], r[6]) if len(r) > 6 else (None, None)
            used = self._lease_used(u, pid)
            if token and used is not None:
                self._lease_peak[token] = max(self._lease_peak.get(token, 0), used)
            if now - (r[4] or 0) < RAMP or self._lease_peak.get(token, 0) >= LEASE_GPU_MB:
                mb += max(0, (r[2] or FOREIGN_NEED_MB) - (used or 0))
        return mb + FOREIGN_NEED_MB * sum(1 for b in self.backends if b.uuid == u and not b.remote
                                          and (b.starting or now - getattr(b, 'ramp_ts', 0) < RAMP))

    def _room_ok(self, c, need, now, rows):
        """Хватит ли на карте памяти ещё на need МиБ с запасом, с учётом набирающих память."""
        u = c['uuid']
        if 'не удалось проверить процессы' in (self._foreign.get(u) or ()):
            return False
        pending = self._pending(u, now, rows)
        if c.get('total'):
            return c['total'] - c['used'] - pending >= need + self._margin(u, need, rows)
        return c['used'] + pending <= FOREIGN_FREE_MB

    def _margin(self, u, need, rows):
        """Запас памяти карты сверх заявки: 2 ГБ, рядом с работающим чужим ComfyUI 6 ГБ, рядом с арендой от 50 ГБ 8 ГБ."""
        margin = MARGIN_COMFY_MB if self._comfy_on(u) else MARGIN_MB
        if need >= BIG_LEASE_MB or any(r[0] == u and (r[2] or 0) >= BIG_LEASE_MB for r in rows):
            margin = max(margin, BIG_MARGIN_MB)
        return margin

    def _room_why(self, c, need, now, rows):
        """Почему _room_ok отказал — для журнала ожидания."""
        u = c['uuid']
        if 'не удалось проверить процессы' in (self._foreign.get(u) or ()):
            return 'не удалось проверить процессы карты'
        margin = self._margin(u, need, rows)
        free = c['total'] - c['used'] if c.get('total') else None
        return 'мало памяти: свободно %s ГБ, обещано %s ГБ, нужно %s + запас %s ГБ%s' % (
            gb(free) if free is not None else '?', gb(self._pending(u, now, rows)), gb(need), gb(margin),
            ' (рядом аренда от 50 ГБ)' if margin == BIG_MARGIN_MB else ' (рядом чужой ComfyUI)' if margin == MARGIN_COMFY_MB else '')

    def _watch_cards(self, now, rows):
        """Уведомления в панель и трей: аренда держит память при простое карты (задача зависла?) и переполнение
        видеопамяти — задачи стоят на 100 % ниже предела мощности (драйвер уносит память в RAM, считать почти нечем)."""
        cards = {c['uuid']: c for c in self._gpu_cache}
        tokens = {r[6] for r in rows}
        for card, owner, _need, _excl, _ts, pid, token in rows:
            c = cards.get(card)
            used = self._lease_used(card, pid)
            if not c or used is None or used < STUCK_MB or (c.get('util') or 0) > STUCK_UTIL:
                self._stuck.pop(token, None)
                continue
            since = self._stuck.setdefault(token, now)
            if now - since >= STUCK_S and token not in self._stuck_said:
                self._stuck_said.add(token)
                self.resource_notice('lease_stuck', 'Аренда «%s» держит %s ГБ на %s, а карта простаивает %d мин — задача, похоже, '
                                     'зависла (PID %s)' % (owner, gb(used), card_label(c['name']), (now - since) // 60, pid),
                                     card_label(c['name']), owner=owner, pid=pid, used_mb=used)
        for token in set(self._stuck) - tokens:
            self._stuck.pop(token, None)
        self._stuck_said &= tokens
        for c in self._gpu_cache:
            u, total, power, limit = c['uuid'], c.get('total'), c.get('power'), c.get('power_limit')
            if not (total and c['used'] >= total * 0.98 and (c.get('util') or 0) >= 90
                    and power is not None and limit and power < limit * 0.85):
                self._overflow.pop(u, None)
                continue
            since = self._overflow.setdefault(u, now)
            if now - since >= OVERFLOW_S and now - self._overflow_said.get(u, 0) >= OVERFLOW_REPEAT_S:
                self._overflow_said[u] = now
                leases = ', '.join('%s %s ГБ' % (re.sub(r'\d{6,}\w*$', '', str(r[1]))[:28], gb(r[2])) for r in rows if r[0] == u)
                self.resource_notice('vram_overflow', 'Переполнена видеопамять %s: занято %s из %s ГБ, загрузка %d %% при %d из %d Вт '
                                     'уже %d мин — возможно, видеопамять вытесняется в RAM и карта почти не считает%s' % (
                                         card_label(c['name']), gb(c['used']), gb(total), c['util'], power, limit,
                                         (now - since) // 60, '; аренды: ' + leases if leases else ''), card_label(c['name']))

    def _ram_promised(self):
        """RAM ПК, которую аренды с ram_mb ещё возьмут сверх уже взятого их процессами, МиБ.
        Пока задача грузится (например, кэш данных рос ~45 мин), её заявка закрыта от других."""
        with _LK:
            rows = db().execute("SELECT ram, pid FROM leases WHERE ram > 0 AND expires >= ?", (time.time(),)).fetchall()
        return sum(max(0, ram - _tree_ram_mb(pid)) for ram, pid in rows)

    def _ram_why(self, need, now):
        """Почему аренде с ram_mb нельзя сейчас: '' — RAM ПК хватает (или её не просили)."""
        pc = self._pc or {}
        if not need or not pc.get('ts'):        # замера нет совсем (нет psutil) — как раньше
            return ''
        if now - pc['ts'] > 60:                 # замер завис: ПК, скорее всего, в подкачке
            return 'нет свежего замера RAM ПК (%d с)' % (now - pc['ts'])
        free, promised = pc.get('ram_free_gb', 0) * 1024, self._ram_promised()
        if free - promised >= need + RAM_MARGIN_MB:
            return ''
        return 'мало RAM ПК: свободно %s ГБ, обещано %s ГБ, нужно %s + запас %s ГБ' % (
            gb(free), gb(promised), gb(need), gb(RAM_MARGIN_MB))

    def _usable(self, b, now, rows):
        """Можно ли дать бэкенду задание: аренде целиком и аренде, ждущей памяти, — приоритет."""
        if now - max(self._wanted_excl.get(b.uuid, 0), self._wanted.get(b.uuid, 0)) < 10:
            return False
        if not getattr(b, 'freed', False):
            return True
        c = next((c for c in self._gpu_cache if c['uuid'] == b.uuid), None)
        return c is None or self._room_ok(c, FOREIGN_NEED_MB, now, rows)

    def bump(self, jid):
        """Панель: задание очереди встаёт первым на раздачу — приоритет выше всех ждущих в его пуле."""
        with _LK:
            r = db().execute("SELECT pool, state FROM jobs WHERE id=?", (jid,)).fetchone()
            if not r or r[1] != 'queued':
                return {'error': 'Задание уже не в очереди'}
            top = db().execute("SELECT MAX(prio_q) FROM jobs WHERE pool=? AND state='queued' AND id<>?", (r[0], jid)).fetchone()[0]
            db().execute("UPDATE jobs SET prio_q=MAX(prio_q, ?) WHERE id=?", ((top or 0) + 1, jid))
            db().commit()
        glog('bump %s' % jid)
        return {'ok': True}

    def lease(self, body):
        token = body.get("token")
        ttl = max(30, min(300, int(body.get("ttl", 120))))
        if token:
            with _LK:  # Продление уже выданной аренды не ждёт сетевой отправки на другую карту.
                row = db().execute("SELECT card, expires, pid, ctime FROM leases WHERE token=?", (token,)).fetchone()
                if row and row[1] <= time.time() and not _lease_alive(row[2], row[3]):
                    row = None
                if token:
                    if not row:
                        return {"error": "аренда истекла"}
                    if body.get("release"):
                        db().execute("UPDATE lease_log SET end_ts=? WHERE token=?", (time.time(), token))
                        db().execute("DELETE FROM leases WHERE token=?", (token,))
                        self._kept.discard(token)
                    else:
                        db().execute("UPDATE leases SET expires=? WHERE token=?", (time.time()+ttl, token))
                    db().commit()
                    return {"released": bool(body.get("release")), "token": token, "card": row[0]}
        # Обычная аренда делит карту, пока хватает памяти; целиком — для замеров FPS и бенчмарков.
        need = max(1024, int(body.get("vram_mb") or FOREIGN_NEED_MB))
        exclusive = bool(body.get("exclusive"))
        pid = body.get("pid")
        pid = pid if isinstance(pid, int) and not isinstance(pid, bool) and pid > 0 else None
        owner = str(body.get("owner") or "задача")[:200]
        ram = max(0, int(body.get("ram_mb") or 0))
        with self.scheduling:
            self.refresh_inventory()
            self.leased_cards()
            rows, now = self._lease_rows(), time.time()
            # since — когда клиент начал ждать; без него (старые клиенты) ожидание не известно: NULL.
            since = body.get("since")
            req = min(now, since) if isinstance(since, (int, float)) and not isinstance(since, bool) \
                and since >= now - 7 * 86400 else None
            ram_why = self._ram_why(ram, now)
            if ram_why:   # RAM на весь ПК: карты не перебираем и модели ради неё не выгружаем
                seen = self._lease_waits.get((owner, pid))
                self._lease_waits[(owner, pid)] = dict(since=seen['since'] if seen else (req or now), last=now, need=need,
                                                       exclusive=exclusive, card=body.get("card"), why={'ПК': ram_why})
                return {"waiting": True}
            cards = [c for c in self._gpu_cache
                     if not body.get("card") or body["card"] in (c["uuid"], card_label(c["name"]))]
            # сначала простаивающая карта, потом с меньшим числом раннеров, потом по приоритету
            cards.sort(key=lambda c: (c["util"] >= FOREIGN_FREE_UTIL, sum(1 for r in rows if r[0] == c["uuid"]), c["prio"]))
            spare, why = None, {}
            for c in cards:
                u = c["uuid"]
                if self._exclusive(u, rows) or self._measuring.get(u):
                    why[card_label(c["name"])] = 'идёт замер' if self._measuring.get(u) else 'карта отдана аренде целиком'
                    continue
                bs = [b for b in self.backends if b.uuid == u and not b.remote]
                if exclusive:
                    shared = any(r[0] == u for r in rows)
                    if shared or self._foreign.get(u) or self.calm_left(u) or (not bs and not card_free(c)) \
                            or any(b.starting or self.inflight(b) for b in bs):
                        if spare is None and (shared or not self._foreign.get(u)):
                            spare = u
                        why[card_label(c["name"])] = ('карту делят аренды' if shared else 'на карте чужие процессы'
                                                      if self._foreign.get(u) else 'на карте работает очередь')
                        continue
                    if any(not b.stop() for b in bs):
                        why[card_label(c["name"])] = 'бэкенд очереди не остановился'
                        continue
                elif now - self._wanted_excl.get(u, 0) < 10:
                    why[card_label(c["name"])] = 'ждёт аренда целиком, её не обгоняем'
                    continue
                elif not self._room_ok(c, need, now, rows):
                    # выгрузить можно, только пока наша модель в памяти; иначе бэкенд не держим
                    if spare is None and any(b.ready and not b.freed for b in bs) \
                            and (not c.get("total") or c["total"] - MARGIN_MB >= need):
                        spare = u
                    why[card_label(c["name"])] = self._room_why(c, need, now, rows)
                    continue
                self._lease_waits.pop((owner, pid), None)
                token = uuid.uuid4().hex
                with _LK:
                    db().execute("INSERT INTO leases(token,card,owner,expires,need,exclusive,ts,pid,ram,ctime)"
                                 " VALUES(?,?,?,?,?,?,?,?,?,?)", (token, u, owner, now + ttl, need, int(exclusive), now, pid,
                                                                 ram, pc_slots._ctime(pid) if pid and pc_slots.psutil else None))
                    db().execute("INSERT OR REPLACE INTO lease_log(token,card,owner,need,exclusive,pid,start_ts,end_ts,req_ts)"
                                 " VALUES(?,?,?,?,?,?,?,NULL,?)", (token, u, owner, need, int(exclusive), pid, now, req))
                    db().commit()
                return {"token": token, "card": u, "name": card_label(c["name"]), "ttl": ttl, "shared": not exclusive}
            if spare:
                (self._wanted_excl if exclusive else self._wanted)[spare] = now
            seen = self._lease_waits.get((owner, pid))
            self._lease_waits[(owner, pid)] = dict(since=seen['since'] if seen else (req or now), last=now, need=need,
                                                   exclusive=exclusive, card=body.get("card"), why=why)
            return {"waiting": True}

    # --- вспомогательное ---
    def pool_backends(self, pool):
        return [b for b in self.backends if b.pool == pool and b.alive()]

    def inflight(self, b):
        rows = jobs_where(b.pool, ("running", "submitting", "uncertain", "cancelling"))
        return sum(1 for r in rows if r["backend_port"] == b.port)

    def card_taken(self):
        return {b.uuid for b in self.backends} | {r[0] for r in self._lease_rows() if r[3]}

    def card_pool(self, uuid_):
        for b in self.backends:
            if b.alive() and b.uuid == uuid_:
                return b.pool
        return None

    def _video_active(self):
        """Видеопул h3 реально работает (есть его бэкенд или его задания в очереди)."""
        if "h3" not in POOLS():
            return False
        if any(b.pool == "h3" and b.alive() for b in self.backends):
            return True
        return bool(jobs_where("h3", ("queued", "running")))

    def _card_order_key(self, pool):
        """Ключ сортировки карт для выбора под пул: affinity пула, плюс уступка 6000 видео.

        krea: обычно порядок 6000→4090 (affinity=None → card_prio). Но пока активен
        видеопул h3 — картинки уступают ему 6000 и садятся на 4090. h3: сначала 6000
        (там 96 ГБ). Пока h3 выключен в конфиге, уступка не срабатывает — поведение
        прежнее, это задел на эпоху видео."""
        aff = POOLS()[pool].get("card_affinity")
        cede_6000 = (pool == "krea" and self._video_active())

        def key(card):
            name = card["name"]
            if cede_6000:
                return (0 if "4090" in name else 1, card_prio(name))
            if aff:
                for i, want in enumerate(aff):
                    if want in name:
                        return (i, 0)
                return (len(aff), 0)
            return (card_prio(name), 0)
        return key

    def pick_card(self, pool, avoid=()):
        """Карта без нашего бэкенда, где хватает памяти под модель с запасом, лучшая по affinity пула.
        Чужие задания карту не блокируют: делим её, пока хватает памяти; замеры и аренды целиком — нет."""
        taken, now, rows = self.card_taken(), time.time(), self._lease_rows()
        order = self._card_order_key(pool)
        cands = [c for c in self._gpu_cache if c["uuid"] not in taken and not self._measuring.get(c["uuid"])
                 and now - max(self._wanted.get(c["uuid"], 0), self._wanted_excl.get(c["uuid"], 0)) >= 10
                 and card_label(c["name"]) not in avoid and self.cooldown.get(c["uuid"], 0) < now
                 and self._room_ok(c, FOREIGN_NEED_MB, now, rows)]
        if not cands:
            return None
        # карта, где чужой расчёт уже грузит GPU, — после простаивающей
        cands.sort(key=lambda c: (self.contended(c["uuid"]) or bool(self._foreign.get(c["uuid"])) and c["util"] >= FOREIGN_FREE_UTIL,)
                   + tuple(order(c)))
        return cands[0]

    def ensure_backend(self, pool, avoid=()):
        """Возвращает бэкенд пула со свободным слотом, при нужде поднимает новый."""
        now, rows = time.time(), self._lease_rows()
        cand = [b for b in self.pool_backends(pool)
                if not b.remote and b.ready and not b.blocked and b.card not in avoid and self.inflight(b) < MAXDEPTH and self.card_pool(b.uuid) == pool
                and self._usable(b, now, rows)]
        if cand:
            cand.sort(key=lambda b: (card_prio(b.card), self.inflight(b)))
            return cand[0]
        # свободного слота нет — пробуем занять ещё одну карту
        spec = POOLS()[pool]
        used_ports = {b.port for b in self.backends if b.alive()}
        free_ports = [p for p in spec["ports"] if p not in used_ports]
        if not free_ports:
            return None
        card = self.pick_card(pool, avoid)
        if card is None:
            self.preempt_for(pool)
            return None
        # порт может держать чужой сервер: проверка готовности поймала бы его ответ
        port = next((p for p in free_ports if not _port_busy(p)), None)
        if port is None:
            glog("ports %s busy, skip start" % free_ports)
            return None
        b = Backend(pool, port, card)
        self.backends.append(b)
        b.start_async()
        return None

    def preempt_for(self, pool, priority=None):
        """Обычное задание вытесняет наш фон; пул может освободить чужой тёплый слот."""
        if priority is not None and priority >= 0:
            for b in self.backends:
                active = [r for r in jobs_where(b.pool, ('running', 'submitting', 'uncertain', 'cancelling'))
                          if r['backend_port'] == b.port]
                if not active or any(r['prio_q'] >= 0 or r['state'] != 'running' for r in active):
                    continue
                if b.remote and not getattr(b, 'targeted_interrupt', False):
                    continue
                queue = b.get('/queue', timeout=3)
                if queue is None:
                    continue
                ids = {r['bpid'] for r in active}
                if any(x[1] not in ids for x in queue.get('queue_running', []) + queue.get('queue_pending', [])):
                    continue
                for r in active:
                    if r['bg_preempt']:
                        continue
                    # Флаг пишется до запроса: потеря ответа не допускает дублирования.
                    job_set(r['id'], bg_preempt=1)
                    try:
                        b._req('/queue', {'delete': [r['bpid']]}, timeout=3)
                        b._req('/interrupt', {'prompt_id': r['bpid']}, timeout=3)
                    except OSError:
                        pass
                return None
            return None

        victims = [b for b in self.backends if not b.remote and b.alive() and not b.starting and not b.blocked
                   and b.pool != pool and self.inflight(b) == 0]
        if not victims:
            return None
        victims.sort(key=lambda b: -card_prio(b.card))  # сначала младшая карта (4090)
        v = victims[0]
        card = {"uuid": v.uuid, "name": v.card, "used": 0, "util": 0, "prio": card_prio(v.card)}
        glog("preempt %s:%d on %s for pool %s" % (v.pool, v.port, v.card, pool))
        if v.stop():
            self.backends.remove(v)
            self._inventory_ts = 0
        return None  # Следующий тик повторно проверит свободную память.

    # --- главный цикл ---
    def refresh_origins(self):
        # Карта вызовов приходит с хаба чуть позже самого POST /prompt.
        known = chat_origin.mappings()
        with _LK:
            pending = db().execute("SELECT DISTINCT client_id FROM jobs WHERE origin=client_id"
                                   " AND (chat_title LIKE '%(сопоставление)' OR chat_title='Источник не указан')").fetchall()
            for (call,) in pending:
                source = known.get(call)
                if not source:
                    continue
                db().execute("UPDATE jobs SET origin=?,chat_title=? WHERE client_id=?"
                             " AND origin=client_id AND (chat_title LIKE '%(сопоставление)'"
                             " OR chat_title='Источник не указан')",
                             (source['thread_id'], source['title'][:200], call))
            # Отвязанные job_*.cmd не наследуют GPUQ_CALL_ID: чат известен по имени задачи.
            for jid, task in db().execute("SELECT id, task FROM jobs WHERE origin=client_id AND task LIKE 'job%'"
                                          " AND (chat_title LIKE '%(сопоставление)' OR chat_title='Источник не указан')").fetchall():
                source = known.get('job:' + task.split(' → ')[0].lower())
                if source:
                    db().execute("UPDATE jobs SET origin=?,chat_title=? WHERE id=?",
                                 (source['thread_id'], source['title'][:200], jid))
            db().commit()

    def tick(self):
        self.refresh_origins()
        self.refresh_inventory()
        self.leased_cards()
        if not _CFG.get('test_mode') and not self._pc_busy and time.time() - self._pc_ts >= 10:
            self._pc_busy = True
            def pc_sample():
                try:
                    self._pc = pcstat.sample()
                except Exception:
                    glog('pc: ' + traceback.format_exc()[-300:])
                finally:
                    self._pc_ts, self._pc_busy = time.time(), False
            threading.Thread(target=pc_sample, daemon=True).start()
        if _CFG.get('free_idle_comfy') and not _CFG.get('test_mode') and not self.idle_monitor.running and time.time() - self.idle_monitor.checked >= CHECK_SECONDS:
            self.idle_monitor.running = True
            def check_idle():
                try:
                    self.idle_monitor.check()
                except Exception:
                    glog('idle monitor: ' + traceback.format_exc()[-600:])
                finally:
                    self.idle_monitor.checked = time.time()
                    self.idle_monitor.running = False
            threading.Thread(target=check_idle, daemon=True).start()
        rows = self._lease_rows()
        self._track_contention(time.time())
        self._watch_cards(time.time(), rows)
        for token in set(self._lease_peak) - {r[6] for r in rows if len(r) > 6}:   # set() — снимок без гонки с HTTP
            self._lease_peak.pop(token, None)
        if not _CFG.get('test_mode'):
            import cloud   # облачные карты: в этой редакции пустая заглушка
            cloud.keep(self, CARD_SPEED, STATE_DIR, glog)
        for b in list(self.backends):
            if b.remote:
                b.probe()
                continue
            # Чужие задания и обычные аренды карту делят; останавливаемся только ради замера и аренды целиком.
            measuring = self._measuring.get(b.uuid)
            b.blocked = self._exclusive(b.uuid, rows) or bool(measuring)
            if not b.ready and not b.starting and b.alive():
                b.stop()
            if b.blocked and b.ready and not self.inflight(b):
                b.stop()
                event('', 'Карта %s отдана %s' % (b.card, 'замеру' if measuring else 'аренде целиком'))
            if not b.alive():
                if not b.stop():
                    b.blocked = True
                    continue
                for r in jobs_where(b.pool, ('running', 'submitting', 'uncertain', 'cancelling')):
                    if r['backend_port'] == b.port:
                        self._requeue_or_fail(r, 'Бэкенд остановился')
                self.cooldown[b.uuid] = time.time() + 20
                self.backends.remove(b)
        for pool in POOLS():
            for r in jobs_where(pool, ('running', 'submitting', 'uncertain', 'cancelling')):
                self._poll_running(r)
        # Один слот на узел сохраняет честное чередование чатов и не прячет очередь в ComfyUI.
        pending = [(pool, r) for pool in POOLS() for r in queued_sorted(pool)]
        pending.sort(key=lambda item: -item[1]['prio_q'])
        for pool, r in pending:
            with self.scheduling:
                if job_row(r['id'])['state'] != 'queued':
                    continue
                graph = json.loads(r['graph'])
                if not valid_graph(graph):
                    job_set(r['id'],state='error',done_ts=time.time(),error='Некорректный граф в сохранённой очереди')
                    continue
                avoid = json.loads(r['avoid'] or '[]')
                b = self._assign_backend(pool, True, avoid, graph, r['prio_q'], r['id'])
                if b is None:
                    self.preempt_for(pool, r['prio_q'])
                    if r['attempts'] and time.time() - (r['dispatch_ts'] or r['submit_ts']) > 600:
                        job_set(r['id'], state='error', done_ts=time.time(), error='Повтор не выполнен: за 10 минут не появился другой совместимый узел')
                        event(r['id'], 'Нет другого совместимого узла для повтора')
                    continue
                self._forward(r, b)
        now = time.time()
        self._log_waits(now)
        self.sample_history()
        cards = {c['uuid']: c for c in self._gpu_cache}
        for b in list(self.backends):
            if b.remote or not b.ready or not b.alive() or self.inflight(b):
                continue
            idle = now - b.last_used
            c = cards.get(b.uuid)
            # чужим заданиям рядом не хватает памяти или её ждёт аренда — выгружаем простаивающую модель
            short = bool(c and c.get('total') and self._foreign.get(b.uuid) and c['total'] - c['used'] < LOW_FREE_MB)
            wanted = now - self._wanted.get(b.uuid, 0) < 10
            if not b.freed and (idle > IDLE_FREE or short or wanted):
                b.free()
            if not POOLS()[b.pool]['warm'] and idle > IDLE_FREE * 4:
                b.stop()

    def _log_waits(self, now):
        """Раз в WAIT_LOG_S, пока задания или аренды ждут дольше минуты: что на каждой карте и узле мешает."""
        waiting = [r for p in POOLS() for r in queued_sorted(p) if now - r['submit_ts'] > 60]
        for key, w in list(self._lease_waits.items()):
            if now - w['last'] > 120:          # клиент перестал спрашивать: ушёл или получил карту под другим pid
                self._lease_waits.pop(key, None)
        held = [(k, w) for k, w in list(self._lease_waits.items()) if now - w['last'] < 30 and now - w['since'] > 60]
        if not (waiting or held) or now - self._wait_log_ts < WAIT_LOG_S:
            return
        self._wait_log_ts = now
        for (owner, _pid), w in sorted(held, key=lambda kw: kw[1]['since']):
            glog('аренда ждёт %d мин: «%s» %s ГБ%s на %s | %s' % (
                (now - w['since']) // 60, re.sub(r'\d{6,}\w*$', '', owner)[:40], gb(w['need']),
                ' целиком' if w['exclusive'] else '', w['card'] or 'любой карте',
                ' | '.join('%s: %s' % kv for kv in w['why'].items()) or 'карт нет'))
        if not waiting:
            return
        rows, parts = self._lease_rows(), []
        for c in self._gpu_cache:
            u = c['uuid']
            bs = [b for b in self.backends if b.uuid == u and not b.remote]
            busy = sum(self.inflight(b) for b in bs)
            state = ('ComfyUI запускается' if any(b.starting for b in bs) else 'считает %d' % busy if busy
                     else 'бэкенда нет' if not bs else 'модель выгружена' if all(b.freed for b in bs) else 'ждёт задание')
            leases = ', '.join('%s %.0f ГБ' % (re.sub(r'\d{6,}\w*$', '', str(r[1]))[:28], (r[2] or 0) / 1024)
                               for r in rows if r[0] == u)
            parts.append('%s: %s, свободно %s ГБ, обещано арендам %s ГБ, загрузка %d%%%s%s%s' % (
                card_label(c['name']), state, gb((c.get('total') or 0) - (c.get('used') or 0)),
                gb(self._pending(u, now, rows)), c.get('util') or 0,
                ', считает чужая задача' if self.contended(u) else '', ', аренды: ' + leases if leases else '',
                ', замер' if self._measuring.get(u) else ''))
        for b in self.backends:
            if b.remote:
                parts.append('%s: %s' % (b.card, 'не в сети' if not b.ready else 'занят своей очередью' if b.blocked
                                         else 'считает' if self.inflight(b) else 'свободен'))
        oldest = min(waiting, key=lambda r: r['submit_ts'])
        glog('ожидают раздачи: %d, дольше всех %d мин («%s», не на %s) | %s' % (
            len(waiting), (now - oldest['submit_ts']) // 60, (oldest['chat_title'] or oldest['task'] or '?')[:50],
            ', '.join(json.loads(oldest['avoid'] or '[]')) or '—', ' | '.join(parts)))

    def _background_free(self, b):
        return not any(self.inflight(x) for x in self.backends if x.uuid == b.uuid) and not any(
            row[0] == b.uuid for row in self._lease_rows())

    def _track_contention(self, now):
        """Отметка «на карте считает чужая задача»: пока наши задания на ней не идут, загрузка карты высокая.
        Держится, пока жив хотя бы один из тех процессов, а простой карты не подтвердился дольше CONTEND_HOLD:
        видео и обучение между стадиями ненадолго отпускают карту. Пока считаем мы сами, загрузку не различить —
        отметка остаётся прежней."""
        for c in self._gpu_cache:
            u = c['uuid']
            pids = {p for p in self._observed.get(u) or () if isinstance(p, int)}
            seen = self._contend.get(u)
            if seen and not seen[1] & pids:
                self._contend.pop(u, None)
                seen = None
            if not pids or any(b.starting or self.inflight(b) or now - b.last_used < 3
                               for b in self.backends if b.uuid == u and not b.remote):
                continue
            if (c.get('util') or 0) >= CONTEND_UTIL:
                self._contend[u] = (now, pids)
            elif seen and now - seen[0] > CONTEND_HOLD:
                self._contend.pop(u, None)

    def contended(self, u):
        return u in self._contend

    def _deep_slot(self, pool, local, loaded, now):
        """Бэкенд спокойной карты, где та же модель досчитает быстрее STICKY_WAIT_S: кадр ждёт в его ComfyUI
        и стартует сразу после текущего, без паузы диспетчера и без смены модели на другой карте."""
        durations, best = None, None
        for b in local:
            if self.contended(b.uuid) or loaded(b) > 1 or not 0 < self.inflight(b) < DEPTH_SAME:
                continue
            active = [r for r in jobs_where(pool, ('running',)) if r['backend_port'] == b.port]
            if len(active) != 1 or not active[0]['bpid'] or active[0]['prio_q'] < 0:
                continue
            durations = durations or self._durations()
            est = self.estimate(durations, pool, active[0]['signature'], b.card)
            left = None if est is None else est - (now - (active[0]['start_ts'] or now))
            if left is not None and 0 < left <= STICKY_WAIT_S and (best is None or left < best[0]):
                best = (left, b)
        return best[1] if best else None

    def _start_calm(self, pool, avoid):
        """Карта без чужого расчёта для пула: её бэкенд уже поднимается или поднимаем сейчас. False — такой нет."""
        if any(b.pool == pool and not b.remote and b.starting and b.card not in avoid and not self.contended(b.uuid)
               for b in self.backends):
            return True
        used = {b.port for b in self.backends if b.alive()}
        ports = [p for p in POOLS()[pool]['ports'] if p not in used]
        card = self.pick_card(pool, avoid) if ports else None
        if card is None or self.contended(card['uuid']):
            return False
        port = next((p for p in ports if not _port_busy(p)), None)
        if port is None:
            return False
        b = Backend(pool, port, card)
        self.backends.append(b)
        b.start_async()
        glog('start %s on %s: на другой карте считает чужая задача' % (pool, b.card))
        return True

    def _assign_backend(self, pool, allow_start, avoid=(), graph=None, priority=0, job_id=None):
        """Узел для задания. Сначала карты ПК без чужого расчёта (рядом с видео или обучением кадр идёт в 2–3 раза
        дольше и тормозит их): с этой моделью в памяти, потом пустая, потом со сменой модели. Та же модель вот-вот
        освободится — кадр ждёт в её ComfyUI. Карту с чужим расчётом берём, только если спокойной нет и не будет."""
        now, rows = time.time(), self._lease_rows()
        local = [b for b in self.pool_backends(pool) if b.ready and not b.blocked
                 and b.card not in avoid and not b.remote and self._usable(b, now, rows)]
        cand = [b for b in local if self.inflight(b) < MAXDEPTH]
        if priority < 0:
            cand = [b for b in cand if self._background_free(b)]
            # Обычная очередь всех пулов имеет преимущество перед фоном.
            if any(r['prio_q'] >= 0 for p in POOLS() for r in queued_sorted(p)):
                return None
        key = model_key(graph or {})

        def loaded(b):
            """0 — нужная модель уже в памяти; 1 — те же веса, другие LoRA (1–2 с); 2 — память пуста; 3 — смена модели."""
            held = None if getattr(b, 'freed', False) else getattr(b, 'model_key', None)
            if not held:
                return 2
            want = backend_model_key(b, graph or {}) if key else None
            return 0 if held == want else 1 if want and weights_of(held) == weights_of(want) else 3

        def rank(b):
            return (loaded(b), card_prio(b.card))
        calm = [b for b in cand if not self.contended(b.uuid)]
        best = min(calm, key=rank) if calm else None
        if best is not None and (loaded(best) <= 1 or priority < 0):
            return best
        if priority >= 0 and key:
            deep = self._deep_slot(pool, local, loaded, now)
            if deep is not None:
                return deep
        if best is not None:
            return best
        if cand and priority < 0:
            return None   # фон рядом с чужим расчётом не садится
        if cand:
            # Спокойная карта занята нашим заданием, её бэкенд поднимается или его можно поднять — ждём её.
            if any(not self.contended(b.uuid) for b in local) or (allow_start and self._start_calm(pool, avoid)):
                return None
            return min(cand, key=rank)
        if allow_start:
            self.ensure_backend(pool, avoid)
        for b in sorted(self.pool_backends(pool), key=lambda node: CARD_SPEED.get(node.card, 1.0)):
            if b.remote and b.ready and not b.blocked and b.card not in avoid and not self.inflight(b) and (priority >= 0 or self._background_free(b)):
                if b.supports(graph or {}):
                    durations = self._durations()
                    # Форма графа определяется тем же кодом, что при постановке задания.
                    sig = graph_signature(graph or {})
                    remote_seconds = self.estimate(durations, pool, sig, b.card)
                    if remote_seconds is not None:
                        for local in self.pool_backends(pool):
                            if local.remote or local.blocked or local.card in avoid or self._exclusive(local.uuid, rows) or self._measuring.get(local.uuid):
                                continue
                            if local.starting and COLD_START < remote_seconds:
                                return None
                            for active in jobs_where(pool, ('running',)):
                                if active['backend_port'] != local.port:
                                    continue
                                estimate = self.estimate(durations, pool, active['signature'], local.card)
                                remaining = None if estimate is None else estimate - (now - (active['start_ts'] or now))
                                if remaining is not None and 0 < remaining < remote_seconds:
                                    return None
                    return b
        return None

    def _forward(self, r, b):
        graph = json.loads(r['graph'])
        if b.remote:
            try:
                graph = b.prepare(graph, POOLS()[r['pool']]['input_dir'])
            except (OSError, ValueError, KeyError) as e:
                b.blocked = True
                event(r['id'], 'Не удалось передать референсы на %s: %s' % (b.card, e))
                return
        # Этот префикс запрещает внутреннему comfy-farm-router повторно распределять задание.
        token = 'krea2-farm-gpuq-' + r['id'] + '-' + uuid.uuid4().hex
        job_set(r['id'], state='submitting', backend_port=b.port, token=token,
                card=b.card, dispatch_ts=time.time(), start_ts=time.time(), error=None, retry_stop=0, model_event=None)
        if not b.remote:  # слушатель превью подключается тем же токеном до отправки графа
            LIVE.watch(r['id'], b.port, token, lambda jid=r['id']: (job_row(jid) or {'state': ''})['state'] in LIVE_STATES)
        bpid, errs = b.submit(graph, token)
        if bpid is None:
            if str(errs).startswith('reject:'):
                job_set(r['id'], state='error', error=str(errs)[:1500], done_ts=time.time())
                event(r['id'], 'Граф отклонён на %s: %s' % (b.card, str(errs)[:200]))
            else:
                job_set(r['id'], state='uncertain', error='Ответ на отправку потерян; проверяем принятие')
                event(r['id'], 'Потерян ответ %s; повтор заблокирован до сверки' % b.card)
            return
        if not b.remote and (b.freed or not b.ramp_ts):
            b.ramp_ts = time.time()
        self._remember_model(r, b)
        b.freed = False
        b.last_used = time.time()
        self._sticky_since.pop(r['id'], None)
        job_set(r['id'], state='running', bpid=bpid)

        glog('run %s -> %s:%d bpid=%s' % (r['id'], b.pool, b.port, bpid))

    def _remember_model(self, r, b):
        key = backend_model_key(b, json.loads(r['graph']))
        previous = getattr(b, 'model_key', None) if not b.freed else None
        model_event = ('hit' if previous == key else 'swap') if key else None
        b.model_key = key
        job_set(r['id'], model_event=model_event)
        if model_event:
            self.resource_notice('model_' + model_event, 'Модель: ' + model_event, b.card)

    def _recover_submission(self, r, b):
        queue = b.get('/queue', timeout=3)
        hist = b.get('/history?max_items=1000', timeout=5)
        if queue is None or hist is None:
            return
        rows = list(queue.get('queue_running', [])) + list(queue.get('queue_pending', []))
        rows += [v.get('prompt', []) for v in hist.values() if isinstance(v, dict)]
        for row in rows:
            if len(row) > 3 and isinstance(row[3], dict) and row[3].get('client_id') == r['token']:
                if r['model_event'] is None:
                    self._remember_model(r, b)
                b.freed = False
                b.last_used = time.time()
                job_set(r['id'], state='cancelling' if r['state']=='cancelling' else 'running', bpid=row[1], error=None)
                return
        # Отсутствие в ограниченной истории не доказывает, что запрос не выполнялся.
        if r['state'] not in ('uncertain', 'cancelling'):
            job_set(r['id'], state='uncertain', error='Не удалось подтвердить принятие задания')
            event(r['id'], 'Нужна проверка потерянной отправки на %s' % b.card)

    def _poll_running(self, r):
        b = next((x for x in self.backends if x.port == r['backend_port']), None)
        if b is None:
            job_set(r['id'], error='Нет подтверждения остановки прежнего бэкенда')
            return
        if not r['bpid']:
            self._recover_submission(r, b)
            current = job_row(r['id'])
            elapsed = time.time() - (r['start_ts'] or time.time())
            if (not current['bpid'] and not b.remote and
                    (elapsed >= float(POOLS()[r['pool']].get('job_timeout', JOB_TIMEOUT)) or r['state']=='cancelling')):
                if b.stop():
                    self._requeue_or_fail(current, 'Остановлена потерянная локальная отправка')
            return
        hist = b.get('/history/' + r['bpid'], timeout=3)
        entry = (hist or {}).get(r['bpid'])
        if entry:
            status = (entry.get('status') or {}).get('status_str', '')
            if r['state'] == 'cancelling':
                self._interrupted.pop(r['id'], None)
                job_set(r['id'], state='cancelled', done_ts=time.time())
                if not b.remote:
                    self._next_started(r, b)
                return
            if status == 'success':
                try:
                    entry, media, receipts = self.collect_media(r, b, entry)
                except (OSError, ValueError) as e:
                    job_set(r['id'], error='Повтор доставки результата: ' + str(e)[:400])
                    return  # Готовый кадр не генерируем повторно из-за сбоя доставки.
                fields = dict(state='done', result=json.dumps(entry), media=json.dumps(media), done_ts=time.time(), error=None)
                started = None if b.remote else exec_start(entry)
                if started and r['start_ts'] and started - r['start_ts'] > 2 and started < fields['done_ts']:
                    fields['start_ts'] = started   # кадр ждал в ComfyUI за предыдущим: длительность — с начала исполнения
                job_set(r['id'], **fields)
                if not b.remote:
                    self._next_started(r, b)
                if b.remote and receipts:
                    b.helper.retention.cleanup_after_download(b.card, r['bpid'], hist[r['bpid']], receipts)
                b.last_used = time.time()
                glog('done ' + r['id'])
                return
            if status == 'error' and r['bg_preempt']:
                self._resume_background(r)
                return
            if status == 'error':
                err = json.dumps(entry.get('status'), ensure_ascii=False)
                if r['retry_stop'] or any(s in err.lower() for s in ('outofmemory', 'out of memory', 'cuda error', 'device lost')):
                    self._requeue_or_fail(r, ('Сторож остановил зависшее задание на ' if r['retry_stop'] else 'Ошибка памяти/CUDA на ') + b.card)
                    if not b.remote:
                        b.stop()
                else:
                    job_set(r['id'], state='error', result=json.dumps(entry), error=err[:1500], done_ts=time.time())
                    event(r['id'], 'Ошибка графа на ' + b.card)
                    if not b.remote:
                        self._next_started(r, b)
                b.last_used = time.time()
                return
        if r['bg_preempt']:
            queue = b.get('/queue', timeout=3)
            if queue is not None and not any(x[1] == r['bpid'] for x in queue.get('queue_running', []) + queue.get('queue_pending', [])):
                self._resume_background(r)
            return
        elapsed = time.time() - (r['start_ts'] or time.time())
        timeout = float(POOLS()[r['pool']].get('job_timeout', JOB_TIMEOUT))
        if elapsed < timeout and r['state'] != 'cancelling':
            return
        if b.remote:
            # Только адресная отмена нашего id; потеря сети не разрешает повтор.
            q = b.get('/queue', timeout=3)
            if q is None:
                job_set(r['id'], error='Узел не отвечает; ждём подтверждения остановки')
                return
            active = q.get('queue_running', []) + q.get('queue_pending', [])
            if any(x[1] == r['bpid'] for x in active):
                try:
                    if r['state'] != 'cancelling':
                        job_set(r['id'], retry_stop=1)
                    b._req('/queue', {'delete': [r['bpid']]}, timeout=3)
                    if any(x[1] == r['bpid'] for x in q.get('queue_running', [])):
                        if getattr(b,'targeted_interrupt',False):
                            b._req('/interrupt', {'prompt_id': r['bpid']}, timeout=3)
                        else:
                            job_set(r['id'], error='Не подтверждена адресная отмена на ноутбуке; ждём завершения')
                except OSError:
                    pass
                return
        else:
            if r['state'] == 'cancelling' and self._drop_pending(r, b):
                job_set(r['id'], state='cancelled', done_ts=time.time())
                event(r['id'], 'Отменено до начала исполнения на ' + b.card)
                return
            if r['state'] == 'cancelling' and r['bpid'] and any(
                    x['backend_port'] == b.port and x['id'] != r['id'] for x in jobs_where(r['pool'], ('running',))):
                # За отменяемым кадром ждёт следующий: прерываем только этот кадр, бэкенд и очередь за ним живут.
                first = self._interrupted.setdefault(r['id'], time.time())
                if time.time() - first < 60:
                    try:
                        b._req('/interrupt', {'prompt_id': r['bpid']}, timeout=3)
                    except OSError:
                        pass
                    return
            self._interrupted.pop(r['id'], None)
            if not b.stop():
                job_set(r['id'], error='Не удалось подтвердить остановку бэкенда; повтор заблокирован')
                return
        if r['state'] == 'cancelling':
            job_set(r['id'], state='cancelled', done_ts=time.time())
        else:
            self._requeue_or_fail(r, 'Превышено время задания на ' + b.card)

    def _next_started(self, r, b):
        """Кадр, ждавший в ComfyUI за законченным (DEPTH_SAME), начинает считаться сейчас."""
        now = time.time()
        for nxt in jobs_where(r['pool'], ('running',)):
            if nxt['backend_port'] == b.port and nxt['id'] != r['id'] and (nxt['start_ts'] or 0) < now:
                job_set(nxt['id'], start_ts=now)

    def _drop_pending(self, r, b):
        """Отмена кадра, который ещё ждёт в очереди ComfyUI за другим: убираем только его, бэкенд не трогаем."""
        if not r['bpid']:
            return False
        queue = b.get('/queue', timeout=3)
        if queue is None or not any(x[1] == r['bpid'] for x in queue.get('queue_pending', [])):
            return False
        try:
            b._req('/queue', {'delete': [r['bpid']]}, timeout=3)
        except OSError:
            return False
        after = b.get('/queue', timeout=3)
        return after is not None and not any(x[1] == r['bpid'] for x in after.get('queue_running', []) + after.get('queue_pending', []))

    def _save_attempt(self, r):
        if r['start_ts']:
            with _LK:
                db().execute('INSERT OR IGNORE INTO job_spans VALUES(?,?,?,?)',
                             (r['id'], r['start_ts'], time.time(), r['card']))
                db().commit()

    def _resume_background(self, r):
        self._save_attempt(r)
        job_set(r['id'], state='queued', bg_preempt=0, backend_port=None, bpid=None, token=None,
                start_ts=None, error='Фоновое задание уступило обычной очереди')
        event(r['id'], 'Фоновое задание возвращено в очередь без расходования попытки')

    def _requeue_or_fail(self, r, reason='Бэкенд остановился'):
        current = job_row(r['id'])
        if not current or current['state'] in ('done', 'error', 'cancelled', 'queued'):
            return
        if current['state'] == 'cancelling':
            job_set(r['id'], state='cancelled', done_ts=time.time())
            return
        attempts = (current['attempts'] or 0) + 1
        avoid = json.loads(current['avoid'] or '[]')
        if current['card'] and current['card'] not in avoid:
            if not {card_label(c['name']) for c in self._gpu_cache} <= set(avoid) | {current['card']}:   # упавшую карту исключаем, только пока остаётся другая; запреты клиента не трогаем
                avoid.append(current['card'])
        if attempts <= MAX_ATTEMPTS:
            self._save_attempt(current)
            job_set(r['id'], state='queued', attempts=attempts, avoid=json.dumps(avoid),
                    backend_port=None, bpid=None, token=None, start_ts=None, error=reason)
            event(r['id'], reason + '; ожидает другой свободный узел')
        else:
            job_set(r['id'], state='error', attempts=attempts, error=reason + '; исчерпаны повторы', done_ts=time.time())
            event(r['id'], reason + '; исчерпаны повторы')

    def collect_media(self, r, b, entry):
        from urllib.parse import urlencode
        import copy
        result = copy.deepcopy(entry)
        media, receipts = [], []
        folder = Path(POOLS()[r['pool']]['output_dir']) / 'gpuq' / r['id']
        for node in result.get('outputs', {}).values():
            for kind in ('images', 'gifs', 'videos', 'audio'):
                for descriptor in node.get(kind) or []:
                    if not isinstance(descriptor, dict) or not descriptor.get('filename'):
                        continue
                    suffix = Path(descriptor['filename']).suffix.lower()
                    if suffix not in ('.png','.jpg','.jpeg','.webp','.gif','.mp4','.webm','.mov','.wav','.mp3','.flac'):
                        continue
                    folder.mkdir(parents=True, exist_ok=True)
                    dest = folder / ('%03d%s' % (len(media), suffix))
                    source = {k: descriptor.get(k) or ('output' if k == 'type' else '')
                              for k in ('filename', 'subfolder', 'type')}
                    if b.remote:
                        with urllib.request.urlopen(b.base + '/view?' + urlencode(source), timeout=30) as response:
                            receipts.append(b.helper.retention.atomic_download(response, dest, source))
                    else:
                        original = self.view_file(r['pool'], source['filename'], source['subfolder'], source['type'])
                        if not original:
                            raise OSError('Не найден результат ' + source['filename'])
                        shutil.copyfile(original, dest.with_suffix(suffix + '.part'))
                        os.replace(dest.with_suffix(suffix + '.part'), dest)
                    if not dest.stat().st_size:
                        raise OSError('Пустой результат')
                    if suffix in ('.png','.jpg','.jpeg','.webp','.gif'):
                        from PIL import Image
                        with Image.open(dest) as im:
                            im.verify()
                    descriptor.update(filename=dest.name, subfolder='gpuq/' + r['id'], type='output')
                    media.append({'path': str(dest), 'filename': source['filename'],
                                  'type': mimetypes.guess_type(str(dest))[0] or 'application/octet-stream'})
        return result, media, receipts

    def _run_supervise(self):
        while not self._stop:
            try:
                self.run()
            except Exception:
                glog('Диспетчер перезапущен\n' + traceback.format_exc())
            if not self._stop:
                time.sleep(2)

    def run(self):
        while not self._stop:
            try:
                self.tick()
            except Exception:
                glog('tick error\n' + traceback.format_exc())
            time.sleep(TICK)

    # --- для фасада ---
    def system_stats(self, pool):
        for b in self.pool_backends(pool):
            if b.remote or not b.ready:
                continue
            st = b.get("/system_stats", timeout=5)
            if st:
                st["gpuq"] = True
                self.stats_cache[pool] = st
                return st
        spec = POOLS()[pool]
        cached = self.stats_cache.get(pool)
        if cached:
            cached["gpuq"] = True
            return cached
        # Холодный ответ: бэкендов нет. devices не пустой — иначе ферма (farm.status)
        # ловит IndexError на devices[0] и считает локальные карты офлайн, уводя их
        # долю на ноутбуки. Имя здесь — только ярлык, карту выбирает диспетчер.
        return {"system": {"os": "nt", "comfyui_version": "gpuq",
                           "argv": [str(Path(spec["root"]) / "main.py")],
                           "pytorch_version": "2.7.0+cu130", "embedded_python": False},
                "devices": [{"name": "GpuQ", "type": "cuda",
                             "index": 0, "vram_total": 0, "vram_free": 0,
                             "torch_vram_total": 0, "torch_vram_free": 0}],
                "gpuq": True}

    def view_file(self, pool, filename, subfolder, typ):
        spec = POOLS()[pool]
        if not filename or any(x in filename + subfolder for x in ('..', ':')) or os.path.isabs(filename) or os.path.isabs(subfolder):
            return None
        if typ == "input":
            base = spec["input_dir"]
            cand = [os.path.join(base, subfolder, filename)]
        elif typ == "temp":
            cand = [str(b.temp_dir / subfolder / filename)
                    for b in self.backends if b.pool == pool and not b.remote]
        else:
            cand = [os.path.join(spec["output_dir"], subfolder, filename)]
        for p in cand:
            if os.path.isfile(p):
                return p
        return None

    def models_folder(self, pool, folder):
        """Список моделей папки (ферме нужны /models/loras для сверки LoRA).

        Живой бэкенд отвечает точно; кэшируем на диск, чтобы отвечать и на холодную
        (после перезапуска ПК — до первого бэкенда). Всегда список, не словарь:
        ферма делает {n for n in ...}, из пустого словаря вышло бы пустое множество."""
        if not folder.isidentifier():
            folder = "loras"
        for b in self.pool_backends(pool):
            r = b.get("/models/" + folder, timeout=10)
            if isinstance(r, list):
                cache = STATE_DIR / ("models_%s_%s.json" % (pool, folder))
                try:
                    cache.write_text(json.dumps(r), encoding="utf-8")
                except OSError:
                    pass
                return r
        cache = STATE_DIR / ("models_%s_%s.json" % (pool, folder))
        try:
            data = json.loads(cache.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
        except (OSError, ValueError):
            pass
        return []

    def _foreign_stats(self):
        """Прошлые задания вне очереди за 14 дней: длительности по (карта, форма) и секунды на единицу работы
        по (карта, модель) и (карта, тип); ключи с None — приведённые к RTX PRO 6000. Кэш 60 с."""
        now = time.time()
        when, cached = self._fdur
        if now - when < 60:
            return cached
        with _LK:
            rows = db().execute("SELECT card,task,what,meta,start_ts,done_ts FROM foreign_jobs WHERE done_ts>? AND err=0"
                                " AND start_ts>0 AND done_ts>start_ts AND (exact=1 OR via IN ('unity', 'farm'))"
                                " ORDER BY done_ts DESC LIMIT 4000", (now - 14 * 86400,)).fetchall()
        sigs, units = defaultdict(list), defaultdict(list)
        for card, task, what, meta, start, done in rows:
            meta, sec, speed = _loads(meta, {}), done - start, CARD_SPEED.get(card, 1.0)
            sig = foreign_signature(task, what, meta)
            if sig:
                sigs[(card, sig)].append(sec)
                sigs[(None, sig)].append(sec / speed)
            work = work_units(meta)
            if work:
                for key in (('model', meta.get('model')), ('kind', meta.get('kind'))):
                    units[(card, key)].append(sec / work)
                    units[(None, key)].append(sec / work / speed)
        result = {'sig': dict(sigs), 'unit': dict(units)}
        self._fdur = (now, result)
        return result

    def _foreign_eta(self, card, task, what, meta, elapsed):
        """(обычно, осталось, примерно ли) для задания вне очереди. Сначала такие же задания на этой карте
        (на другой — с поправкой на скорость), потом пересчёт по объёму работы с той же модели или того же типа,
        иначе — примерно от прошедшего. Остаток есть всегда."""
        stats, speed = self._foreign_stats(), CARD_SPEED.get(card, 1.0)
        sig = foreign_signature(task, what, meta)
        samples = (stats['sig'].get((card, sig)) or [d * speed for d in stats['sig'].get((None, sig), [])]) if sig else []
        if samples:
            typical = _median(samples)
            if elapsed < typical:
                return typical, typical - elapsed, False
            left, approx = remaining_after(samples, elapsed)
            return typical, left, approx
        work = work_units(meta)
        if work:
            for key in (('model', (meta or {}).get('model')), ('kind', (meta or {}).get('kind'))):
                per = stats['unit'].get((card, key)) or [x * speed for x in stats['unit'].get((None, key), [])]
                if per:
                    typical = _median(per) * work
                    return typical, (typical - elapsed if elapsed < typical else max(5.0, 0.15 * elapsed)), True
        return None, max(5.0, 0.25 * elapsed), True

    def _foreign_estimate(self, card, sig):
        """Сколько обычно длится такое же задание на этой карте; на другой — с поправкой на скорость."""
        samples = self._foreign_stats()['sig']
        if not sig:
            return None
        if (card, sig) in samples:
            return _median(samples[(card, sig)])
        return _median(samples[(None, sig)]) * CARD_SPEED.get(card, 1.0) if (None, sig) in samples else None

    def _samples(self):
        """Длительности готовых заданий по (пул, форма, карта); ключи с None — приведённые к RTX PRO 6000.
        Пересчитываются, только когда меняется набор готовых заданий."""
        with _LK:
            stamp = db().execute("SELECT COUNT(*), MAX(done_ts) FROM jobs WHERE state='done'").fetchone()
            if getattr(self, '_dur_stamp', None) == stamp:
                return self._dur_groups
            rows = db().execute("SELECT pool,signature,card,done_ts-start_ts FROM jobs WHERE state='done'"
                                " AND start_ts>0 AND done_ts>start_ts AND card IS NOT NULL"
                                " AND signature IS NOT NULL ORDER BY n DESC LIMIT 2000").fetchall()
        groups = defaultdict(list)
        for pool, sig, card, sec in rows:
            speed = CARD_SPEED.get(card, 1.0)
            groups[(pool, sig, card)].append(sec)
            groups[(pool, sig, None)].append(sec / speed)
            groups[(pool, None, card)].append(sec)
            groups[(pool, None, None)].append(sec / speed)
        self._dur_stamp, self._dur_groups = stamp, dict(groups)
        return self._dur_groups

    def _durations(self):
        """Медианы длительности готовых заданий: форма графа и карта, затем грубее."""
        return {k: _median(v) for k, v in self._samples().items()}

    def _queue_remaining(self, pool, sig, card, elapsed, est):
        """Остаток задания очереди всегда числом: до медианы — по ней, дальше — по прошлым долгим, иначе примерно."""
        if est is not None and elapsed < est:
            return est - elapsed, False
        groups = self._samples()
        speed = CARD_SPEED.get(card, 1.0)
        samples = groups.get((pool, sig, card)) or [d * speed for d in groups.get((pool, sig, None), [])]
        if samples:
            return remaining_after(samples, elapsed)
        return max(5.0, 0.25 * elapsed), True

    @staticmethod
    def estimate(durations, pool, sig, card):
        speed = CARD_SPEED.get(card, 1.0)
        for key, scale in (((pool, sig, card), 1.0), ((pool, sig, None), speed),
                           ((pool, None, card), 1.0), ((pool, None, None), speed)):
            if key in durations:
                return durations[key] * scale
        return None

    def _may_run(self, b, raw_graph, sig):
        """Совместимость ноутбука без сетевых запросов: свежий /object_info, иначе прошлый вердикт."""
        info = getattr(b, 'info', None)
        key = (b.card, sig)
        seen = self._fits.get(key)
        if info and time.time() - info[0] <= 55 and getattr(b, 'helper', None) is not None \
                and (seen is None or seen[0] != info[0]):
            try:
                verdict = bool(b.supports(json.loads(raw_graph)))
            except Exception:
                verdict = False
            seen = self._fits[key] = (info[0], verdict)
        return bool(seen and seen[1])

    def _plan(self, pool, queued, active, durations, now, lrows):
        """Прикидка раздачи по порядку очереди: {id: (старт через, карта, длительность)} и конец всей очереди."""
        nodes, ends, unknown = [], [], False
        by_port = defaultdict(list)
        for a in sorted(active, key=lambda a: a['start_ts'] or now):
            by_port[a['backend_port']].append(a)
        backends = list(self.backends)
        reliable = {b.port for b in backends if b.alive() and b.ready}
        unknown = any(r['state'] != 'running' or r['backend_port'] not in reliable for r in active)
        for b in backends:
            if b.pool != pool or not b.alive():
                continue
            rs = by_port.get(b.port)
            if rs:
                if any(r['state'] != 'running' for r in rs) or not b.ready:
                    continue
                free_at = now
                for i, r in enumerate(rs):   # второй кадр ждёт в ComfyUI за первым (DEPTH_SAME)
                    card = r['card'] or b.card
                    est = self.estimate(durations, pool, r['signature'], card)
                    free_at += self._queue_remaining(pool, r['signature'], card, now - (r['start_ts'] or now) if i == 0 else 0, est)[0]
                ends.append(free_at)
                if b.blocked and not b.remote:
                    continue
            elif b.blocked or not (b.ready or b.starting) or (not b.remote and not self._usable(b, now, lrows)):
                continue
            else:
                free_at = now if b.ready else now + COLD_START
            nodes.append([free_at, b.card, b.remote, b])
        used = {b.port for b in backends if b.alive()}
        slots = len([p for p in POOLS()[pool]['ports'] if p not in used])
        ours = {b.uuid for b in backends}
        for c in self._gpu_cache:
            u = c['uuid']
            if slots and u not in ours and not self._exclusive(u, lrows) and not self._measuring.get(u) \
                    and self._room_ok(c, FOREIGN_NEED_MB, now, lrows):
                nodes.append([max(now, self.cooldown.get(u, 0)) + COLD_START, card_label(c['name']), False, None])
                slots -= 1
        # Как в _assign_backend: карта, где считает чужая задача, — только когда спокойной карты ПК нет.
        noisy = {card_label(c['name']) for c in self._gpu_cache if self.contended(c['uuid'])}
        if any(not n[2] and n[1] not in noisy for n in nodes):
            nodes = [n for n in nodes if n[2] or n[1] not in noisy]
        plan = {}
        for r in queued:
            avoid = json.loads(r['avoid'] or '[]')
            fits = [n for n in nodes if n[1] not in avoid
                    and (not n[2] or self._may_run(n[3], r['graph'], r['signature']))]
            if not fits:
                plan[r['id']] = (None, None, None)
                unknown = True
                continue
            node = min(fits, key=lambda n: (n[0], card_prio(n[1])))
            est = self.estimate(durations, pool, r['signature'], node[1])
            plan[r['id']] = (None if node[0] == float('inf') else node[0] - now, node[1], est)
            if est is None or node[0] == float('inf'):
                unknown = True
                node[0] = float('inf')
            else:
                node[0] += est
                ends.append(node[0])
        return plan, (None if unknown else (max(ends) - now if ends else 0))

    def dashboard(self, limit=100, offset=0, card=None):
        now = time.time()
        LIVE.sweep()
        t = time.localtime(now)
        midnight = time.mktime((t.tm_year, t.tm_mon, t.tm_mday, 0, 0, 0, 0, 0, -1))
        page = ('id','pool','state','client_id','card','submit_ts','start_ts','done_ts','error',
                'attempts','chat_title','signature','media','task','what','prompt_text','meta')
        act = ('id','pool','state','backend_port','signature','card','start_ts','chat_title','error','task','what','meta')
        with _LK:
            # Тяжёлый result нужен только старым записям без сохранённых медиа.
            where, args = ('WHERE card=?', (card,)) if card else ('', ())
            cur = db().execute("SELECT %s, CASE WHEN media IS NULL OR media='[]' THEN result END AS result,"
                               " CASE WHEN what IS NULL OR meta IS NULL THEN graph END AS graph FROM jobs %s"
                               " ORDER BY CASE WHEN state IN ('done','error','cancelled') THEN 1 ELSE 0 END, n DESC"
                               " LIMIT ? OFFSET ?" % (",".join(page), where), args + (limit, offset))
            cols = [d[0] for d in cur.description]
            rows = [dict(zip(cols, x)) for x in cur.fetchall()]
            active = [dict(zip(act, x)) for x in db().execute(
                "SELECT %s FROM jobs WHERE state IN ('running','submitting','uncertain','cancelling')" % ",".join(act))]
            done_today = db().execute("SELECT COUNT(*) FROM jobs WHERE state='done' AND done_ts>=?", (midnight,)).fetchone()[0]
            events = db().execute("SELECT e.ts,e.job_id,e.message FROM events e JOIN jobs j ON j.id=e.job_id"
                                  " WHERE j.state NOT IN ('done','cancelled') AND e.ts>? ORDER BY e.ts DESC LIMIT 200",
                                  (now - 3600,)).fetchall()
            # Готово и ошибки за сутки для точки на иконках трея; не зависят от фильтра карты и страницы.
            notices = db().execute("SELECT id,state,done_ts,chat_title,what,card FROM jobs WHERE state IN ('done','error')"
                                   " AND done_ts>? ORDER BY done_ts DESC LIMIT 20", (now - 86400,)).fetchall()
            frows = db().execute("SELECT id,card,task,what,chat_title,start_ts,seen_ts,done_ts,meta,via,media,err,exact"
                                 " FROM foreign_jobs %s ORDER BY start_ts DESC" % where, args).fetchall()
            resource_rows = db().execute('SELECT ts,kind,message,card,details FROM resource_notices WHERE ts>? '
                                         'ORDER BY ts DESC LIMIT 30', (now - 86400,)).fetchall()
            idle_servers = [dict(_loads(state, {}), port=port) for port, state in db().execute('SELECT port,state FROM idle_servers')]
            bypass_rows = db().execute("SELECT task,chat_title,card,start_ts,COALESCE(done_ts,seen_ts),meta FROM foreign_jobs "
                                       "WHERE (via='foreign' OR via IS NULL) AND COALESCE(done_ts,seen_ts)>=?", (midnight,)).fetchall()
        lrows = self._lease_rows()
        with _LK:
            lease_tokens = db().execute("SELECT token,card FROM leases WHERE expires>=?", (now,)).fetchall()
        leases = defaultdict(list)
        for card_, owner, _need, excl, *_rest in lrows:
            leases[card_].append((owner, bool(excl)))
        durations = self._durations()
        plans, etas, stuck, queued_total, waiting = {}, [], {}, 0, {}
        for pool in POOLS():
            queued = queued_sorted(pool)
            queued_total += len(queued)
            waiting[pool] = len(queued)
            mine = [a for a in active if a['pool'] == pool]
            plan, eta = self._plan(pool, queued, mine, durations, now, lrows)
            etas.append(eta)
            for i, r in enumerate(queued):
                plans[r['id']] = (i + 1,) + plan[r['id']]
            if not mine:
                stuck[pool] = [r['id'] for r in queued if now - r['submit_ts'] > 300]
        ready_ports = {b.port for b in self.backends if b.alive() and b.ready}
        running = {a['id'] for a in active if a['state'] == 'running' and a['backend_port'] in ready_ports}
        jobs, fills = [], []
        for r in rows:
            if r['what'] is None or r['meta'] is None:
                try:
                    graph = json.loads(r['graph']) if r['graph'] else None
                    what, prompt = graph_summary(graph)
                    meta = json.dumps(graph_meta(graph))
                except (ValueError, TypeError):
                    what, prompt, meta = 'Граф ComfyUI', '', '{}'
                r['what'] = r['what'] or what
                r['prompt_text'] = prompt if r['prompt_text'] is None else r['prompt_text']
                r['meta'] = meta
                fills.append((r['what'], r['prompt_text'], r['meta'], r['id']))
            media = json.loads(r['media'] or '[]')
            # Старые результаты тоже видны, пока исходные файлы доступны.
            if not media and r['result'] and r['pool'] in POOLS():
                for node in json.loads(r['result']).get('outputs', {}).values():
                    for kind in ('images','gifs','videos'):
                        for im in node.get(kind) or []:
                            path = self.view_file(r['pool'], im.get('filename',''), im.get('subfolder',''), im.get('type','output'))
                            if path:
                                media.append({'path':path,'filename':im['filename'],'type':mimetypes.guess_type(path)[0] or 'application/octet-stream'})
                if media:
                    job_set(r['id'], media=json.dumps(media))
            job = {k: r[k] for k in ('id','pool','state','client_id','card','submit_ts','start_ts','done_ts','error','attempts')}
            est = progress = remaining = position = starts_in = planned = None
            approx_left = False
            if r['state'] == 'queued':
                position, starts_in, planned, est = plans.get(r['id'], (None, None, None, None))
                if est is None:  # карта ещё не выбрана — длительность по любой карте пула
                    est = self.estimate(durations, r['pool'], r['signature'], planned)
                wait = now - r['submit_ts']
                if starts_in is not None and est is not None:
                    remaining = starts_in + est
            else:
                est = self.estimate(durations, r['pool'], r['signature'], r['card'])
                wait = max(0, (r['start_ts'] or r['submit_ts']) - r['submit_ts'])
                if r['id'] in running:
                    elapsed = now - (r['start_ts'] or now)
                    # Время показываем всегда: дольше обычного — по прошлым долгим, без похожих — примерно.
                    remaining, approx_left = self._queue_remaining(r['pool'], r['signature'], r['card'], elapsed, est)
                    by_steps = LIVE.left(r['id'])
                    if by_steps is not None:
                        # Настоящие шаги сэмплера (+3 с на декодирование): после медианы — только они, до неё — не меньше их.
                        remaining = by_steps + 3 if approx_left else max(remaining, by_steps + 3)
                        approx_left = False
                    progress = round(min(0.99, elapsed / (elapsed + remaining)), 3)
            job.update(chat_title=r['chat_title'] or r['client_id'] or 'Источник не указан',
                       estimated_seconds=max(1, round(est)) if est is not None else None,
                       remaining_seconds=round(remaining) if remaining is not None else None, remaining_approx=approx_left,
                       wait_seconds=round(wait), progress=progress, position=position,
                       starts_in_seconds=round(starts_in) if starts_in is not None else None,
                       planned_card=planned,
                       media=[{'url':'/gpuq/media?job=%s&index=%d'%(r['id'],i),
                               'filename':v['filename'], 'type':v['type'].split('/')[0]} for i,v in enumerate(media)])
            if r['start_ts'] and r['done_ts'] and r['state'] in ('done', 'error', 'cancelled'):
                duration = round(max(0, r['done_ts'] - r['start_ts']))
            elif r['start_ts'] and r['state'] in ('running', 'submitting', 'uncertain', 'cancelling'):
                duration = round(max(0, now - r['start_ts']))
            else:
                duration = None
            job.update(task=r['task'] or '', what=r['what'] or '', prompt=r['prompt_text'] or '',
                       duration_seconds=duration, foreign=False, meta=_loads(r['meta'], {}), via='queue')
            if r['state'] != 'queued':
                job.update(LIVE.info(r['id']))  # превью шага и шаг сэмплера, если бэкенд их шлёт
            jobs.append(job)
        if fills:
            with _LK:
                db().executemany("UPDATE jobs SET what=?, prompt_text=?, meta=? WHERE id=?", fills)
                db().commit()
        backends = list(self.backends)
        by_port = {}
        for a in sorted(active, key=lambda a: -(a['start_ts'] or now)):
            by_port[a['backend_port']] = a   # на карте показываем кадр, который считается, а не ждущий за ним
        stats = self._card_stats(now, midnight)
        workers = []
        for c in self._gpu_cache:
            bs = [b for b in backends if not b.remote and b.uuid == c['uuid']]
            run = next((by_port[b.port] for b in bs if b.port in by_port), None)
            foreign = self._foreign.get(c['uuid'])
            cool = self.cooldown.get(c['uuid'], 0) - now
            owners = ', '.join(o for o, _e in leases.get(c['uuid']) or [])
            near = '; рядом задачи: ' + owners if owners else ''
            room = self._room_ok(c, FOREIGN_NEED_MB, now, lrows)
            if run:
                state, reason = 'генерация', 'Считает задание очереди' + near
                if run['state'] in ('submitting', 'uncertain', 'cancelling'):
                    state, reason = {'submitting': ('отправка', 'Передаём задание исполнителю'),
                                     'uncertain': ('проверка отправки', 'Ждём подтверждения; повтор пока запрещён'),
                                     'cancelling': ('отмена', 'Ждём подтверждённой остановки задания')}[run['state']]
            elif self._exclusive(c['uuid'], lrows):
                state, reason = 'аренда', 'Карта целиком у задачи: ' + owners
            elif self._measuring.get(c['uuid']):
                state, reason = 'замер', 'Идёт замер: %s; карта отдана целиком' % self._measuring[c['uuid']]
            elif owners and not bs:
                state, reason = 'аренда', 'Карту делят задачи: ' + owners + (
                    '; памяти хватает — задание очереди сядет рядом' if room else '; памяти мало — задания идут на другую карту')
            elif any(l.get('via') == 'unity' for l in self._foreign_now.get(card_label(c['name']), [])) and not any(
                    l.get('via') == 'foreign' and not l.get('what', '').endswith('ждёт задание')
                    for l in self._foreign_now.get(card_label(c['name']), [])):
                state, reason = 'unity', 'Unity-тест; учитываем фактически занятую память' + near
            elif foreign:
                state = 'чужой процесс'
                names = ', '.join(sorted({self._procs.get(p, ('', str(p)))[1] for p in foreign}))
                if 'не удалось проверить процессы' in foreign:
                    reason = 'Не удалось проверить процессы'
                else:
                    labels = self._foreign_now.get(card_label(c['name'])) or []
                    if labels and all(l['what'].endswith('ждёт задание') for l in labels):
                        state = 'чужой ComfyUI ждёт'
                        reason = ('Чужой %s простаивает, на карте занято %.1f из %.1f ГБ' % (
                            ', '.join(l['what'].split(' · ')[0] for l in labels[:2]),
                            c['used'] / 1024, (c.get('total') or 0) / 1024)).replace('.', ',')
                    else:
                        reason = ('Чужая задача: ' + '; '.join(' · '.join(x for x in (l['what'], l['task']) if x)
                                                              for l in labels[:2])
                                  if labels else 'Чужие процессы на GPU: ' + names)
                    reason += ('; здесь считает чужая задача — кадры очереди идут на другую карту, пока она есть'
                               if self.contended(c['uuid']) else
                               '; ComfyUI очереди работает рядом' if bs else
                               '; памяти хватает — задание очереди сядет рядом' if room else
                               '; памяти мало — задания идут на другую карту')
            elif any(b.starting or not b.ready for b in bs):
                state, reason = 'запуск', 'ComfyUI запускается'
            elif cool > 0 and not bs:
                state, reason = 'пауза после сбоя', 'Повторный запуск через %d с' % cool
            elif bs:
                state, reason = 'готова', 'ComfyUI запущен и ждёт задание' + near
            elif not room:
                state, reason = 'занята', card_busy(c) or 'Мало свободной памяти с учётом запаса'
            else:
                state, reason = 'свободна', 'ComfyUI запустится при первом задании'
            labels = self._foreign_now.get(card_label(c['name'])) or []
            other = next((l for l in labels if l.get('via') == 'unity'), labels[0] if labels else {}) if state == 'unity' else (labels[0] if labels else {})
            if state == 'аренда' and not labels:  # раннер ещё не на карте: источник — по самой аренде
                src = next((self._lease_src[t] for t, lc in lease_tokens if lc == c['uuid'] and t in self._lease_src), None)
                if src:
                    other = {'task': src['owner'], 'chat_title': src['chat_title'], 'meta': {'app': src['app']} if src['app'] else {},
                             'via': 'lease', 'what': ''}
            workers.append({'name': card_label(c['name']), 'online': True, 'kind': 'ПК',
                            'busy': bool(run) or state in ('аренда', 'замер', 'чужой процесс', 'занята', 'unity')
                                    or (state == 'чужой ComfyUI ждёт' and not room),
                            'state': state, 'reason': reason, 'used_mb': c['used'], 'util': c['util'],
                            'temp': c.get('temp'), 'power': c.get('power'), 'power_limit': c.get('power_limit'), 'total_mb': c.get('total'), 'gpu_name': c['name'],
                            'job_id': run['id'] if run else None,
                            'what': run.get('what') if run else other.get('what'),
                            'task': run.get('task') if run else other.get('task'),
                            'chat_title': run['chat_title'] if run else (other.get('chat_title') or ('Чат не определён' if other else None)),
                            'meta': _loads(run.get('meta'), {}) if run else (other.get('meta') or {}),
                            'via': 'queue' if run else other.get('via'),
                            # Программы рабочего стола на карте: объясняют загрузку свободной карты.
                            'apps': sorted({l['what'][len('Приложение '):] for l in labels
                                            if l.get('via') == 'app' and l.get('what', '').startswith('Приложение ')})[:5],
                            'stats': stats.get(card_label(c['name'])) or _empty_stats()})
        for b in backends:
            if not b.remote:
                continue
            run = by_port.get(b.port)
            q = getattr(b, 'queue', None)
            if run:
                state, reason = 'генерация', 'Считает задание очереди'
                if not b.ready:
                    state, reason = 'связь потеряна', 'Результат ещё не подтверждён; ждём восстановления связи'
                elif run['state'] in ('submitting', 'uncertain', 'cancelling'):
                    state, reason = {'submitting': ('отправка', 'Передаём задание исполнителю'),
                                     'uncertain': ('проверка отправки', 'Ждём подтверждения; повтор пока запрещён'),
                                     'cancelling': ('отмена', 'Ждём подтверждённой остановки задания')}[run['state']]
            elif not b.ready:
                state, reason = 'офлайн', getattr(b, 'gpu_reason', '') or 'Нет соединения с ноутбуком'
            elif b.blocked:
                state = 'занята'
                reason = getattr(b, 'gpu_reason', '') or (
                    'На ноутбуке идёт другая очередь ComfyUI'
                    if isinstance(q, dict) and (q.get('queue_running') or q.get('queue_pending'))
                    else 'Ноутбук занят другой задачей')
            elif waiting.get(b.pool) and getattr(b, 'unfit', ''):
                state, reason = 'свободна', 'Задания очереди не подходят: ' + b.unfit
            else:
                state, reason = 'свободна', 'Возьмёт совместимое задание'
            tel = getattr(b, 'telemetry', None) or {}
            if now - tel.get('ts', 0) > 120:
                tel = {}
            live = {} if run else (getattr(b, 'current', None) or {})
            workers.append({'name': b.card, 'online': bool(b.ready), 'kind': getattr(b, 'kind', 'ноутбук'),
                            'busy': bool(run) or bool(b.ready and b.blocked), 'state': state, 'reason': reason,
                            'used_mb': tel.get('used'), 'util': tel.get('util'), 'temp': tel.get('temp'), 'power': tel.get('power'),
                            'power_limit': tel.get('power_limit'),
                            'total_mb': tel.get('total'), 'gpu_name': tel.get('gpu') or '',
                            'job_id': run['id'] if run else None,
                            'what': run.get('what') if run else live.get('what'),
                            'task': run.get('task') if run else live.get('task'),
                            'chat_title': run['chat_title'] if run else (live.get('chat_title') or ('Чат не определён' if live else None)),
                            'meta': _loads(run.get('meta'), {}) if run else (live.get('meta') or {}),
                            'via': 'queue' if run else ('farm' if live else None),
                            'stats': stats.get(b.card) or _empty_stats()})
        alerts = []
        seen = set()
        for ts, jid, message in events:
            if (jid, message) not in seen and len(seen) < 20:
                seen.add((jid, message))
                alerts.append({'ts': ts, 'job_id': jid, 'message': message})
        for a in active:
            if a['state'] == 'uncertain':
                alerts.append({'ts': a['start_ts'], 'job_id': a['id'], 'message': 'Нужно проверить отправку: ' + (a['error'] or '')})
            elif a['backend_port'] not in ready_ports:
                alerts.append({'ts': now, 'job_id': a['id'], 'message': 'Нет связи с исполнителем активного задания; ждём подтверждения результата'})
        resource_notices = [{'id': 'resource:%s:%s' % (ts, kind), 'state': kind, 'ts': ts, 'chat_title': '',
                             'what': message, 'message': message, 'card': c, 'details': _loads(details, {})}
                            for ts, kind, message, c, details in resource_rows]
        alerts = [{'ts': n['ts'], 'job_id': '', 'message': n['message']} for n in resource_notices if now - n['ts'] < 3600] + alerts
        others = []
        live = [r[0] for r in frows if not r[7] and not (r[6] and now - r[6] > 90)]
        with _LK:
            fprompts = dict(db().execute("SELECT id,prompt_text FROM foreign_jobs WHERE id IN (%s)" % ','.join('?' * len(live)),
                                         live).fetchall()) if live else {}
        for fid, fcard, ftask, fwhat, ftitle, fstart, fseen, fdone, fmeta, fvia, fmedia, ferr, fexact in frows:
            done = fdone or (fseen if fseen and now - fseen > 90 else None)
            others.append({'id': 'foreign:' + fid, 'card': fcard, 'task': ftask or '', 'what': fwhat or '',
                           'chat_title': ftitle or 'Чат не определён', 'start_ts': fstart, 'done_ts': done,
                           'duration_seconds': round(max(0, (done or now) - fstart)) if fstart else None,
                           'state': ('error' if ferr else 'done') if done else 'running', 'foreign': True,
                           'via': fvia or 'foreign', 'meta': _loads(fmeta, {}), 'exact': bool(fexact),
                           'count': 1,
                           'media': [{'url': '/gpuq/media?foreign=%s&index=%d' % (quote(fid, safe=''), i),
                                      'filename': v.get('filename') or '', 'type': str(v.get('type') or '').split('/')[0]}
                                     for i, v in enumerate(_loads(fmedia, [])) if isinstance(v, dict)]})
        # Идущим заданиям вне очереди — остаток по прошлым таким же и промпт графа.
        for item in others:
            if item['state'] != 'running':
                continue
            fid = item['id'][len('foreign:'):]
            item['prompt'] = fprompts.get(fid) or ''
            elapsed = max(0, now - (item['start_ts'] or now))
            typical, left, approx = self._foreign_eta(item['card'], item['task'], item['what'], item['meta'], elapsed)
            item.update(estimated_seconds=round(typical) if typical else None, remaining_seconds=round(left),
                        remaining_approx=approx, progress=round(min(0.99, elapsed / (elapsed + left)), 3))
            m = item['meta']
            if m.get('pending') and m.get('pending_eta') is None:  # пачка без похожих в истории — как текущее задание
                m['pending_eta'] = round(m['pending'] * (typical or elapsed + left))
        # Задания очереди без места на картах: старт — когда освободится первая занятая карта ПК
        # (по оценке идущих там заданий вне очереди и пачек раннеров), дальше по порядку очереди.
        free_in = {}
        for item in others:
            if item['state'] == 'running' and item['via'] != 'farm' and item.get('remaining_seconds') is not None:
                t = item['remaining_seconds'] + ((item.get('meta') or {}).get('pending_eta') or 0)
                free_in[item['card']] = max(free_in.get(item['card'], 0), t)
        if free_in:
            after = defaultdict(float)
            for job in sorted((j for j in jobs if j['state'] == 'queued'), key=lambda j: j['position'] or 0):
                if job['starts_in_seconds'] is None:
                    job['starts_in_seconds'] = round(min(free_in.values()) + after[job['pool']])
                    job['starts_approx'] = True
                    if job['estimated_seconds']:
                        job['remaining_seconds'] = job['starts_in_seconds'] + job['estimated_seconds']
                    after[job['pool']] += job['estimated_seconds'] or 0
        # «Очередь стоит» — только задания, которые ждут дольше 5 мин и не знают, когда начнутся:
        # ждущее занятую карту с оценкой старта (в панели «через ~N») очередь не держит.
        by_id = {j['id']: j for j in jobs}
        long_wait = [jid for ids in stuck.values() for jid in ids
                     if jid in by_id and by_id[jid]['starts_in_seconds'] is None]
        if long_wait:
            alerts.insert(0, {'ts': now, 'job_id': '', 'message': 'Очередь стоит больше 5 мин, ждут %d. ' % len(long_wait)
                              + '; '.join('%s — %s' % (w['name'], w['reason']) for w in workers)})
        others = collapse_unity(others)
        bypass = {}
        for task, title, name, start, end, meta in bypass_rows:
            script = (task or 'Источник не определён').split(' → ')[0]
            title = title or chat_for('job:' + script.lower())
            key = (script, title or '', name)
            item = bypass.setdefault(key, {'script': script, 'chat_title': title or 'Чат не определён', 'card': name,
                                           'count': 0, 'duration_seconds': 0, 'path': ''})
            item['path'] = item['path'] or _loads(meta, {}).get('path') or ''
            item['count'] += 1
            item['duration_seconds'] += max(0, min(end or now, now) - max(start or now, midnight))
        for item in bypass.values():
            item['duration_seconds'] = round(item['duration_seconds'])
        return {'jobs': jobs, 'workers': workers, 'alerts': alerts[:30], 'ts': now, 'api': 2, 'foreign': others[offset:offset + limit],
                'pc': self._pc, 'slots': self.slots.view(),
                'bypass_top': sorted(bypass.values(), key=lambda x: (-x['duration_seconds'], -x['count'])),
                'idle_comfy': idle_servers,
                'notices': [{'id': n[0], 'state': n[1], 'ts': n[2], 'chat_title': n[3] or 'Чат не определён',
                             'what': n[4] or '', 'card': n[5] or ''} for n in notices] + resource_notices,
                'summary': {'queued': queued_total, 'running': len(active), 'done_today': done_today,
                            'eta_all': None if None in etas else round(max(etas or [0]))}}

    def _card_stats(self, now, midnight):
        """По картам и ноутбукам: сегодня — готово, ошибки, картинки, видео, время генераций и аренд;
        за 7 дней — готово и среднее время. Кэш на 10 с: панель спрашивает часто."""
        when, cached = self._stats_cache
        if now - when < 10:
            return cached
        names = {c['uuid']: card_label(c['name']) for c in self._gpu_cache}
        with _LK:
            q = db().execute("SELECT card,state,start_ts,done_ts,media,meta FROM jobs WHERE state IN ('done','error')"
                             " AND done_ts>=? AND card IS NOT NULL", (now - 7 * 86400,)).fetchall()
            f = db().execute("SELECT card,err,start_ts,done_ts,media,meta,via,what FROM foreign_jobs WHERE done_ts>=?",
                             (now - 7 * 86400,)).fetchall()
            ls = db().execute("SELECT card,start_ts,end_ts FROM lease_log WHERE end_ts IS NULL OR end_ts>=?",
                              (midnight,)).fetchall()
        stats = defaultdict(_empty_stats)
        gens = [(card, state == 'error', start, done, media, meta) for card, state, start, done, media, meta in q]
        for card, err, start, done, media, meta, via, what in f:
            if via == 'farm' or (what or '').startswith('ComfyUI :'):
                gens.append((card, bool(err), start, done, media, meta))
            elif card and done >= midnight and via != 'unity':
                stats[card]['today']['other'] += 1
        spans, durs = defaultdict(list), defaultdict(list)
        for card, err, start, done, media, meta in gens:
            if not card:
                continue
            s = stats[card]
            types = [str(m.get('type') or '') for m in _loads(media, []) if isinstance(m, dict)]
            kind = ('video' if any(t.startswith('video/') for t in types) else
                    'image' if any(t.startswith('image/') for t in types) else _loads(meta, {}).get('kind'))
            if not err:
                s['week']['done'] += 1
                s['last_done_ts'] = max(s['last_done_ts'] or 0, done)
                if start and done >= start:
                    durs[card].append(done - start)
            if done >= midnight:
                if err:
                    s['today']['errors'] += 1
                else:
                    s['today']['done'] += 1
                    if kind in ('video', 'image'):
                        s['today'][kind + 's'] += 1
                if start and done > max(start, midnight):
                    spans[card].append((max(start, midnight), done))
        for card, items in spans.items():
            stats[card]['today']['gen_seconds'] = _span(items)
        for card, items in durs.items():
            stats[card]['week']['avg_seconds'] = round(sum(items) / len(items))
        held = defaultdict(list)
        for u, start, end in ls:
            card = names.get(u)
            a, b = max(start or now, midnight), min(end or now, now)
            if card and b > a:
                held[card].append((a, b))
        for card, items in held.items():
            stats[card]['today']['lease_seconds'] = _span(items)
        with _LK:
            unity = db().execute("SELECT card,COUNT(*) FROM foreign_jobs WHERE via='unity' AND start_ts>=? GROUP BY card", (midnight,)).fetchall()
        for card, count in unity:
            stats[card]['today']['unity_runs'] = count
        for card, item in self.history(24)['cards'].items():
            stats[card]['today']['busy_pct_24h'] = item['summary']['busy_pct']
        with _LK:
            models = db().execute("SELECT card,kind,COUNT(*) FROM resource_notices WHERE ts>=? AND kind IN ('model_hit','model_swap') GROUP BY card,kind", (midnight,)).fetchall()
        for card, kind, count in models:
            stats[card]['today']['model_hits' if kind == 'model_hit' else 'model_swaps'] = count
        stats = dict(stats)
        self._stats_cache = (now, stats)
        return stats

    def gallery(self, limit=60, offset=0, card=None, kind=None):
        """Все результаты с файлами: задания очереди и законченные задания вне очереди, новые сверху."""
        cond, args = '', ()
        if card:
            cond, args = cond + ' AND card=?', args + (card,)
        if kind:
            cond, args = cond + ' AND media LIKE ?', args + ('%"' + kind + '/%',)
        n = limit + offset + 1
        with _LK:
            q = db().execute("SELECT id,card,what,meta,chat_title,task,start_ts,done_ts,media,prompt_text FROM jobs"
                             " WHERE state='done' AND media IS NOT NULL AND media!='[]'%s"
                             " ORDER BY done_ts DESC LIMIT ?" % cond, args + (n,)).fetchall()
            f = db().execute("SELECT id,card,what,meta,chat_title,task,start_ts,done_ts,media,via,exact,prompt_text FROM foreign_jobs"
                             " WHERE done_ts IS NOT NULL AND media IS NOT NULL AND media!='[]'%s"
                             " ORDER BY done_ts DESC LIMIT ?" % cond, args + (n,)).fetchall()
        rows = [(r, 'queue', True, 'job=%s' % r[0], r[0]) for r in q] + \
               [(r[:9] + (r[11],), r[9] or 'foreign', bool(r[10]), 'foreign=%s' % quote(r[0], safe=''), 'foreign:' + r[0]) for r in f]
        rows.sort(key=lambda x: x[0][7] or 0, reverse=True)
        items = []
        for (jid, card_, what, meta, title, task, start, done, media, prompt), via, exact, key, id_ in rows[offset:offset + limit]:
            files = []
            for i, v in enumerate(_loads(media, [])):
                if not isinstance(v, dict):
                    continue
                major = str(v.get('type') or '').split('/')[0]
                item = {'url': '/gpuq/media?%s&index=%d' % (key, i), 'filename': v.get('filename') or '', 'type': major}
                if major == 'image':
                    item['thumb'] = '/gpuq/thumb?%s&index=%d' % (key, i)
                files.append(item)
            items.append({'id': id_, 'card': card_ or '', 'what': what or 'Граф ComfyUI', 'meta': _loads(meta, {}),
                          'chat_title': title or 'Чат не определён', 'task': task or '', 'done_ts': done,
                          'duration_seconds': round(max(0, done - start)) if start and done else None,
                          'via': via, 'exact': exact, 'media': files, 'prompt_text': prompt or ''})
        return {'items': items, 'has_more': len(rows) > offset + limit, 'ts': time.time()}

    def metrics(self):
        """Сводка очереди для диагностики: загрузка карт, глубина, скорость, простой.

        Отвечает на «карты не простаивают?» и «раздача по скорости работает?»:
        кадров/мин и среднее время кадра считаются по фактической карте (колонка card),
        поэтому 6000 должна давать заметно больше кадров/мин, чем 4090."""
        now = time.time()
        with _LK:
            rows = db().execute("SELECT pool,card,state,start_ts,done_ts FROM jobs").fetchall()
        pools, cards = {}, {}
        for pool, card, state, st, dn in rows:
            p = pools.setdefault(pool, {"queued": 0, "running": 0, "done": 0, "error": 0})
            if state in p:
                p[state] += 1
            if state == "done" and card and st and dn:
                c = cards.setdefault(card, {"done": 0, "_sec": 0.0, "last10m": 0})
                c["done"] += 1
                c["_sec"] += max(0.0, dn - st)
                if now - dn <= 600:
                    c["last10m"] += 1
        for c in cards.values():
            c["avg_sec"] = round(c["_sec"] / c["done"], 1) if c["done"] else None
            c["fpm_10m"] = round(c["last10m"] / 10.0, 2)  # кадров/мин за последние 10 мин
            c.pop("_sec", None)
        backends = [{"pool": b.pool, "port": b.port, "card": b.card,
                     "inflight": self.inflight(b), "freed": b.freed,
                     "idle_s": round(now - b.last_used, 1), "ready": b.ready}
                    for b in self.backends if b.alive()]
        lrows = self._lease_rows()
        live = [{"card": card_label(c["name"]), "used_mb": c["used"], "util": c["util"],
                 "free": card_free(c), "room": self._room_ok(c, FOREIGN_NEED_MB, now, lrows)} for c in self._gpu_cache]
        return {"pools": pools, "cards": cards, "backends": backends, "gpu": live, "ts": now}


MGR = Manager()
LIVE = Live()          # живое превью и шаги заданий очереди (preview.py)
LIVE_STATES = ('submitting', 'running', 'cancelling', 'uncertain')


# ---------------------------------- Фасад -----------------------------------

def _rows(jobs):
    # формат строки очереди ComfyUI: [number, prompt_id, prompt, extra, outputs]; клиентам нужен [1]=id
    return [[r["n"], r["id"], {}, {}, []] for r in jobs]


def _parse_multipart_upload(ctype, raw):
    """Разбирает multipart/form-data от ComfyUI /upload/image (ферма, farm.upload).

    Возвращает (filename, subfolder, data). Достаточно для нашего продюсера:
    часть image с filename= и необязательные текстовые поля subfolder/type."""
    marker = "boundary="
    i = ctype.find(marker)
    if i < 0:
        return None, "", b""
    boundary = ctype[i + len(marker):].split(";")[0].strip().strip('"')
    if not boundary:
        return None, "", b""
    sep = b"--" + boundary.encode()
    filename, subfolder, data = None, "", b""
    for part in raw.split(sep):
        if part in (b"", b"--", b"--\r\n", b"\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        if part.endswith(b"\r\n"):
            part = part[:-2]
        head, _, body = part.partition(b"\r\n\r\n")
        if not _:
            continue
        headers = head.decode("latin-1", "replace")
        low = headers.lower()
        if 'filename="' in low:
            j = low.find('filename="')
            filename = headers[j + len('filename="'):].split('"', 1)[0]
            data = body
        elif 'name="subfolder"' in low:
            subfolder = body.decode("utf-8", "replace").strip()
    return filename, subfolder, data


class Facade(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    pool = "krea"  # переопределяется подклассом на порт

    def log_message(self, *a):
        pass

    def _send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n < 0 or n > 16 * 1024 * 1024:
            raise ValueError("Слишком большой запрос")
        raw = self.rfile.read(n) if n else b""
        self._body_read = True
        return json.loads(raw) if raw else {}

    def _deny(self, why):
        """Отказ: 403 и закрытие соединения. Тело отклонённого запроса не читалось, и оставшиеся в нём байты нельзя разбирать
        как следующий запрос (иначе страница чужого сайта спрячет настоящий запрос в теле своего и обойдёт проверку Origin)."""
        body = json.dumps({"error": why}).encode()
        self.send_response(403)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

    def _gate(self, is_get):
        """Проверка запроса до разбора: имя хоста, однозначное обрамление тела (одна строка Content-Length, без chunked), у GET тела нет."""
        if not self._host_ok():
            self._deny("host")
            return False
        if self.headers.defects:   # битая строка заголовка («Content-Length : 5»): парсер считает всё после неё телом, и Origin с Content-Length пропадают
            self._deny("header")
            return False
        lengths = self.headers.get_all("Content-Length") or []
        if (self.headers.get_all("Transfer-Encoding") or len(lengths) > 1 or any(not re.fullmatch(r"[0-9]{1,12}", v.strip()) for v in lengths)
                or (is_get and lengths and int(lengths[0]) != 0)):
            self._deny("body")
            return False
        return True

    def _host_ok(self):
        """Служба отвечает только на своё имя: страницы чужих сайтов не прочтут её через подмену DNS (DNS rebinding)."""
        host = (self.headers.get("Host") or "").lower()
        port = self.server.server_port
        return host in ("127.0.0.1:%d" % port, "localhost:%d" % port, "[::1]:%d" % port)

    def do_GET(self):
        if not self._gate(True):
            return
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        path = u.path
        try:
            if path == "/system_stats":
                self._send_json(MGR.system_stats(self.pool))
            elif path.startswith("/history/"):
                self._send_json(self._history(path[len("/history/"):]))
            elif path == "/history":
                self._send_json({})
            elif path == "/queue":
                self._send_json(self._queue())
            elif path == "/gpuq/metrics":
                self._send_json(MGR.metrics())
            elif path == "/gpuq/status":
                self._send_json(MGR.dashboard())
            elif path == "/gpuq/report":
                qs = parse_qs(u.query)
                try:
                    days = int(qs.get('days', ['7'])[0])
                    if not 1 <= days <= 30:
                        raise ValueError('days')
                except ValueError:
                    self._send_json({'error': 'days: целое от 1 до 30'}, 400)
                    return
                with _LK:
                    result = queue_report.read(db(), time.time(), days,
                                               {c['uuid']: card_label(c['name']) for c in MGR._gpu_cache})
                self._send_json(result)
            elif path == "/gpuq/history":
                qs = parse_qs(u.query)
                try:
                    hours = float(qs.get('hours', ['24'])[0])
                    if not 0 < hours <= 168:
                        raise ValueError('hours')
                except (ValueError, OverflowError):
                    self._send_json({'error': 'hours: число от 0 до 168 (не включая 0)'}, 400)
                    return
                self._send_json(MGR.history(hours, (qs.get('card', [''])[0] or '')[:64] or None))
            elif path == "/gpuq/dashboard":
                qs = parse_qs(u.query)
                limit = max(1,min(200,int(qs.get('limit',['100'])[0])))
                offset = max(0,int(qs.get('offset',['0'])[0]))
                card = (qs.get('card', [''])[0] or '')[:64] or None
                self._send_json(MGR.dashboard(limit, offset, card))
            elif path in ("/gpuq/media", "/gpuq/thumb"):
                qs = parse_qs(u.query)
                media = media_of(qs)
                index = int(qs.get('index',['-1'])[0])
                if path == "/gpuq/media" and 0 <= index < len(media):
                    self._send_file(media[index]['path'])
                elif path == "/gpuq/thumb" and 0 <= index < len(media) and media[index]['type'].startswith('image/'):
                    try:  # ширина для экранов с масштабом; без неё — прежние 348×284
                        width = max(64, min(720, int(qs['w'][0]))) if 'w' in qs else None
                    except ValueError:
                        width = None
                    self._send_thumb(media[index]['path'], width)
                else:
                    self._send_json({'error': 'нет результата' if path == "/gpuq/media" else 'нет миниатюры'}, 404)
            elif path == "/gpuq/gallery":
                qs = parse_qs(u.query)
                limit = max(1,min(200,int(qs.get('limit',['60'])[0])))
                offset = max(0,int(qs.get('offset',['0'])[0]))
                card = (qs.get('card', [''])[0] or '')[:64] or None
                kind = qs.get('kind', [''])[0]
                self._send_json(MGR.gallery(limit, offset, card, kind if kind in ('image', 'video') else None))
            elif path == "/view":
                self._view(parse_qs(u.query))
            elif path == "/gpuq/ref":
                self._send_ref(parse_qs(u.query))
            elif path == "/gpuq/preview":
                item = LIVE.get((parse_qs(u.query).get('job') or [''])[0][:64])
                if item and item.get('data'):
                    self._send_bytes(item['data'], item['mime'], 'no-store')
                else:
                    self._send_json({'error': 'нет превью'}, 404)
            elif path == "/gpuq/ui" or path.startswith("/gpuq/ui/"):
                self._send_ui(path[len("/gpuq/ui"):])
            elif path.startswith("/models/"):
                self._send_json(MGR.models_folder(self.pool, path[len("/models/"):]))
            elif path == "/object_info" or path.startswith("/object_info/"):
                self._proxy_get(path)
            elif path in ("/prompt", "/"):
                self._send_json({})
            else:
                self._proxy_get(path)
        except ConnectionError:
            self.close_connection = True  # клиент ушёл, отвечать некому
        except Exception:
            glog("facade GET %s\n%s" % (path, traceback.format_exc()))
            try:
                self._send_json({"error": "gpuq"}, 500)
            except ConnectionError:
                self.close_connection = True

    def _unread_body(self):
        """Есть ли у запроса тело, которое мы не читали: такие байты нельзя разбирать как следующий запрос."""
        if self.headers.get("Transfer-Encoding"):
            return True   # chunked служба не читает вовсе
        try:
            return int(self.headers.get("Content-Length") or 0) != 0
        except ValueError:
            return True

    def do_POST(self):
        self._body_read = False
        if not self._gate(False):
            return
        try:
            self._do_post()
        finally:
            if not self._body_read and self._unread_body():
                self.close_connection = True

    def _do_post(self):
        from urllib.parse import urlparse
        path = urlparse(self.path).path
        try:
            if self.headers.get('Origin') and self.headers['Origin'] not in ('http://127.0.0.1:%d' % self.server.server_port, 'http://localhost:%d' % self.server.server_port):
                self._deny('origin')
                return
            if path == "/prompt":
                self._prompt()
            elif path == "/gpuq/lease":
                self._send_json(MGR.lease(self._body()))
            elif path == "/gpuq/bump":
                self._send_json(MGR.bump(str(self._body().get('id') or '')))
            elif path == "/gpuq/slot":
                self._send_json(MGR.slots.request(self._body()))
            elif path == "/upload/image" or path == "/upload/mask":
                self._upload_image()
            elif path == "/queue":
                self._queue_delete()
            elif path == "/free":
                self._send_json({})
            elif path == "/interrupt":
                self._send_json({})
            else:
                self._send_json({})
        except ConnectionError:
            self.close_connection = True
        except (ValueError, TypeError):
            try:
                self._send_json({'error':'Некорректный запрос'},400)
            except ConnectionError:
                self.close_connection = True
        except Exception:
            glog("facade POST %s\n%s" % (path, traceback.format_exc()))
            try:
                self._send_json({"error": "gpuq"}, 500)
            except ConnectionError:
                self.close_connection = True

    # --- обработчики ---
    def _prompt(self):
        body = self._body()
        graph = body.get("prompt")
        if not valid_graph(graph):
            self._send_json({"error": "no prompt"}, 400)
            return
        if not POOLS()[self.pool].get("root"):
            self._send_json({"error": "ComfyUI не настроен: укажите comfy_root, comfy_python и comfy_output в config.json GpuQ"}, 503)
            return
        raw_priority = body.get("priority")
        if raw_priority is None:
            raw_priority = self.headers.get("X-GPUQ-Priority", "0")
        try:
            prio = int(raw_priority)
            if not -(2**63) <= prio < 2**63:
                prio = 0
        except (TypeError, ValueError, OverflowError):
            prio = 0
        client, origin, title = chat_origin.resolve(body, self.client_address[1], self.server.server_port)
        try:
            # Только имена скриптов цепочки клиента, без аргументов.
            pid = chat_origin._tcp_owner(self.client_address[1], self.server.server_port)
            task = describe_process(pid) if pid else ""
            app = program_for(pid) if pid else ""
        except (OSError, ValueError, TypeError):
            task, app = "", ""
        # Клиент может исключить устройства: раннеры Krea2 по умолчанию просят только карты ПК (A/B без 8 бит ноутбуков).
        avoid = body.get("avoid") if isinstance(body.get("avoid"), list) else []
        avoid = [str(x)[:64] for x in avoid if isinstance(x, str)][:8]
        jid, n = job_add(self.pool, graph, client, prio, origin, title, task, app, avoid)
        self._send_json({"prompt_id": jid, "number": n, "node_errors": {}})

    def _upload_image(self):
        """Приём картинки (/upload/image, /upload/mask) от фермы или клиента.

        Пишет в общий input пула — тот же каталог, что читают оба krea-бэкенда и
        _krea_gen.prepare. Ответ формой ComfyUI {name, subfolder, type:input},
        его разбирает farm.upload."""
        n = int(self.headers.get("Content-Length") or 0)
        if n < 0 or n > 128 * 1024 * 1024:
            raise ValueError('Слишком большой файл')
        raw = self.rfile.read(n) if n else b""
        self._body_read = True
        ctype = self.headers.get("Content-Type") or ""
        fname, subfolder, data = _parse_multipart_upload(ctype, raw)
        if not fname or any(v in fname for v in ('/','\\')) or any(v in fname+subfolder for v in ('..',':')) or os.path.isabs(fname) or os.path.isabs(subfolder) or not data:
            self._send_json({"error": "bad upload"}, 400)
            return
        base = POOLS()[self.pool]["input_dir"]
        dest = (Path(base)/subfolder/fname).resolve()
        if not dest.is_relative_to(Path(base).resolve()):
            raise ValueError('Файл вне input')
        dest.parent.mkdir(parents=True, exist_ok=True)
        # Никогда не перезаписываем чужой референс, даже при совпадении имени.
        while True:
            try:
                with dest.open('xb') as f:
                    f.write(data)
                break
            except FileExistsError:
                dest = dest.with_name(uuid.uuid4().hex + dest.suffix)
        fname = dest.name
        self._send_json({"name": fname, "subfolder": subfolder, "type": "input"})

    def _history(self, jid):
        r = job_row(jid)
        if not r:
            return {}
        if r["state"] == "done" and r["result"]:
            return {jid: json.loads(r["result"])}
        if r["state"] == "error":
            if r["result"]:
                return {jid: json.loads(r["result"])}
            return {jid: {"status": {"status_str": "error", "completed": False,
                                     "messages": [["gpuq_error", {"error": r["error"] or "ошибка"}]]},
                          "outputs": {}}}
        return {}

    def _queue(self):
        return {"queue_running": _rows(jobs_where(self.pool, ("running", "submitting", "uncertain", "cancelling"))),
                "queue_pending": _rows(jobs_where(self.pool, ("queued",))),
                "gpuq": True}

    def _queue_delete(self):
        body = self._body()
        ids = body.get("delete") or []
        with MGR.scheduling:
            for jid in ids:
                r = job_row(jid)
                if not r:
                    continue
                if r["state"] == "queued":
                    job_set(jid, state="cancelled", done_ts=time.time())
                elif r['state'] in ('running','submitting','uncertain'):
                    job_set(jid, state='cancelling')
        self._send_json({})

    def _view(self, qs):
        filename = (qs.get("filename") or [""])[0]
        subfolder = (qs.get("subfolder") or [""])[0]
        typ = (qs.get("type") or ["output"])[0]
        p = MGR.view_file(self.pool, filename, subfolder, typ)
        if not p:
            self._send_json({"error": "not found"}, 404)
            return
        self._send_file(p)

    def _send_file(self, p):
        if not os.path.isfile(p):
            self._send_json({'error':'Файл отсутствует'},404)
            return
        ctype = mimetypes.guess_type(p)[0] or "application/octet-stream"
        active = Path(p).suffix.lower() in (".html", ".htm", ".xhtml", ".svg", ".svgz", ".xml", ".js", ".mjs")
        if active:   # страница из результатов не должна исполнять скрипты на адресе службы
            ctype = "application/octet-stream"
        size = os.path.getsize(p)
        start, end = 0, size - 1
        # Range: видео в панели перематывается и показывает кадр-превью, не скачивая файл целиком.
        m = re.fullmatch(r'bytes=(\d*)-(\d*)', (self.headers.get('Range') or '').strip())
        partial = bool(m and (m.group(1) or m.group(2)))
        if partial:
            if m.group(1):
                start = int(m.group(1))
                end = min(end, int(m.group(2))) if m.group(2) else end
            else:
                start = max(0, size - int(m.group(2)))
            if start > end:
                self.send_response(416)
                self.send_header("Content-Range", "bytes */%d" % size)
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", ctype)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "sandbox")
        if active:
            self.send_header("Content-Disposition", "attachment")
        self.send_header("Accept-Ranges", "bytes")
        if partial:
            self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Cache-Control", "private, max-age=60")
        self.end_headers()
        with open(p, 'rb') as f:
            f.seek(start)
            left = end - start + 1
            while left > 0:
                chunk = f.read(min(256 * 1024, left))
                if not chunk:
                    break
                self.wfile.write(chunk)
                left -= len(chunk)

    def _send_ui(self, rest):
        """Статика панели: только файлы gpu_dual/gpuq/ui вида имя.html|css|js, без подкаталогов."""
        if not rest:  # относительные ссылки страницы считаются от /gpuq/ui/
            self.send_response(301)
            self.send_header("Location", "/gpuq/ui/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        name = rest[1:] or 'index.html'
        p = UI_DIR / name
        if not re.fullmatch(r'[a-z0-9_-]+\.(html|css|js)', name) or not p.is_file():
            self._send_json({'error': 'нет такого файла'}, 404)
            return
        body = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", UI_TYPES[p.suffix])
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", UI_CSP)
        self.end_headers()
        self.wfile.write(body)

    def _send_ref(self, qs):
        """Миниатюра референса (LoadImage) задания по его ID: из input очереди или с /view живого ComfyUI раннера."""
        from io import BytesIO
        try:
            index = int(qs.get('i', ['0'])[0])
            width = max(48, min(480, int(qs.get('w', ['120'])[0])))
        except ValueError:
            self._send_json({'error': 'параметры'}, 400)
            return
        data = None
        if 'job' in qs:
            r = job_row(qs['job'][0])
            refs = (_loads(r['meta'], {}).get('refs') or []) if r else []
            if 0 <= index < len(refs):
                sub, _, name = refs[index].replace('\\', '/').rpartition('/')
                path = MGR.view_file(self.pool, name, sub, 'input')
                if path and os.path.getsize(path) <= 64 * 1024 * 1024:
                    with open(path, 'rb') as f:
                        data = f.read()
        elif 'foreign' in qs:
            with _LK:
                row = db().execute('SELECT meta,port FROM foreign_jobs WHERE id=?', (qs['foreign'][0],)).fetchone()
            refs = (_loads(row[0], {}).get('refs') or []) if row else []
            port = row[1] if row else None
            # Только локальный ComfyUI, который сейчас жив и считает это задание; файл — из его input.
            live = isinstance(port, int) and any(isinstance(v, tuple) and v[1].get('engine') == 'ComfyUI' and v[1].get('port') == port
                                                 for v in list(MGR._labels.values()))
            if live and 0 <= index < len(refs):
                sub, _, name = refs[index].replace('\\', '/').rpartition('/')
                try:
                    with _NOPROXY.open('http://127.0.0.1:%d/view?%s' % (port, urlencode({'filename': name, 'subfolder': sub, 'type': 'input'})),
                                       timeout=4) as resp:
                        if resp.headers.get_content_type().startswith('image/'):
                            data = resp.read(64 * 1024 * 1024 + 1)
                except (OSError, ValueError):
                    data = None
        if not data or len(data) > 64 * 1024 * 1024:
            self._send_json({'error': 'нет референса'}, 404)
            return
        self._send_thumb(BytesIO(data), width)

    def _send_bytes(self, body, ctype, cache):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(body)

    def _send_thumb(self, p, width=None):
        from io import BytesIO
        from PIL import Image
        try:
            with Image.open(p) as im:
                im.thumbnail((width, width * 2) if width else (348, 284))
                out = BytesIO()
                im.convert('RGB').save(out, 'JPEG', quality=85)
        except (OSError, ValueError, Image.DecompressionBombError):
            self._send_json({'error': 'нет миниатюры'}, 404)
            return
        self._send_bytes(out.getvalue(), "image/jpeg", "private, max-age=86400")

    def _proxy_get(self, path):
        """Прочие GET (object_info и т.п.) — к любому живому бэкенду пула."""
        for b in MGR.pool_backends(self.pool):
            r = b.get(path, timeout=30)
            if r is not None:
                self._send_json(r)
                return
        self._send_json({})


def make_handler(pool):
    return type("Facade_" + pool, (Facade,), {"pool": pool})


def serve_pool(pool):
    port = POOLS()[pool]["facade_port"]
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(pool))
    httpd.daemon_threads = True
    glog("facade %s on %d" % (pool, port))
    httpd.serve_forever()


def _port_busy(port):
    s = socket.socket()
    s.settimeout(1)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def stop_owned_processes(directory):
    """Бэкенды упавшего или перезапущенного gpuq живут дальше: держат порт и память
    карты, а новый диспетчер о них не знает. Узнаём их по --user-directory в GpuQueue."""
    state_match = str(directory).replace("'", "''")
    ps = ("Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and"
          " $_.CommandLine -like '*--user-directory*" + state_match + "*' } | ForEach-Object { $_.ProcessId }")
    ps = "$ErrorActionPreference='Stop'; " + ps
    def owned_pids():
        result = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True,
                                text=True, timeout=15, creationflags=NO_WINDOW, check=True)
        return [pid for pid in result.stdout.split() if pid.isdigit()]
    try:
        for pid in owned_pids():
            # без /T: фильтр сам находит и лаунчер venv, и ComfyUI; /T идёт по ParentProcessId
            # и мог бы задеть чужой процесс, доставшийся от умершего родителя с тем же PID
            r = subprocess.run(["taskkill", "/F", "/PID", pid], capture_output=True,
                               creationflags=NO_WINDOW, timeout=10)
            if r.returncode == 0:  # ComfyUI мог уже умереть вместе со своим лаунчером
                glog("убит осиротевший бэкенд pid %s" % pid)
        return not owned_pids()
    except (OSError, subprocess.SubprocessError):
        return False


def kill_orphans():
    return stop_owned_processes(str(STATE_DIR) + '\\')


def main():
    _load_config()
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    try:  # сессия демона: бэкенды ComfyUI инитят CUDA только в session 0 (S4U-задача), не в интерактивной
        _sid = ctypes.c_ulong()
        ctypes.windll.kernel32.ProcessIdToSessionId(os.getpid(), ctypes.byref(_sid))
        glog("=== gpuq start, pid %d, session %d ===" % (os.getpid(), _sid.value))
    except Exception:
        glog("=== gpuq start, pid %d ===" % os.getpid())
    for pool, spec in POOLS().items():
        if _port_busy(spec["facade_port"]):
            # порт уже занят: вторая копия gpuq или чужой ComfyUI — не вмешиваемся
            st = None
            try:
                with urllib.request.urlopen("http://127.0.0.1:%d/system_stats" % spec["facade_port"], timeout=5) as r:
                    st = json.loads(r.read())
            except OSError:
                pass
            glog("port %d busy (gpuq=%s), abort" % (spec["facade_port"], bool(st and st.get("gpuq"))))
            print("PORT_BUSY %d" % spec["facade_port"])
            return 1
    if not kill_orphans():  # Повтор разрешён только после подтверждённой остановки прежнего вычисления.
        glog('Не подтверждена остановка своих прежних бэкендов; восстановление отложено')
        return 1
    db()
    from farm import Remote
    MGR.backends.extend(Remote(spec) for spec in _CFG.get('farm', []))
    if not _CFG.get('test_mode'):
        import cloud   # до восстановления заданий: задания облачных карт не перезапускаются
        cloud.attach(MGR, cloud.load_state(STATE_DIR), CARD_SPEED)
    remote_ports = {b.port for b in MGR.backends if b.remote}
    for pool in POOLS():
        for r in jobs_where(pool, ('running','submitting','uncertain','cancelling')):
            if r['backend_port'] not in remote_ports:
                MGR._requeue_or_fail(r, 'Восстановление после перезапуска очереди')
    threading.Thread(target=MGR._run_supervise, daemon=True).start()
    threads = []
    for pool in POOLS():
        t = threading.Thread(target=serve_pool, args=(pool,), daemon=True)
        t.start()
        threads.append(t)
    print("GPUQ_READY %d" % os.getpid(), flush=True)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass
    finally:
        MGR._stop = True
        for b in list(MGR.backends):
            b.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
