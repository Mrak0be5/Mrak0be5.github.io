# -*- coding: utf-8 -*-
"""Облачные карты в эту редакцию GpuQ не входят.

Демон зовёт эти функции на каждом шаге, поэтому они остаются пустыми заглушками."""


def load_state(state_dir):
    return {}


def attach(manager, state, speed):
    return None


def keep(manager, speed, state_dir, log):
    return None
