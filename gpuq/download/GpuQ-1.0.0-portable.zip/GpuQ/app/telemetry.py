"""Отделяем вычисления от постоянно открытого рабочего стола Windows."""
import ntpath
import xml.etree.ElementTree as ET

# WDDM помечает даже оболочку и Chromium как C+G. Одно их наличие не означает расчёт.
# Загрузку и память карты дополнительно проверяет диспетчер перед новым заданием.
DESKTOP_APPS = {
    'dwm.exe','explorer.exe','crossdeviceresume.exe','startmenuexperiencehost.exe',
    'searchhost.exe','shellexperiencehost.exe','sihost.exe','shellhost.exe',
    'applicationframehost.exe','systemsettings.exe','textinputhost.exe','tabtip.exe',
    'chxsmartscreen.exe','openwith.exe','snippingtool.exe','chrome.exe','msedge.exe',
    'msedgewebview2.exe','steamwebhelper.exe','slack.exe','telegram.exe','whatsapp.root.exe',
    'cursor.exe','code.exe','chatgpt.exe','kimi.exe',
    'antigravity.exe','lockapp.exe','logonui.exe','crashreporter.exe',
}
# Удалённый рабочий стол кодирует экран на GPU (тип C или C+G) и генерациям не мешает.
REMOTE_APPS = {'remoting_desktop.exe', 'rustdesk.exe'}


def compute_pids(xml):
    result = {}
    try:
        cards = ET.fromstring(xml).findall('gpu')
    except ET.ParseError as e:
        raise ValueError('Недоступна телеметрия GPU') from e
    if not cards:
        raise ValueError('Нет карт в телеметрии')
    for gpu in cards:
        if not gpu.findtext('uuid') or gpu.find('processes') is None:
            raise ValueError('Неполная телеметрия GPU')
        ids = set()
        for p in gpu.findall('./processes/process_info'):
            kind = p.findtext('type', '')
            name = ntpath.basename(p.findtext('process_name', '')).lower()
            pid = p.findtext('pid', '')
            if pid.isdigit() and kind != 'G' and name not in REMOTE_APPS and not (kind == 'C+G' and name in DESKTOP_APPS):
                ids.add(int(pid))
        result[gpu.findtext('uuid')] = ids
    return result


def process_info(xml):
    """{pid: (тип, имя)}: подпись в панели и отбор приложений с графикой (C+G)."""
    info = {}
    for p in ET.fromstring(xml).iter('process_info'):
        pid = p.findtext('pid', '')
        if pid.isdigit():
            info[int(pid)] = (p.findtext('type', ''), ntpath.basename(p.findtext('process_name', '')).lower())
    return info


def process_memory(xml):
    """Память процесса по карте; WDDM N/A оставляем неизвестным, без выдуманной брони."""
    result = {}
    for gpu in ET.fromstring(xml).findall('gpu'):
        for p in gpu.findall('./processes/process_info'):
            used = p.findtext('used_memory', '').split()
            pid = p.findtext('pid', '')
            if pid.isdigit() and used and used[0].isdigit():
                result[(gpu.findtext('uuid'), int(pid))] = int(used[0])
    return result
