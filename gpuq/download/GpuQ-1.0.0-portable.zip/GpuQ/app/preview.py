"""Живое превью заданий очереди: websocket ComfyUI бэкенда с clientId = токен задания.

ComfyUI шлёт превью шага (бинарное сообщение 1: тип картинки + JPEG) и прогресс сэмплера
({"type":"progress","data":{"value","max"}}) только клиенту, чей clientId отправил граф. Поэтому слушатель
подключается тем же токеном до отправки. В памяти — последний кадр и шаг по каждому заданию; на диск ничего."""
import base64
import collections
import json
import os
import socket
import struct
import threading
import time

KEEP_S = 600          # после конца задания превью ещё отдаётся панели (переход в готовый кадр)
MAX_FRAME = 8 << 20   # больше кадр превью не бывает; иначе — чужой протокол, закрываем


class Closed(Exception):
    pass


def ws_open(port, path, timeout=5):
    """Рукопожатие RFC 6455 со своим ComfyUI на 127.0.0.1 → (сокет, байты после заголовков)."""
    sock = socket.create_connection(('127.0.0.1', port), timeout=timeout)
    try:
        key = base64.b64encode(os.urandom(16)).decode()
        sock.sendall(('GET %s HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n'
                      'Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n' % (path, port, key)).encode())
        head = b''
        while b'\r\n\r\n' not in head:
            part = sock.recv(4096)
            if not part or len(head) > 16384:
                raise OSError('websocket: нет ответа')
            head += part
        if not head.startswith(b'HTTP/1.1 101'):
            raise OSError('websocket: ' + head.split(b'\r\n', 1)[0].decode('latin-1'))
        return sock, head.split(b'\r\n\r\n', 1)[1]
    except BaseException:
        sock.close()
        raise


class Reader:
    """Сообщения сервера. Кадр разбирается, только когда пришёл целиком, поэтому тайм-аут сокета
    (проверка, живо ли задание) ничего не теряет. Ping получает pong с маской, как требует RFC 6455."""

    def __init__(self, sock, rest=b''):
        self.sock, self.buf = sock, rest
        self.message, self.opcode = b'', 0

    def _frame(self):
        b = self.buf
        if len(b) < 2:
            return None
        n, i = b[1] & 0x7f, 2
        if n == 126:
            if len(b) < 4:
                return None
            n, i = struct.unpack('>H', b[2:4])[0], 4
        elif n == 127:
            if len(b) < 10:
                return None
            n, i = struct.unpack('>Q', b[2:10])[0], 10
        if n > MAX_FRAME:
            raise Closed()
        key = None
        if b[1] & 0x80:
            if len(b) < i + 4:
                return None
            key, i = b[i:i + 4], i + 4
        if len(b) < i + n:
            return None
        data = b[i:i + n]
        if key:
            data = bytes(x ^ key[k % 4] for k, x in enumerate(data))
        self.buf = b[i + n:]
        return b[0] & 0x80, b[0] & 0x0f, data

    def pong(self, data):
        mask = os.urandom(4)
        self.sock.sendall(bytes([0x8A, 0x80 | len(data)]) + mask + bytes(x ^ mask[k % 4] for k, x in enumerate(data)))

    def next(self):
        """(код, данные) следующего сообщения; socket.timeout пробрасывается без потери данных."""
        while True:
            frame = self._frame()
            if frame is None:
                part = self.sock.recv(65536)
                if not part:
                    raise Closed()
                self.buf += part
                continue
            fin, op, data = frame
            if op == 0x8:
                raise Closed()
            if op == 0x9:
                self.pong(data[:125])
                continue
            if op == 0xA:
                continue
            if op:
                self.message, self.opcode = data, op
            else:
                self.message += data
            if fin:
                message, self.message = self.message, b''
                return self.opcode, message


class Live:
    """Последний кадр превью и шаг сэмплера по заданию очереди."""

    def __init__(self):
        self._lock = threading.Lock()
        self._items = {}

    def watch(self, jid, port, client_id, alive, limit=4 * 3600):
        """Слушать бэкенд, пока alive() истинно (проверка раз в 5 с), не дольше limit секунд."""
        threading.Thread(target=self._run, args=(jid, port, client_id, alive, limit),
                         name='gpuq-preview', daemon=True).start()

    def _set(self, jid, **values):
        with self._lock:
            item = self._items.setdefault(jid, {})
            item.update(values, seen=time.time())

    def _step(self, jid, value, top):
        """Шаг сэмплера: скорость — по последним четырём шагам текущего прохода (hires начинает отсчёт заново)."""
        now = time.time()
        with self._lock:
            item = self._items.setdefault(jid, {})
            marks = item.get('marks')
            if marks is None or item.get('max') != top or value < item.get('value', 0):
                marks = item['marks'] = collections.deque(maxlen=4)
            marks.append((now, value))
            item.update(value=value, max=top, seen=now)
            (t0, v0), (t1, v1) = marks[0], marks[-1]
            item['rate'] = (t1 - t0) / (v1 - v0) if v1 > v0 else item.get('rate') if len(marks) > 1 else None

    def left(self, jid):
        """Секунд до конца текущего прохода сэмплера по настоящим шагам; None — шагов ещё мало."""
        item = self.get(jid)
        if not item or not item.get('rate') or not item.get('max'):
            return None
        return max(0.0, (item['max'] - item['value']) * item['rate'])

    def get(self, jid):
        with self._lock:
            item = self._items.get(jid)
            return dict(item) if item else None

    def info(self, jid):
        """Для панели: время последнего кадра и шаг, без самих байтов."""
        item = self.get(jid)
        if not item:
            return {}
        out = {}
        if item.get('data'):
            out['preview_ts'] = round(item['ts'], 2)
        if item.get('max'):
            out.update(step=item.get('value'), steps=item['max'])
        return out

    def _run(self, jid, port, client_id, alive, limit):
        deadline = time.time() + limit
        try:
            sock, rest = ws_open(port, '/ws?clientId=' + client_id)
        except OSError:
            return
        try:
            sock.settimeout(5)
            reader = Reader(sock, rest)
            while time.time() < deadline:
                try:
                    op, data = reader.next()
                except socket.timeout:
                    if not alive():
                        return
                    continue
                if op == 2 and len(data) > 8 and struct.unpack('>I', data[:4])[0] == 1:
                    kind = struct.unpack('>I', data[4:8])[0]
                    self._set(jid, data=data[8:], mime='image/png' if kind == 2 else 'image/jpeg', ts=time.time())
                elif op == 1:
                    try:
                        msg = json.loads(data)
                    except ValueError:
                        continue
                    d = msg.get('data') if isinstance(msg, dict) else None
                    if not isinstance(d, dict):
                        continue
                    if msg.get('type') == 'progress':
                        if isinstance(d.get('value'), int) and isinstance(d.get('max'), int) and d['max'] > 0:
                            self._step(jid, d['value'], d['max'])
                    elif msg.get('type') == 'executing' and d.get('node') is None and d.get('prompt_id'):
                        return  # граф выполнен
        except (OSError, Closed, struct.error):
            return
        finally:
            sock.close()

    def sweep(self):
        """Забыть превью заданий, о которых давно ничего не приходило."""
        cut = time.time() - KEEP_S
        with self._lock:
            for jid in [j for j, v in self._items.items() if v.get('seen', 0) < cut]:
                del self._items[jid]
