# -*- coding: utf-8 -*-
"""Короткие подписи для истории: что считает граф и какая задача его прислала.
Аргументы командных строк не сохраняются: только имена скриптов и движков."""
import re
from collections import deque
from pathlib import PureWindowsPath

import origin as chat_origin

try:
    import psutil
except ImportError:  # без psutil подписи задач просто пустые
    psutil = None

SCRIPT_RE = re.compile(r'(?i)^[\w.\-]+\.(?:py|pyw|cmd|bat|ps1|js)$')
JOB_RE = re.compile(r'(?i)^job_')
MODEL_KEYS = ('unet_name', 'ckpt_name', 'model_name')
TEXT_KEYS = ('text', 'prompt', 'text_g', 'text_l', 'positive')
FRAME_KEYS = ('length', 'frames', 'num_frames', 'video_frames')
FPS_KEYS = ('fps', 'frame_rate')
VIDEO_RE = re.compile(r'(?i)video|vhs_|webm|animated')
PROMPT_MAX = 2000
# Кто запустил задачу, если чат не определён: ближайшее известное приложение вверх по дереву процессов.
APPS = {'cursor.exe': 'Cursor', 'code.exe': 'VS Code', 'windsurf.exe': 'Windsurf', 'stabilitymatrix.exe': 'StabilityMatrix', 'comfyui.exe': 'ComfyUI Desktop',
        'unity hub.exe': 'Unity Hub', 'unity.exe': 'Unity', 'blender.exe': 'Blender', 'chrome.exe': 'Chrome',
        'msedge.exe': 'Edge', 'firefox.exe': 'Firefox', 'telegram.exe': 'Telegram', 'windowsterminal.exe': 'Терминал',
        'sshd.exe': 'SSH-сессия', 'wmiprvse.exe': 'Отвязанный запуск', 'gpuq.exe': 'GpuQ',
        'explorer.exe': 'Проводник', 'svchost.exe': 'Планировщик задач', 'services.exe': 'Служба Windows'}
SHELLS = {'cmd.exe', 'powershell.exe', 'pwsh.exe', 'conhost.exe', 'python.exe', 'pythonw.exe', 'py.exe', 'node.exe', 'uv.exe'}
GONE = () if psutil is None else (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess, OSError)
_cache = {}


def _stem(value):
    return re.sub(r'(?i)\.(safetensors|ckpt|pt|pth|gguf|bin)$', '', PureWindowsPath(str(value)).name)


def _inputs(node):
    v = node.get('inputs')
    return v if isinstance(v, dict) else {}


def _texts(node):
    return [v for k, v in _inputs(node).items() if k in TEXT_KEYS and isinstance(v, str) and v.strip()]


def _int(value):
    return value if isinstance(value, int) and not isinstance(value, bool) else None


def _num(value):
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0 else None


def _nodes(graph):
    return {str(k): v for k, v in graph.items() if isinstance(v, dict)} if isinstance(graph, dict) else {}


def graph_meta(graph):
    """Что считает граф: kind image|video, model, w×h, frames, fps, seconds, batch, steps, loras."""
    nodes = _nodes(graph)
    kinds = [str(n.get('class_type')) for n in nodes.values()]
    meta = {'kind': 'video' if any(VIDEO_RE.search(k) for k in kinds) else 'image'}
    model = next((_stem(_inputs(n)[key]) for key in MODEL_KEYS for n in nodes.values()
                  if isinstance(_inputs(n).get(key), str)), None)
    if model:
        meta['model'] = model
    # размер латента, иначе первого узла с размером: сначала видеоузлы, потом остальные
    sized = [n for n in nodes.values() if _int(_inputs(n).get('width')) and _int(_inputs(n).get('height'))]
    sized.sort(key=lambda n: 0 if 'Latent' in str(n.get('class_type')) else 1 if VIDEO_RE.search(str(n.get('class_type'))) else 2)
    if sized:
        meta['w'], meta['h'] = _inputs(sized[0])['width'], _inputs(sized[0])['height']
        if (_int(_inputs(sized[0]).get('batch_size')) or 0) > 1:
            meta['batch'] = _inputs(sized[0])['batch_size']
    frames = next((_int(_inputs(n).get(k)) for n in nodes.values() for k in FRAME_KEYS
                   if (_int(_inputs(n).get(k)) or 0) > 1), None)
    fps = next((_num(_inputs(n).get(k)) for n in nodes.values() for k in FPS_KEYS if _num(_inputs(n).get(k))), None)
    if frames:
        meta['kind'], meta['frames'] = 'video', frames
    if meta['kind'] == 'video' and fps:
        meta['fps'] = round(fps, 2)
        if frames:
            meta['seconds'] = round(frames / fps, 1)
    steps = next((_inputs(n)['steps'] for n in nodes.values()
                  if re.search('Sampler|Scheduler', str(n.get('class_type'))) and _int(_inputs(n).get('steps'))), None)
    if steps:
        meta['steps'] = steps
    loras, weights = [], []
    for n in nodes.values():
        name = _inputs(n).get('lora_name')
        if isinstance(name, str) and _stem(name) not in loras:
            loras.append(_stem(name))
            w = _inputs(n).get('strength_model', _inputs(n).get('strength'))
            weights.append(round(w, 3) if isinstance(w, (int, float)) and not isinstance(w, bool) else None)
    if loras:
        meta['loras'] = loras
        meta['lora_w'] = weights
    # Референсы: картинки узлов LoadImage (имя в папке input этого ComfyUI, без пометки « [input]»).
    refs = []
    for n in nodes.values():
        image = _inputs(n).get('image')
        if 'LoadImage' in str(n.get('class_type')) and isinstance(image, str) and image.strip():
            name = re.sub(r'\s*\[(input|output|temp)\]$', '', image.strip())
            if name not in refs:
                refs.append(name)
    if refs:
        meta['refs'] = refs[:4]
    return meta


def _dec(value):
    return ('%g' % value).replace('.', ',')


def meta_text(meta, model=True):
    """«модель · 832×1216 · 8 шаг. · LoRA: …»; у видео после размера секунды, кадры и к/с."""
    meta = meta if isinstance(meta, dict) else {}
    parts = [meta.get('model') or 'Граф ComfyUI'] if model else []
    if meta.get('w') and meta.get('h'):
        parts.append('%d×%d' % (meta['w'], meta['h']))
    if meta.get('seconds'):
        parts.append(_dec(meta['seconds']) + ' с')
    if meta.get('frames'):
        parts.append('%d кадр.' % meta['frames'])
    elif meta.get('kind') == 'video':
        parts.append('видео')
    if meta.get('fps'):
        parts.append(_dec(meta['fps']) + ' к/с')
    if meta.get('batch'):
        parts.append('×%d' % meta['batch'])
    if meta.get('steps'):
        parts.append('%d шаг.' % meta['steps'])
    loras = meta.get('loras') or []
    if loras:
        parts.append('LoRA: ' + ', '.join(loras[:2]) + (' …' if len(loras) > 2 else ''))
    return ' · '.join(parts)[:160]


def graph_summary(graph):
    """(что, промпт): подпись по graph_meta и текст позитивного промпта."""
    nodes = _nodes(graph)
    prompt = ''
    start = next((_inputs(n)['positive'] for n in nodes.values()
                  if isinstance(_inputs(n).get('positive'), list) and _inputs(n)['positive']), None)
    if start:
        todo, seen = deque([(str(start[0]), 0)]), set()
        while todo:
            key, depth = todo.popleft()
            node = nodes.get(key)
            if node is None or key in seen or depth > 8:
                continue
            seen.add(key)
            texts = _texts(node)
            if texts:
                prompt = texts[0]
                break
            for v in _inputs(node).values():
                if isinstance(v, list) and v:
                    todo.append((str(v[0]), depth + 1))
    if not prompt:
        prompt = max((t for n in nodes.values() for t in _texts(n)), key=len, default='')
    return meta_text(graph_meta(graph)), ' '.join(prompt.split())[:PROMPT_MAX]


def _names(proc):
    out = []
    for arg in proc.cmdline()[1:]:
        for piece in re.split(r'[\s"]+', arg):
            name = PureWindowsPath(piece).name if piece else ''
            if name and SCRIPT_RE.match(name) and name not in out:
                out.append(name)
    return out


def _script_paths(proc):
    """Полные пути скриптов из командной строки: [(имя, путь)]; относительный путь — от рабочей папки процесса."""
    try:
        cwd = proc.cwd()
    except GONE:
        cwd = ''
    out = []
    for arg in proc.cmdline()[1:]:
        arg = arg.strip().strip('"')
        whole = SCRIPT_RE.match(PureWindowsPath(arg).name) if arg else None
        for piece in [arg] if whole else re.split(r'[\s"]+', arg):
            path = PureWindowsPath(piece) if piece else None
            if path and SCRIPT_RE.match(path.name):
                out.append((path.name, str(path if path.is_absolute() or not cwd else PureWindowsPath(cwd) / path)))
    return out


def script_path(chain, name):
    """Где лежит скрипт name из цепочки процессов (первый в подписи задачи): полный путь или ''."""
    for p in reversed(chain):
        try:
            for n, path in _script_paths(p):
                if n.lower() == name.lower():
                    return path
        except GONE:
            continue
    return ''


def describe_process(pid):
    """«job_x.cmd → run.py → main.py»: только имена скриптов цепочки, без аргументов."""
    if psutil is None or not isinstance(pid, int) or pid <= 0:
        return ''
    try:
        proc = psutil.Process(pid)
        key = (pid, proc.create_time())
        if key in _cache:
            return _cache[key]
        chain = [proc] + proc.parents()[:8]
        chain.reverse()
        jobs, rest = [], []
        for p in chain:
            try:
                for name in _names(p):
                    if name not in jobs and name not in rest:
                        (jobs if JOB_RE.match(name) else rest).append(name)
            except GONE:
                continue
        text = (' → '.join(jobs[:1] + rest[-2:]) or proc.name())[:120]
    except GONE:
        return ''
    if len(_cache) > 2048:
        _cache.clear()
    _cache[key] = text
    return text


def program_for(pid):
    """Какая программа запустила процесс: ближайшее известное приложение, иначе верхний не системный процесс."""
    if psutil is None or not isinstance(pid, int) or pid <= 0:
        return ''
    try:
        proc = psutil.Process(pid)
        chain = [proc] + proc.parents()[:12]
    except GONE:
        return ''
    top = ''
    for p in chain:
        try:
            name = p.name().lower()
        except GONE:
            continue
        if name in APPS:
            return APPS[name]
        if name not in SHELLS and name not in ('wininit.exe', 'winlogon.exe', 'system', 'smss.exe', 'csrss.exe'):
            top = re.sub(r'(?i)\.exe$', '', p.name())
    return top


def _listen_port(pids):
    try:
        ports = [c.laddr.port for c in psutil.net_connections('tcp')
                 if c.status == psutil.CONN_LISTEN and c.pid in pids and c.laddr]
    except GONE:
        return None
    return min(ports) if ports else None


def client_pid(port, skip=()):
    """PID единственного локального клиента, подключённого к порту (туннель ноутбука)."""
    if psutil is None or not port:
        return None
    try:
        pids = {c.pid for c in psutil.net_connections('tcp')
                if c.status == psutil.CONN_ESTABLISHED and c.raddr and c.raddr.port == port
                and c.raddr.ip in ('127.0.0.1', '::1') and c.pid and c.pid not in skip}
    except GONE:
        return None
    return pids.pop() if len(pids) == 1 else None


GENERIC_PROJECTS = {'unity', 'client', 'project', 'game', 'src', 'app'}


def describe_foreign(pid):
    """Подпись чужого процесса на GPU: движок, порт, задача, ссылка на чат, время запуска."""
    info = {'engine': '', 'port': None, 'task': '', 'ref': None, 'start': None, 'chain': [], 'leased': False,
            'out': None, 'app': '', 'path': ''}
    if psutil is None or not isinstance(pid, int) or pid <= 0:
        return info
    try:
        proc = psutil.Process(pid)
        info['start'] = proc.create_time()
        args = proc.cmdline()
        low = [a.lower() for a in args]
        if 'main.py' in [PureWindowsPath(a).name for a in low] or any('comfyui' in a for a in low):
            info['engine'] = 'ComfyUI'
        elif '-projectpath' in low:
            i = low.index('-projectpath')
            path = PureWindowsPath(args[i + 1]) if i + 1 < len(args) else None
            # Папка проекта «unity», «client» и т. п. ничего не говорит — берём папку выше (dwarf3d\unity → dwarf3d).
            name = (path.parent.name if path.name.lower() in GENERIC_PROJECTS and path.parent.name else path.name) if path else ''
            info['engine'] = ('Unity ' + name).strip()
        else:
            info['engine'] = re.sub(r'(?i)\.exe$', '', proc.name())
        if info['engine'] == 'ComfyUI':
            info['out'] = _output_dir(proc, args)
        info['port'] = _listen_port({pid, proc.ppid()})
        info['task'] = describe_process(pid)
        info['app'] = program_for(proc.ppid()) or program_for(pid)
        chain = [proc] + proc.parents()[:8]
        info['chain'] = [p.pid for p in chain]
        info['path'] = script_path(chain, info['task'].split(' → ')[0])   # панель: где лежит скрипт, обходящий очередь
        for p in chain:  # раннер под арендой: run_leased.py где-то выше по цепочке
            try:
                if 'run_leased.py' in [n.lower() for n in _names(p)]:
                    info['leased'] = True
                    break
            except GONE:
                continue
    except GONE:
        return info
    first = info['task'].split(' → ')[0]
    info['ref'] = chat_origin._call_for_pid(pid) or ('job:' + first.lower() if JOB_RE.match(first) else None)
    return info


def _output_dir(proc, args):
    """Папка результатов ComfyUI: --output-directory или output рядом с main.py (от рабочей папки)."""
    path = None
    for i, a in enumerate(args):
        if a.lower().startswith('--output-directory='):
            path = a.split('=', 1)[1]
        elif a.lower() == '--output-directory' and i + 1 < len(args):
            path = args[i + 1]
    if path is None:
        main = next((a for a in args if PureWindowsPath(a).name.lower() == 'main.py'), None)
        path = str(PureWindowsPath(main).parent / 'output') if main else None
    if path and not PureWindowsPath(path).is_absolute():
        try:
            path = str(PureWindowsPath(proc.cwd()) / path)
        except GONE:
            return None
    return path


def chat_for(ref):
    found = chat_origin.mappings().get(ref) if ref else None
    return found['title'] if found else ''
