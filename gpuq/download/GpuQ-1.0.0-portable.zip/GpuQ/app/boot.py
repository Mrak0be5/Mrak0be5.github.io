# -*- coding: utf-8 -*-
"""Запуск одного бэкенда ComfyUI внутри очереди gpuq.

gpuq поднимает несколько ComfyUI на соседних портах (по одному на карту и пул).
Эта обёртка повторяет приёмы боевого boot_qwen21.py — чистит sys.path от H3-Stable,
добавляет vendor, перехватывает stdout/stderr в отдельный журнал каждого бэкенда,
пишет свой PID в pid-файл — но берёт все пути из переменных окружения, чтобы один
файл годился и для Qwen21 (пул krea), и для портативного ComfyUI (пул h3).

Переменные окружения:
  GPUQ_COMFY_ROOT  — каталог установки ComfyUI (где лежит main.py);
  GPUQ_BACKEND_LOG — файл журнала бэкенда (utf-8, дозапись);
  GPUQ_PIDFILE     — куда записать os.getpid() (не обязателен).
Аргументы ComfyUI передаются как обычные argv этого скрипта.
"""
import os
import sys
import traceback
from pathlib import Path

ROOT = Path(os.environ["GPUQ_COMFY_ROOT"]).resolve()
os.chdir(ROOT)

pidfile = os.environ.get("GPUQ_PIDFILE")
if pidfile:
    try:
        Path(pidfile).write_text(str(os.getpid()), encoding="utf-8")
    except OSError:
        pass

# Пакет H3-Stable кладёт .pth, который затеняет дерево Qwen21. Убираем его из путей.
sys.path = [p for p in sys.path if Path(p).name != "ComfyUI-H3-Stable"]
vendor = ROOT / "vendor"
if vendor.is_dir():
    sys.path.insert(0, str(vendor))
    # triton из vendor ищет свой TinyCC только в site-packages (нужен для --use-sage-attention)
    tcc = vendor / "triton" / "runtime" / "tcc" / "tcc.exe"
    if tcc.exists():
        os.environ.setdefault("CC", str(tcc))
sys.path.insert(0, str(ROOT))
assets_dir = ROOT / "app" / "assets"
assets_init = assets_dir / "__init__.py"
if assets_dir.is_dir() and not assets_init.exists():
    try:
        assets_init.write_text("", encoding="utf-8")
    except OSError:
        pass

log_path = os.environ.get("GPUQ_BACKEND_LOG")
if log_path:
    logf = open(log_path, "a", encoding="utf-8", buffering=1)
    sys.stdout = logf
    sys.stderr = logf

print("\n=== GPUQ BACKEND BOOT === pid %d" % os.getpid(), flush=True)
print("root %s" % ROOT, flush=True)
print("argv %r" % sys.argv[1:], flush=True)

import runpy

# argv[0] должен указывать на main.py этого дерева: клиенты (_krea_gen, _comic, _krea_run)
# проверяют, что system_stats.argv[0] содержит "ComfyUI-Qwen21".
sys.argv = [str(ROOT / "main.py")] + sys.argv[1:]
try:
    runpy.run_path(str(ROOT / "main.py"), run_name="__main__")
except Exception:
    err = traceback.format_exc()
    print(err, flush=True)
    raise
