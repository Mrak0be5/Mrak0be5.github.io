@echo off
"%~dp0python\python.exe" "%~dp0app\gpuq_status.py" %*
