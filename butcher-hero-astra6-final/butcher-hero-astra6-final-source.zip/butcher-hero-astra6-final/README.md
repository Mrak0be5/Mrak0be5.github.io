# Butcher Hero — Astra 6 — Original 3D

An original, procedural Three.js advertising reel. English, 29.6 seconds, 1080×1920, 30 fps (888 frames), H.264 + AAC. All characters, props, environments, animation, typography compositing and sound effects are built in this project. No image/video generation APIs, game footage, stock visuals or external character models are used.

## Files

- `film.js`: eleven scenes, camera choreography, physical chains, screen graphics and the deterministic `render(t)` entry point.
- `hero.js`: the original stitched orange character, articulated mask/jaw, armored hands, boots and pose system.
- `world.js`: warriors, bosses, five themed islands, castle and three-floor tower.
- `weapons.js`: original saw, hook, hammer, axes, sword and instanced chain links.
- `audio.py`: seeded procedural 48 kHz stereo soundtrack and effects, 150 BPM, with the intentional 21.4–21.6 s pause.
- `render.mjs`, `render-server.sh`: server-only rendering and verification.
- `preview.html`: a seekable preview. Playback starts only on a click.
- `export-model.mjs`: export the final hero and held chainsaw as a self-contained GLB, preserving model parts, materials and pivot hierarchy. Run `/usr/bin/node export-model.mjs` on the server; animation tracks are not baked into this asset.
- `assets/fonts`: bundled fonts and their licenses.

## Server rendering

The launcher deliberately permits only Linux host `claude-hub-prod`. Do not render on the user's Windows PC. In this workspace, generic `node`/`npm`/`python` commands can forward to Windows: use explicit Linux executables.

```sh
/bin/sh render-server.sh
```

The launcher installs the locked Node dependencies if needed and generates the audio. It expects server Chrome at `/opt/google/chrome/chrome` and FFmpeg/FFprobe at `../../.cache/hubrender/bin/`; paths can be overridden with `SERVER_CHROME`, `FFMPEG` and `FFPROBE`. It uses a separate headless server Chromium process and does not connect to the user's browser. For installation from an empty archive, Node 22 or newer, a working Linux npm installation, Python 3 and pip are required. NumPy is installed in a project-local directory if needed.

Output: `output/butcher-hero-astra6-final_en.mp4`. Verification checks frame count, resolution, fps, duration, codecs, size, black frames and sound level. Timestamped frame hashes check deterministic rendering.

```sh
/usr/bin/node render.mjs --storyboard
/usr/bin/node render.mjs --still=23.2
/usr/bin/node render.mjs --verify-only
```

For a local preview on the server, run `/usr/bin/python3 -m http.server 8766` in this directory and open `preview.html` through your approved server preview route. The published page plays the pre-rendered MP4 and does not render 3D on the viewer's machine.

## Timeline

| Time | Scene |
| --- | --- |
| 0–2.4 | Hook and chew close-up |
| 2.4–5.6 | Eat and get stronger |
| 5.6–8.8 | Level 1 versus level 100 |
| 8.8–12.0 | Five new lands |
| 12.0–15.2 | Four epic weapons |
| 15.2–18.4 | Boss tower |
| 18.4–20.0 | Boss defeated |
| 20.0–21.6 | Giant rematch |
| 21.6–24.8 | Deity of destruction |
| 24.8–26.4 | Chained brand reveal |
| 26.4–29.6 | App icon and Play Free |

The original game name and requested marketing copy belong to their respective owners. Font licenses are included beside their files. Three.js is MIT licensed; other runtime dependencies retain their own licenses.
