import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

const mat=(c,rough=.65,metal=0)=>new THREE.MeshStandardMaterial({color:c,roughness:rough,metalness:metal});
const steel=mat('#343f55',.36,.68),edge=mat('#c3d4df',.25,.65),dark=mat('#17202b',.84),wood=mat('#473329',.85),gold=mat('#f0ae26',.35,.45);
function mesh(g,m,p=[0,0,0],r=[0,0,0]){const o=new THREE.Mesh(g,m);o.position.set(...p);o.rotation.set(...r);o.castShadow=true;o.receiveShadow=true;return o;}
function slab(points,depth,material,bevel=.04){const s=new THREE.Shape();points.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:!!bevel,bevelThickness:bevel,bevelSize:bevel,bevelSegments:2,steps:1,curveSegments:12});g.translate(0,0,-depth/2);return mesh(g,material)}
function box(w,h,d,m,p,r){return mesh(new THREE.BoxGeometry(w,h,d),m,p,r)}
function cylinder(r1,r2,h,m,p,r){return mesh(new THREE.CylinderGeometry(r1,r2,h,10),m,p,r)}
function torus(radius,tube,m,p,r){return mesh(new THREE.TorusGeometry(radius,tube,5,14),m,p,r)}
function pipe(points,r,m){return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),16,r,6,false),m)}
function grip(root,len=1.1){root.add(cylinder(.057,.075,len,wood,[0,-.12,0]));for(let i=0;i<6;i++)root.add(torus(.073,.014,dark,[0,-.55+i*.105,0],[Math.PI/2,0,0]));root.add(cylinder(.093,.093,.11,steel,[0,-.68,0]));}
function consolidate(root){root.updateMatrixWorld(true);const buckets=new Map();root.traverse(o=>{if(o.isMesh){if(!buckets.has(o.material))buckets.set(o.material,[]);const g=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();g.applyMatrix4(o.matrixWorld);buckets.get(o.material).push(g)}});root.clear();for(const [m,geos] of buckets){const g=mergeGeometries(geos,false);if(g)root.add(mesh(g,m));geos.forEach(g=>g.dispose())}return root;}

export function makeWeapon(kind='hammer'){
  const root=new THREE.Group();root.name='Weapon '+kind;
  if(kind==='hammer'){
    const violet=mat('#7952bd',.47,.18),facet=mat('#b5a3ef',.34,.24),shadow=mat('#392859',.58,.30);grip(root);
    root.add(box(.9,.53,.48,shadow,[0,.65,0]));
    for(const s of [-1,1]){
      const cap=slab([[-.12,-.25],[.08,-.30],[.21,-.14],[.21,.14],[.08,.30],[-.12,.25]],.58,violet,.05);cap.position.set(s*.45,.65,0);cap.scale.x=s;root.add(cap);
      root.add(box(.085,.57,.61,steel,[s*.34,.65,0]));
    }
    const crest=slab([[-.21,0],[-.10,.16],[.07,.22],[.22,.08],[.1,-.07]],.055,facet,.015);crest.position.set(0,.73,.32);root.add(crest);
    root.add(pipe([[-.25,.79,.26],[-.12,.64,.28],[.02,.70,.29],[.16,.48,.27]],.012,facet));
  }else if(kind==='iceaxe'||kind==='greenaxe'){
    const col=kind==='iceaxe'?'#3cacc6':'#69a92b',hi=kind==='iceaxe'?'#bcf3f1':'#c5e78a';const blade=mat(col,.57,.2),cut=mat(hi,.36,.37);grip(root);
    for(const s of [-1,1]){
      const shape=new THREE.Shape();shape.moveTo(.075,.43);shape.lineTo(.20,.56);shape.quadraticCurveTo(.25,.92,.58,1.15);shape.quadraticCurveTo(.54,.87,.74,.69);shape.quadraticCurveTo(.63,.31,.29,.25);shape.quadraticCurveTo(.30,.45,.075,.43);
      const g=new THREE.ExtrudeGeometry(shape,{depth:.14,bevelEnabled:true,bevelThickness:.04,bevelSize:.035,bevelSegments:2,curveSegments:9});g.translate(0,0,-.07);const a=mesh(g,blade);a.scale.x=s;root.add(a);
      const e=slab([[.60,1.09],[.55,.89],[.69,.68],[.60,.45],[.43,.32],[.31,.29],[.48,.39],[.59,.58],[.61,.72],[.50,.9]],.17,cut,.014);e.scale.x=s;root.add(e);
    }
    root.add(cylinder(.12,.12,.78,steel,[0,.6,0]));root.add(mesh(new THREE.IcosahedronGeometry(.15,0),cut,[0,.72,.04]));
  }else if(kind==='sword'){
    grip(root,.80);const blade=slab([[-.10,.1],[-.19,.30],[-.135,1.18],[0,1.51],[.135,1.18],[.19,.30],[.1,.1]],.06,gold,.04);root.add(blade);
    const rib=slab([[0,.21],[.06,.38],[.03,1.17],[0,1.44],[-.022,1.14],[-.04,.4]],.024,mat('#ffeab0',.29,.5),.009);rib.position.z=.085;root.add(rib);
    root.add(slab([[-.43,.12],[-.45,.0],[-.23,-.09],[0,.005],[.23,-.09],[.45,0],[.43,.12],[.17,.055],[-.17,.055]],.20,gold,.025));root.add(mesh(new THREE.IcosahedronGeometry(.13,0),gold,[0,-.68,0]));
  }else if(kind==='chainsaw'){
    const yellow=mat('#dc9f24',.58,.20),light=mat('#fbd068',.52,.10),orange=mat('#ae5124',.7,.08),bladeMat=mat('#73889a',.38,.6);
    const body=slab([[-.36,-.19],[-.37,.21],[-.20,.34],[.30,.29],[.4,.10],[.33,-.26],[-.12,-.34]],.46,yellow,.065);root.add(body);
    const panel=slab([[-.23,-.15],[-.25,.12],[-.12,.19],[.19,.16],[.25,.02],[.20,-.21]],.025,orange,.025);panel.position.z=.32;root.add(panel);
    root.add(box(.34,.22,.05,steel,[-.035,.015,.355]));for(let i=0;i<5;i++)root.add(box(.30,.017,.04,dark,[-.04,-.066+i*.039,.39]));
    root.add(cylinder(.105,.105,.075,edge,[.23,-.14,.365],[Math.PI/2,0,0]));root.add(cylinder(.055,.055,.078,dark,[.23,-.14,.405],[Math.PI/2,0,0]));
    const blade=slab([[-.105,.25],[-.16,1.27],[-.11,1.43],[0,1.5],[.11,1.43],[.16,1.27],[.105,.25]],.10,bladeMat,.018);root.add(blade);
    root.add(slab([[-.026,.41],[-.04,1.3],[0,1.36],[.04,1.3],[.026,.41]],.15,steel,.008));
    for(let i=0;i<26;i++){
      const a=i/26*Math.PI*2;let x=Math.cos(a)*.17,y=.87+Math.sin(a)*.62;const tooth=box(.065,.074,.13,i%2?edge:steel,[x,y,0],[0,0,a-.2]);root.add(tooth);
    }
    root.add(pipe([[-.41,-.12,0],[-.57,.05,0],[-.5,.45,0],[-.16,.5,0]],.065,dark));root.add(pipe([[.34,-.15,-.12],[.56,-.16,-.16],[.56,.22,-.16],[.34,.28,-.12]],.065,dark));
    root.add(box(.17,.08,.10,light,[-.19,.35,.11]));
    for(const [x,y] of [[-.24,-.20],[.22,.17],[-.24,.15]])root.add(cylinder(.026,.026,.07,edge,[x,y,.33],[Math.PI/2,0,0]));
  }else if(kind==='hook'){
    const h=new THREE.Shape();h.moveTo(-.055,-.35);h.lineTo(-.055,.24);h.bezierCurveTo(-.06,.55,.46,.64,.49,.23);h.bezierCurveTo(.53,-.02,.26,-.09,.20,.09);h.lineTo(.36,.09);h.bezierCurveTo(.42,.39,.08,.46,.075,.23);h.lineTo(.075,-.35);h.closePath();const g=new THREE.ExtrudeGeometry(h,{depth:.10,bevelEnabled:true,bevelThickness:.025,bevelSize:.025,bevelSegments:2,curveSegments:12});g.translate(-.2,0,-.05);root.add(mesh(g,mat('#e79557',.37,.52)));root.add(torus(.08,.025,steel,[-.19,-.4,0]));
  }
  consolidate(root);root.userData.type=kind;return root;
}

export function makeChainSystem(capacity=280){
  const chain=new THREE.InstancedMesh(new THREE.TorusGeometry(.045,.015,5,10),mat('#67798b',.48,.36),capacity);chain.name='Articulated chain links';chain.instanceMatrix.setUsage(THREE.DynamicDrawUsage);chain.frustumCulled=false;chain.castShadow=false;
  const dummy=new THREE.Object3D(),up=new THREE.Vector3(0,1,0);let cursor=0;
  function reset(){cursor=0;chain.visible=true;}
  function add(a,b,{sag=.3,time=0,links=22,wave=0,size=1}={}){
    a=new THREE.Vector3(...a);b=new THREE.Vector3(...b);const delta=b.clone().sub(a),distance=delta.length();if(distance<.075*size)return;sag=Math.min(sag,distance*.22);wave=Math.min(wave,distance*.10);links=Math.max(1,Math.ceil(Math.hypot(distance,sag*2)/(.087*size)));const tangent=new THREE.Vector3();
    for(let i=0;i<links&&cursor<capacity;i++){
      const t=(i+.5)/links;dummy.position.copy(a).lerp(b,t);dummy.position.y-=Math.sin(t*Math.PI)*sag;dummy.position.x+=Math.sin(t*Math.PI)*Math.sin(t*9+time*18)*wave;
      tangent.copy(delta);tangent.y-=Math.cos(t*Math.PI)*Math.PI*sag;tangent.x+=wave*(Math.PI*Math.cos(t*Math.PI)*Math.sin(t*9+time*18)+9*Math.sin(t*Math.PI)*Math.cos(t*9+time*18));tangent.normalize();dummy.quaternion.setFromUnitVectors(up,tangent);dummy.rotateY(i%2*Math.PI/2);dummy.scale.set(size,size*1.38,size);dummy.updateMatrix();chain.setMatrixAt(cursor++,dummy.matrix);
    }
  }
  function finish(){chain.count=cursor;chain.visible=cursor>0;chain.instanceMatrix.needsUpdate=true;}
  return {mesh:chain,reset,add,finish};
}
