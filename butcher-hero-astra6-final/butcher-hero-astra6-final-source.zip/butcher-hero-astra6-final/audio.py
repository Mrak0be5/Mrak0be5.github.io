#!/usr/bin/env python3
"""Original, deterministic score and foley for the final Astra 6 3D reel.

No samples, model calls, voices, or external audio. Only NumPy oscillators,
seeded noise, envelopes and modal synthesis. Run: python audio.py --output x.wav
"""
from __future__ import annotations

import argparse
from pathlib import Path
import platform
import wave

import numpy as np


SR = 48_000
DURATION = 29.6
N = round(SR * DURATION)
BEAT = .4
RNG = np.random.default_rng(6015055)
MUSIC = np.zeros((N, 2), dtype=np.float64)
FX = np.zeros_like(MUSIC)
KICKS: list[float] = []


def timebase(duration: float) -> np.ndarray:
    return np.arange(round(duration * SR), dtype=np.float64) / SR


def smooth_edges(y: np.ndarray, attack: float = .002, release: float = .01) -> np.ndarray:
    y = y.copy()
    a = min(round(attack * SR), len(y))
    r = min(round(release * SR), len(y))
    if a:
        y[:a] *= np.sin(np.linspace(0, np.pi / 2, a)) ** 2
    if r:
        y[-r:] *= np.cos(np.linspace(0, np.pi / 2, r)) ** 2
    return y


def add(bus: np.ndarray, at: float, y: np.ndarray, gain: float = 1, pan: float = 0) -> None:
    begin = round(at * SR)
    offset = max(0, -begin)
    begin = max(0, begin)
    end = min(N, begin + len(y) - offset)
    if end <= begin:
        return
    if y.ndim == 1:
        theta = (np.clip(pan, -1, 1) + 1) * np.pi / 4
        stereo = y[offset:offset + end - begin, None] * np.array([np.cos(theta), np.sin(theta)])
    else:
        stereo = y[offset:offset + end - begin]
    bus[begin:end] += stereo * gain


def noise(length: int, low: float = 80, high: float = 13000) -> np.ndarray:
    # Smooth frequency filtering keeps both hiss and synthetic foley controlled.
    x = RNG.standard_normal(length)
    spec = np.fft.rfft(x)
    freq = np.fft.rfftfreq(length, 1 / SR)
    filt = (1 - np.exp(-(freq / max(low, 1)) ** 4)) * np.exp(-(freq / high) ** 4)
    x = np.fft.irfft(spec * filt, n=length)
    return x / max(np.std(x), 1e-9)


def kick() -> np.ndarray:
    t = timebase(.38)
    phase = 2 * np.pi * (46 * t + 104 * .020 * (1 - np.exp(-t / .020)))
    body = np.sin(phase) * np.exp(-t / .095)
    dirt = np.tanh(2.3 * body) * .68
    click = noise(len(t), 1700, 5500) * np.exp(-t / .0035) * .16
    return smooth_edges(dirt + click, .0003, .035)


def snare() -> np.ndarray:
    t = timebase(.23)
    body = (np.sin(2 * np.pi * 177 * t) + .40 * np.sin(2 * np.pi * 303 * t)) * np.exp(-t / .044)
    snap = noise(len(t), 1200, 10500) * (np.exp(-t / .056) + .4 * np.exp(-((t - .010) / .004) ** 2))
    return smooth_edges(.34 * body + .32 * snap, .0007, .025)


def hat(opened: bool = False) -> np.ndarray:
    dur = .20 if opened else .065
    t = timebase(dur)
    ring = sum(np.sin(2 * np.pi * f * t) for f in (5431, 6879, 8141)) / 3
    y = (.75 * noise(len(t), 6000, 15000) + .25 * ring) * np.exp(-t / (.052 if opened else .015))
    return smooth_edges(y, .0003, .010)


def midi(number: int | float) -> float:
    return 440 * 2 ** ((number - 69) / 12)


def bass(note: int, dur: float, accent: bool = False) -> np.ndarray:
    t = timebase(dur)
    f = midi(note)
    glide = 1 + (.06 if accent else .025) * np.exp(-t / .017)
    phase = 2 * np.pi * np.cumsum(f * glide) / SR
    sub = np.sin(phase)
    buzzy = np.tanh(3.5 * np.sin(phase)) / 1.8 + .11 * np.sin(phase * 3)
    attack = 1 - np.exp(-t / .005)
    env = attack * (.64 + .36 * np.exp(-t / .07))
    return smooth_edges((.63 * sub + .37 * buzzy) * env, .003, .026)


def bell(note: int, dur: float = .35) -> np.ndarray:
    t = timebase(dur)
    f = midi(note)
    y = sum(amp * np.sin(2 * np.pi * f * ratio * t + .08 * np.sin(2 * np.pi * 6 * t))
            * np.exp(-t / decay)
            for ratio, amp, decay in ((1, .7, .14), (2.01, .24, .065), (3.99, .11, .05)))
    return smooth_edges(y, .001, .02)


def chord(notes: tuple[int, ...], dur: float) -> np.ndarray:
    t = timebase(dur)
    left, right = np.zeros(len(t)), np.zeros(len(t))
    for i, note in enumerate(notes):
        f = midi(note)
        for h in range(1, 6):
            left += np.sin(2 * np.pi * f * (1 - .0018) * h * t + i) / (h ** 1.7)
            right += np.sin(2 * np.pi * f * (1 + .0018) * h * t + i + .35) / (h ** 1.7)
    env = np.minimum(t / .20, 1) * np.minimum((dur - t) / .25, 1)
    env *= .75 + .25 * np.sin(2 * np.pi * 1.25 * t) ** 2
    return np.column_stack((left, right)) * env[:, None] / len(notes)


def chain(dur: float = .28, strength: float = 1) -> np.ndarray:
    t = timebase(dur)
    y = np.zeros(len(t))
    for k in range(8):
        onset = k * .019 + RNG.uniform(0, .007)
        u = np.maximum(t - onset, 0)
        gate = t >= onset
        ring = sum(np.sin(2 * np.pi * f * u + k) * np.exp(-u / decay)
                   for f, decay in ((1427 + 31 * k, .027), (2381 + 53 * k, .015), (4077 + 19 * k, .012)))
        y += ring * gate * (.13 - k * .010)
    y += noise(len(t), 1800, 9000) * np.exp(-t / .055) * .12
    return smooth_edges(y * strength, .001, .02)


def impact(dur: float = .55, weight: float = 1) -> np.ndarray:
    t = timebase(dur)
    phase = 2 * np.pi * (32 * t + 125 * .025 * (1 - np.exp(-t / .025)))
    thud = np.sin(phase) * np.exp(-t / .125)
    crack = noise(len(t), 250, 8000) * np.exp(-t / .035)
    ring = np.sin(2 * np.pi * 117 * t) * np.exp(-t / .15)
    return smooth_edges((.73 * thud + .24 * crack + .1 * ring) * weight, .0003, .03)


def hook() -> np.ndarray:
    t = timebase(.26)
    # Needle scratch, close metal bite, and a tiny elastic tail.
    rasp = noise(len(t), 1300, 8500) * np.exp(-t / .014) * .35
    phase = 2 * np.pi * (80 * t + 780 * .028 * (1 - np.exp(-t / .028)))
    puncture = np.sin(phase + 2 * np.sin(2 * np.pi * 44 * t)) * np.exp(-t / .052) * .45
    return smooth_edges(rasp + puncture + chain(.26, .30), .0003, .02)


def chew() -> np.ndarray:
    t = timebase(.29)
    y = np.zeros(len(t))
    for onset, f, decay, gain in ((0, 190, .04, .48), (.058, 110, .05, .33), (.12, 235, .034, .27)):
        u = np.maximum(t - onset, 0)
        phase = 2 * np.pi * (f * .34 * u + f * .66 * .027 * (1 - np.exp(-u / .027)))
        wet = np.sin(phase + 1.8 * np.sin(2 * np.pi * 36 * u))
        textured = noise(len(t), 150, 3300) * (.5 + .5 * np.sin(2 * np.pi * 74 * u))
        y += (wet + textured * .50) * np.exp(-u / decay) * (t >= onset) * gain
    return smooth_edges(np.tanh(1.25 * y), .0005, .02)


def whoosh(dur: float, rising: bool = True) -> np.ndarray:
    t = timebase(dur)
    p = t / dur
    env = np.sin(p * np.pi / 2) ** 2 if rising else np.cos(p * np.pi / 2) ** 2
    phase = 2 * np.pi * (140 * t + 1150 * t * t / (2 * dur))
    y = noise(len(t), 650, 7500) * .24 + np.sin(phase) * .075
    return smooth_edges(y * env, .012, .015)


def clank(note: int = 61) -> np.ndarray:
    t = timebase(.42)
    f = midi(note)
    ring = sum(np.sin(2 * np.pi * f * ratio * t) * amplitude * np.exp(-t / decay)
               for ratio, amplitude, decay in ((1, .34, .12), (2.71, .20, .045), (4.17, .13, .033)))
    return smooth_edges(ring + noise(len(t), 1700, 8500) * np.exp(-t / .009) * .19, .0004, .015)


def shimmer(at: float, notes: tuple[int, ...], gain: float = .16) -> None:
    for j, note in enumerate(notes):
        add(FX, at + j * .065, bell(note, .45), gain, (j % 3 - 1) * .28)


def score() -> None:
    roots = (38, 38, 34, 36)
    harmonies = ((50, 53, 57), (50, 53, 60), (46, 50, 53), (48, 52, 55))
    # 17 bars from 2.4 to 29.6. Per-scene instrumentation preserves the cuts.
    for bar in range(17):
        at = 2.4 + bar * 1.6
        underdog = bar in (2, 3)
        tower = bar in (8, 9)
        rematch = bar == 11
        logo = bar == 14
        cta = bar >= 15
        intensity = .55 if underdog else (.70 if rematch else 1)
        root = roots[(bar // 2) % 4]
        if bar in (0, 12, 13, 15, 16):
            root = 38
        # Spacious synthetic string/organ chord; deliberately below the foley.
        add(MUSIC, at, chord(harmonies[(bar // 2) % 4], 1.6), .070 if tower else .043)
        kicks = (0, 2) if underdog else ((0, 1.5, 2, 3.5) if bar % 2 else (0, 1.75, 2, 3.25))
        if rematch:
            kicks = (0, 1, 2)
        for b in kicks:
            add(MUSIC, at + b * BEAT, kick(), .53 * intensity)
            KICKS.append(at + b * BEAT)
        for b in (1, 3):
            add(MUSIC, at + b * BEAT, snare(), .29 * intensity)
            add(MUSIC, at + b * BEAT + .014, clank(43), .038, .2)
        for h in range(8):
            if underdog and h % 2:
                continue
            add(MUSIC, at + h * .2, hat(h in (3, 7) and not underdog),
                (.060 if h % 2 else .085) * intensity, (-1 if h % 2 else 1) * .20)
        if not underdog and bar % 2:
            for h in (13, 14, 15):
                add(MUSIC, at + h * .1, hat(), .036, (h - 14) * .35)
        # Syncopated bass is the core hook, with octave pickup at each bar end.
        pattern = ((0, 0, .28), (.75, 0, .12), (1.5, 0, .16), (2, 0, .25),
                   (2.75, 7, .10), (3.25, 12, .15), (3.75, 7, .08))
        if underdog:
            pattern = ((0, 0, .40), (2, -5, .29))
        for offset, note, dur in pattern:
            add(MUSIC, at + offset * BEAT, bass(root + note, dur, offset == 0), .205 * intensity)
        # Arpeggio appears as the hero gains power; no melody in the standoff.
        if not underdog and not rematch:
            notes = (62, 69, 65, 74, 72, 65, 69, 61)
            for j in range(8):
                if tower and j % 2:
                    continue
                start = at + j * .2
                sound = bell(notes[(j + (bar % 2) * 2) % 8], .27)
                gain = .067 if tower else (.098 if cta else .083)
                pan = (-1 if j % 2 else 1) * .32
                add(MUSIC, start, sound, gain, pan)
                add(MUSIC, start + .3, sound, gain * .20, -pan)
        if bar in (1, 5, 7, 9, 13):
            for j in range(4):
                add(MUSIC, at + 1.2 + j * .1, snare(), .10 + .025 * j, (j - 1.5) * .14)
        if logo:
            # Give falling title letters room; harmonic pedal remains.
            start, end = round(at * SR), round((at + 1.6) * SR)
            MUSIC[start:end] *= .70
    # Punchy but subtle ducking keeps kick and bass distinct.
    duck = np.ones(N)
    for at in KICKS:
        i = round(at * SR)
        n = min(round(.17 * SR), N - i)
        duck[i:i+n] = np.minimum(duck[i:i+n], 1 - .10 * np.exp(-np.arange(n) / (SR * .047)))
    MUSIC[:] *= duck[:, None]


def foley() -> None:
    add(FX, 0, impact(.27, .55), .68)
    add(FX, .055, clank(74), .19, -.1)
    add(FX, .20, whoosh(.20), .42, -.25)
    add(FX, .40, impact(), .84)
    add(FX, .43, chain(.29), .42, .23)
    add(FX, .64, whoosh(.16), .68)
    add(FX, .80, hook(), .92)
    add(FX, .805, impact(.30, .7), .49)
    add(FX, 1.20, chew(), .78)
    add(FX, 1.22, impact(.22, .45), .44)
    add(FX, 1.60, chew(), .73)
    shimmer(1.65, (74, 81), .18)
    add(FX, 2.04, whoosh(.36), .64)

    for at in (2.4, 5.6, 8.8, 12, 15.2, 18.4, 20, 21.6, 24.8, 26.4):
        add(FX, at, impact(.64 if at == 21.6 else .48), .67 if at == 21.6 else .42)
    # Grow: kill, short local chains, four diminishing gulps and upgrade pings.
    for j, at in enumerate((2.80, 3.20, 3.60, 4.00)):
        add(FX, at, impact(), .48 if j == 0 else .28)
    for j, at in enumerate((3.20, 3.60, 4.00, 4.40)):
        pan = (j - 1.5) * .28
        add(FX, at, chain(.19), .24, pan)
        add(FX, at + .17, hook(), .32, pan)
        add(FX, at + .30, chew(), .35, pan * .5)
        shimmer(at + .37, (74 + j * 2,), .11)
    shimmer(4.80, (62, 65, 69, 74), .17)
    # Standoff: almost dry bassy stone resonance and one absurd nervous gulp.
    add(FX, 5.6, clank(26), .16)
    add(FX, 8.02, chew(), .19)
    add(FX, 8.42, whoosh(.38), .56)
    # The islands accelerate; the foley uses the same falling/island cadence.
    # Film uses attack_time = island_progress * .91 - .06; follow that
    # actual time warp so the accelerating islands remain frame-synchronous.
    for j, (at, duration) in enumerate(((8.8,.8),(9.6,.6),(10.2,.5),(10.7,.4),(11.1,.9))):
        hit = at + duration * (.06 / .91)
        chain_start = at + duration * (.46 / .91)
        puncture = at + duration * (.63 / .91)
        swallow = at + duration * (.76 / .91)
        add(FX, hit, impact(.30, .55), .30)
        add(FX, chain_start, chain(.18), .28, (j % 2 * 2 - 1) * .25)
        add(FX, puncture, hook(), .32)
        add(FX, swallow, chew(), .28)
        shimmer(swallow + .06, (69 + j * 2,), .13)
    # Arsenal springs: each element has a separate pitched metal signature.
    for j, at in enumerate((12.4, 12.8, 13.2, 13.6)):
        add(FX, at - .10, whoosh(.10), .28, (j - 1.5) * .30)
        add(FX, at, chain(.24), .40, (j - 1.5) * .30)
        add(FX, at, clank((62, 65, 69, 74)[j]), .29)
    add(FX, 14.2, whoosh(.20), .48)
    add(FX, 14.45, impact(.65), .61)
    add(FX, 14.45, chain(.36), .33)
    # Tower: descending iron gates, then a sparse vampire tritone sting.
    for at, note in ((15.6, 38), (16.0, 41), (16.4, 44)):
        add(FX, at, clank(note), .20, -.2 if note % 2 else .2)
    add(FX, 16.8, chord((50, 56, 61), 1.40), .068)
    add(FX, 18.20, whoosh(.20), .51)
    add(FX, 18.54, impact(.42, .72), .46)
    add(FX, 18.54, chain(.24), .31)
    add(FX, 18.78, chain(.18), .24)
    add(FX, 18.94, hook(), .57)
    add(FX, 19.08, chew(), .56)
    shimmer(19.2, (74, 69, 65, 62), .17)
    add(FX, 19.67, whoosh(.33), .43)
    # Rematch escalation: musical number increases, chains wind up then SILENCE.
    for at, note in ((20.0, 50), (20.4, 62), (20.8, 74), (21.0, 86)):
        add(FX, at, bell(note), .15)
    add(FX, 20.9, chain(.40), .39)
    add(FX, 21.12, whoosh(.28), .55)
    add(FX, 21.6, impact(.90, 1.10), .40)
    add(FX, 21.6, chain(.45), .34)
    add(FX, 21.77, clank(38), .25)
    add(FX, 22.17, chain(.20), .33)
    add(FX, 22.34, hook(), .60)
    add(FX, 22.47, chew(), .58)
    # Wordless victory is an instrumental brass-like chord, no synthetic voice.
    add(FX, 22.4, chord((38, 50, 57, 62), 1.10), .18)
    shimmer(22.8, (62, 69, 74, 77), .19)
    add(FX, 24.40, whoosh(.40), .52)
    # Logo has a clean iron clack on each beat.
    for at, note in ((24.8, 50), (25.2, 57), (25.6, 62), (26.0, 69)):
        add(FX, at, clank(note), .49)
        add(FX, at + .025, chain(.17), .22)
    # Small iron contacts track the staggered title letters within the beat.
    for start, count in ((24.94, 7), (25.34, 4)):
        for j in range(count):
            add(FX, start + .045*j, clank(62 + j % 3), .075, (j-(count-1)/2)*.075)
    # Final poster slam, elastic icon landing, reassuring CTA click.
    add(FX, 26.4, impact(.60, .80), .43)
    add(FX, 26.82, whoosh(.18, False), .31)
    shimmer(27.2, (74, 77, 81), .15)
    add(FX, 27.9, clank(81), .22)
    shimmer(27.9, (74, 81, 86), .15)


def render(output: Path) -> None:
    if platform.system() != 'Linux':
        raise RuntimeError('Synthesize on the Linux render server, never the user PC.')
    global RNG
    RNG = np.random.default_rng(6015055)
    MUSIC.fill(0)
    FX.fill(0)
    KICKS.clear()
    score()
    foley()
    # Preserve score dynamics; compress foley peaks smoothly without clipping.
    mix = MUSIC + np.tanh(FX * 1.13) * .64
    mix -= np.mean(mix, axis=0)
    # A short lead-in into absolute silence makes the rematch gap click-free.
    gap_start, gap_end = round(21.4 * SR), round(21.6 * SR)
    fade = round(.006 * SR)
    mix[gap_start-fade:gap_start] *= np.linspace(1, 0, fade)[:, None]
    mix[gap_start:gap_end] = 0
    # Tight end cadence with just enough tail to avoid an abrupt file edge.
    tail = round(.12 * SR)
    mix[-tail:] *= np.cos(np.linspace(0, np.pi / 2, tail))[:, None] ** 2
    peak = np.max(np.abs(mix))
    mix *= .925 / max(peak, 1e-9)
    pcm = np.round(np.clip(mix, -.93, .93) * 32767).astype('<i2')
    output.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(output), 'wb') as wav:
        wav.setnchannels(2)
        wav.setsampwidth(2)
        wav.setframerate(SR)
        wav.writeframes(pcm.tobytes())
    print(f'Wrote {output}: {N} frames, {DURATION:.3f}s, {SR}Hz, stereo PCM16')
    print(f'Peak={np.max(np.abs(mix)):.5f}, RMS={np.sqrt(np.mean(mix * mix)):.5f}, '
          f'silent gap nonzero samples={np.count_nonzero(pcm[gap_start:gap_end])}')
    for a, b in ((0, 2.4), (2.4, 5.6), (5.6, 8.8), (8.8, 12), (12, 15.2),
                 (15.2, 18.4), (18.4, 20), (20, 21.6), (21.6, 24.8), (24.8, 26.4), (26.4, 29.6)):
        block = mix[round(a * SR):round(b * SR)]
        print(f'{a:4.1f}-{b:4.1f}: RMS {np.sqrt(np.mean(block * block)):.4f}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).with_name('soundtrack.wav'))
    args = parser.parse_args()
    render(args.output)
