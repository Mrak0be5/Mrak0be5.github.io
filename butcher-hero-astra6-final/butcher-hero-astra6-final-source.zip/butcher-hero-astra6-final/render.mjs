import puppeteer from 'puppeteer-core';
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas';
import { createServer } from 'node:http';
import { createReadStream, existsSync, mkdirSync, writeFileSync, statSync, renameSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import { hostname } from 'node:os';
import { extname, dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';

if (process.platform !== 'linux' || hostname() !== 'claude-hub-prod') {
  throw new Error('This entry point runs only on the Linux render server claude-hub-prod.');
}
const ROOT = dirname(fileURLToPath(import.meta.url));
const OUT = join(ROOT, 'output');
const argv = process.argv.slice(2);
const flag = name => argv.includes(name);
const value = name => argv.find(arg => arg.startsWith(name + '='))?.slice(name.length + 1);
const draft = flag('--draft');
const W = draft ? 540 : 1080, H = draft ? 960 : 1920;
const FPS = 30, FRAMES = 888, DURATION = 29.6;
const FFMPEG = process.env.FFMPEG || resolve(ROOT, '../../.cache/hubrender/bin/ffmpeg');
const FFPROBE = process.env.FFPROBE || resolve(ROOT, '../../.cache/hubrender/bin/ffprobe');
const CHROME = process.env.SERVER_CHROME || '/opt/google/chrome/chrome';
const FILE = join(OUT, draft ? 'butcher-hero-astra6-final_draft.mp4' : 'butcher-hero-astra6-final_en.mp4');
const KEYS = [['HOOK & CHEW',1.4],['GROW',4.4],['UNDERDOG',7.4],['LANDS',10.3],['ARSENAL',14.2],['BOSS TOWER',17.6],['DINNER',19.45],['REMATCH',20.8],['DEITY',23.2],['LOGO',25.9],['PLAY FREE',28.6]];
mkdirSync(OUT, { recursive: true });

function command(binary, args) {
  const r = spawnSync(binary, args, { encoding:'utf8', maxBuffer:32*1024*1024 });
  if (r.error) throw r.error;
  if (r.status !== 0) throw new Error(`${binary} exited ${r.status}: ${r.stderr || r.stdout}`);
  return r;
}

function verify(file, frameChecks = null) {
  const p = JSON.parse(command(FFPROBE, ['-v','error','-count_frames','-show_streams','-show_format','-of','json',file]).stdout);
  const v = p.streams.find(s=>s.codec_type==='video'), a = p.streams.find(s=>s.codec_type==='audio');
  const inspection = command(FFMPEG, ['-hide_banner','-nostdin','-threads','2','-filter_threads','1','-i',file,'-vf','blackdetect=d=0.05:pix_th=0.02:pic_th=0.995','-af','volumedetect','-threads','2','-f','null','-']).stderr;
  const mean = Number(inspection.match(/mean_volume:\s*([-\w.]+) dB/)?.[1] ?? '-Infinity');
  const peak = Number(inspection.match(/max_volume:\s*([-\w.]+) dB/)?.[1] ?? '-Infinity');
  const black = inspection.split('\n').filter(s=>s.includes('black_start:'));
  const checks = {h264:v?.codec_name==='h264',aac:a?.codec_name==='aac',dimensions:v?.width===W&&v?.height===H,fps:v?.avg_frame_rate==='30/1',frames:Number(v?.nb_read_frames)===FRAMES,duration:Math.abs(Number(p.format.duration)-DURATION)<.02,under60MB:statSync(file).size<60_000_000,audible:Number.isFinite(mean)&&mean>-42,noBlackFrames:black.length===0};
  const report = {file,server:hostname(),bytes:statSync(file).size,width:v?.width,height:v?.height,frames:Number(v?.nb_read_frames),fps:v?.avg_frame_rate,duration:Number(p.format.duration),audioMeanDb:mean,audioPeakDb:peak,checks,black,frameChecks};
  writeFileSync(join(OUT,draft?'verification-draft.json':'verification.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify(report,null,2));
  const bad=Object.entries(checks).filter(([,yes])=>!yes).map(([name])=>name);
  if(bad.length)throw new Error(`Verification failed: ${bad.join(', ')}`);
}
if(flag('--verify-only')){verify(FILE);process.exit(0)}

const benchmarkModule = `
import * as THREE from 'three';
export async function createFilm(canvas,width,height){
 const glcanvas=document.createElement('canvas');
 const renderer=new THREE.WebGLRenderer({canvas:glcanvas,antialias:true,preserveDrawingBuffer:true});
 renderer.setSize(width,height,false);renderer.setPixelRatio(1);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.setClearColor(0x0c1525);renderer.outputColorSpace=THREE.SRGBColorSpace;
 const scene=new THREE.Scene();scene.background=new THREE.Color(0x0c1525);
 const camera=new THREE.PerspectiveCamera(36,width/height,.1,50);camera.position.set(5,4,9);camera.lookAt(0,1.4,0);
 scene.add(new THREE.HemisphereLight(0xa9cfff,0x4b1605,2));
 const key=new THREE.DirectionalLight(0xffd3a2,4);key.position.set(3,7,5);key.castShadow=true;key.shadow.mapSize.set(1024,1024);scene.add(key);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(40,40),new THREE.MeshStandardMaterial({color:0x26354a,roughness:.65}));floor.rotation.x=-Math.PI/2;floor.receiveShadow=true;scene.add(floor);
 const hero=new THREE.Group();scene.add(hero);
 const mesh=new THREE.Mesh(new THREE.TorusKnotGeometry(1,.32,96,12),new THREE.MeshStandardMaterial({color:0xec812b,metalness:.25,roughness:.36}));mesh.position.y=1.8;mesh.castShadow=true;mesh.receiveShadow=true;hero.add(mesh);
 for(let i=0;i<12;i++){const m=new THREE.Mesh(new THREE.IcosahedronGeometry(.25,1),new THREE.MeshStandardMaterial({color:i%2?0x72cacc:0xecd8ad,metalness:.4,roughness:.35}));let a=i*Math.PI/6;m.position.set(Math.cos(a)*1.6,1.8+Math.sin(a)*1.6,-.2);m.castShadow=true;hero.add(m)}
 const ctx=canvas.getContext('2d',{alpha:false});
 return {scene,camera,render(t){hero.rotation.y=t*.4;mesh.rotation.z=t*.25;renderer.render(scene,camera);ctx.drawImage(glcanvas,0,0,width,height);ctx.fillStyle='#fee415';ctx.font='900 90px sans-serif';ctx.textAlign='center';ctx.fillText('SERVER 3D',width/2,250)},dispose(){renderer.dispose()}};
}`;

function runtimeHTML() {
  const module = flag('--benchmark') ? '/__benchmark__.js' : (value('--module') || '/film.js');
  return `<!doctype html><html><meta charset="utf-8"><style>html,body{margin:0;background:#0b0c15;overflow:hidden}canvas{display:block;width:${W}px;height:${H}px}@font-face{font-family:'Londrina Solid';font-weight:900;src:url('/assets/fonts/LondrinaSolid-Black.ttf')}@font-face{font-family:'Londrina Solid';font-weight:400;src:url('/assets/fonts/LondrinaSolid-Regular.ttf')}@font-face{font-family:'Barlow Condensed';font-weight:700;src:url('/assets/fonts/BarlowCondensed-Bold.ttf')}</style><script type="importmap">{"imports":{"three":"/node_modules/three/build/three.module.js","three/addons/":"/node_modules/three/examples/jsm/"}}</script><canvas id="film" width="${W}" height="${H}"></canvas><script type="module">
import {createFilm} from '${module}';
const canvas=document.getElementById('film');
${existsSync(join(ROOT,'assets/fonts/LondrinaSolid-Black.ttf'))?'await document.fonts.load(\'900 100px "Londrina Solid"\');':''}
${existsSync(join(ROOT,'assets/fonts/LondrinaSolid-Regular.ttf'))?'await document.fonts.load(\'400 100px "Londrina Solid"\');':''}
await document.fonts.ready;
window.__film=await createFilm(canvas,${W},${H});
window.__render=async(t)=>{await window.__film.render(t)};
const sample=document.createElement('canvas');sample.width=27;sample.height=48;const ctx=sample.getContext('2d',{willReadFrequently:true});
window.__capture=async(t)=>{await window.__render(t);ctx.drawImage(canvas,0,0,27,48);const d=ctx.getImageData(0,0,27,48).data;let dark=0,sum=0;for(let i=0;i<d.length;i+=4){let b=Math.max(d[i],d[i+1],d[i+2]);sum+=b;if(b<5)dark++}return {png:canvas.toDataURL('image/png').split(',')[1],mean:sum/(27*48),dark:dark/(27*48)}};
window.__filmReady=true;
</script></html>`;
}

const types={'.js':'text/javascript','.mjs':'text/javascript','.html':'text/html','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.ttf':'font/ttf','.wav':'audio/wav','.mp4':'video/mp4','.glb':'model/gltf-binary'};
const server=createServer((req,res)=>{
  const path=new URL(req.url,'http://127.0.0.1').pathname;
  if(path==='/favicon.ico'){res.writeHead(204);res.end();return}
  if(path==='/__render__'){res.writeHead(200,{'Content-Type':'text/html'});res.end(runtimeHTML());return}
  if(path==='/__benchmark__.js'){res.writeHead(200,{'Content-Type':'text/javascript'});res.end(benchmarkModule);return}
  const file=resolve(ROOT,'.'+decodeURIComponent(path));
  if(!file.startsWith(ROOT+'/')||!existsSync(file)||!statSync(file).isFile()){res.writeHead(404);res.end('Not found');return}
  res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-store'});createReadStream(file).pipe(res);
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
let browser;
try{
 browser=await puppeteer.launch({executablePath:CHROME,headless:true,pipe:true,timeout:120000,protocolTimeout:180000,env:{...process.env,PATH:'/usr/bin:/bin:/usr/sbin:/sbin',OMP_NUM_THREADS:'2',LP_NUM_THREADS:'2'},args:['--no-sandbox','--disable-dev-shm-usage','--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-background-timer-throttling','--disable-renderer-backgrounding','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--num-raster-threads=2','--renderer-process-limit=1','--hide-scrollbars','--mute-audio']});
 const page=await browser.newPage();await page.setViewport({width:W,height:H,deviceScaleFactor:1});
 const errors=[];page.on('pageerror',e=>{errors.push(e.message);console.error('PAGE ERROR',e.message)});
 page.on('console',message=>{if(message.type()==='error'){const text=message.text();console.error('BROWSER',text);if(text.includes('THREE.')&&text.includes('failed'))errors.push(text)}});
 await page.goto(`http://127.0.0.1:${server.address().port}/__render__`,{waitUntil:'networkidle0',timeout:120000});
 await page.waitForFunction(()=>window.__filmReady===true,{timeout:120000});
 async function capture(t){
   if(errors.length)throw new Error(errors.join('\n'));
   const result=await page.evaluate(t=>window.__capture(t),t);
   if(result.dark>.995)throw new Error(`Unexpected black source frame at ${t}s`);
   return {...result,buffer:Buffer.from(result.png,'base64')};
 }
 if(flag('--benchmark')){
   await capture(0);
   const stats=[];
   for(const mode of ['canvas-png','cdp-png']){
     const times=[];let bytes=0;
     for(let i=0;i<10;i++){
       const start=performance.now();let buffer;
       if(mode==='canvas-png')buffer=(await capture((i+1)/30)).buffer;
       else{await page.evaluate(t=>window.__render(t),(i+1)/30);buffer=await page.screenshot({type:'png',captureBeyondViewport:false,optimizeForSpeed:true})}
       times.push((performance.now()-start)/1000);bytes+=buffer.length;
       if(i===9)writeFileSync(join(OUT,`benchmark-${mode}.png`),buffer);
     }
     stats.push({mode,frames:10,meanSeconds:times.reduce((a,b)=>a+b,0)/times.length,times,meanBytes:bytes/10});
   }
   const result={server:hostname(),chrome:await browser.version(),width:W,height:H,scene:'13 standard-material objects + floor + 1024 shadow map + 2D copy and caption',stats};
   writeFileSync(join(OUT,'benchmark.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
 }else if(flag('--storyboard')){
   const font=join(ROOT,'assets/fonts/LondrinaSolid-Black.ttf');if(existsSync(font))GlobalFonts.registerFromPath(font,'Londrina Solid');
   const sheet=createCanvas(1170,1672),ctx=sheet.getContext('2d');ctx.fillStyle='#10111A';ctx.fillRect(0,0,sheet.width,sheet.height);ctx.fillStyle='#FEE415';ctx.font='900 27px "Londrina Solid", sans-serif';ctx.fillText('BUTCHER HERO / ASTRA 6 / ORIGINAL 3D',18,39);mkdirSync(join(OUT,'keyframes'),{recursive:true});
   for(let i=0;i<KEYS.length;i++){const [name,t]=KEYS[i],captureResult=await capture(t),image=await loadImage(captureResult.buffer);const x=18+(i%4)*288,y=60+Math.floor(i/4)*534;ctx.drawImage(image,x,y,270,480);ctx.fillStyle='#EEEDE9';ctx.font='900 18px "Londrina Solid", sans-serif';ctx.fillText(`${String(i+1).padStart(2,'0')} ${name} / ${t.toFixed(2)}s`,x,y+506);writeFileSync(join(OUT,'keyframes',`${String(i+1).padStart(2,'0')}.png`),captureResult.buffer);console.log(`Storyboard ${i+1}/11`)}
   writeFileSync(join(OUT,'storyboard.png'),sheet.toBuffer('image/png'));console.log('Storyboard:',join(OUT,'storyboard.png'));
 }else if(value('--still')!==undefined){
   const t=Number(value('--still'));if(!Number.isFinite(t)||t<0||t>=DURATION)throw new Error('Still timestamp must be in [0,29.6)');const result=await capture(t);const path=join(OUT,`still-${t.toFixed(3).replace('.','p')}.png`);writeFileSync(path,result.buffer);console.log(path);
 }else{
   const audio=join(OUT,'soundtrack.wav');if(!existsSync(audio))throw new Error('Missing output/soundtrack.wav. Generate the score before rendering.');
   const hashes=[];
   for(let i=0;i<KEYS.length;i++){
     const[scene,t]=KEYS[i],perturbTime=KEYS[(i+5)%KEYS.length][1];
     const one=(await capture(t)).buffer;
     // Exercise scene/material/pose resets, not merely repeated identical calls.
     await capture(perturbTime);
     const two=(await capture(t)).buffer;
     const a=createHash('sha256').update(one).digest('hex'),b=createHash('sha256').update(two).digest('hex');
     if(a!==b)throw new Error(`History-dependent keyframe ${scene}: render(${t}) → render(${perturbTime}) → render(${t}) differed`);
     hashes.push({scene,t,perturbTime,sha256:a});
   }
   const partial=FILE.replace('.mp4','.partial.mp4');
   const ffmpeg=spawn(FFMPEG,['-hide_banner','-nostdin','-y','-threads','2','-filter_threads','1','-f','image2pipe','-vcodec','png','-framerate',String(FPS),'-i','pipe:0','-i',audio,'-map','0:v:0','-map','1:a:0','-c:v','libx264','-preset','medium','-crf','19','-maxrate','12M','-bufsize','24M','-pix_fmt','yuv420p','-r',String(FPS),'-frames:v',String(FRAMES),'-threads','2','-c:a','aac','-b:a','192k','-ar','48000','-t',String(DURATION),'-movflags','+faststart','-metadata','title=Butcher Hero — Astra 6 — Original 3D',partial],{stdio:['pipe','ignore','pipe']});
   let log='',pipeError=null;ffmpeg.stderr.on('data',chunk=>{log=(log+chunk.toString()).slice(-32000)});ffmpeg.stdin.on('error',error=>{pipeError=error});const done=once(ffmpeg,'close');let darkestMean=Infinity,maximumDarkFraction=0;const start=performance.now();
   try{for(let frame=0;frame<FRAMES;frame++){if(pipeError)throw pipeError;const result=await capture(frame/FPS);darkestMean=Math.min(darkestMean,result.mean);maximumDarkFraction=Math.max(maximumDarkFraction,result.dark);if(!ffmpeg.stdin.write(result.buffer))await once(ffmpeg.stdin,'drain');if(frame%30===0||frame===FRAMES-1){const seconds=(performance.now()-start)/1000;console.log(`Frame ${frame+1}/${FRAMES} (${((frame+1)/FRAMES*100).toFixed(1)}%), elapsed ${seconds.toFixed(1)}s, ETA ${(seconds/(frame+1)*(FRAMES-frame-1)).toFixed(0)}s`)}}ffmpeg.stdin.end();const[status]=await done;if(status!==0)throw new Error(`FFmpeg ${status}: ${log}`)}catch(error){ffmpeg.stdin.destroy();ffmpeg.kill('SIGTERM');throw new Error(error.message+'\n'+log,{cause:error})}
   renameSync(partial,FILE);verify(FILE,{sourceFramesInspected:FRAMES,darkestMean,maximumDarkFraction,deterministic:hashes,renderSeconds:(performance.now()-start)/1000});console.log('Rendered and verified:',FILE);
 }
}finally{
 if(browser)await browser.close();
 await new Promise(resolve=>server.close(resolve));
}
