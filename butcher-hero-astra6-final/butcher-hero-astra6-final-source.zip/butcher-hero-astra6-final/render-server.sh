#!/bin/sh
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin
export PATH
if [ "$(uname -s)" != Linux ] || [ "$(hostname)" != claude-hub-prod ]; then
  echo 'Render only on the Linux server claude-hub-prod.' >&2
  exit 1
fi
cd "$(dirname "$0")"
if [ ! -d node_modules/three ]; then
  /usr/bin/node /usr/lib/node_modules/npm/bin/npm-cli.js ci --no-audit --no-fund
fi
if [ -f audio.py ]; then
  PYTHONPATH="$PWD/.audio-deps${PYTHONPATH:+:$PYTHONPATH}"
  export PYTHONPATH
  if ! /usr/bin/python3 -c 'import numpy' >/dev/null 2>&1; then
    /usr/bin/python3 -m pip install --target "$PWD/.audio-deps" 'numpy==2.5.3'
  fi
  /usr/bin/python3 audio.py --output output/soundtrack.wav
fi
exec /usr/bin/node render.mjs "$@"
