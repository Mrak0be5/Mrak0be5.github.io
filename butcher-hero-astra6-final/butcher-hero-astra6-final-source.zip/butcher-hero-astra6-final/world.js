import * as THREE from 'three';

// Fresh, deterministic, asset-free game art. Y up; character fronts face +Z.
// Static scenery is merged by material to keep the software renderer practical.
const TAU=Math.PI*2;
const materials=new Map();
function material(color,emissive=0,metalness=0){
  const key=`${color}|${emissive}|${metalness}`;
  if(!materials.has(key)) materials.set(key,new THREE.MeshStandardMaterial({color,roughness:.83,metalness,flatShading:true,emissive:emissive?color:0,emissiveIntensity:emissive}));
  return materials.get(key);
}
function rng(seed=91){return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}
function group(name){const g=new THREE.Group();g.name=name;return g;}
function mesh(parent,geometry,color,x=0,y=0,z=0,emissive=0){
  const o=new THREE.Mesh(geometry,typeof color==='object'?color:material(color,emissive));o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;
}
function polyGeometry(points,depth=.2,bevel=.05){
  const shape=new THREE.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
  const geo=new THREE.ExtrudeGeometry(shape,{depth,bevelEnabled:bevel>0,bevelThickness:bevel,bevelSize:bevel,bevelSegments:1,steps:1,curveSegments:3});geo.translate(0,0,-depth/2);return geo;
}
function poly(parent,points,depth,color,x=0,y=0,z=0,bevel=.04){return mesh(parent,polyGeometry(points,depth,bevel),color,x,y,z);}
function block(parent,w,h,d,color,x=0,y=0,z=0,b=.05){
  const c=Math.min(b,w*.2,h*.2);return poly(parent,[[-w/2+c,-h/2],[w/2-c,-h/2],[w/2,-h/2+c],[w/2,h/2-c],[w/2-c,h/2],[-w/2+c,h/2],[-w/2,h/2-c],[-w/2,-h/2+c]],d,color,x,y,z,c*.3);
}
function ball(parent,scale,color,x=0,y=0,z=0,detail=1){const o=mesh(parent,new THREE.IcosahedronGeometry(1,detail),color,x,y,z);o.scale.set(...scale);return o;}
function cylinder(parent,radiusTop,radiusBottom,height,color,x=0,y=0,z=0,sides=8){return mesh(parent,new THREE.CylinderGeometry(radiusTop,radiusBottom,height,sides),color,x,y,z);}
function beam(parent,a,b,width,color,depth=width){const d=new THREE.Vector3().subVectors(new THREE.Vector3(...b),new THREE.Vector3(...a));const m=block(parent,width,d.length(),depth,color,...new THREE.Vector3(...a).add(new THREE.Vector3(...b)).multiplyScalar(.5).toArray(),width*.15);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d.normalize());return m;}
function line(parent,points,radius,color,emissive=0){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));return mesh(parent,new THREE.TubeGeometry(curve,Math.max(4,points.length*2),radius,5,false),color,0,0,0,emissive);}
function eyes(parent,y,z,w=.23,color='#ff5a2b',size=.09){
  for(const s of [-1,1]){const e=block(parent,w,size,.06,color,s*w*.77,y,z,.005);e.rotation.z=s*.17;}
}
function normalize(g,height){g.updateMatrixWorld(true);const b=new THREE.Box3().setFromObject(g),h=b.max.y-b.min.y,s=height/h;g.scale.multiplyScalar(s);g.position.y=-b.min.y*s;const wrapper=group(g.name);wrapper.add(g);wrapper.userData={...g.userData,height,model:g};return wrapper;}

function mergeStatic(root){
  root.updateMatrixWorld(true);const batches=new Map();
  root.traverse(o=>{if(o.isMesh){const key=o.material.uuid;if(!batches.has(key))batches.set(key,{material:o.material,geos:[]});const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(o.matrixWorld);batches.get(key).geos.push(geo);}});
  const result=group(root.name);for(const {material:mat,geos}of batches.values()){
    let n=0;for(const geo of geos)n+=geo.attributes.position.count;
    const p=new Float32Array(n*3),norm=new Float32Array(n*3);let offset=0;
    for(const geo of geos){p.set(geo.attributes.position.array,offset);norm.set(geo.attributes.normal.array,offset);offset+=geo.attributes.position.array.length;geo.dispose();}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(p,3));geo.setAttribute('normal',new THREE.BufferAttribute(norm,3));geo.computeBoundingSphere();const m=mesh(result,geo,mat);m.name='Static '+mat.color.getHexString();
  }return result;
}

function warrior(){
  const g=group('Red armored warrior'),parts={};
  for(const s of [-1,1]){block(g,.34,.28,.54,'#283143',s*.26,.15,.08);beam(g,[s*.26,.25,0],[s*.26,.76,0],.24,'#4c2838');block(g,.29,.31,.31,'#982c43',s*.27,.49,.06);}
  block(g,.78,.32,.47,'#392d42',0,.77,0);block(g,.88,.73,.53,'#a62a3d',0,1.21,0);
  poly(g,[[-.34,-.20],[.34,-.20],[.42,.18],[0,.28],[-.42,.18]],.09,'#e25055',0,1.30,.32);
  block(g,.70,.13,.61,'#222739',0,.87,.05);block(g,.14,.16,.06,'#dda354',0,.88,.40);
  for(const s of [-1,1]){const arm=group(s<0?'leftArm':'rightArm');g.add(arm);arm.position.set(s*.52,1.44,0);parts[s<0?'leftArm':'rightArm']=arm;ball(arm,[.26,.23,.26],'#d2454e');beam(arm,[s*.05,-.12,0],[s*.11,-.65,.05],.23,'#762539');block(arm,.26,.26,.30,'#c39372',s*.11,-.66,.06);}
  const head=group('head');head.position.set(0,1.76,.02);g.add(head);parts.head=head;
  ball(head,[.35,.35,.32],'#a82c41');poly(head,[[-.32,-.09],[.32,-.09],[.29,.18],[0,.30],[-.29,.18]],.09,'#cf4850',0,.03,.26);
  block(head,.49,.10,.07,'#241e30',0,-.02,.36);eyes(head,-.015,.405,.145,'#ffd97a',.035);
  block(head,.075,.38,.08,'#cf6065',0,-.07,.40);poly(head,[[-.09,-.12],[.10,-.12],[.13,.42],[-.04,.55],[-.13,.35]],.12,'#6a1830',0,.33,-.06);
  const sword=group('warrior sword');g.add(sword);sword.position.set(.75,.79,.14);sword.rotation.z=-.22;block(sword,.11,.29,.10,'#442d34',0,0,0);block(sword,.44,.08,.13,'#dda353',0,.15,0);poly(sword,[[-.09,0],[.09,0],[.08,.75],[0,.91],[-.08,.75]],.07,'#b9d2dd',0,.19,0,.015);
  g.userData=parts;return normalize(g,2);
}

function golem(ice=false){
  const g=group(ice?'Ice golem':'Lava golem'),stone=ice?'#72a5bd':'#57526f',light=ice?'#b4e5eb':'#77738b',dark=ice?'#315777':'#342d47',fire=ice?'#a8f6ff':'#ff6522';
  for(const s of [-1,1]){ball(g,[.67,.36,.87],dark,s*.75,.32,.27);ball(g,[.57,.91,.56],stone,s*.77,1.11,0);ball(g,[.51,.44,.50],light,s*.73,1.76,.02);}
  ball(g,[1.42,1.57,.87],stone,0,3.03,0);poly(g,[[-1.12,-.8],[1.12,-.8],[1.32,.40],[.71,1.15],[-.75,1.15],[-1.32,.4]],.28,light,0,3.12,.65,.065);
  for(const s of [-1,1]){const arm=group(s<0?'leftArm':'rightArm');g.add(arm);arm.position.set(s*1.30,3.85,0);g.userData[arm.name]=arm;ball(arm,[.76,.73,.73],light);ball(arm,[.54,.86,.52],stone,s*.37,-.78,.02);ball(arm,[.65,.66,.67],dark,s*.47,-1.72,.20);for(let k=0;k<3;k++)block(arm,.30,.35,.27,light,s*.47+(k-1)*.30,-1.56,.75,.045);}
  const head=group('head');head.position.set(0,4.82,.03);g.add(head);g.userData.head=head;
  ball(head,[.90,.88,.80],stone);poly(head,[[-.68,-.42],[.68,-.42],[.72,.42],[.4,.69],[-.4,.69],[-.72,.42]],.22,dark,0,.02,.64,.055);
  eyes(head,.16,.82,.40,fire,.12);for(const s of [-1,1]){const brow=block(head,.64,.18,.20,light,s*.36,.36,.85);brow.rotation.z=s*.23;}
  poly(head,[[-.47,.1],[.47,.1],[.33,-.19],[-.32,-.19]],.04,'#170e20',0,-.28,.81,.012);
  for(let j=0;j<4;j++)poly(head,[[-.055,.06],[.055,.06],[0,-.11]],.03,fire,(j-1.5)*.17,-.24,.855,.004);
  const cracks=[[[0,4.2,.92],[-.24,3.79,1.04],[.17,3.35,1.13],[-.27,2.87,1.06]], [[-.26,3.8,1.04],[-.91,3.6,.95],[-1.18,3.14,.72]],[[.15,3.35,1.13],[.77,3.55,1.02],[1.19,3.29,.78]], [[-.27,2.87,1.06],[.35,2.56,.91],[.58,2.08,.55]]];
  for(const points of cracks){line(g,points,.095,'#261e30');line(g,points.map(([x,y,z])=>[x,y,z+.105]),.042,fire,.35);}
  if(ice)for(const s of [-1,1]){const crystal=cylinder(g,0,.24,.79,'#b4f5ff',s*1.55,4.30,-.12,4);crystal.rotation.z=s*-.45;}
  return normalize(g,ice?2:6);
}

function bear(){
  const g=group('Candy island bear');ball(g,[.64,.76,.42],'#754732',0,.93,0);ball(g,[.46,.55,.09],'#b6885b',0,.98,.40);
  for(const s of [-1,1]){ball(g,[.29,.24,.41],'#51352b',s*.37,.23,.19);ball(g,[.27,.50,.25],'#70462f',s*.68,.85,.03);ball(g,[.25,.22,.26],'#51352b',s*.68,.48,.16);}
  const h=group('head');h.position.set(0,1.62,.08);g.add(h);g.userData.head=h;ball(h,[.52,.47,.42],'#8c573b');for(const s of [-1,1]){ball(h,[.19,.20,.11],'#71422e',s*.38,.36,-.02);ball(h,[.11,.12,.055],'#bc8256',s*.38,.36,.077);}
  ball(h,[.33,.24,.21],'#ceaa76',0,-.16,.36);ball(h,[.17,.105,.10],'#262a32',0,-.09,.54);eyes(h,.085,.43,.13,'#171d29',.065);block(h,.22,.045,.06,'#39232c',0,-.29,.52,.01);
  for(const s of [-1,1])poly(h,[[-.045,.055],[.045,.055],[0,-.07]],.04,'#f0dfbd',s*.14,-.26,.56,.005);return normalize(g,2);
}

function dragon(){
  const g=group('Young ember dragon');ball(g,[.41,.61,.37],'#b34939',0,.72,0);ball(g,[.25,.46,.085],'#e9b76d',0,.72,.37);
  for(const s of [-1,1]){ball(g,[.22,.19,.36],'#82323a',s*.30,.17,.19);const wing=poly(g,[[0,0],[s*.68,.45],[s*1.08,.34],[s*.82,-.04],[s*.45,.08],[s*.25,-.25]],.055,'#276e70',s*.30,1.01,-.12,.015);beam(g,[s*.31,1.02,-.08],[s*1.35,1.38,-.08],.075,'#273a43');beam(g,[s*.37,1.32,0],[s*.53,.84,.15],.12,'#c75b40');}
  line(g,[[0,.45,-.22],[.21,.33,-.75],[.50,.64,-1.02]],.12,'#a33b3b');poly(g,[[-.14,0],[.12,0],[.02,.35]],.10,'#ec9944',.52,.71,-1.00,.02);
  const h=group('head');h.position.set(0,1.50,.17);g.add(h);g.userData.head=h;ball(h,[.42,.37,.43],'#c95741');ball(h,[.32,.17,.27],'#dc8554',0,-.12,.37);eyes(h,.05,.50,.16,'#ffda48',.085);
  for(const s of [-1,1]){const horn=cylinder(h,0,.095,.41,'#ead5a0',s*.28,.43,-.09,5);horn.rotation.z=-s*.30;ball(h,[.035,.03,.02],'#472b35',s*.14,-.08,.63,0);}return normalize(g,2);
}

function zombie(){
  const g=group('Graveyard zombie');for(const s of [-1,1]){block(g,.26,.22,.43,'#34293b',s*.22,.12,.09);beam(g,[s*.22,.24,0],[s*.19,.73,0],.20,'#466c54');}
  poly(g,[[-.42,-.40],[-.19,-.32],[0,-.46],[.21,-.31],[.42,-.42],[.37,.4],[-.36,.4]],.35,'#4e3452',0,1.03,0,.035);
  poly(g,[[-.10,-.32],[.21,-.17],[.25,.35],[-.05,.37]],.07,'#7b9a59',.03,1.06,.24);
  for(const s of [-1,1]){const a=group(s<0?'leftArm':'rightArm');g.add(a);a.position.set(s*.42,1.25,0);g.userData[a.name]=a;beam(a,[0,0,0],[s*.10,-.36,.15],.17,'#668752');beam(a,[s*.10,-.36,.15],[s*.14,-.44,.47],.14,'#8cab63');block(a,.18,.16,.17,'#91a866',s*.14,-.45,.51);}
  const h=group('head');h.position.set(.05,1.73,.05);h.rotation.z=-.12;g.add(h);g.userData.head=h;block(h,.65,.63,.50,'#89a966',0,0,0,.08);block(h,.20,.12,.06,'#25352b',-.17,.09,.29,.01);ball(h,[.10,.115,.025],'#e5ddad',.17,.10,.30);ball(h,[.04,.05,.015],'#d94326',.18,.10,.329);block(h,.32,.12,.04,'#354032',.02,-.16,.295,.01);for(let j=0;j<3;j++)block(h,.055,.065,.035,'#ede2bb',(j-1)*.07,-.12,.322,.003);block(h,.59,.095,.48,'#333e36',0,.33,-.02,.01);return normalize(g,2);
}

function vampire(){
  const g=group('Vampire king');
  poly(g,[[-.47,-1.04],[-.69,-1.00],[-.97,-.53],[-1.08,.60],[-.63,.92],[0,.48],[.63,.92],[1.08,.60],[.97,-.53],[.69,-1.00],[.47,-1.04]],.10,'#671c39',0,1.13,-.29,.025);
  poly(g,[[-.40,-.99],[.0,-.81],[.40,-.99],[.28,.41],[.47,.69],[0,.78],[-.47,.69],[-.28,.41]],.35,'#252335',0,1.09,0,.035);
  poly(g,[[-.22,-.70],[0,-.85],[.22,-.70],[.14,.49],[-.14,.49]],.055,'#b92c46',0,1.14,.25,.02);
  for(const s of [-1,1]){poly(g,[[0,-.2],[s*.44,.19],[s*.45,.59],[s*.16,.50]],.10,'#b63b51',s*.24,1.55,.0,.03);beam(g,[s*.36,1.51,0],[s*.61,1.10,.17],.19,'#32253d');ball(g,[.12,.20,.12],'#dcc7a4',s*.65,1.01,.19);block(g,.25,.18,.35,'#1e2130',s*.20,.10,.09);}
  const h=group('head');h.position.set(0,2.0,.06);g.add(h);g.userData.head=h;poly(h,[[-.26,-.19],[0,-.47],[.26,-.19],[.30,.23],[0,.37],[-.30,.23]],.33,'#ead8b4');
  poly(h,[[-.29,.17],[-.15,.27],[0,.05],[.15,.27],[.29,.17],[.22,.43],[-.22,.43]],.06,'#252432',0,.0,.22,.01);eyes(h,-.055,.23,.12,'#db3039',.055);block(h,.17,.055,.04,'#612637',0,-.25,.225,.01);
  for(const s of [-1,1])poly(h,[[-.025,.04],[.025,.04],[0,-.045]],.02,'#fff0cf',s*.07,-.23,.258,.002);
  poly(h,[[-.34,-.075],[.34,-.075],[.38,.24],[.18,.08],[0,.34],[-.18,.08],[-.38,.24]],.16,'#d5a33a',0,.42,.02,.018);ball(h,[.06,.075,.035],'#d73549',0,.47,.126,0);
  return normalize(g,2);
}

function crab(){
  const g=group('TNT crab');ball(g,[.75,.35,.51],'#a33f43',0,.48,0);ball(g,[.60,.28,.42],'#dc5b45',0,.62,-.025);
  for(const s of [-1,1])for(let j=0;j<3;j++){const x=s*(.68+j*.10),z=(j-1)*.33;beam(g,[s*.49,.45,z],[x,.52,z+.07],.105,'#b63d3a');beam(g,[x,.52,z+.07],[x+s*.18,.07,z+.16],.075,'#7e333c');}
  for(const s of [-1,1]){beam(g,[s*.50,.51,.34],[s*.82,.57,.69],.14,'#b63d3a');ball(g,[.25,.27,.25],'#d65746',s*.91,.66,.82);poly(g,[[0,0],[s*.28,.30],[s*.37,.02],[s*.13,-.13]],.19,'#e47b57',s*.99,.80,.82,.025);beam(g,[s*.27,.64,.35],[s*.29,.98,.44],.07,'#9d373e');ball(g,[.11,.105,.095],'#eccea1',s*.29,1.0,.45);ball(g,[.045,.055,.025],'#1e2631',s*.29,1.0,.537);}
  for(let j=0;j<4;j++){const t=cylinder(g,.11,.11,.55,'#c93039',(j-1.5)*.19,1.0,-.03,7);t.rotation.x=Math.PI/2;}
  block(g,.79,.09,.67,'#493442',0,1.01,-.02,.02);line(g,[[.20,1.07,-.29],[.32,1.28,-.26],[.19,1.35,-.18]],.027,'#e1b26d');ball(g,[.06,.065,.06],'#ffd154',.19,1.36,-.18,0);return normalize(g,2);
}

function berserker(){
  const g=group('Chained berserker');for(const s of [-1,1]){ball(g,[.29,.20,.37],'#3c2838',s*.34,.17,.09);beam(g,[s*.34,.24,0],[s*.31,.73,0],.31,'#804734');}
  ball(g,[.77,.64,.44],'#b56645',0,1.08,0);block(g,.80,.23,.48,'#3b2d40',0,.68,0,.045);
  for(const s of [-1,1]){ball(g,[.35,.40,.32],'#bd7450',s*.73,1.36,0);beam(g,[s*.76,1.28,0],[s*.92,.76,.10],.36,'#a95b3d');block(g,.41,.19,.39,'#354255',s*.91,.84,.1,.04);ball(g,[.30,.29,.28],'#c48357',s*.94,.63,.16);}
  const h=group('head');g.add(h);h.position.set(0,1.78,.06);g.userData.head=h;ball(h,[.38,.35,.32],'#bf7750');poly(h,[[-.34,-.06],[.34,-.06],[.32,.30],[0,.40],[-.32,.30]],.29,'#414959',0,.10,-.06,.04);eyes(h,.005,.305,.15,'#ffb655',.06);block(h,.30,.10,.05,'#4c2733',0,-.18,.31,.015);
  for(const s of [-1,1]){const horn=cylinder(h,0,.11,.48,'#e2c99b',s*.32,.49,-.1,5);horn.rotation.z=-s*.55;}return normalize(g,2);
}

export function makeEnemy(type='warrior'){
  const factories={warrior,golem:()=>golem(false),icegolem:()=>golem(true),bear,dragon,zombie,vampire,crab,berserker};
  const result=(factories[type]||warrior)();result.userData.type=type;result.name=`Enemy: ${type}`;return result;
}

function pine(parent,x,z,height,color='#173543'){
  cylinder(parent,.095,.16,height*.52,'#27333e',x,height*.20,z,5);
  for(let j=0;j<3;j++){const h=height*(.64-j*.08),r=height*(.25-j*.06);const o=cylinder(parent,0,r,h,color,x,height*(.37+j*.22),z,5);o.rotation.y=j*.47;}
}
function crystal(parent,x,y,z,height,color){const o=cylinder(parent,0,height*.19,height,color,x,y+height/2,z,5);o.rotation.z=(x>0?-.13:.13);block(parent,height*.21,height*.64,height*.22,color,x,y+height*.30,z,.025);}
function tomb(parent,x,z,angle=0){const t=poly(parent,[[-.20,0],[.20,0],[.20,.45],[.12,.60],[-.12,.60],[-.20,.45]],.14,'#8b8796',x,.0,z,.03);t.rotation.y=angle;block(parent,.06,.23,.035,'#484654',x,.32,z+.10,.005);block(parent,.18,.055,.035,'#484654',x,.37,z+.10,.005);}
function ribbon(parent,color){const o=poly(parent,[[-4,-.25],[-2,-.10],[-.8,-.60],[.8,-.42],[2.2,.16],[4,.22],[4,.90],[2,.78],[.65,.24],[-.85,.10],[-2,.56],[-4,.4]],.035,color,0,.018,0,.01);o.rotation.x=-Math.PI/2;}
function floatingChunk(g,radius,top,side,r){
  cylinder(g,radius,radius*.98,.22,top,0,-.12,0,12);
  for(let i=0;i<12;i++){const a=i*TAU/12,b=(i+1)*TAU/12;const vertices=new Float32Array([Math.cos(a)*radius,-.21,Math.sin(a)*radius,Math.cos(b)*radius,-.21,Math.sin(b)*radius,Math.cos(b)*radius*.36,-1.45-r()*.40,Math.sin(b)*radius*.36,Math.cos(a)*radius*.36,-1.45-r()*.40,Math.sin(a)*radius*.36]);const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(vertices,3));geo.setIndex([0,1,2,0,2,3]);geo.computeVertexNormals();mesh(g,geo,i%3?side:'#2a3345');}
}

export function makeIsland(theme='meadow'){
  const g=group(`Floating ${theme} island`),r=rng(400+theme.length*31);
  const colors={meadow:['#507962','#364956'],ice:['#b2d6de','#537f9a'],candy:['#d997a5','#aa637f'],fire:['#584146','#382f42'],grave:['#546459','#303d48']};
  const [top,side]=colors[theme]||colors.meadow;floatingChunk(g,4,top,side,r);
  if(theme==='candy')ribbon(g,'#f278ac');if(theme==='grave')ribbon(g,'#93b748');
  if(theme==='fire')for(const p of [[[-3,.02,-1],[-1,.04,-1.7],[1,.03,-1.2],[2.8,.02,-2]], [[1,.04,-1.2],[1.7,.025,.7],[3.8,.03,1]]]){line(g,p,.085,'#ee5227',.1);}
  for(let i=0;i<9;i++){
    const a=i*TAU/9+.1,rr=3.05+r()*.40,x=Math.cos(a)*rr,z=Math.sin(a)*rr;
    if(theme==='ice')crystal(g,x,0,z,.45+r()*.73,i%2?'#87c6db':'#d1eef0');
    else if(theme==='fire')crystal(g,x,0,z,.45+r()*.75,i%2?'#418f92':'#62b9b4');
    else if(theme==='grave')tomb(g,x,z,(r()-.5)*.50);
    else if(theme==='candy'){const stick=cylinder(g,.035,.035,.73,'#f5e1ba',x,.35,z,6);const sweet=ball(g,[.21,.21,.11],i%2?'#e65a80':'#f2c85f',x,.80,z);sweet.rotation.z=i*.5;}
    else{ball(g,[.24+r()*.19,.13+r()*.20,.22+r()*.16],i%2?'#7d8c84':'#93a08b',x,.1,z,0);if(i%3===0)pine(g,x,z,1.9+r()*.4,'#305b4c');}
  }
  const result=mergeStatic(g);result.userData.theme=theme;result.userData.groundY=0;return result;
}

function arch(parent,x,z,height,width,color='#303346'){
  const spring=height-width*.72;
  for(const s of [-1,1]){block(parent,.44,spring,.65,color,x+s*width*.5,spring*.5,z,.05);block(parent,.72,.30,.88,'#222c3d',x+s*width*.5,.14,z,.04);let last=[x+s*width*.5,spring,z];for(let j=1;j<=7;j++){const t=j/7,next=[x+s*width*.5*(1-t),spring+width*.72*Math.sin(t*Math.PI/2),z];beam(parent,last,next,.28,color,.55);last=next;}}
  block(parent,.40,.43,.69,'#4a485c',x,height-.1,z,.035);
}
function makeSky(){
  const mat=new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,uniforms:{low:{value:new THREE.Color('#7c1630')},high:{value:new THREE.Color('#080e25')}},vertexShader:'varying vec3 vP;void main(){vP=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'uniform vec3 low;uniform vec3 high;varying vec3 vP;void main(){float h=clamp(normalize(vP).y*1.25+.15,0.,1.);gl_FragColor=vec4(mix(low,high,h),1.);}'});
  const sky=new THREE.Mesh(new THREE.SphereGeometry(55,16,10),mat);sky.name='Crimson night sky';sky.renderOrder=-20;return sky;
}
export function makeArena(theme='forest'){
  const g=group(`${theme} arena`),r=rng(607);
  cylinder(g,10,9.80,.38,'#334a53',0,-.20,0,16);
  cylinder(g,9.80,7.8,1.5,'#222e41',0,-1.10,0,16);
  // Broad angular paving gives a contact surface without overwhelming the cast.
  for(let j=0;j<15;j++){const a=j*TAU/15;const x=Math.cos(a)*6.9,z=Math.sin(a)*6.9;const slab=block(g,1.65,.06,1.45,j%2?'#3b5360':'#435b64',x,.008,z,.10);slab.rotation.y=-a;}
  if(theme==='cathedral'||theme==='tower'||theme==='castle'){arch(g,-6,-7,8,3);arch(g,6,-8,9,3.2);arch(g,0,-12,10,4,'#252b3d');}
  else for(let i=0;i<20;i++){const a=.12+i*Math.PI/21;const rr=9+r()*3;pine(g,Math.cos(a)*rr,-Math.sin(a)*rr,3.6+r()*3.4,i%3?'#16333f':'#203e4b');}
  for(let j=0;j<13;j++){const a=r()*TAU,rr=7+r()*2;ball(g,[.25+r()*.6,.12+r()*.33,.20+r()*.4],'#5e6f77',Math.cos(a)*rr,.05,Math.sin(a)*rr,0);}
  const result=mergeStatic(g);result.add(makeSky());
  const moon=mesh(result,new THREE.SphereGeometry(1.80,20,12),new THREE.MeshBasicMaterial({color:'#b63142'}),-4.5,7.8,-14.5);moon.name='Blood moon';moon.castShadow=false;
  for(const [x,y,s]of [[-.51,.4,.26],[.48,-.2,.35],[.36,.62,.16]]){const crater=ball(result,[s,s*.74,.05],new THREE.MeshBasicMaterial({color:'#81273b'}),-4.5+x,7.8+y,-12.77,1);crater.castShadow=false;}
  result.userData.groundY=0;return result;
}

function hangingChain(parent,x,y,z,length=2){for(let i=0;i<8;i++){const link=mesh(parent,new THREE.TorusGeometry(.095,.027,4,8),material('#596577'),x,y-i*length/8,z);if(i%2)link.rotation.y=Math.PI/2;}}
export function makeTower({populate=false}={}){
  const tower=group('Three-storey boss tower');const stone=group('Tower architecture');
  for(let level=0;level<3;level++){const y=level*6;block(stone,6.4,.43,3.8,'#323849',0,y-.24,0,.08);for(const s of [-1,1]){block(stone,.52,5.55,.65,'#38384b',s*2.98,y+2.65,-1.2,.065);block(stone,.76,.28,.95,'#595064',s*2.98,y+5.45,-1.2,.055);}const room=group('Room arch');arch(room,0,-1.90,5.50,5.5,'#514659');room.position.y=y;stone.add(room);hangingChain(stone,-2.2,y+4.3,-.30,2.8);hangingChain(stone,2.2,y+4.3,-.30,2.8);}
  block(stone,2.9,.4,1.65,'#6a3444',0,12.2,-.10,.06);
  tower.add(mergeStatic(stone));
  const moon=mesh(tower,new THREE.SphereGeometry(1.12,16,10),new THREE.MeshBasicMaterial({color:'#aa243d'}),0,15.10,-2.80);moon.name='Vampire chamber blood moon';moon.castShadow=false;
  const rooms=[];for(const [i,type]of ['crab','berserker','vampire'].entries()){
    const entry={floorY:i*6,y:i*6,center:[0,i*6,0],type};
    if(populate){const enemy=makeEnemy(type);enemy.scale.multiplyScalar([.9,1.5,1.6][i]);enemy.position.set(0,i*6+(i===2?.4:0),0);tower.add(enemy);entry.enemy=enemy;}
    rooms.push(entry);
  }
  tower.userData.rooms=rooms;tower.userData.floors=[0,6,12];return tower;
}

export function poseEnemy(enemy,t=0,energy=1){
  const p=enemy.userData;
  if(p.head)p.head.rotation.z=Math.sin(t*2.1)*.026*energy;
  if(p.leftArm)p.leftArm.rotation.z=Math.sin(t*2.5)*.025*energy;
  if(p.rightArm)p.rightArm.rotation.z=-Math.sin(t*2.5)*.025*energy;
}
