import * as THREE from 'three';
import {mergeGeometries,mergeVertices} from 'three/addons/utils/BufferGeometryUtils.js';

// Fresh dimensional design: matte sculpted ogre, cast bone face and armored fists.
// Y-up. Front +Z. Neutral model height 5.05, soles Y=0. No external assets.
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const smooth=v=>{v=clamp(v);return v*v*(3-2*v)};
const C={orange:0xd67932,light:0xe79745,shadow:0x9a401c,deep:0x66281b,ink:0x141b23,bone:0xe8d6a9,boneSide:0x9f8e73,navy:0x27344a,steel:0x67798b,iron:0x303e4d,red:0x9f2422,teal:0x174d51};
const mat=(color,roughness=.82,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
function materials(){return {
 skin:new THREE.MeshStandardMaterial({color:0xffffff,vertexColors:true,roughness:.83}),
 skinLight:mat(C.light),skinDark:mat(C.shadow),skinDeep:mat(C.deep),skinOrange:mat(C.orange),
 ink:mat(C.ink,.88),bone:mat(C.bone,.70),boneSide:mat(C.boneSide,.81),ivory:mat(0xffedc3,.66),
 navy:mat(C.navy,.92),navyLight:mat(0x475370,.87),belt:mat(0x312c2b,.95),steel:mat(C.steel,.47,.5),iron:mat(C.iron,.72,.25),
 red:mat(C.red,.80),teal:mat(C.teal,.90),tealHi:mat(0x2d7470,.81),tongue:mat(0x8e3244,.82),
 eye:new THREE.MeshBasicMaterial({color:0xff302b}),eyeCore:new THREE.MeshBasicMaterial({color:0xff8263}),
 } }
function mesh(g,m,p,name,pos=[0,0,0]){const o=new THREE.Mesh(g,m);o.name=name;o.position.set(...pos);o.castShadow=true;o.receiveShadow=true;p.add(o);return o}
function shapeGeometry(points,depth=.15,bevel=.05,holes=[]){const s=new THREE.Shape();points.forEach(([x,y],i)=>i?s.lineTo(x,y):s.moveTo(x,y));s.closePath();for(const pts of holes){const h=new THREE.Path();pts.forEach(([x,y],i)=>i?h.lineTo(x,y):h.moveTo(x,y));h.closePath();s.holes.push(h)}const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:bevel>0,bevelThickness:bevel,bevelSize:bevel,bevelSegments:2,curveSegments:5,steps:1});g.translate(0,0,-depth*.5);g.computeVertexNormals();return g}
function poly(p,name,pts,depth,bevel,m,pos=[0,0,0]){return mesh(shapeGeometry(pts,depth,bevel),m,p,name,pos)}
function boxGeo(w,h,d,b=.035){return shapeGeometry([[-w/2,-h/2],[w/2,-h/2],[w/2,h/2],[-w/2,h/2]],d,b)}
function box(p,name,w,h,d,m,pos=[0,0,0],bevel=.035){return mesh(boxGeo(w,h,d,bevel),m,p,name,pos)}
function group(p,name,pos=[0,0,0]){const g=new THREE.Group();g.name=name;g.position.set(...pos);p.add(g);return g}
function cyl(p,name,r,h,m,pos,axis='y',segments=8){const o=mesh(new THREE.CylinderGeometry(r,r,h,segments,1),m,p,name,pos);if(axis==='z')o.rotation.x=Math.PI/2;return o}
function tubeGeo(points,r=.016,sides=5){return new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),Math.max(8,points.length*4),r,sides,false)}
function bakeMerge(parent,name,geometries,material){if(!geometries.length)return null;const merged=mergeGeometries(geometries,false);geometries.forEach(g=>g.dispose());return mesh(merged,material,parent,name)}
function transformGeometry(g,pos=[0,0,0],rotation=[0,0,0]){const matrix=new THREE.Matrix4().compose(new THREE.Vector3(...pos),new THREE.Quaternion().setFromEuler(new THREE.Euler(...rotation)),new THREE.Vector3(1,1,1));return g.applyMatrix4(matrix)}
function sculptGeometry(rings,segments=20,front=C.orange,back=C.shadow){
 const verts=[],normals=[],colors=[],indices=[],cf=new THREE.Color(front),cb=new THREE.Color(back);
 for(let j=0;j<rings.length;j++){const [y,w,d,zc=0]=rings[j];for(let i=0;i<segments;i++){const a=i/segments*Math.PI*2,c=Math.cos(a),s=Math.sin(a),x=Math.sign(c)*Math.pow(Math.abs(c),.83)*w,z=zc+Math.sign(s)*Math.pow(Math.abs(s),.9)*d;verts.push(x,y,z);const col=cb.clone().lerp(cf,smooth((s+.20)/.92));if(j===0)col.multiplyScalar(.86);colors.push(col.r,col.g,col.b)}}
 for(let j=0;j<rings.length-1;j++)for(let i=0;i<segments;i++){const a=j*segments+i,b=j*segments+(i+1)%segments,c=b+segments,d=a+segments;indices.push(a,c,b,a,d,c)}
 for(const [j,reverse]of[[0,false],[rings.length-1,true]]){const center=verts.length/3;verts.push(0,rings[j][0],rings[j][3]||0);colors.push(cb.r,cb.g,cb.b);for(let i=0;i<segments;i++){const a=j*segments+i,b=j*segments+(i+1)%segments;indices.push(center,...(reverse?[b,a]:[a,b]))}}
 const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));g.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));g.setIndex(indices);g.computeVertexNormals();return g;
}
function scars(parent,m,sets){
 const incisions=[],crosses=[];
 for(const points of sets){incisions.push(tubeGeo(points,.018,5));for(let i=1;i<points.length;i++){const a=new THREE.Vector3(...points[i-1]),b=new THREE.Vector3(...points[i]),v=b.clone().sub(a),len=v.length(),n=Math.max(1,Math.round(len/.105));for(let j=0;j<n;j++){const p=a.clone().lerp(b,(j+.5)/n);p.z+=.023;const angle=-Math.atan2(v.x,v.y);crosses.push(transformGeometry(boxGeo(.104,.022,.026,.007),p.toArray(),[0,0,angle]));}}}
 bakeMerge(parent,'Deep hand-stitched incisions',incisions,m.skinDeep);bakeMerge(parent,'Raised dark surgical stitches',crosses,m.belt);
}
function curvedFace(g){const a=g.attributes.position;for(let i=0;i<a.count;i++){const x=a.getX(i),y=a.getY(i);a.setZ(i,a.getZ(i)+.16*Math.max(0,1-(x/.72)**2)*Math.max(0,1-((y-.07)/.72)**2))}g.deleteAttribute('normal');const welded=mergeVertices(g,1e-4);welded.computeVertexNormals();g.dispose();return welded}

function buildHead(parent,m){
 const head=group(parent,'Head pivot',[0,3.93,.48]);
 // Full enclosed shell: no bald dome and no exposed human gums.
 poly(head,'Dark helmet understructure',[[-.50,.47],[-.66,.15],[-.59,-.27],[-.34,-.47],[.34,-.47],[.59,-.27],[.66,.15],[.50,.47],[.25,.62],[-.25,.62]],.53,.065,m.ink,[0,0,-.075]);
 const outer=[[-.44,.51],[-.59,.29],[-.59,-.12],[-.43,-.26],[-.23,-.27],[0,-.24],[.23,-.27],[.43,-.26],[.59,-.12],[.59,.29],[.44,.51],[.18,.60],[-.18,.60]];
 const left=[[-.49,.21],[-.37,.22],[-.09,.065],[-.11,-.035],[-.34,.015],[-.47,.075]];
 const right=left.map(([x,y])=>[-x,y]).reverse();
 const face=mesh(curvedFace(shapeGeometry(outer,.105,.035,[left,right])),m.bone,head,'Cast bone hockey faceplate',[0,0,.21]);
 const sockets=[];for(const [i,points]of [left,right].entries()){
  sockets.push(transformGeometry(shapeGeometry(points,.025,.014),[0,0,.280]));
  const cx=i? .28:-.28;
  const red=points.map(([x,y])=>[cx+(x-cx)*.85,.085+(y-.085)*.46]);
  poly(head,'Fierce red recessed slit '+i,red,.018,.008,m.eye,[0,0,.309]);
  const hot=red.map(([x,y])=>[cx+(x-cx)*.28,.077+(y-.077)*.24]);
  poly(head,'Eye inner ember '+i,hot,.006,.003,m.eyeCore,[0,0,.326]);
 }
 bakeMerge(head,'Deep angular eye sockets',sockets,m.ink);
 // Curved paint follows the sculpted face; both eyes stay physically recessed.
 const chevrons=[[[[-.31,.46],[0,.33],[.31,.46],[.17,.24],[0,.17],[-.17,.24]],'Crown chevron'],[[[-.55,-.05],[-.32,-.15],[-.39,-.235],[-.54,-.17]],'Left cheek'],[[[.55,-.05],[.32,-.15],[.39,-.235],[.54,-.17]],'Right cheek']];
 for(const [points,name]of chevrons)mesh(curvedFace(shapeGeometry(points,.008,.004)),m.red,head,name,[0,0,.315]);
 // Broad faceted nose tapers into mask shadow, replacing a soft human nose.
 poly(head,'Bone central nose ridge',[[-.06,.07],[.06,.07],[.104,-.155],[0,-.206],[-.104,-.155]],.10,.014,m.boneSide,[0,0,.35]);
 const vents=[],bolts=[];for(const side of[-1,1]){
  for(const [x,y,r]of[[.49,.37,.024],[.44,-.235,.021]]){const geo=new THREE.CylinderGeometry(r,r,.03,8);geo.rotateX(Math.PI/2);bolts.push(transformGeometry(geo,[side*x,y,.30]));}
  for(const [x,y]of[[.19,-.145],[.28,-.205],[.51,-.025]]){const g=new THREE.CylinderGeometry(.018,.018,.015,8);g.rotateX(Math.PI/2);vents.push(transformGeometry(g,[side*x,y,.36]));}
 }
 bakeMerge(head,'Faceplate fasteners',bolts,m.steel);bakeMerge(head,'Mask punched vents',vents,m.ink);
 // Separate BONE jaw hinges down to expose a black cartoon mouth, never pink lips.
 const jaw=group(head,'Bone jaw hinge',[0,-.205,.115]);
 poly(jaw,'Black mouth interior',[[-.49,-.035],[-.40,-.23],[-.23,-.34],[.23,-.34],[.40,-.23],[.49,-.035]],.035,.025,m.ink,[0,-.025,.15]);
 poly(jaw,'Articulated bone chin',[[-.46,-.17],[-.27,-.34],[0,-.39],[.27,-.34],[.46,-.17],[.39,-.065],[.22,-.15],[0,-.19],[-.22,-.15],[-.39,-.065]],.17,.035,m.bone,[0,0,.19]);
 const topTeeth=[],lowerTeeth=[];for(let i=0;i<6;i++){const x=-.31+i*.124,w=i%2?.084:.096;topTeeth.push(transformGeometry(shapeGeometry([[-w/2,0],[w/2,0],[w*.25,-.14],[-w*.2,-.13]],.065,.01),[x,-.245,.318]));}
 for(let i=0;i<5;i++){const x=-.25+i*.126;lowerTeeth.push(transformGeometry(shapeGeometry([[-.041,0],[.041,0],[.014,.10],[-.020,.115]],.06,.009),[x,-.22,.32]));}
 bakeMerge(head,'Upper chunky bone fangs',topTeeth,m.ivory);bakeMerge(jaw,'Lower chunky bone fangs',lowerTeeth,m.ivory);
 // Tall swept, broad mohawk fins are faceted dark teal, with a single edge plane.
 const fins=[],highlights=[];for(let i=0;i<6;i++){const z=-.34+i*.13,peak=.91-.035*Math.abs(i-2.5),lean=-.085;
  const g=shapeGeometry([[-.065,.40],[-.12,.60],[lean,peak],[.11,.64],[.085,.41]],.105,.014);fins.push(transformGeometry(g,[0,0,z]));
  const hi=shapeGeometry([[lean,peak],[.11,.64],[.062,.47],[.012,.57]],.008,.004);highlights.push(transformGeometry(hi,[0,0,z+.064]));
 }
 bakeMerge(head,'Heavy dark teal mohawk blades',fins,m.teal);bakeMerge(head,'Mohawk broad lit edges',highlights,m.tealHi);
 head.userData.base=head.position.clone();jaw.userData.base=jaw.position.clone();return {head,jaw};
}

function buildArm(parent,m,side){
 const shoulder=group(parent,side<0?'Left shoulder pivot':'Right shoulder pivot',[side*1.10,3.21,-.015]);
 // One continuous shoulder/biceps volume, wider above and contracted at elbow.
 mesh(sculptGeometry([[-.86,.255,.31,.03],[-.66,.33,.36,.04],[-.35,.405,.405,0],[-.08,.46,.41,-.02],[.19,.365,.34,-.02],[.28,.20,.22,-.01]],16),m.skin,shoulder,'Sculpted deltoid and upper arm',[side*.16,-.02,0]);
 const forearm=group(shoulder,'Elbow hinge',[side*.18,-.75,.035]);
 mesh(sculptGeometry([[-.68,.30,.30,.045],[-.49,.37,.37,.035],[-.20,.355,.35,.03],[.055,.26,.29,.015]],14),m.skin,forearm,'Massive tapered forearm');
 poly(forearm,'Combat bracer front',[[-.30,-.08],[-.35,-.36],[-.29,-.62],[.26,-.64],[.34,-.38],[.27,-.08]],.21,.044,m.iron,[0,0,.255]);
 poly(forearm,'Bracer bright inset',[[-.23,-.23],[-.26,-.40],[-.20,-.55],[.18,-.56],[.25,-.38],[.20,-.23]],.025,.019,m.steel,[0,0,.392]);
 box(forearm,'Wrist dark wrap',.62,.13,.58,m.belt,[0,-.63,.03],.03);
 const hand=group(forearm,'Clenched armored fist',[0,-.79,.095]);
 poly(hand,'Solid leather clenched fist',[[-.28,.15],[.25,.15],[.34,.045],[.32,-.24],[.19,-.33],[-.22,-.30],[-.32,-.15]],.44,.050,m.ink);
 const knuckleGeo=[];for(let i=0;i<4;i++)knuckleGeo.push(transformGeometry(boxGeo(.115,.19,.15,.017),[-.225+i*.149,-.015,.25],[.1,0,(i-1.5)*-.045]));
 bakeMerge(hand,'Four cast steel knuckle blocks',knuckleGeo,m.iron);
 box(hand,'Folded armored thumb',.20,.33,.19,m.belt,[-side*.30,-.12,.15],.038).rotation.z=side*.35;
 // Hand socket is at the centre of the grip. Weapon long axis should be +Y.
 const grip=group(hand,'Weapon hand socket',[side*.035,-.04,.07]);
 const rivets=[];for(const x of[-.21,.21])for(const y of[-.27,-.52]){const g=new THREE.CylinderGeometry(.032,.032,.02,8);g.rotateX(Math.PI/2);rivets.push(transformGeometry(g,[x,y,.42]));}bakeMerge(forearm,'Bracer rivets',rivets,m.steel);
 shoulder.userData.base=shoulder.position.clone();forearm.userData.base=forearm.position.clone();hand.userData.base=hand.position.clone();return {shoulder,forearm,hand,grip};
}

function buildLeg(parent,m,side){
 const leg=group(parent,side<0?'Left planted boot':'Right planted boot',[side*.55,.71,.035]);
 mesh(sculptGeometry([[-.13,.27,.28,0],[.15,.315,.31,-.02],[.52,.34,.34,-.01]],14),m.skin,leg,'Short powerful leg');
 mesh(sculptGeometry([[-.665,.37,.515,.16],[-.51,.385,.51,.15],[-.19,.34,.41,.05],[.04,.30,.32,-.02]],12,C.iron,C.ink),m.skin,leg,'Heavy squared leather boot');
 mesh(sculptGeometry([[-.705,.39,.54,.16],[-.61,.39,.54,.16]],12,C.ink,C.ink),m.skin,leg,'Broad tread sole');
 poly(leg,'Boot iron toe guard',[[-.30,-.52],[-.27,-.31],[.27,-.31],[.30,-.52],[.22,-.60],[-.22,-.60]],.13,.025,m.iron,[0,0,.595]);
 poly(leg,'Boot shin shield',[[-.245,.025],[.245,.025],[.265,-.22],[.175,-.32],[-.175,-.32],[-.265,-.22]],.075,.022,m.navyLight,[0,0,.33]);
 box(leg,'Boot buckle strap',.65,.088,.035,m.belt,[0,-.165,.401],.015);box(leg,'Boot square buckle',.13,.14,.045,m.steel,[side*.08,-.165,.434],.018);
 leg.userData.base=leg.position.clone();return leg;
}

export function buildHero(){
 const hero=new THREE.Group();hero.name='BUTCHER | original sculpted hero';const m=materials();
 const body=group(hero,'Heavy hunch and body pivot');
 const torso=mesh(sculptGeometry([[1.32,.71,.43,0],[1.55,1.00,.60,.015],[1.93,1.19,.745,.075],[2.35,1.235,.79,.095],[2.70,1.165,.69,.055],[3.05,1.20,.585,-.01],[3.31,1.015,.525,-.055],[3.47,.77,.425,-.035],[3.61,.43,.305,.045]],24),m.skin,body,'Continuous massive stitched torso');
 // Chest planes are integrated in the torso rings; no floating muscle shells.
 // A ridged blue cloth mesh, cut into large uneven teeth along the hem.
 const shorts=mesh(sculptGeometry([[1.14,.82,.46,.025],[1.32,1.045,.54,.005],[1.57,1.075,.585,.012],[1.69,1.00,.59,.013]],20,C.navy,C.ink),m.skin,body,'Heavy navy torn shorts');
 const torn=[];for(let i=0;i<7;i++){const x=-.88+i*.291,z=.075+.48*Math.sqrt(Math.max(0,1-(x/1.08)**2));torn.push(transformGeometry(shapeGeometry([[-.16,.12],[.14,.12],[.13,-.035],[.055,-.02],[0,-.19],[-.11,-.04]],.11,.018),[x,1.20,z]));}bakeMerge(body,'Ragged cloth hem',torn,m.navy);
 // Heavy belt anchors torso/shorts and avoids the diaper-shaped upper silhouette.
 const belt=mesh(sculptGeometry([[1.61,1.035,.625,.013],[1.77,1.055,.62,.013]],20,0x39322e,0x232328),m.skin,body,'Thick waist leather belt');
 poly(body,'Iron butcher belt plate',[[-.25,.105],[.25,.105],[.285,-.07],[0,-.16],[-.285,-.07]],.11,.025,m.iron,[0,1.686,.676]);
 const badge=poly(body,'Belt brutal diamond',[[-.09,.01],[0,.10],[.09,.01],[0,-.09]],.025,.005,m.steel,[0,1.68,.752]);
 scars(body,m,[
 [[-.64,3.16,.535],[-.53,2.92,.635],[-.36,2.70,.72],[-.16,2.47,.875],[.05,2.28,.895],[.30,2.07,.83],[.55,1.91,.735]],
 [[.74,3.17,.49],[.68,2.98,.61],[.88,2.77,.595]],
 [[-.94,2.60,.60],[-.91,2.42,.69],[-.82,2.23,.73]],
 [[.52,2.70,.715],[.62,2.61,.727],[.73,2.52,.705]],
 ]);
 // A dark angular recessed navel, deliberately off centre.
 poly(body,'Recessed belly scar',[[-.043,.035],[.035,.035],[.015,-.04],[-.025,-.06]],.012,.006,m.skinDeep,[.04,1.98,.825]);
 const {head,jaw}=buildHead(body,m);
 const armParts=[buildArm(body,m,-1),buildArm(body,m,1)];
 const legs=[buildLeg(hero,m,-1),buildLeg(hero,m,1)];
 const back=group(body,'Layered spine armor');
 const plates=[],edges=[],rivets=[];
 for(let i=0;i<4;i++){const y=3.25-i*.375,w=.66-i*.055,z=-.59-i*.015,pts=[[-w,.19],[-w*.55,.28],[0,.23],[w*.55,.28],[w,.19],[w*.88,-.16],[0,-.29],[-w*.88,-.16]];
  plates.push(transformGeometry(shapeGeometry(pts,.14,.035),[0,y,z]));
  edges.push(transformGeometry(shapeGeometry([[-.05,.20],[.05,.20],[.065,-.16],[0,-.24],[-.065,-.16]],.025,.01),[0,y,z-.108]));
  for(const side of[-1,1])for(const dy of[.095,-.09]){let g=new THREE.CylinderGeometry(.045,.045,.027,8);g.rotateX(Math.PI/2);rivets.push(transformGeometry(g,[side*w*.72,y+dy,z-.108]));}
 }
 bakeMerge(back,'Overlapping beveled spine plates',plates,m.iron);bakeMerge(back,'Steel vertebrae ridges',edges,m.steel);bakeMerge(back,'Large spine rivets',rivets,m.steel);
 const weaponRoots=[group(back,'Chain mount upper left',[-.63,3.42,-.58]),group(back,'Chain mount upper right',[.63,3.42,-.58]),group(back,'Chain mount lower left',[-.60,2.68,-.68]),group(back,'Chain mount lower right',[.60,2.68,-.68])];
 const ringGeo=[];for(const r of weaponRoots){const g=new THREE.TorusGeometry(.085,.024,6,12);ringGeo.push(transformGeometry(g,r.position.toArray()));}bakeMerge(back,'Weapon chain anchor rings',ringGeo,m.steel);
 const hands=armParts.map(x=>x.hand);hands.L=hands.left=hands[0];hands.R=hands.right=hands[1];
 hero.userData.parts={body,torso,head,jaw,arms:armParts.map(x=>x.shoulder),forearms:armParts.map(x=>x.forearm),hands,handSockets:armParts.map(x=>x.grip),legs,weaponRoots,back};
 hero.userData.materials=m;hero.userData.baseScale=1;poseHero(hero,0);return hero;
}

export function poseHero(hero,t,opt={}){
 const p=hero.userData.parts;if(!p)return;const mode=opt.mode||'idle',chew=clamp(opt.chew||0),power=clamp(opt.power||0),phase=opt.attack!==undefined?clamp(opt.attack):opt.phase===undefined?(t%1):clamp(opt.phase),breath=Math.sin(t*2.8);
 // Only local bone transforms are touched; callers retain world placement/scale.
 p.body.position.set(0,breath*.022,0);p.body.rotation.set(0,0,0);p.body.scale.set(1+power*.035,1+power*.018,1+power*.025);
 p.head.position.copy(p.head.userData.base);p.head.position.y+=breath*.014;p.head.rotation.set(-.055+Math.sin(t*1.7)*.016,Math.sin(t*.7)*.025,0);
 p.jaw.position.copy(p.jaw.userData.base);p.jaw.position.y-=chew*.16;p.jaw.rotation.set(chew*.32,0,0);
 for(let i=0;i<2;i++){const s=i?1:-1;p.arms[i].position.copy(p.arms[i].userData.base);p.arms[i].rotation.set(-.035+Math.sin(t*2.8+i*.4)*.015,0,s*.18);p.forearms[i].position.copy(p.forearms[i].userData.base);p.forearms[i].rotation.set(-.10,0,-s*.055);p.hands[i].rotation.set(0,0,s*.045);p.legs[i].position.copy(p.legs[i].userData.base);p.legs[i].rotation.set(0,-s*.11,s*.025);}
 if(mode==='walk'){const s=Math.sin(t*8);p.body.position.y+=Math.abs(s)*.075;p.body.rotation.z=s*.04;p.arms[0].rotation.x+=s*.25;p.arms[1].rotation.x-=s*.25;p.legs[0].rotation.x=s*.32;p.legs[1].rotation.x=-s*.32;}
 if(mode==='anticipation'||mode==='charge'){const a=smooth(phase);p.body.rotation.x=-.14*a;p.body.position.y-=.14*a;p.head.rotation.x=-.18*a;p.arms[1].rotation.set(-.45*a,0,.55*a+.18);p.forearms[1].rotation.x=-.72*a;}
 if(mode==='punch'||mode==='attack'||mode==='swing'){const a=Math.sin(phase*Math.PI),hit=Math.sin(clamp((phase-.18)/.65)*Math.PI);p.body.rotation.y=-.25*a;p.body.rotation.x=.09*a;p.head.rotation.y=.12*a;p.arms[1].rotation.set(-1.45*hit-.08,-.20*a,.18-.25*a);p.forearms[1].rotation.x=-.42*a;p.arms[0].rotation.z=-.35-.10*a;p.hands[1].rotation.z=-.22*a;}
 if(mode==='roar'||mode==='power'){const a=opt.intensity===undefined?1:opt.intensity;p.arms[0].rotation.z=-.75*a;p.arms[1].rotation.z=.75*a;p.forearms[0].rotation.x=-.62*a;p.forearms[1].rotation.x=-.62*a;p.head.rotation.x=-.15;p.body.scale.x*=1+.04*a;p.jaw.position.y-=.13*a;p.jaw.rotation.x+=.22*a;}
 if(mode==='chew'){const bite=opt.chew===undefined?.5+.5*Math.sin(t*16):chew;p.jaw.position.y=p.jaw.userData.base.y-bite*.18;p.jaw.rotation.x=bite*.29;p.head.rotation.x-=bite*.045;p.body.scale.x*=1+bite*.025;}
 if(mode==='victory'){p.arms[0].rotation.set(-.4,0,-1.55);p.forearms[0].rotation.x=-.9;p.head.rotation.z=-.07;p.arms[1].rotation.x=-.25;}
 if(opt.look!==undefined)p.head.rotation.y=opt.look;if(opt.lean!==undefined)p.body.rotation.x+=opt.lean;
 return hero;
}
