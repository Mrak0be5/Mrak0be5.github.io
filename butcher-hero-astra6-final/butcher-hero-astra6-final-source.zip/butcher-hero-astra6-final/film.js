import * as THREE from 'three';
import {buildHero,poseHero} from './hero.js';
import {makeArena,makeIsland,makeEnemy,makeTower,poseEnemy} from './world.js';
import {makeWeapon,makeChainSystem} from './weapons.js';

export const DURATION=29.6,FPS=30;
const starts=[0,2.4,5.6,8.8,12,15.2,18.4,20,21.6,24.8,26.4];
const ink='#100d18',cream='#fff0d0',yellow='#ffe223',green='#6efa48';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)),lerp=(a,b,t)=>a+(b-a)*t;
const ease=t=>1-(1-clamp(t))**5, smooth=t=>{t=clamp(t);return t*t*(3-2*t)},back=t=>{t=clamp(t)-1;return 1+2.70158*t*t*t+1.70158*t*t};
const bump=(t,at,span=.24)=>Math.sin(clamp((t-at)/span)*Math.PI);
const rnd=n=>{const v=Math.sin(n*127.13+31.17)*43758.5453;return v-Math.floor(v)};
const V=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
function poly(g,p,color,stroke=null,lw=3){g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.closePath();g.fillStyle=color;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.lineJoin='round';g.stroke()}}
function round(g,x,y,w,h,r,c,stroke=null,lw=3){g.beginPath();g.roundRect(x,y,w,h,r);g.fillStyle=c;g.fill();if(stroke){g.strokeStyle=stroke;g.lineWidth=lw;g.stroke()}}
function line(g,p,c,w=3){g.beginPath();p.forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.strokeStyle=c;g.lineWidth=w;g.lineCap='round';g.lineJoin='round';g.stroke()}
function label(g,s,x,y,size,{color=cream,max=420,two=false,angle=0,outline=5}={}){
  g.save();g.translate(x,y);g.rotate(angle);g.font=`900 ${size}px "Londrina Solid"`;g.textBaseline='alphabetic';g.textAlign='center';const width=g.measureText(s).width;if(width>max)g.scale(max/width,1);
  g.lineJoin='round';g.strokeStyle=ink;g.lineWidth=outline*2;if(outline)g.strokeText(s,0,0);g.fillStyle=color;g.fillText(s,0,0);
  if(two){g.save();g.beginPath();g.rect(-700,-size*.35,1400,size*.7);g.clip();g.fillStyle='#efa811';g.fillText(s,0,0);g.restore()}g.restore();
}
function title(g,a,b,t,{y=145,size=84}={}){
  let q=back(t/.30);g.save();g.translate(0,-180*(1-q));label(g,a,240,y,36,{angle:-.025,outline:4});label(g,b,240,y+size*.96,size,{color:yellow,two:true,angle:-.025,max:414,outline:6});g.restore();
}
function pill(g,s,x,y,{size=24,color=cream,bg=ink}={}){g.save();g.font=`900 ${size}px "Londrina Solid"`;let w=g.measureText(s).width+25;round(g,x-w/2,y-size*.82,w,size*1.30,7,bg,'#d8d1cd',1.5);label(g,s,x,y+size*.13,size,{outline:0,color,max:w-13});g.restore()}
function star(g,x,y,r,col=cream){let p=[];for(let i=0;i<16;i++){let a=i*Math.PI/8,rr=i%2?r*.34:r;p.push([x+Math.cos(a)*rr,y+Math.sin(a)*rr])}poly(g,p,col,ink,2)}
function sparks(g,x,y,p,{color='#ff7026',radius=230,n=28,seed=0}={}){if(p<0||p>1)return;g.save();g.globalAlpha=1-p*p;for(let i=0;i<n;i++){let a=rnd(i+seed)*Math.PI*2,r=radius*ease(p)*(.22+.78*rnd(i+88+seed)),s=(2+rnd(i+8)*8)*(1-p*.6),xx=x+Math.cos(a)*r,yy=y+Math.sin(a)*r+p*p*95;g.save();g.translate(xx,yy);g.rotate(a);poly(g,[[-s,0],[0,-s*.45],[s*2,0],[0,s*.4]],i%5?color:cream);g.restore()}g.restore()}
function streaks(g,t,a=1){g.save();g.globalAlpha=.25*a;for(let i=0;i<24;i++){let x=rnd(i+61)*570,y=(rnd(i+11)*1700+t*1000)%1300-240;line(g,[[x,y],[x,y+50+rnd(i)*180]],i%3?cream:'#ff6b24',1+rnd(i+3)*2)}g.restore()}
function screenChain(g,x,y1,y2){line(g,[[x,y1],[x,y2]],ink,7);for(let y=y1;y<y2;y+=12){g.beginPath();g.ellipse(x,y,3,7,0,0,Math.PI*2);g.strokeStyle='#8d9aad';g.lineWidth=2;g.stroke()}}

export async function createFilm(canvas,width=1080,height=1920){
  const glCanvas=document.createElement('canvas');const renderer=new THREE.WebGLRenderer({canvas:glCanvas,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  renderer.setSize(width,height,false);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.00;
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  const scene=new THREE.Scene();scene.background=new THREE.Color('#18192e');scene.fog=new THREE.Fog('#18192e',25,68);
  const camera=new THREE.PerspectiveCamera(39,width/height,.08,160);
  const ambient=new THREE.HemisphereLight('#b8cadd','#332d42',1.7);scene.add(ambient);
  const key=new THREE.DirectionalLight('#ffe2b2',2.7);key.position.set(-6,9,7);key.castShadow=true;key.shadow.mapSize.set(1024,1024);Object.assign(key.shadow.camera,{left:-13,right:13,top:16,bottom:-9,near:.1,far:60});key.shadow.bias=-.001;key.shadow.normalBias=.045;scene.add(key);scene.add(key.target);
  const fill=new THREE.DirectionalLight('#a6bed9',.9);fill.position.set(6,4,2);scene.add(fill);
  const rim=new THREE.DirectionalLight('#ef7038',1.8);rim.position.set(-4,6,-5);scene.add(rim);
  const arena=makeArena('forest'),castle=makeArena('castle'),tower=makeTower();scene.add(arena,castle,tower);
  const islandNames=['meadow','ice','candy','fire','grave'],islands=islandNames.map(makeIsland);islands.forEach(x=>scene.add(x));
  const hero=buildHero();scene.add(hero);
  const saw=makeWeapon('chainsaw');const socket=hero.userData.parts.handSockets[1];socket.add(saw);saw.position.set(.04,-.02,.42);saw.rotation.set(.08,0,-.58);saw.scale.setScalar(.79);
  const warriors=Array.from({length:16},()=>{const e=makeEnemy('warrior');scene.add(e);return e});
  const types=['golem','icegolem','bear','dragon','zombie','vampire','crab','berserker'];const enemies=Object.fromEntries(types.map(k=>{const e=makeEnemy(k);scene.add(e);return[k,e]}));
  const weapons=['hammer','iceaxe','greenaxe','sword','hook','hook','hook','hook'].map(makeWeapon);weapons.forEach(w=>scene.add(w));
  const chains=makeChainSystem(900);scene.add(chains.mesh);
  const groundRing=new THREE.Mesh(new THREE.RingGeometry(.92,1.0,48),new THREE.MeshBasicMaterial({color:'#f28a4c',transparent:true,opacity:.7,side:THREE.DoubleSide,depthWrite:false}));groundRing.rotation.x=-Math.PI/2;scene.add(groundRing);
  const particles=new THREE.InstancedMesh(new THREE.OctahedronGeometry(.030,0),new THREE.MeshBasicMaterial({color:'#e56b37'}),64);particles.frustumCulled=false;scene.add(particles);const particleDummy=new THREE.Object3D();
  const silhouette=new THREE.MeshBasicMaterial({color:'#10131b'});
  const ctx=canvas.getContext('2d',{alpha:false});const poster=document.createElement('canvas');poster.width=width;poster.height=height;const posterCtx=poster.getContext('2d');
  let overlay=[],currentTime=0;
  function project(v){const p=(Array.isArray(v)?new THREE.Vector3(...v):v.clone()).project(camera);return[(p.x*.5+.5)*540,(-p.y*.5+.5)*960]}
  function local(x,y,z){hero.updateMatrixWorld(true);return hero.localToWorld(V(x,y,z)).toArray()}
  function position(o,p,s=1,r=[0,0,0]){o.visible=true;o.position.set(...p);o.scale.setScalar(s);o.rotation.set(...r);return o;}
  function cam(p,target,fov=39,shake=0){camera.position.set(...p);if(shake){camera.position.x+=Math.sin(currentTime*171)*shake;camera.position.y+=Math.cos(currentTime*137)*shake*.7}camera.fov=fov;camera.lookAt(...target);camera.updateProjectionMatrix();camera.updateMatrixWorld(true)}
  function setHero(t,p=[0,0,0],s=1,rot=-.18,opt={}){hero.visible=true;hero.position.set(...p);hero.scale.setScalar(s);hero.rotation.set(0,rot,0);poseHero(hero,t,opt);hero.updateMatrixWorld(true);return hero;}
  function setEnemy(e,t,p,s=1,rot=0){position(e,p,s,[0,rot,0]);poseEnemy(e,t,.4);return e;}
  function attack(e,u,base,{scale=.75,weapon=0,from=null,id=0,showWeapon=true,showHook=true}={}){
    const mouth=from||local(0,3.57,1.25),p=clamp((u-.6)/.10)**3;const at=[base[0],base[1]+.9*scale,base[2]];
    if(u<.7){position(e,[lerp(base[0],mouth[0],p),lerp(base[1],mouth[1]-.45*scale,p),lerp(base[2],mouth[2],p)],scale*(1-p*.93),[0,.18,(id%2?1:-1)*.58*smooth(u/.4)]);poseEnemy(e,u<0?currentTime:0,u<0?.35:0)}
    if(showWeapon&&u>=0&&u<.2){const w=weapons[weapon];position(w,[at[0],at[1]+2.7*(1-ease(u/.10)),at[2]+.25],1+2.6*bump(u,0,.15),[0,.2,lerp(-.65,.3,ease(u/.12))]);}
    if(showHook&&u>=.4&&u<.73){const ext=ease((u-.4)/.2),x=lerp(lerp(mouth[0],at[0],ext),mouth[0],p),y=lerp(lerp(mouth[1],at[1],ext),mouth[1],p),z=lerp(lerp(mouth[2],at[2],ext),mouth[2],p);chains.add(mouth,[x,y,z],{sag:.5*(1-clamp((u-.6)/.1)),time:currentTime,wave:.13*(1-p),links:25,size:.85});position(weapons[4+id%4],[x,y,z],.85,[0,.2,-.2]);}
    if(u>=0&&u<.48)overlay.push(g=>{const[x,y]=project(at);sparks(g,x,y,u/.48,{color:'#eac3ae',radius:130,n:15,seed:id*19});if(u<.095)star(g,x,y,92*(1-u/.12));});
    if(u>.57&&u<.9)overlay.push(g=>{const[x,y]=project(at);sparks(g,x,y,(u-.57)/.33,{color:'#d92c36',radius:92,n:17,seed:60+id});});
    if(u>.7&&u<1.22)overlay.push(g=>{const[x,y]=project(mouth);const p=(u-.7)/.52;g.save();g.globalAlpha=1-p;label(g,'+1',x+38,y-20-90*p,43,{color:green,outline:4,max:100});g.restore()});
  }
  function burst(at,t,color='#ee6033',strength=1){overlay.push(g=>{const[x,y]=project(at);sparks(g,x,y,t,{color,radius:260*strength,n:40,seed:200});});}
  function orbitWeapons(t,phase=1,{launch=0,amplitude=1}={}){
    const poses=[[-2.45,4.1,-.3],[-1.45,5.8,-.6],[1.55,5.8,-.6],[2.55,4.1,-.3]],kinds=[1,2,3,0];
    poses.forEach((p,i)=>{const w=weapons[kinds[i]],root=local(i<2?-.67:.67,3.22,-.55);let a=Array.isArray(phase)?phase[i]:phase;if(a<=0)return;let y=lerp(11,p[1],back(a));const at=[p[0],y,p[2]];if(launch>0){at[0]=lerp(at[0],-3+i*2,launch);at[1]=lerp(at[1],1.4,launch)+Math.sin(launch*Math.PI)*2;at[2]=lerp(at[2],-5.3,launch)}position(w,at,amplitude,[.12,.22,(i-1.5)*-.13+launch*1.3]);chains.add(root,at,{sag:.45*(1-launch),time:t,links:27,size:.92});});
  }
  function reset(t){currentTime=t;overlay=[];[...warriors,...Object.values(enemies)].forEach(e=>poseEnemy(e,0,0));hero.visible=false;[arena,castle,tower,groundRing,...islands,...warriors,...Object.values(enemies),...weapons].forEach(o=>o.visible=false);saw.visible=true;scene.overrideMaterial=null;scene.background.set('#18192e');scene.fog.color.set('#18192e');scene.fog.near=27;scene.fog.far=70;chains.reset();particles.visible=true;key.intensity=2.7;ambient.intensity=1.7;rim.intensity=1.8;key.target.position.set(0,2,0);key.position.set(-6,9,7);groundRing.material.opacity=.7;}
  function ambientParticles(t,sceneIndex){
    if(!particles.visible)return;for(let i=0;i<64;i++){let x=(rnd(i+9)-.5)*17,y=(rnd(i+99)*12+t*(.3+rnd(i)*.5))%12,z=(rnd(i+44)-.5)*16;particleDummy.position.set(x,y,z);particleDummy.rotation.set(t+i,i,t*.3);particleDummy.scale.setScalar(.5+rnd(i+2));particleDummy.updateMatrix();particles.setMatrixAt(i,particleDummy.matrix)}particles.instanceMatrix.needsUpdate=true;
  }

  function hookShot(u){
    arena.visible=true;setHero(u,[0,0,0],1,-.18,{mode:'chew',chew:bump(u,1.15,.3)+bump(u,1.55,.28),power:.25});
    cam([lerp(.4,.1,ease(u/2.4)),4.3,lerp(4.8,4.45,ease(u/2.4))],[0,3.72,.2],41,(bump(u,.4,.15)+bump(u,1.2,.12))*.055);
    if(u<1.14)attack(warriors[0],u-.4,[.44,4.25,1.15],{scale:.46,from:local(0,3.57,1.25),id:1,showHook:false});
    if(u>=.8&&u<1.2){let p=ease((u-.8)/.25);position(weapons[4],[.15,lerp(4.4,4.6,p),lerp(1.6,3.3,p)],lerp(.9,1.5,p),[.2,.2,-.35]);weapons[4].updateMatrixWorld(true);chains.add(local(0,3.6,1.25),weapons[4].localToWorld(V(-.19,-.4,0)).toArray(),{sag:.2,links:22,time:u});}
    overlay.push(g=>{if(u<.18){g.fillStyle=`rgba(255,238,212,${.13*(1-u/.18)})`;g.fillRect(0,0,540,960)}if(u>=.8){const word=u<1.2?'HOOK.':'CHEW.',a=back((u-(u<1.2?.8:1.2))/.13);g.save();g.translate(240,255);g.scale(a,a);label(g,word,0,0,124,{color:yellow,two:true,angle:-.045,max:410,outline:7});g.restore();}if(u>=.81&&u<1.4)sparks(g,280,365,(u-.81)/.59,{color:'#bb2132',radius:350,n:23,seed:119});if(u>=1.6)label(g,'+1',418,506-(u-1.6)*65,65,{color:green,outline:5,max:120});});
  }
  function growShot(u){
    arena.visible=true;let growth=.67+.12*clamp(Math.floor((u-1.1+.01)/.4)+1,0,4),chew=[1.1,1.5,1.9,2.3].reduce((a,v)=>a+bump(u,v,.22),0);setHero(u,[0,0,1.3],growth*(1+chew*.035),-.30,{mode:u<.65?'attack':'chew',attack:clamp(u/.7),chew,power:clamp(u/2.6)});
    cam([4.7-.5*smooth(u/3.2),6.15,14.0],[0,3.18,.3],40,bump(u,.4,.18)*.1);
    const positions=[[-2.25,0,-.7],[-.90,0,-2.65],[1.0,0,-2.6],[2.35,0,-.65]];
    positions.forEach((p,i)=>attack(warriors[i],u-(.4+i*.4),p,{scale:.86,id:i,showWeapon:i===0}));
    if(u>.35&&u<.9){groundRing.visible=true;groundRing.position.set(0,.08,-.7);groundRing.scale.setScalar(1+5*ease((u-.35)/.55));groundRing.material.opacity=1-clamp((u-.35)/.55);}
    overlay.push(g=>{title(g,'EAT AND GET','STRONGER',u,{size:84});const chips=[['+DMG',95,555],['+SPD',405,540],['+ARMOR',94,684],['+HP',410,690]];chips.forEach(([s,x,y],i)=>{const q=back((u-1.2-i*.4)/.2);if(q>0){g.save();g.translate(x,y);g.scale(q,q);pill(g,s,0,0,{color:green,size:22});g.restore()}});if(u<.24)streaks(g,u,1-u/.24);});
  }
  function underdogShot(u){
    castle.visible=true;const stop=Math.min(u,1.35);setEnemy(enemies.golem,stop,[.7,0,-.8],1.37,-.16);setHero(stop,[-2.1,0,1.7],.35,.32,{mode:'chew',chew:bump(u,2.35,.22)});
    cam([5.3,lerp(3.5,5.0,ease(u/1.35)),17.3],[0,lerp(3.0,4.1,ease(u/1.35)),0],42);
    overlay.push(g=>{title(g,'START AS A','FEEBLE DEMON…',u,{size:63,y:135});pill(g,'LVL 100',405,342,{bg:'#9d3037',size:27});pill(g,'LVL 1',97,698,{size:25});if(u>1.6){let p=(u-1.6)/1.4;g.fillStyle='#9ce8ee';g.beginPath();g.ellipse(139,735+20*p,4,8,0,0,Math.PI*2);g.fill();}});
  }
  function islandsShot(u){
    let marks=[0,.8,1.4,1.9,2.3,3.2],k=marks.findIndex((v,i)=>u>=v&&u<marks[i+1]);if(k<0)k=4;const p=(u-marks[k])/(marks[k+1]-marks[k]);const yy=(1-ease(p/.21))*10;
    const island=islands[k];position(island,[0,yy,0],1.02);const heroScale=.59+k*.075;setHero(u,[-.83,yy+.07,.45],heroScale,-.30,{mode:'chew',chew:bump(p,.78,.18)});
    cam([4.2,6.6,13.8],[0,2.45,0],42,p<.2?(1-p/.2)*.025:0);
    const e=[warriors[0],enemies.icegolem,enemies.bear,enemies.dragon,enemies.zombie][k];attack(e,p*.91-.06,[1.18,yy+.06,-.3],{scale:.64,id:0,weapon:k%2?1:0});
    if(k>0&&p<.17)position(islands[k-1],[0,-ease(p/.17)*14,0],1.02);
    overlay.push(g=>{title(g,'EXPLORE NEW','LANDS',u,{size:93});label(g,['THE WILDS','FROSTFALL','SUGAR RUSH','EMBER ISLES','THE HOLLOW'][k],240,315,25,{outline:3,max:380});pill(g,`LVL ${[9,23,47,71,99][k]}`,211,747,{color:yellow,size:31});for(let i=0;i<5;i++)round(g,168+i*31,810,22,5,2,i===k?yellow:'#545064');});
  }
  function arsenalShot(u){
    arena.visible=true;setHero(u,[0,0,1.3],1.13,Math.PI-.12,{mode:u>=2.2?'attack':'charge',attack:u>=2.2?clamp((u-2.2)/.8):.4,power:.5});saw.visible=false;
    cam([2.1-.5*smooth(u/3.2),5.8,15.7],[0,3.65,-1.6],43,bump(u,2.4,.25)*.12);
    for(let i=0;i<16;i++){const x=(i%4-1.5)*1.55,z=-4.0-Math.floor(i/4)*1.36;setEnemy(warriors[i],u,[x,u>2.45?-ease((u-2.45)/.7)*.3:0,z],.67,(i%3-1)*.12);if(u>=2.45){warriors[i].rotation.z=(i%2?1:-1)*1.40*ease((u-2.45)/.4);warriors[i].position.y=.55;}}
    const arrival=[0,1,2,3].map(i=>clamp((u-.4-i*.4)/.33)),launch=clamp((u-2.25)/.28);orbitWeapons(u,arrival,{launch,amplitude:1.13});
    if(u>=2.45&&u<3.15){burst([0,1.7,-4.5],(u-2.45)/.7,'#ea363d',1.4);groundRing.visible=true;groundRing.position.set(0,.12,-4.8);groundRing.scale.setScalar(2+7*ease((u-2.45)/.7));groundRing.material.opacity=1-(u-2.45)/.7;}
    overlay.push(g=>title(g,'COLLECT EPIC','WEAPONS',u,{size:87}));
  }
  function towerShot(u){
    tower.visible=true;const lift=12*smooth(u/1.85);cam([3.7,3.2+lift,12],[0,2.55+lift,0],42);
    setEnemy(enemies.crab,Math.min(u,1.8),[0,.2,.10],1.35,0);setEnemy(enemies.berserker,Math.min(u,1.8),[0,6.1,.0],1.6,0);setEnemy(enemies.vampire,u,[0,12.4,.05],1.60,0);
    chains.add([-2,4.0,-.3],[-.7,1.6,.3],{sag:.3,links:20,size:1});chains.add([2,10.0,-.3],[.7,7.7,.3],{sag:.3,links:20,size:1});chains.add([-2,16.3,-.3],[-.8,14.4,.3],{sag:.3,links:20,size:1});chains.add([2,16.3,-.3],[.8,14.4,.3],{sag:.3,links:20,size:1});
    for(const [i,x] of [-1.9,1.9].entries())setEnemy(warriors[i],u,[x,12.0,1.0],.65,i?.6:-.6);
    key.position.set(-5,10+lift,7);key.target.position.set(0,2+lift,0);
    overlay.push(g=>{title(g,'CLIMB THE','BOSS TOWER',u,{size:74,y:132});if(u>1.85){let p=ease((u-1.85)/.25);g.save();g.globalAlpha=p;round(g,29,652,421,98,12,'#131323dd','#ad9bad',1.5);label(g,"The ritual isn't for summoning",240,688,26,{max:399,outline:0});label(g,"It's for dinner.",240,726,35,{color:yellow,max:400,outline:0});g.restore()}});
  }
  function dinnerShot(u){
    tower.visible=true;cam([3.7-.9*ease(u/1.6),15.2,12],[0,14.6,0],42,bump(u,.14,.15)*.14);key.position.set(-5,22,7);key.target.position.set(0,14,0);
    if(u<.68){let pull=clamp((u-.54)/.14)**3;position(enemies.vampire,[0,12.4-6*pull,.05],1.6*(1-pull*.75),[0,0,.5*smooth(u/.4)]);}
    for(const [i,x] of [-1.9,1.9].entries())setEnemy(warriors[i],u,[x,12.0,1.0],.65,i?.6:-.6);
    if(u<.4){const p=ease(u/.15);position(weapons[0],[0,lerp(8,14.3,p),.9],1.6,[0,.1,lerp(-.2,.3,p)]);chains.add([0,7,1],[0,lerp(8,14.3,p),.9],{sag:0,links:34,size:1.3});}
    if(u>=.38&&u<.7){const ext=ease((u-.38)/.16),pull=clamp((u-.54)/.15)**3,y=lerp(lerp(8,14,ext),8,pull);position(weapons[4],[0,y,.9],1,[0,0,.1]);chains.add([0,8,1],[0,y,.9],{sag:.25*(1-pull),links:26,size:1.2});}
    burst([0,14,.3],(u-.14)/.65,'#d52635',1.1);
    overlay.push(g=>{if(u>.12&&u<.20){g.fillStyle=`rgba(255,244,217,${.85*(1-(u-.12)/.08)})`;g.fillRect(0,0,540,960)}if(u>.78){const q=back((u-.78)/.16);g.save();g.translate(240,380);g.scale(q,q);label(g,'BOSS',0,0,117,{color:yellow,two:true,max:404,angle:-.035,outline:7});label(g,'DEFEATED!',0,97,87,{color:yellow,two:true,max:416,angle:-.035,outline:6});g.restore();label(g,'+1',246,653-(u-.8)*60,67,{color:green,outline:5,max:120});}if(u>1.30){let q=(u-1.30)/.30,y=960*(1-q);const p=[[0,y],[75,y-19],[136,y+13],[220,y-23],[300,y+12],[410,y-24],[540,y],[540,960],[0,960]];poly(g,p,'#181424');line(g,p.slice(0,7),'#ff741d',12);sparks(g,270,y,.28,{color:yellow,radius:370,n:35})}});
  }
  function rematchShot(u){
    castle.visible=true;const hold=Math.min(u,1.4);setHero(hold,[-.6,0,1.2],1.48,Math.PI-.18,{mode:'charge',attack:clamp(u/1.2),power:1});saw.visible=false;
    setEnemy(enemies.golem,hold,[2.5,0,-1.45],.23,-.25);cam([4.8,4.9,17.3],[0,3.3,0],42);
    const p=ease(u/.9);position(weapons[0],[-1.7,lerp(5,7.7,p),.35],1.85,[.1,.1,-1.0+p*.7]);chains.add(local(-.67,3.3,-.6),weapons[0].position.toArray(),{sag:.2,links:30,size:1.3});
    overlay.push(g=>{pill(g,'LVL',110,189,{size:33});if(u<1.2)label(g,['99','100','999'][Math.min(2,Math.floor(u/.4))],292,221,96,{color:yellow,two:true,outline:6,max:300});else{g.save();g.translate(298,190);g.beginPath();g.moveTo(0,0);g.bezierCurveTo(-22,-40,-66,-34,-66,0);g.bezierCurveTo(-66,39,-22,39,0,0);g.bezierCurveTo(22,-39,66,-39,66,0);g.bezierCurveTo(66,39,22,39,0,0);g.strokeStyle=ink;g.lineWidth=23;g.stroke();g.strokeStyle=yellow;g.lineWidth=12;g.stroke();g.restore()}pill(g,'LVL 100',410,705,{size:24,bg:'#a6343b'});if(u>.8&&u<1.4){const points=[[140,353],[161,390],[145,428],[194,458],[175,487]];line(g,points,ink,9);line(g,points,yellow,4)}});
  }
  function deityShot(u){
    castle.visible=true;const action=Math.min(1,clamp((u-.1)/.85));setHero(u,[-.35,0,.8],1.15,-.28,{mode:u<1.1?'attack':'roar',attack:action,chew:bump(u,.88,.25),intensity:u<1.1?0:.55,power:1});
    cam([3.4-.6*smooth(u/3.2),5.65,14.5],[0,4.1,.0],41,(1-clamp((u-.08)/.55))*.18);
    attack(enemies.golem,u-.17,[2.0,1.45,1.15],{scale:.30,weapon:0,id:0,showWeapon:true});
    if(u>=1.1)orbitWeapons(u,clamp((u-1.1)/.3),{amplitude:.95});
    burst([2.0,2.3,1.15],(u-.1)/1.05,'#ff7823',1.3);
    overlay.push(g=>{if(u<.1){g.fillStyle=u<.067?'#fff5d5':ink;g.fillRect(0,0,540,960);if(u>=.067)poly(g,[[480,230],[98,460],[438,541],[256,465]],'#d83938');}if(u>.56){title(g,'…END AS A','DEITY OF',u-.56,{size:80,y:126});const q=back((u-.76)/.25);if(q>0){g.save();g.translate(0,-100*(1-q));label(g,'DESTRUCTION.',240,286,68,{color:yellow,two:true,angle:-.025,max:414,outline:6});g.restore()}}if(u>3){g.fillStyle=`rgba(255,246,224,${clamp((u-3)/.17)})`;g.fillRect(0,0,540,960)}});
  }
  function brandWord(g,word,y,size,u,at,color,stroke){
    g.font=`900 ${size}px "Londrina Solid"`;const widths=[...word].map(c=>g.measureText(c).width),total=widths.reduce((a,b)=>a+b,0)+2*(word.length-1);let x=245-total/2;
    [...word].forEach((letter,i)=>{let q=back((u-at-i*.045)/.37),yy=lerp(-150,y,q),xx=x+widths[i]/2;if(u>=at+i*.045){screenChain(g,xx,-30,yy-size*.72);g.save();g.font=`900 ${size}px "Londrina Solid"`;g.textAlign='center';g.lineJoin='round';g.lineWidth=15;g.strokeStyle=ink;g.strokeText(letter,xx+3,yy+6);g.fillStyle=ink;g.fillText(letter,xx+3,yy+6);g.lineWidth=8;g.strokeStyle=stroke;g.strokeText(letter,xx,yy);g.fillStyle=color;g.fillText(letter,xx,yy);g.restore()}x+=widths[i]+2;});
  }
  function logoShot(u){
    arena.visible=true;setHero(u,[0,0,0],1,-.18,{mode:'victory',power:.4});cam([4.0,5.6,18],[0,5.6,0],40);
    orbitWeapons(u,.99,{amplitude:.66});
    overlay.push(g=>{brandWord(g,'BUTCHER',369,103,u,0,'#d2e8f8','#cb4770');brandWord(g,'HERO',510,158,u,.4,'#ff83a9','#fff1dc');if(u>.94)label(g,'HOOK. CHEW. REPEAT.',244,573,29,{color:yellow,outline:4,max:400})});
  }
  function pointer(g,x,y,press){g.save();g.translate(x,y+press*9);g.rotate(-.23);g.beginPath();g.moveTo(-8,56);g.lineTo(-20,10);g.bezierCurveTo(-25,-8,-8,-16,-2,2);g.lineTo(6,23);g.lineTo(6,-26);g.bezierCurveTo(6,-43,27,-43,28,-26);g.lineTo(28,5);g.bezierCurveTo(42,-5,49,2,47,14);g.bezierCurveTo(61,8,68,19,64,34);g.bezierCurveTo(78,37,70,65,57,82);g.lineTo(9,82);g.closePath();g.fillStyle='#fff2d2';g.fill();g.strokeStyle=ink;g.lineWidth=5;g.stroke();round(g,5,73,53,24,4,'#d94643',ink,5);g.restore()}
  function ctaShot(u){
    u=Math.min(u,2.25);particles.visible=false;setHero(0,[0,0,0],1,-.24,{mode:'charge',attack:.35});cam([2.9,3.8,9.0],[0,2.65,0],40);scene.overrideMaterial=silhouette;scene.background.set('#f6cd06');scene.fog.color.set('#f6cd06');saw.visible=true;
    position(weapons[4],[1.7,3.8,.4],1.6,[0,.2,-.5]);chains.add(local(-.67,3.3,-.55),[1.7,3.8,.4],{sag:.8,links:28,size:1.3});
    const posterProgress=smooth((u-.17)/.53);
    overlay.push(g=>{
      // The fully rendered 3D silhouette becomes the same square app icon.
      posterCtx.setTransform(1,0,0,1,0,0);posterCtx.drawImage(glCanvas,0,0);posterCtx.setTransform(width/540,0,0,height/960,0,0);const hp=hero.userData.parts.head;hp.updateMatrixWorld(true);for(const sign of [-1,1]){const pts=[[.11,.08],[.46,.17],[.40,.06],[.13,.005]].map(([x,y])=>project(hp.localToWorld(V(sign*x,y,.41))));poly(posterCtx,pts,'#ff342d');}
      g.fillStyle='#172036';g.fillRect(0,0,540,960);const bg=g.createLinearGradient(0,0,0,960);bg.addColorStop(0,'#742335');bg.addColorStop(.55,'#141c31');bg.addColorStop(1,'#0a1120');g.fillStyle=bg;g.fillRect(0,0,540,960);
      const w=lerp(540,225,posterProgress),h=lerp(960,225,posterProgress),x=lerp(0,127.5,posterProgress),y=lerp(0,294,posterProgress);
      g.save();g.beginPath();g.roundRect(x,y,w,h,32*posterProgress);g.clip();g.fillStyle='#f6cd06';g.fillRect(x,y,w,h);const sy=lerp(0,125,posterProgress),sh=lerp(960,540,posterProgress);g.drawImage(poster,0,sy*height/960,width,sh*height/960,x,y,w,h);g.restore();
      if(posterProgress>.8){g.strokeStyle=ink;g.lineWidth=7;g.beginPath();g.roundRect(x,y,w,h,32);g.stroke();label(g,'BUTCHER HERO',242,205,54,{max:415,outline:5});label(g,'BUILT TO DEVOUR.',240,246,27,{max:400,color:yellow,outline:3});}
      if(u>.66){const q=back((u-.66)/.3),press=bump(u,1.5,.19);g.save();g.translate(242,620);g.scale(q,q);round(g,-183,-40+press*6,366,97,20,'#1c6519',ink,6);round(g,-183,-51+press*9,366,94,20,'#5bea32',ink,6);line(g,[[-153,-39],[150,-39]],'#b0fd78',3);label(g,'PLAY FREE',-12,13+press*9,63,{color:'#12271b',outline:0,max:305});poly(g,[[137,-22],[156,-9],[137,5]],'#12271b');g.restore();if(u>=1.0&&u<2.1)pointer(g,363,780-162*ease((u-1.0)/.3),press);if(press>.2)star(g,376,582,24*press,yellow);}
      if(u>1.0){g.save();g.globalAlpha=ease((u-1)/.25);round(g,37,702,195,54,11,'#111727','#847383',1.5);round(g,245,702,197,54,11,'#111727','#847383',1.5);label(g,'App Store',135,724,21,{outline:0,max:174});star(g,113,742,5,yellow);label(g,'4.6',143,748,19,{color:yellow,outline:0,max:60});label(g,'Google Play',343,724,21,{outline:0,max:174});label(g,'1M+',343,748,19,{color:yellow,outline:0,max:80});g.restore();}
    });
  }
  const shots=[hookShot,growShot,underdogShot,islandsShot,arsenalShot,towerShot,dinnerShot,rematchShot,deityShot,logoShot,ctaShot];
  function render(t){
    t=clamp(t,0,DURATION-1/FPS);let k=starts.findIndex((s,i)=>t>=s&&(i===10||t<starts[i+1]));if(k<0)k=10;const u=t-starts[k];reset(t);shots[k](u);chains.finish();ambientParticles(k===10?Math.min(t,28.65):t,k);scene.updateMatrixWorld(true);renderer.render(scene,camera);
    ctx.setTransform(width/540,0,0,height/960,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.drawImage(glCanvas,0,0,540,960);
    if(k!==10){const grad=ctx.createRadialGradient(260,450,270,270,465,620);grad.addColorStop(0,'#080c1600');grad.addColorStop(1,'#080c1655');ctx.fillStyle=grad;ctx.fillRect(0,0,540,960)}
    overlay.forEach(fn=>fn(ctx));if(k>0&&k!==8&&k!==10&&u<.05){ctx.fillStyle=`rgba(255,222,169,${.15*(1-u/.05)})`;ctx.fillRect(0,0,540,960)}ctx.setTransform(1,0,0,1,0,0);
  }
  return {scene,camera,hero,renderer,render,dispose(){renderer.dispose();}};
}
