import * as THREE from 'three';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {mkdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,join} from 'node:path';
import {hostname} from 'node:os';
import {buildHero,poseHero} from './hero.js';
import {makeWeapon} from './weapons.js';

// Node-only exporter: no browser, rasterization, network or extra dependencies.
if(process.platform!=='linux'||hostname()!=='claude-hub-prod'){
  throw new Error('Export only on the authorized Linux render server.');
}
if(typeof globalThis.FileReader==='undefined'){
  globalThis.FileReader=class FileReader {
    result=null;error=null;onload=null;onloadend=null;onerror=null;
    async readAsArrayBuffer(blob){
      try{this.result=await blob.arrayBuffer();this.onload?.({target:this});this.onloadend?.({target:this})}
      catch(error){this.error=error;this.onerror?.({target:this});this.onloadend?.({target:this})}
    }
    async readAsDataURL(blob){
      try{const data=await blob.arrayBuffer();this.result=`data:${blob.type||'application/octet-stream'};base64,${Buffer.from(data).toString('base64')}`;this.onload?.({target:this});this.onloadend?.({target:this})}
      catch(error){this.error=error;this.onerror?.({target:this});this.onloadend?.({target:this})}
    }
  };
}

const root=dirname(fileURLToPath(import.meta.url));
const output=join(root,'output');
await mkdir(output,{recursive:true});
const hero=buildHero();
const parts=hero.userData.parts;
for(const [name,material]of Object.entries(hero.userData.materials))material.name=`Butcher_${name}`;
const saw=makeWeapon('chainsaw');
parts.handSockets[1].add(saw);
saw.name='Legendary chainsaw | held right hand';
saw.position.set(.04,-.02,.42);
saw.rotation.set(.08,0,-.58);
saw.scale.setScalar(.79);
poseHero(hero,0,{mode:'idle'});
hero.updateMatrixWorld(true);

// Runtime pose references point to other Object3Ds; serialization must keep the
// actual node hierarchy and avoid copying those circular references into extras.
let sourceNodes=0,sourceMeshes=0,sourceTriangles=0;
hero.traverse(object=>{
  sourceNodes++;
  object.userData={};
  if(object.isMesh){
    sourceMeshes++;
    const geometry=object.geometry;
    sourceTriangles+=(geometry.index?geometry.index.count:geometry.attributes.position.count)/3;
  }
});
hero.userData={title:'Butcher Hero — Astra 6',source:'Original procedural geometry',axes:'Y up, front +Z',pose:'Idle with held chainsaw',licenseNote:'Source project accompanies the film'};

const binary=await new GLTFExporter().parseAsync(hero,{binary:true,trs:true,onlyVisible:true,includeCustomExtensions:false});
const bytes=Buffer.from(binary);
if(bytes.readUInt32LE(0)!==0x46546c67||bytes.readUInt32LE(4)!==2||bytes.readUInt32LE(8)!==bytes.length){
  throw new Error('Invalid GLB v2 header or declared file length');
}
const jsonLength=bytes.readUInt32LE(12),jsonType=bytes.readUInt32LE(16);
if(jsonType!==0x4e4f534a)throw new Error('First GLB chunk must contain JSON');
const document=JSON.parse(bytes.subarray(20,20+jsonLength).toString('utf8').trim());
if(document.asset?.version!=='2.0'||!document.nodes?.length||!document.meshes?.length){
  throw new Error('Export contains no usable glTF scene');
}
if(document.nodes.length!==sourceNodes)throw new Error(`Lost hierarchy nodes: ${document.nodes.length}/${sourceNodes}`);
const primitives=document.meshes.flatMap(mesh=>mesh.primitives);
const checks={
  glbV2:true,
  allNodesPreserved:document.nodes.length===sourceNodes,
  allMeshesPreserved:document.meshes.length===sourceMeshes,
  vertexColorsPreserved:primitives.some(primitive=>primitive.attributes.COLOR_0!==undefined),
  unlitEyesPreserved:document.extensionsUsed?.includes('KHR_materials_unlit')||false,
  noExternalBuffers:document.buffers?.every(buffer=>buffer.uri===undefined)||false,
  handHierarchyPreserved:document.nodes.some(node=>node.name==='Weapon hand socket'&&node.children?.length),
  noAnimationTracks:!document.animations?.length,
};
if(Object.values(checks).some(value=>!value))throw new Error(`Export checks failed: ${JSON.stringify(checks)}`);
const path=join(output,'butcher-hero-astra6.glb');
await writeFile(path,bytes);
const report={file:path,bytes:bytes.length,nodes:document.nodes.length,meshes:document.meshes.length,materials:document.materials.length,triangles:sourceTriangles,checks};
await writeFile(join(output,'model-export.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
